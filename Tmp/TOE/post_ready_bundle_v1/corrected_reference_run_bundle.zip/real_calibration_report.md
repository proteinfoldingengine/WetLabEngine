# Real Calibration Report
## Restricted Affine Coupling Program

## Status
This report summarizes one completed real-data calibration run of the restricted affine theorem pipeline.

## Anchored constants
       C0       V0  lambda0        a0        b0  sigma_p  sqrt_E_r4
-0.033051 0.072602 0.005796 -0.606057 -0.000001 0.183691   0.119021

## Screened-family calibration
             label  alpha  beta    nu  delta_cov  delta_var  lambda_theta  lambda_drift  eta_nu_theta  M_theta  epsilon_observed  epsilon_bound  bound_minus_abs_epsilon
screened_point_001    0.8  0.90  0.00  -0.000705   0.000085     -0.009219      0.015015      0.012236      0.0         -0.000652       0.005073                 0.004421
screened_point_002    1.0  1.00  0.00   0.000028  -0.000563      0.004912      0.000884      0.009565      0.0         -0.000311       0.003942                 0.003631
screened_point_003    1.2  1.10  0.05   0.000469  -0.000394      0.010406      0.004610      0.013091      0.0          0.000232       0.005424                 0.005192
screened_point_004    1.5  1.20  0.10  -0.000327   0.000465     -0.007008      0.012803      0.009897      0.0         -0.000044       0.004088                 0.004044
screened_point_005    0.9  1.05 -0.05   0.000201   0.000342      0.001257      0.004538      0.011053      0.0          0.000410       0.004566                 0.004156

## Summary
- screened points: **5**
- mean |epsilon|: **0.00032995**
- mean predicted bound: **0.00461877**
- mean bound margin: **0.00428883**
- minimum bound margin: **0.00363073**
- all screened points within bound: **True**

## Read
This report is intended to answer the key calibration question:

> Does the observed remainder stay within the theorem-controlled bound scale on the real screened family?

If the answer is yes, this run qualifies as a real-data calibrated restricted theorem pass.

