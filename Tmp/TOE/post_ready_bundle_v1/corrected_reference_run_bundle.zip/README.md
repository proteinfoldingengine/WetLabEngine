# Corrected Reference Run Bundle

This bundle freezes the exact reference run that the next source-export calibration should be compared against.

Contents:
- corrected_reference_run.md
- real_calibration_report.md
- real_calibration_run_summary.csv
- anchor_constants.csv
- screened_family_calibration.csv
- user_payload_curvature_completion_bundle.zip
