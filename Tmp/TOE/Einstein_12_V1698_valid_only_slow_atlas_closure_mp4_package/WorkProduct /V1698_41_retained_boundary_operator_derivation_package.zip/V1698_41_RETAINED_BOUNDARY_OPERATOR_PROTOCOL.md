# V1698.41 — Retained Boundary Operator Derivation

**Verdict:** `RETAINED_BOUNDARY_OPERATOR_PROTOCOL_DERIVED_NO_EXECUTION`

## Why this branch exists

V1698.40 produced a mixed closure audit.

The adjoint-current object still separated valid from nulls strongly, and the closed-domain boundary term was suppressed.

But open-domain closure failed:

```text
open source-boundary adjoint was not measurable
```

Root cause:

```text
boundary was only a node flag
```

That is not enough for a variational boundary term.

---

## Correct object

The missing object is:

```text
∂R
```

a retained boundary operator.

It maps retained atlas objects to exposed boundary sectors:

```text
∂R0:
  nodes / retained pairs -> boundary node sectors

∂R1:
  directed transition edges -> boundary edge sectors

∂R2_path:
  path-composition objects -> boundary path sectors

∂R2_cycle:
  cycle / holonomy objects -> boundary cycle sectors
```

---

## Edge boundary

For a directed edge:

```text
e = p -> q
```

the signed retained boundary is:

```text
∂R1(e) = b_q − b_p
```

where `b_p` marks whether the retained object is exposed to the boundary sector.

This is not just a node penalty. It is an oriented boundary map.

---

## Path boundary

For a two-step path:

```text
p -> q -> r
```

the path boundary is:

```text
∂R2_path
=
∂R1(q->r)
+
∂R1(p->q)
−
∂R1(p->r_ref)
```

So path-composition defects contribute only through their actual retained boundary exposure.

---

## Cycle boundary

For a cycle:

```text
C
```

the boundary is:

```text
∂R2_cycle(C)
=
Σ_e∈C orientation(e,C) ∂R1(e)
```

Closed interior cycles have zero retained boundary. Exposed/open cycles have signed boundary sectors.

---

## Corrected variational identity

```text
δA_R[η]
=
Interior_R(η)
+
Boundary_∂R(η)
```

Closed retained domain:

```text
∂R = 0
Boundary_∂R(η) = 0
```

Open retained domain:

```text
Boundary_∂R(η)
=
Measured_Retained_Boundary_Current(η)
```

Closure residual:

```text
C_∂R(η)
=
Boundary_∂R(η)
−
Measured_Retained_Boundary_Current(η)
```

---

## Boundary currents

```text
J_∂R:
  transition boundary current

S_∂R:
  source/provenance boundary current

A_∂R:
  atlas path/cycle boundary current
```

Total:

```text
B_R(η)
=
J_∂R(η)
+
S_∂R(η)
+
A_∂R(η)
```

---

## Next branch

```text
V1698.42 — Retained Boundary Operator Closure Test
```

Required:

```text
construct ∂R0, ∂R1, ∂R2_path, ∂R2_cycle
compute boundary current B_R(η)
test closed-domain suppression
test open-domain measured boundary matching
test source/order/support/edge/cycle nulls
no fitted coefficients
```

## Safe claim

V1698.40 failed open-boundary closure because boundary was represented as a node flag. The correct object is a retained boundary operator ∂R mapping nodes, edges, paths, and cycles to exposed boundary sectors.
