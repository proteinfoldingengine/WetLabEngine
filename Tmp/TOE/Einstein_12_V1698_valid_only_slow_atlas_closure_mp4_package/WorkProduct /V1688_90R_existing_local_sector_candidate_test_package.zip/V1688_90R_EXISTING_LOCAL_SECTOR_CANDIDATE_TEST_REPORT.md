# V1688.90R — Existing Local-Sector Candidate Hardened Test

**Verdict:** `POSITIVE_HARDENED_SIGNAL_IN_EXISTING_LOCAL_SECTOR_CANDIDATE`

This run uses the existing V1688.52 local-sector harness logic found in File Library. That source emits source-flow fields, C_corr, provenance edges, graph cycles, cycle defects, correction loss, and weak_target, which is closer to the missing local-sector engine than the dashboard-only V1687 script.

## Result

```json
{
  "version": "V1688.90R",
  "verdict": "EXISTING_LOCAL_SECTOR_CANDIDATE_EXECUTED",
  "node_count": 4992,
  "edge_count": 19008,
  "cycle_count": 4524,
  "cycle_node_map_rows": 18096,
  "r2_M0": 0.004816167078976585,
  "r2_Ccorr": 0.09627401304888306,
  "r2_topology_control": 0.09930413010614025,
  "r2_H_resid": 0.11992176201998517,
  "r2_full_hardened": 0.12010849542963986,
  "unique_full_over_topology": 0.020804365323499607,
  "null_max": 0.0014138253659677913,
  "observed_minus_null_max": 0.019390539957531816,
  "runtime_seconds": 2.9666521549224854,
  "source_note": "Recovered/optimized execution of existing V1688.52 local-sector harness logic found in File Library; finite toy/local-sector candidate, not external empirical validation.",
  "claim_boundary": "No GR/Einstein/Riemann/physical-spacetime claim.",
  "signal_verdict": "POSITIVE_HARDENED_SIGNAL_IN_EXISTING_LOCAL_SECTOR_CANDIDATE"
}
```

## Boundary

This is a finite toy/local-sector candidate, not external empirical validation and not a GR/Einstein/physical-curvature result.
