# V1698.67 - Signed Boundary Pairing Clean-Room Exactness Repair

**Verdict:** `SIGNED_BOUNDARY_REPAIR_NO_IMPROVEMENT_DRIFT_REMAINS`

## Repair rule

```text
No thresholds changed.
No nulls changed.
No gate weakened.
Only signed_boundary_residual implementation changed.
```

## Old clean-room result

```json
{
  "verdict": "REPLICATION_FAIL_NO_LAW_CLAIM",
  "pass_rate": 0.3333333333333333,
  "open_pass_rate": 0.0,
  "closed_filled_pass_rate": 0.6666666666666666
}
```

## Repaired clean-room result

```json
{
  "contract_hash": "45a923ea0421a1a3",
  "verdict": "REPLICATION_FAIL_NO_LAW_CLAIM",
  "pass_rate": 0.3333333333333333,
  "open_pass_rate": 0.0,
  "closed_filled_pass_rate": 0.6666666666666666,
  "check_count": 30,
  "checks": [
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "baseline",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "node_relabel",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "orientation_reversal",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "basis_transform",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "baseline",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "node_relabel",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "orientation_reversal",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "basis_transform",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "baseline",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "node_relabel",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "orientation_reversal",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "basis_transform",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    }
  ]
}
```

## Interpretation

This branch replaces the V1698.64 signed-boundary proxy with a frozen-style signed boundary-pairing operator:

```text
C_signed(eta) = deltaA_R(eta) - <B_boundary, gamma_dR eta>
```

The patched harness was then executed as a separate process.

## Next

```text
V1698.68 - Curvature Bianchi Clean-Room Drift Repair
```
