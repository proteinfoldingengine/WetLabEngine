# V1690.11 — All-Boundary Mixed Result Postmortem

**Verdict:** `STRESS_SIGNAL_STABLE_NULL_SEPARATION_MIXED_NO_LAW_CLAIM`

## Why this postmortem is needed

V1690.10 fixed the earlier weak `2x4` single-boundary issue by using:

```text
all adjacent loop pairs
full boundary support for Q_A
boundary-shuffle null
generator-component shuffle null
graph-level median reporting
```

But the all-boundary result was mixed.

## V1690.10 core numbers

```json
{
  "graph_case_count": 15,
  "boundary_case_count": 35,
  "sizes_tested": [
    "2x3",
    "2x4",
    "3x3"
  ],
  "seed_count_per_size": 5,
  "stationary_pass_rate_mean": 1.0,
  "faith_edge_rate_mean": 1.0,
  "graph_advantage_median_mean": 0.017986995603511136,
  "graph_advantage_median_min": -0.3026132157845995,
  "graph_advantage_positive_rate_mean": 0.7666666666666667,
  "boundary_valid_beats_null_rate": 0.7142857142857143,
  "boundary_stress_improves_source_rate": 1.0,
  "boundary_E_stress_mean": 0.5288014131006997,
  "boundary_null_E_mean": 0.5406971502912647
}
```

## What is supported

```text
stationary solver is stable
faithfulness gates are stable
Q_A stress balancing consistently improves E_source
all-boundary coverage repaired the earlier 2x4 weakness
```

The strongest supported statement is:

```text
stationary A_pq + Q_A produces a stable stress-improvement diagnostic
```

## What is not supported

```text
uniform law closure
uniform valid-vs-null separation
source-balanced closure
source-free closure
a sufficient null suite
```

## Root cause

The issue is not stationarity anymore.

The issue is falsification sharpness.

The current nulls are not consistently separated from the valid pipeline across all boundary geometries.

In plain terms:

```text
Q_A helps the valid pipeline,
but the current nulls can sometimes stay too close.
```

That means the aggregate endomorphism residual is still too compressed.

## Scientific status ladder

```text
Level 0 schema: passed
Level 1 stationarity: passed in these audits
Level 2 stress-balanced compatibility: diagnostic only; mixed null separation
Level 3 source-balanced compatibility: not established
Level 4 source-free compatibility: not established
```

## Frozen stop rule

Do not tune `A_pq`.

Do not tune `Q_A`.

Do not add cosmetic null thresholds.

The next step must strengthen falsification and component-resolved comparison.

## Required next corrections

```text
1. report component-resolved residuals:
   B, product, O3, H4, S, Pi

2. add component-preserving but cross-component-breaking nulls

3. add commutator-flatten null:
   preserve A norms but force loop generators to commute

4. add boundary-current relabel null:
   preserve event magnitudes but relabel source/order boundary assignments

5. require valid advantage over null in component-resolved residuals

6. require median and worst-quartile stability by graph size
```

## Next branch

```text
V1690.12 — Component-Resolved Compatibility and Stronger Null Suite
```

## Safe claim

V1690 has progressed from object definition to stationary solver and stress-balanced diagnostics.

The stable part is:

```text
stress improvement under stationary A
```

The unresolved part is:

```text
null separation strong enough for law closure
```
