# V1698.50 - Closed-Domain Interior Stationarity Audit

**Verdict:** `CLOSED_DOMAIN_INTERIOR_STATIONARITY_AUDIT_MIXED_NO_LAW_CLAIM`

## Audit target

In closed-filled domains:

```text
B_boundary = 0
C_signed = deltaA_R
```

So remaining failures are interior stationarity failures.

## Component split

```text
deltaA_R =
delta L_edge
+
delta L_R2
+
delta L_R3
+
delta L_source_edge
```

## Summary

```json
{
  "version": "V1698.50",
  "verdict": "CLOSED_DOMAIN_INTERIOR_STATIONARITY_AUDIT_MIXED_NO_LAW_CLAIM",
  "purpose": "Isolate closed-filled signed closure hardening failures by decomposing interior stationarity into edge, R2, R3, and source components.",
  "row_count": 450,
  "check_count": 15,
  "pass_rate": 0.6,
  "mean_lower_than_null_rate": 0.9466666666666667,
  "min_best_null_to_valid_ratio": 0.8125685353265801,
  "dominant_component_counts": {
    "R2": 14,
    "R3": 1
  },
  "valid_component_mean_shares": {
    "edge_share": 0.0,
    "R2_share": 8.494105939037079,
    "R3_share": 4.6042833095288875,
    "source_share": 3.8796861168958103
  },
  "failure_count": 6,
  "claim_boundary": "Interior stationarity diagnostic only. No final law closure.",
  "runtime_seconds": 13.500593900680542
}
```
