# V1698.48 - Signed Boundary Pairing Closure Test

**Verdict:** `SIGNED_BOUNDARY_PAIRING_CLOSURE_PASS_NO_LAW_CLAIM`

## Tested object

```text
C_signed(eta) = deltaA_R(eta) - <B_boundary, gamma_dR eta>_dR
```

## Summary

```json
{
  "version": "V1698.48",
  "verdict": "SIGNED_BOUNDARY_PAIRING_CLOSURE_PASS_NO_LAW_CLAIM",
  "purpose": "Execute signed boundary pairing closure residual C_signed = deltaA_R - <B_boundary,gamma_dR eta>.",
  "checks": [
    {
      "domain": "open",
      "valid_mean_abs_C_signed": 0.39608930599004694,
      "residual_lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 6.038858069944527,
      "valid_mean_boundary_pairing": -0.005562513700588274,
      "structural_pass": true
    },
    {
      "domain": "closed_filled",
      "valid_mean_abs_C_signed": 0.3559323159168006,
      "residual_lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 5.69008267529821,
      "valid_mean_boundary_pairing": 0.0,
      "structural_pass": true
    }
  ],
  "structural_pass_rate": 1.0,
  "mean_residual_lower_than_null_rate": 1.0,
  "min_best_null_to_valid_ratio": 5.69008267529821,
  "open_check": {
    "domain": "open",
    "valid_mean_abs_C_signed": 0.39608930599004694,
    "residual_lower_than_null_rate": 1.0,
    "best_null_to_valid_ratio": 6.038858069944527,
    "valid_mean_boundary_pairing": -0.005562513700588274,
    "structural_pass": true
  },
  "closed_check": {
    "domain": "closed_filled",
    "valid_mean_abs_C_signed": 0.3559323159168006,
    "residual_lower_than_null_rate": 1.0,
    "best_null_to_valid_ratio": 5.69008267529821,
    "valid_mean_boundary_pairing": 0.0,
    "structural_pass": true
  },
  "claim_boundary": "Signed boundary pairing closure test only. No final law closure.",
  "runtime_seconds": 10.14584231376648
}
```
