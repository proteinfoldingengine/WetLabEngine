
#!/usr/bin/env python3
from pathlib import Path
import argparse, json, csv, hashlib, math, shutil, sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyArrowPatch
from matplotlib.animation import FuncAnimation, PillowWriter

MODES=["valid","node_order_shuffle","source_shuffle","support_shuffle","transition_shuffle","cocycle_break"]
DIM=3
EPS=1e-8

def h(*x,n=12):
    return hashlib.sha256("|".join(map(str,x)).encode()).hexdigest()[:n]

def mat_s(M): return json.dumps(np.round(np.asarray(M,float),10).tolist())
def parse_mat(s): return np.array(json.loads(s),float)
def norm(M): return float(np.linalg.norm(np.asarray(M,float)))

def write_csv(path, rows, cols):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for r in rows: w.writerow({c:r.get(c,"") for c in cols})

def basis(i):
    a=.22*i; c=math.cos(a); s=math.sin(a)
    R=np.array([[c,-s,0],[s,c,0],[0,0,1.0]])
    S=np.diag([1+.04*i,1+.025*i,1+.012*i])
    Sh=np.eye(3); Sh[0,1]=.02*i
    return R@S@Sh

def emit_valid(n=5):
    B={i:basis(i) for i in range(n)}
    charts=[]; trans=[]; overlaps=[]
    for i,M in B.items():
        charts.append(dict(chart_id=f"U{i}",ordered_index=i,source_value=float(i%2),
            support_signature=h("support",i),retained_order_signature=h("order",i),
            basis_matrix=mat_s(M),chart_signature=h("chart",i,mat_s(M))))
    for i in range(n):
        for j in range(n):
            if i==j: continue
            T=np.linalg.inv(B[j])@B[i]
            overlaps.append(dict(overlap_id=f"U{i}_cap_U{j}",from_chart=f"U{i}",to_chart=f"U{j}",
                nonempty="true",overlap_signature=h("overlap",i,j)))
            trans.append(dict(transition_id=f"T_U{i}_U{j}",from_chart=f"U{i}",to_chart=f"U{j}",
                matrix=mat_s(T),transition_signature=h("T",i,j,mat_s(T))))
    return {"charts":charts,"overlaps":overlaps,"transitions":trans}

def apply_null(tables,mode):
    import copy
    t=copy.deepcopy(tables)
    if mode=="valid": return t
    charts=t["charts"]; trans=t["transitions"]
    if mode=="node_order_shuffle":
        vals=[c["retained_order_signature"] for c in charts][1:]+[charts[0]["retained_order_signature"]]
        for c,v in zip(charts,vals): c["retained_order_signature"]=v
    elif mode=="source_shuffle":
        vals=[c["source_value"] for c in charts][1:]+[charts[0]["source_value"]]
        for c,v in zip(charts,vals): c["source_value"]=v
    elif mode=="support_shuffle":
        vals=[c["support_signature"] for c in charts][1:]+[charts[0]["support_signature"]]
        for c,v in zip(charts,vals): c["support_signature"]=v
    elif mode=="transition_shuffle":
        mats=[r["matrix"] for r in trans][4:]+[r["matrix"] for r in trans][:4]
        for r,m in zip(trans,mats): r["matrix"]=m; r["transition_signature"]=h("shuffle",r["transition_id"],m)
    elif mode=="cocycle_break":
        for r in trans:
            if r["from_chart"]=="U0" and r["to_chart"]=="U1":
                M=parse_mat(r["matrix"]); M[0,0]+=.08; r["matrix"]=mat_s(M); r["transition_signature"]=h("break",r["matrix"]); break
    return t

def lookup(trans):
    return {(r["from_chart"],r["to_chart"]):parse_mat(r["matrix"]) for r in trans}

def admiss(t,ref):
    R={c["chart_id"]:c for c in ref["charts"]}; mism=[]
    for c in t["charts"]:
        rc=R[c["chart_id"]]
        for fld in ["source_value","support_signature","retained_order_signature"]:
            if str(c[fld])!=str(rc[fld]): mism.append({"chart_id":c["chart_id"],"field":fld})
    return {"admissible":len(mism)==0,"mismatch_count":len(mism),"mismatches":mism}

def coverage(t):
    C={c["chart_id"] for c in t["charts"]}
    O={(o["from_chart"],o["to_chart"]) for o in t["overlaps"] if o["nonempty"]=="true"}
    T={(r["from_chart"],r["to_chart"]) for r in t["transitions"]}
    R={(a,b) for a in C for b in C if a!=b}
    return {"overlap_coverage":len(O&R)/len(R),"transition_coverage":len(T&R)/len(R),"coverage_pass":R.issubset(O) and R.issubset(T)}

def inv_rows(t):
    T=lookup(t["transitions"]); out=[]
    for (a,b),Tab in T.items():
        if (b,a) not in T: res=float("inf")
        else: res=norm(T[(b,a)]@Tab-np.eye(DIM))
        out.append({"pair":f"{a}<->{b}","inverse_residual":res,"passed":res<=EPS})
    return out

def coc_rows(t):
    C=[c["chart_id"] for c in t["charts"]]; T=lookup(t["transitions"]); out=[]
    for a in C:
      for b in C:
        for c in C:
          if len({a,b,c})<3: continue
          if (a,b) in T and (b,c) in T and (c,a) in T:
            res=norm(T[(c,a)]@T[(b,c)]@T[(a,b)]-np.eye(DIM))
            out.append({"triple":f"{a}->{b}->{c}->{a}","cocycle_residual":res,"passed":res<=EPS})
    return out

def hol_rows(t):
    T=lookup(t["transitions"])
    loops=[["U0","U1","U2","U0"],["U0","U2","U3","U0"],["U1","U3","U4","U1"],["U0","U1","U3","U4","U0"]]
    out=[]
    for loop in loops:
        H=np.eye(DIM); ok=True
        for p,q in zip(loop[:-1],loop[1:]):
            if (p,q) not in T: ok=False; break
            H=T[(p,q)]@H
        res=norm(H-np.eye(DIM)) if ok else float("inf")
        out.append({"loop":"->".join(loop),"holonomy_residual":res,"passed":res<=EPS})
    return out

def evaluate(mode,t,ref):
    cov=coverage(t); ad=admiss(t,ref); inv=inv_rows(t); coc=coc_rows(t); hol=hol_rows(t)
    ir=sum(r["passed"] for r in inv)/len(inv); cr=sum(r["passed"] for r in coc)/len(coc); hr=sum(r["passed"] for r in hol)/len(hol)
    closed=cov["coverage_pass"] and ad["admissible"] and ir==1 and cr==1 and hr==1
    return dict(mode=mode,coverage=cov,retained_admissibility=ad,inverse_pass_rate=ir,cocycle_pass_rate=cr,holonomy_pass_rate=hr,
                max_inverse_residual=max(r["inverse_residual"] for r in inv),max_cocycle_residual=max(r["cocycle_residual"] for r in coc),
                max_holonomy_residual=max(r["holonomy_residual"] for r in hol),global_atlas_closed=closed,
                inverse_rows=inv,cocycle_rows=coc,holonomy_rows=hol)

def positions(n=5):
    th=np.linspace(0,2*np.pi,n,endpoint=False)+np.pi/2
    return {f"U{i}":np.array([np.cos(th[i]),np.sin(th[i])]) for i in range(n)}

def draw(ax,r,pos):
    ax.set_aspect("equal"); ax.set_xlim(-1.6,1.6); ax.set_ylim(-1.6,1.6); ax.axis("off")
    ring=["U0","U1","U2","U3","U4","U0"]
    for a,b in zip(ring[:-1],ring[1:]):
        ax.add_patch(FancyArrowPatch(pos[a],pos[b],arrowstyle="-|>",mutation_scale=13,linewidth=1.7,alpha=.7))
    for name,p in pos.items():
        ax.add_patch(Circle(p,.23,fill=True,alpha=.18))
        ax.text(p[0],p[1],name,ha="center",va="center",fontsize=11,weight="bold")
    c="green" if r["global_atlas_closed"] else "red"
    ax.text(0,.2,"GLOBAL\nRETAINED\nATLAS",ha="center",va="center",fontsize=11,weight="bold")
    ax.text(0,-.28,"CLOSED" if r["global_atlas_closed"] else "REJECTED",ha="center",va="center",fontsize=16,weight="bold",color=c)
    txt=f"mode: {r['mode']}\nadmissible: {r['retained_admissibility']['admissible']}\ninv: {r['inverse_pass_rate']:.2f}\ncocycle: {r['cocycle_pass_rate']:.2f}\nholonomy: {r['holonomy_pass_rate']:.2f}"
    ax.text(-1.52,-1.45,txt,ha="left",va="bottom",fontsize=8,bbox=dict(boxstyle="round",alpha=.15))

def visuals(outdir,results):
    pos=positions()
    fig=plt.figure(figsize=(14,8))
    fig.suptitle("V1698 Global Retained-Atlas Closure — Visual Proof",fontsize=16,weight="bold")
    for i,r in enumerate(results):
        ax=fig.add_subplot(2,3,i+1); draw(ax,r,pos); ax.set_title(r["mode"],fontsize=10)
    fig.text(.5,.02,"Valid atlas closes. Retained-breaking nulls fail. Closure = coverage + inverse + cocycle + holonomy + retained admissibility.",ha="center",fontsize=10)
    fig.tight_layout(rect=[0,.04,1,.94])
    static=outdir/"global_atlas_closure_visual_proof_static.png"; fig.savefig(static,dpi=180); plt.close(fig)

    fig,ax=plt.subplots(figsize=(7,7))
    fig.suptitle("Global Retained-Atlas Closure Simulation",fontsize=14,weight="bold")
    def update(i):
        ax.clear(); r=results[i%len(results)]; draw(ax,r,pos); ax.set_title("valid closes" if r["global_atlas_closed"] else f"{r['mode']} rejected")
    anim=FuncAnimation(fig,update,frames=len(results),interval=1300,repeat=True)
    gif=outdir/"global_atlas_closure_visual_proof_animation.gif"; anim.save(gif,writer=PillowWriter(fps=1)); plt.close(fig)
    return static,gif

def run(outdir):
    if outdir.exists(): shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    ref=emit_valid(5); results=[]
    for mode in MODES:
        t=apply_null(ref,mode); r=evaluate(mode,t,ref); results.append(r)
        write_csv(outdir/f"{mode}_inverse_residuals.csv",r["inverse_rows"],["pair","inverse_residual","passed"])
        write_csv(outdir/f"{mode}_cocycle_residuals.csv",r["cocycle_rows"],["triple","cocycle_residual","passed"])
        write_csv(outdir/f"{mode}_holonomy_residuals.csv",r["holonomy_rows"],["loop","holonomy_residual","passed"])
    summary=[{k:r[k] for k in ["mode","inverse_pass_rate","cocycle_pass_rate","holonomy_pass_rate","max_inverse_residual","max_cocycle_residual","max_holonomy_residual","global_atlas_closed"]} |
             {"retained_admissible":r["retained_admissibility"]["admissible"],"admissibility_mismatch_count":r["retained_admissibility"]["mismatch_count"]} for r in results]
    write_csv(outdir/"global_atlas_closure_visual_summary.csv",summary,["mode","retained_admissible","admissibility_mismatch_count","inverse_pass_rate","cocycle_pass_rate","holonomy_pass_rate","max_inverse_residual","max_cocycle_residual","max_holonomy_residual","global_atlas_closed"])
    static,gif=visuals(outdir,results)
    valid_closed=next(r for r in results if r["mode"]=="valid")["global_atlas_closed"]
    nulls_fail=all(not r["global_atlas_closed"] for r in results if r["mode"]!="valid")
    proof={"version":"V1698_GLOBAL_ATLAS_CLOSURE_VISUAL_PROOF","verdict":"GLOBAL_ATLAS_CLOSURE_VISUAL_PROOF_PASS" if valid_closed and nulls_fail else "GLOBAL_ATLAS_CLOSURE_VISUAL_PROOF_FAIL",
           "construction":"T_ij = B_j^-1 B_i","findings":{"valid_atlas_closes":valid_closed,"all_nulls_fail":nulls_fail,"null_modes":[m for m in MODES if m!="valid"]},
           "rules":["coverage","pairwise transitions","inverse consistency","triple-overlap cocycle closure","retained-loop holonomy closure","source/support/retained-order admissibility","null rejection"],
           "visuals":{"static_png":str(static),"animation_gif":str(gif)}}
    (outdir/"global_atlas_closure_visual_proof_summary.json").write_text(json.dumps(proof,indent=2))
    (outdir/"global_atlas_closure_visual_proof_report.md").write_text(f"""# V1698 Global Retained-Atlas Closure Visual Proof

**Verdict:** `{proof['verdict']}`

## Construction

```text
T_ij = B_j^-1 B_i
```

The valid atlas closes because:

```text
T_ki T_jk T_ij = I
```

and retained loops return identity holonomy.

## Findings

```json
{json.dumps(proof['findings'], indent=2)}
```

## Rules proved visually

```text
coverage
pairwise transitions
inverse consistency
triple-overlap cocycle closure
retained-loop holonomy closure
source/support/retained-order admissibility
null rejection
```

## Boundary

Executable visual proof of retained global atlas closure.
Not a continuum physical spacetime claim.
""")
    return proof

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--outdir",default="global_atlas_closure_visual_proof_run"); args=ap.parse_args()
    proof=run(Path(args.outdir))
    print(json.dumps({"verdict":proof["verdict"],"findings":proof["findings"],"static_png":proof["visuals"]["static_png"],"animation_gif":proof["visuals"]["animation_gif"]},indent=2))
    return 0 if proof["verdict"].endswith("_PASS") else 2
if __name__=="__main__": sys.exit(main())
