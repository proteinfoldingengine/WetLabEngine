#!/usr/bin/env python3
"""
V1698.69 Full-Stack Clean-Room Ledger Validator Scaffold
Rejects proxy clean-room runs that lack required full-stack retained ledger tables.
"""
from pathlib import Path
import json, csv, sys

REQUIRED = {
  "run_manifest": ["run_id","contract_hash","emitter_version","seed","domain","size_label","transform","mode","null_family","created_order_index"],
  "C0_nodes": ["node_id","ordered_index","source_value","support_vector","retained_order_vector","generated_algebra_signature","local_signature_SigOD","parent_event_ids"],
  "C1_edges": ["edge_id","p","q","T_pq","A_pq","source_delta","support_delta","order_delta","edge_package_signature","parent_event_ids","boundary_exposure","orientation"],
  "Gamma_R_connection": ["edge_id","from_algebra","to_algebra","transition_matrix","generator_map","faithfulness_defect","connection_signature"],
  "R2_path_faces": ["face_id","p","q","r","edge_pq","edge_qr","reference_pr","F2_matrix","F2_projection_signature","path_reference_mode","face_orientation"],
  "R3_cycle_faces": ["cycle_id","ordered_edge_ids","cycle_nodes","holonomy_matrix","F3_matrix","F3_projection_signature","cycle_orientation"],
  "W1_edge_witnesses": ["W1_id","edge_id","p","q","source_delta","support_delta","order_delta","generator_image_hash","ordered_index_span","parent_event_ids","W1_signature"],
  "W2_face_witnesses": ["W2_id","face_id","ordered_edge_sequence","edge_witness_ids","source_assignment","support_assignment","order_assignment","path_reference_id","fill_signature","fill2"],
  "W3_cell_witnesses": ["W3_id","cell_id","face_witness_ids","boundary_orientation","cell_source_current_JR","order_consistency_signature","support_consistency_signature","filling_signature","fill3"],
  "J_R_source_current": ["cell_id","JR_value","JR_matrix_or_component","source_free_flag","provenance_obstruction_signature"],
  "boundary_operator": ["object_id","object_dim","boundary_ids","orientation_signs","boundary_exposure","gamma_dR_component","B_boundary_component"],
  "signed_boundary_pairing": ["case_id","variation","deltaA_R","boundary_pairing","C_signed","C_signed_abs","domain"],
  "W3_bianchi_residuals": ["cell_id","W3_id","Alt_D_F2","F3_cell","JR","B_R_matrix","B_R_norm","projection_signature"],
  "null_transform_log": ["mode","null_family","changed_tables","preserved_tables","expected_failure_channel","null_signature"],
  "gate_checks": ["domain","size_label","transform","mode_group","valid_W3_count","signed_residual_lower_than_null_rate","filling_null_W3_corrupt_rate","curvature_null_B_corrupt_rate","passed"]
}

def cols(path):
    with open(path, newline="") as f:
        return next(csv.reader(f))

def main(root):
    root = Path(root)
    failures = []
    for table, required in REQUIRED.items():
        path = root / f"{table}.csv"
        if not path.exists():
            failures.append({"table": table, "failure": "missing_table"})
            continue
        have = set(cols(path))
        missing = [c for c in required if c not in have]
        if missing:
            failures.append({"table": table, "failure": "missing_columns", "missing": missing})
    verdict = "FULL_STACK_LEDGER_VALIDATION_PASS" if not failures else "FULL_STACK_LEDGER_VALIDATION_FAIL"
    out = {"verdict": verdict, "failure_count": len(failures), "failures": failures}
    print(json.dumps(out, indent=2))
    return 0 if not failures else 2

if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
