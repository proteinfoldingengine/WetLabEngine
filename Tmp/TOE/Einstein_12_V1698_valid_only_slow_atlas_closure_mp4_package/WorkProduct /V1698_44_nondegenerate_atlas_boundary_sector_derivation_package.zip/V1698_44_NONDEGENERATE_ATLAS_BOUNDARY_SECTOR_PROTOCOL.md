# V1698.44 - Nondegenerate Atlas Boundary Sector Derivation

**Verdict:** `NONDEGENERATE_ATLAS_BOUNDARY_SECTOR_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

V1698.43 exposed a real degeneracy:

```text
A_boundary = 0
path_boundary_count = 0
cycle_boundary_count = 0
```

The retained boundary operator worked for edge/source boundary sectors, but the atlas boundary sector was inactive.

## Root cause

The old path/cycle boundary was inherited only from signed endpoint node flags:

```text
dR2_path = dR1(p->q) + dR1(q->r) - dR1(p->r_ref)
```

```text
dR2_cycle = sum_e orientation(e,C) dR1(e)
```

That can cancel even when an atlas object is boundary-exposed.

The missing idea is:

```text
atlas boundary exposure is not only endpoint exposure
```

It also occurs when a path or cycle cannot be extended to a retained admissible higher object inside the domain.

## Corrected principle

Atlas boundary exposure is nonzero when:

```text
a path-composition object lacks an admissible retained reference
```

or:

```text
a cycle holonomy defect lacks an admissible retained filling
```

This is not a fitted weight. It is an admissibility / extension condition.

## Nondegenerate path boundary

```text
dR2_path_star(p,q,r)
=
endpoint_exposure
+
reference_exposure
+
provenance_exposure
```

where:

```text
endpoint_exposure =
|b_q-b_p| + |b_r-b_q| + |b_r-b_p|
```

```text
reference_exposure =
1 if p->r_ref is missing or externally supported
0 otherwise
```

```text
provenance_exposure =
1 if support/order path current cannot be represented by retained p->r reference
0 otherwise
```

## Nondegenerate cycle boundary

```text
dR2_cycle_star(C)
=
endpoint_exposure(C)
+
filling_exposure(C)
+
holonomy_exposure(C)
```

where:

```text
endpoint_exposure(C) =
sum_e in C |dR1(e)|
```

```text
filling_exposure(C) =
1 if the cycle has no retained admissible interior filling object
0 otherwise
```

```text
holonomy_exposure(C) =
1 if cycle holonomy defect is nonzero and cannot be assigned to an interior retained 2-cell
0 otherwise
```

## Corrected atlas boundary current

```text
A_boundary_star
=
sum_path |R2(path)| dR2_path_star(path)
+
sum_cycle |R3(C)| dR2_cycle_star(C)
```

This measures unfillable path/cycle compatibility defects at retained boundary sectors.

## Next branch

```text
V1698.45 - Nondegenerate Atlas Boundary Sector Test
```

Required:

```text
replace degenerate dR2_path/dR2_cycle
with dR2_path_star/dR2_cycle_star
verify A_boundary_star is nonzero in open retained domains
verify closed/interior suppression
test source/order/support/edge/cycle nulls
no fitted boundary weights
```

## Safe claim

V1698.43 failed because path/cycle boundary exposure was defined only by signed endpoint node flags. The corrected dR2_path_star and dR2_cycle_star detect atlas-extension failure: missing references, unfilled cycles, and provenance/order discontinuity.
