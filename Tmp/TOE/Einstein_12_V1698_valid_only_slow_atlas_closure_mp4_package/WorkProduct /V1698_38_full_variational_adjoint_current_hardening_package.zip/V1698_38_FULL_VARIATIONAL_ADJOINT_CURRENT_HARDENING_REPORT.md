# V1698.38 — Full Variational Adjoint Current Hardening

**Verdict:** `FULL_VARIATIONAL_ADJOINT_CURRENT_HARDENING_PASS_NO_LAW_CLAIM`

## Frozen source action

```text
L_source =
Σ_edges [Δ_S(p,q) · tr_log(T_pq)]²
+
Σ_boundary rho_p²
```

## Hardening scope

```text
sizes: 3x4, 4x5, 5x6
nulls: source/order/support/edge/cycle
variations: support/order/source/boundary/harmonic
```

## Summary

```json
{
  "version": "V1698.38",
  "verdict": "FULL_VARIATIONAL_ADJOINT_CURRENT_HARDENING_PASS_NO_LAW_CLAIM",
  "purpose": "Harden V1698.37 provenance-coupled variational adjoint current across size/seed/null holdouts.",
  "valid": {
    "mode": "valid",
    "cases": 45,
    "mean_abs_total": 0.03159580403316258,
    "median_abs_total": 0.0176500650539424,
    "mean_abs_source_adj": 0.0032775670166055684,
    "mean_abs_transition_adj": 0.02858537437018248,
    "mean_A_R": 0.02476673896190107,
    "mean_L_source": 0.002264886650572685,
    "mean_path_count": 52.0,
    "mean_cycle_count": 4.0
  },
  "null_summary": [
    {
      "mode": "cycle_package_shuffle",
      "cases": 45,
      "mean_abs_total": 0.07356745984310464,
      "median_abs_total": 0.049354375724064425,
      "mean_abs_source_adj": 0.003061286404617805,
      "mean_abs_transition_adj": 0.07424422046991866,
      "mean_A_R": -0.0018131200643583473,
      "mean_L_source": 0.002077573125092158,
      "mean_path_count": 52.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "edge_package_shuffle",
      "cases": 45,
      "mean_abs_total": 0.15929183106599965,
      "median_abs_total": 0.0726469391487683,
      "mean_abs_source_adj": 0.0017207745225770548,
      "mean_abs_transition_adj": 0.15903357737254248,
      "mean_A_R": 0.027692857080276037,
      "mean_L_source": 0.000501719089779979,
      "mean_path_count": 52.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "order_shuffle",
      "cases": 45,
      "mean_abs_total": 0.21460780036915614,
      "median_abs_total": 0.16949129042487243,
      "mean_abs_source_adj": 0.19343744476587846,
      "mean_abs_transition_adj": 0.03098269229589353,
      "mean_A_R": 0.14351344138852085,
      "mean_L_source": 0.12325404795632267,
      "mean_path_count": 52.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "source_shuffle",
      "cases": 45,
      "mean_abs_total": 1.7660171327658563,
      "median_abs_total": 0.9559146706550337,
      "mean_abs_source_adj": 1.7473621392593626,
      "mean_abs_transition_adj": 0.03455327376697732,
      "mean_A_R": 0.5964907070593976,
      "mean_L_source": 0.5807466509182291,
      "mean_path_count": 52.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "support_shuffle",
      "cases": 45,
      "mean_abs_total": 1.3199689771939107,
      "median_abs_total": 0.7116456769828972,
      "mean_abs_source_adj": 1.3111292175547677,
      "mean_abs_transition_adj": 0.024239002628503547,
      "mean_A_R": -0.015425393740997606,
      "mean_L_source": -0.023733301140854084,
      "mean_path_count": 52.0,
      "mean_cycle_count": 4.0
    }
  ],
  "total_lower_than_null_rate": 1.0,
  "source_adj_lower_than_null_rate": 0.6,
  "transition_adj_lower_than_null_rate": 0.8,
  "best_total_null_to_valid_ratio": 2.32839334500115,
  "size_lower_rate": 1.0,
  "source_shuffle_to_valid_ratio": 55.8940399445563,
  "order_shuffle_to_valid_ratio": 6.792287992959889,
  "edge_shuffle_to_valid_ratio": 5.041550165767812,
  "cycle_shuffle_to_valid_ratio": 2.32839334500115,
  "claim_boundary": "Hardening diagnostic only. No law closure.",
  "runtime_seconds": 6.61109471321106
}
```
