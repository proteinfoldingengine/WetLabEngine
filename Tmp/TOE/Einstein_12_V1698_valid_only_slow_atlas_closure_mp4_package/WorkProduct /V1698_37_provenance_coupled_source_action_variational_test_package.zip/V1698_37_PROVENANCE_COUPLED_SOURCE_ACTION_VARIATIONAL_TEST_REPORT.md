# V1698.37 — Provenance-Coupled Source Action Variational Test

**Verdict:** `PROVENANCE_COUPLED_SOURCE_ACTION_SIGNAL_PRESENT_NO_LAW_CLAIM`

## Corrected source action

```text
L_source = Σ_edges [Δ_S(p,q) * tr_log(T_pq)]² + Σ_boundary rho_p²
```

## Primary check

```text
source_shuffle should no longer outperform valid
```

## Summary

```json
{
  "version": "V1698.37",
  "verdict": "PROVENANCE_COUPLED_SOURCE_ACTION_SIGNAL_PRESENT_NO_LAW_CLAIM",
  "purpose": "Replace boundary-norm L_source with provenance-coupled edge source action and rerun variational adjoint test.",
  "valid": {
    "mode": "valid",
    "cases": 40,
    "mean_abs_total": 0.029816953241112998,
    "median_abs_total": 0.02283301214767164,
    "mean_abs_source_adj": 0.0039644012499451264,
    "mean_abs_transition_adj": 0.02676591930964613,
    "mean_A_R": 0.02037675294142005,
    "mean_L_source": 0.0024725434712991046,
    "mean_path_count": 51.0,
    "mean_cycle_count": 4.0
  },
  "source_shuffle": {
    "mode": "source_shuffle",
    "cases": 40,
    "mean_abs_total": 2.6871449058245567,
    "median_abs_total": 1.4001820320341807,
    "mean_abs_source_adj": 2.6622104613656106,
    "mean_abs_transition_adj": 0.03220407938194615,
    "mean_A_R": 0.7043670060968843,
    "mean_L_source": 0.6926530960020827,
    "mean_path_count": 51.0,
    "mean_cycle_count": 4.0
  },
  "null_summary": [
    {
      "mode": "cycle_package_shuffle",
      "cases": 40,
      "mean_abs_total": 0.06393430779949583,
      "median_abs_total": 0.03456206379759408,
      "mean_abs_source_adj": 0.0038114216325269012,
      "mean_abs_transition_adj": 0.06301428316747837,
      "mean_A_R": 0.0024689315591963634,
      "mean_L_source": 0.002337771642935138,
      "mean_path_count": 51.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "edge_package_shuffle",
      "cases": 40,
      "mean_abs_total": 0.14609049477343206,
      "median_abs_total": 0.08537506018591046,
      "mean_abs_source_adj": 0.001978901028820701,
      "mean_abs_transition_adj": 0.14578036312349085,
      "mean_A_R": -0.013483519121670895,
      "mean_L_source": 0.000713126942386566,
      "mean_path_count": 51.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "order_shuffle",
      "cases": 40,
      "mean_abs_total": 0.3561960086782001,
      "median_abs_total": 0.2881974352053618,
      "mean_abs_source_adj": 0.3328530098558602,
      "mean_abs_transition_adj": 0.028132458078928772,
      "mean_A_R": 0.2815450068722747,
      "mean_L_source": 0.26467160027632275,
      "mean_path_count": 51.0,
      "mean_cycle_count": 4.0
    },
    {
      "mode": "source_shuffle",
      "cases": 40,
      "mean_abs_total": 2.6871449058245567,
      "median_abs_total": 1.4001820320341807,
      "mean_abs_source_adj": 2.6622104613656106,
      "mean_abs_transition_adj": 0.03220407938194615,
      "mean_A_R": 0.7043670060968843,
      "mean_L_source": 0.6926530960020827,
      "mean_path_count": 51.0,
      "mean_cycle_count": 4.0
    }
  ],
  "total_lower_than_null_rate": 1.0,
  "source_adj_lower_than_null_rate": 0.5,
  "best_total_null_to_valid_ratio": 2.144226718281733,
  "source_shuffle_to_valid_total_ratio": 90.121377727798,
  "source_shuffle_to_valid_source_adj_ratio": 671.5290135505155,
  "variation_lower_rate": 1.0,
  "claim_boundary": "Provenance-coupled source action diagnostic only. No law closure.",
  "runtime_seconds": 5.389146327972412
}
```
