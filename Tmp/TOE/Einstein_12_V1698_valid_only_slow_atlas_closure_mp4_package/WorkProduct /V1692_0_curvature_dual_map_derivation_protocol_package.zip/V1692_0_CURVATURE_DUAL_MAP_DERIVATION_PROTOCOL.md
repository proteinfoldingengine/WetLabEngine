# V1692.0 — Curvature-Dual Map Derivation Protocol

**Verdict:** `CURVATURE_DUAL_MAP_PROTOCOL_FROZEN_NO_EXECUTION`

## Why V1692 is needed

V1691.8 successfully emitted:

```text
exact adjoint gradients
stationary A
dual boundary trace Q_A
component identity residual tables
```

But V1691.9 diagnosed that v0 was still too degenerate because two objects were not exact enough:

```text
D_ΓR_Γ^k
ρ_P^k
```

The curvature side was still obtained by template pairing.

That is not enough.

---

## 1. Core correction

Curvature remains:

```text
R_Γ(C) = Ω_C − Id
```

But component curvature comparison must be:

```text
D_ΓR_Γ^k(C_i,C_j)
=
Φ_k[
  τ_curv(R_Γ(C_j)) − R_Γ(C_i)
]
```

where:

```text
Φ_k : End(G_p) → V_k*
```

is a component curvature-dual probe map.

This replaces:

```text
gradient-template pairing
```

from V1691.8.

---

## 2. Component curvature probes

### Branch

```text
Φ_B(E): B_p ↦ E B_p
```

The branch curvature covector is:

```text
W_B(EB_p)
```

### Source

```text
Φ_S(E): S_p ↦ E S_p
```

The source curvature covector is:

```text
W_S(ES_p)
```

### Product

For retained pair `(x,y)`:

```text
Φ_⊕(E)(x,y)
=
E(x⊕y)
−
D_1⊕[Ex]
−
D_2⊕[Ey]
```

This is the product analogue of curvature acting on the recombination law.

### O3

For retained triple `(x,y,z)`:

```text
Φ_O3(E)
=
E(O3)
−
D_1O3[Ex]
−
D_2O3[Ey]
−
D_3O3[Ez]
```

### H4

```text
Φ_H4(E)
=
P⊥(E H4)
```

with the dual rule:

```text
Φ_H4 must annihilate span(B,O3)
```

### Pi

```text
Φ_Π(E)
=
d_Π(order/action induced by E)
```

This is the retained incidence/order curvature probe.

---

## 3. Exact rho_P

`ρ_P` must use the same component action maps.

For event action:

```text
E_event
```

define:

```text
ρ_P^k(J_P,C)
=
Σ_events σ_e |m_e| Φ_k(E_event,e) / (M_C G_C)
```

This forbids event-label-only assignment.

Event labels may choose which event action is present, but they cannot replace the component-dual action.

---

## 4. Q_A stays unchanged

The exact stress term remains:

```text
Q_A^k(∂C)
=
Σ_{e∈∂C}
σ(C,e) τ^k_{e→C}(G_e^k)
```

where `G_e^k` is the exact component adjoint stress.

The required equality is:

```text
D_ΓR_Γ^k
=
ρ_P^k
+
Q_A^k
```

with all three terms in the same `V_k*` frame.

---

## 5. Required before execution

Before more Python, derive:

```text
Φ_B
Φ_S
Φ_⊕
Φ_O3
Φ_H4
Φ_Π
E_event for ρ_P
τ_k dual transport
```

or explicitly declare and justify a common-frame simplification.

---

## 6. New killer nulls

```text
N_curv_template_pair
N_phi_shuffle
N_rho_label_only
N_tau_identity_invalid
N_H4_probe_leak
```

These directly target the degeneracies from V1691.8.

---

## Final statement

V1692.0 freezes the next mathematical target:

```text
derive D_ΓR_Γ^k as a curvature-dual map.
```

No more template pairing.
