# V1695.4 — Pair-Labeled Invariant Postmortem and Scale-Scramble Hardening Plan

**Verdict:** `PAIR_IDENTITY_DIAGNOSTIC_PRESENT_SCALE_SCRAMBLE_BLOCKS_PROMOTION`

## Bottom line

V1695.3 fixed the pair-shuffle weakness.

```json
{
  "graph_cases": 20,
  "comparison_cases": 70,
  "action_reduction_rate": 0.0,
  "all_null_separation_rate": 0.8964285714285715,
  "pair_shuffle_separation_rate": 1.0,
  "scale_scramble_separation_rate": 0.6,
  "D1D2_drop_separation_rate": 0.9857142857142858,
  "scalar_product_separation_rate": 1.0,
  "identity_score_scale_cv": 0.08615625743612186,
  "stable_rank_scale_cv": 0.07981548821096997
}
```

## What survived

```text
pair-shuffle separation
D1/D2 derivative sensitivity
scalar-collapse rejection
pair-labeled Gram/order signature
```

The clean claim is now:

```text
Φ_⊕ carries a pair-labeled, derivative-sensitive product-curvature diagnostic.
```

## What still blocks promotion

```text
scale-scramble separation = 0.6
```

That means the invariant is now pair-sensitive, but not scale-robust enough.

## Diagnosis

The current invariant is mostly local to a graph.

A scale-scramble null can preserve enough local pair structure while breaking cross-scale structure.

So the next invariant must bind pair labels across graph sizes or resolution ladders.

## Scientific decision

Keep the pair-labeled diagnostic.

Do not claim scale-stable product law.

## Next branch

```text
V1695.5 — Cross-Scale Pair Transport Invariant
```

Required next:

```text
define pair label transport from coarse to fine graph
compute cross-scale pair Gram consistency
compute resolution-ladder covariance alignment
separate N_scale_scramble at >=0.75
retain pair-shuffle, D1/D2-drop, scalar-collapse separation
restore action-reduction/stationarity gate
```

## Safe claim

The product curvature probe now has a pair-labeled derivative-sensitive diagnostic, but scale-stable retained product structure remains unproven.
