#!/usr/bin/env python3
"""
V1698.70 Full-Stack Ledger Validator and Ingestion Harness
==========================================================

Accepts only full-stack retained-ledger-complete clean-room runs.

Rejects:
- proxy skeletons
- graph-cycle-only Bianchi
- circulation-only filling
- missing W1/W2/W3
- missing J_R
- missing Gamma_R
- missing signed boundary-pairing components
- missing null transform log

This validator does not weaken thresholds, change nulls, or score from proxy fields.
"""

from __future__ import annotations

from pathlib import Path
import argparse
import csv
import json
import sys
from typing import Dict, List, Any, Set

CONTRACT_HASHES = {
    "V1698.63": "45a923ea0421a1a3",
    "V1698.69": "940f448ed7fd6585",
}

REQUIRED = {
  "run_manifest": ["run_id","contract_hash","emitter_version","seed","domain","size_label","transform","mode","null_family","created_order_index"],
  "C0_nodes": ["node_id","ordered_index","source_value","support_vector","retained_order_vector","generated_algebra_signature","local_signature_SigOD","parent_event_ids"],
  "C1_edges": ["edge_id","p","q","T_pq","A_pq","source_delta","support_delta","order_delta","edge_package_signature","parent_event_ids","boundary_exposure","orientation"],
  "Gamma_R_connection": ["edge_id","from_algebra","to_algebra","transition_matrix","generator_map","faithfulness_defect","connection_signature"],
  "R2_path_faces": ["face_id","p","q","r","edge_pq","edge_qr","reference_pr","F2_matrix","F2_projection_signature","path_reference_mode","face_orientation"],
  "R3_cycle_faces": ["cycle_id","ordered_edge_ids","cycle_nodes","holonomy_matrix","F3_matrix","F3_projection_signature","cycle_orientation"],
  "W1_edge_witnesses": ["W1_id","edge_id","p","q","source_delta","support_delta","order_delta","generator_image_hash","ordered_index_span","parent_event_ids","W1_signature"],
  "W2_face_witnesses": ["W2_id","face_id","ordered_edge_sequence","edge_witness_ids","source_assignment","support_assignment","order_assignment","path_reference_id","fill_signature","fill2"],
  "W3_cell_witnesses": ["W3_id","cell_id","face_witness_ids","boundary_orientation","cell_source_current_JR","order_consistency_signature","support_consistency_signature","filling_signature","fill3"],
  "J_R_source_current": ["cell_id","JR_value","JR_matrix_or_component","source_free_flag","provenance_obstruction_signature"],
  "boundary_operator": ["object_id","object_dim","boundary_ids","orientation_signs","boundary_exposure","gamma_dR_component","B_boundary_component"],
  "signed_boundary_pairing": ["case_id","variation","deltaA_R","boundary_pairing","C_signed","C_signed_abs","domain"],
  "W3_bianchi_residuals": ["cell_id","W3_id","Alt_D_F2","F3_cell","JR","B_R_matrix","B_R_norm","projection_signature"],
  "null_transform_log": ["mode","null_family","changed_tables","preserved_tables","expected_failure_channel","null_signature"],
  "gate_checks": ["domain","size_label","transform","mode_group","valid_W3_count","signed_residual_lower_than_null_rate","filling_null_W3_corrupt_rate","curvature_null_B_corrupt_rate","passed"]
}

FROZEN_THRESHOLDS = {
    "signed_residual_lower_than_null_rate": 0.8,
    "filling_null_W3_corrupt_rate": 2/3,
    "curvature_null_B_corrupt_rate": 0.5,
    "integrated_pass_rate": 0.9,
    "open_pass_rate": 0.9,
    "closed_filled_pass_rate": 0.9,
}

REQUIRED_MODES = {"valid","source_shuffle","order_shuffle","support_shuffle","edge_package_shuffle","cycle_package_shuffle"}
REQUIRED_DOMAINS = {"open","closed_filled"}


def read_csv_rows(path: Path) -> List[Dict[str, str]]:
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def header(path: Path) -> List[str]:
    with path.open(newline="") as f:
        return next(csv.reader(f))


def split_ids(value: str) -> List[str]:
    if value is None:
        return []
    text = str(value).strip()
    if not text:
        return []
    for sep in [";","|",","]:
        if sep in text:
            return [x.strip() for x in text.split(sep) if x.strip()]
    return [text]


def truthy(v: str) -> bool:
    return str(v).strip().lower() in {"1","true","yes","y"}


def validate_schema(root: Path) -> List[Dict[str, Any]]:
    failures = []
    for table, req_cols in REQUIRED.items():
        p = root / f"{table}.csv"
        if not p.exists():
            failures.append({"table": table, "failure": "missing_table", "severity": "hard"})
            continue
        have = set(header(p))
        missing = [c for c in req_cols if c not in have]
        if missing:
            failures.append({"table": table, "failure": "missing_columns", "missing": missing, "severity": "hard"})
    return failures


def validate_contract(root: Path) -> List[Dict[str, Any]]:
    failures = []
    p = root / "run_manifest.csv"
    if not p.exists():
        return [{"table":"run_manifest", "failure":"missing_for_contract_validation", "severity":"hard"}]
    rows = read_csv_rows(p)
    if not rows:
        return [{"table":"run_manifest", "failure":"empty_manifest", "severity":"hard"}]
    hashes = {r.get("contract_hash","") for r in rows}
    allowed = set(CONTRACT_HASHES.values())
    if not hashes & allowed:
        failures.append({"table":"run_manifest", "failure":"contract_hash_mismatch", "found": sorted(hashes), "allowed": sorted(allowed), "severity":"hard"})
    domains = {r.get("domain","") for r in rows}
    modes = {r.get("mode","") for r in rows}
    if not REQUIRED_DOMAINS.issubset(domains):
        failures.append({"table":"run_manifest", "failure":"missing_required_domains", "missing": sorted(REQUIRED_DOMAINS - domains), "severity":"hard"})
    if not REQUIRED_MODES.issubset(modes):
        failures.append({"table":"run_manifest", "failure":"missing_required_modes", "missing": sorted(REQUIRED_MODES - modes), "severity":"hard"})
    return failures


def validate_referential_integrity(root: Path) -> List[Dict[str, Any]]:
    failures = []
    try:
        edges = read_csv_rows(root/"C1_edges.csv")
        W1 = read_csv_rows(root/"W1_edge_witnesses.csv")
        W2 = read_csv_rows(root/"W2_face_witnesses.csv")
        W3 = read_csv_rows(root/"W3_cell_witnesses.csv")
        JR = read_csv_rows(root/"J_R_source_current.csv")
        B = read_csv_rows(root/"W3_bianchi_residuals.csv")
    except FileNotFoundError:
        return [{"table":"referential_integrity", "failure":"skipped_missing_required_table", "severity":"hard"}]

    edge_ids = {r["edge_id"] for r in edges}
    w1_ids = {r["W1_id"] for r in W1}
    w2_ids = {r["W2_id"] for r in W2}
    w3_ids = {r["W3_id"] for r in W3}
    cell_ids = {r["cell_id"] for r in W3}
    jr_cells = {r["cell_id"] for r in JR}

    for r in W1:
        if r.get("edge_id") not in edge_ids:
            failures.append({"table":"W1_edge_witnesses", "failure":"W1_references_missing_edge", "W1_id":r.get("W1_id"), "edge_id":r.get("edge_id"), "severity":"hard"})

    for r in W2:
        for wid in split_ids(r.get("edge_witness_ids","")):
            if wid not in w1_ids:
                failures.append({"table":"W2_face_witnesses", "failure":"W2_references_missing_W1", "W2_id":r.get("W2_id"), "W1_id":wid, "severity":"hard"})
        if not truthy(r.get("fill2","")):
            failures.append({"table":"W2_face_witnesses", "failure":"non_filled_face_in_W2_table", "W2_id":r.get("W2_id"), "severity":"hard"})

    for r in W3:
        for wid in split_ids(r.get("face_witness_ids","")):
            if wid not in w2_ids:
                failures.append({"table":"W3_cell_witnesses", "failure":"W3_references_missing_W2", "W3_id":r.get("W3_id"), "W2_id":wid, "severity":"hard"})
        if not truthy(r.get("fill3","")):
            failures.append({"table":"W3_cell_witnesses", "failure":"non_filled_cell_in_W3_table", "W3_id":r.get("W3_id"), "severity":"hard"})
        if r.get("cell_id") not in jr_cells:
            failures.append({"table":"J_R_source_current", "failure":"missing_JR_for_W3_cell", "cell_id":r.get("cell_id"), "severity":"hard"})

    for r in B:
        if r.get("W3_id") not in w3_ids:
            failures.append({"table":"W3_bianchi_residuals", "failure":"Bianchi_row_not_W3_certified", "W3_id":r.get("W3_id"), "severity":"hard"})
        if r.get("cell_id") not in cell_ids:
            failures.append({"table":"W3_bianchi_residuals", "failure":"Bianchi_cell_missing_W3_cell", "cell_id":r.get("cell_id"), "severity":"hard"})

    return failures


def validate_no_proxy_shortcuts(root: Path) -> List[Dict[str, Any]]:
    failures = []

    # Bianchi rows must be W3-certified and include JR and projection signature.
    try:
        b_rows = read_csv_rows(root/"W3_bianchi_residuals.csv")
        w3_rows = read_csv_rows(root/"W3_cell_witnesses.csv")
    except FileNotFoundError:
        return [{"table":"proxy_shortcuts", "failure":"skipped_missing_table", "severity":"hard"}]

    w3_ids = {r["W3_id"] for r in w3_rows}
    for r in b_rows:
        if r.get("W3_id") not in w3_ids:
            failures.append({"table":"W3_bianchi_residuals", "failure":"graph_cycle_or_uncertified_bianchi_row", "severity":"hard"})
        if r.get("JR") is None or str(r.get("JR")).strip() == "":
            failures.append({"table":"W3_bianchi_residuals", "failure":"missing_JR_component", "cell_id":r.get("cell_id"), "severity":"hard"})

    # Signed boundary rows must include decomposed deltaA_R and boundary_pairing.
    try:
        sb = read_csv_rows(root/"signed_boundary_pairing.csv")
    except FileNotFoundError:
        return failures
    for r in sb:
        if r.get("deltaA_R","") == "" or r.get("boundary_pairing","") == "":
            failures.append({"table":"signed_boundary_pairing", "failure":"scalar_proxy_boundary_pairing", "case_id":r.get("case_id"), "severity":"hard"})

    return failures


def validate_gate_recompute(root: Path) -> Dict[str, Any]:
    rows = read_csv_rows(root/"gate_checks.csv")
    failures = []
    if not rows:
        return {"verdict":"GATE_RECOMPUTE_FAIL", "failures":[{"failure":"empty_gate_checks"}]}

    pass_rows = []
    for r in rows:
        try:
            signed = float(r["signed_residual_lower_than_null_rate"])
            filling = float(r["filling_null_W3_corrupt_rate"])
            curvature = float(r["curvature_null_B_corrupt_rate"])
            valid_w3 = float(r["valid_W3_count"])
        except Exception as e:
            failures.append({"table":"gate_checks", "failure":"non_numeric_gate_value", "row":r, "error":str(e)})
            continue
        expected = (
            valid_w3 > 0 and
            signed >= FROZEN_THRESHOLDS["signed_residual_lower_than_null_rate"] and
            filling >= FROZEN_THRESHOLDS["filling_null_W3_corrupt_rate"] and
            curvature >= FROZEN_THRESHOLDS["curvature_null_B_corrupt_rate"]
        )
        reported = truthy(r.get("passed",""))
        if expected != reported:
            failures.append({"table":"gate_checks", "failure":"reported_pass_mismatch", "expected":expected, "reported":reported, "row":r})
        pass_rows.append(expected)

    pass_rate = sum(pass_rows) / max(1, len(pass_rows))
    open_rows = [p for p,r in zip(pass_rows, rows) if r.get("domain") == "open"]
    closed_rows = [p for p,r in zip(pass_rows, rows) if r.get("domain") == "closed_filled"]
    open_pass = sum(open_rows) / max(1, len(open_rows))
    closed_pass = sum(closed_rows) / max(1, len(closed_rows))
    law_candidate = pass_rate >= 0.9 and open_pass >= 0.9 and closed_pass >= 0.9

    return {
        "verdict": "GATE_RECOMPUTE_PASS" if not failures else "GATE_RECOMPUTE_FAIL",
        "pass_rate": pass_rate,
        "open_pass_rate": open_pass,
        "closed_filled_pass_rate": closed_pass,
        "law_candidate_status": law_candidate,
        "failure_count": len(failures),
        "failures": failures
    }


def validate(root: Path) -> Dict[str, Any]:
    failures = []
    failures += validate_schema(root)
    if failures:
        return {
            "verdict": "FULL_STACK_LEDGER_VALIDATION_FAIL_SCHEMA",
            "failure_count": len(failures),
            "failures": failures,
            "gate_recompute": None
        }

    failures += validate_contract(root)
    failures += validate_referential_integrity(root)
    failures += validate_no_proxy_shortcuts(root)
    gate = validate_gate_recompute(root)
    failures += gate.get("failures", [])

    if failures:
        verdict = "FULL_STACK_LEDGER_VALIDATION_FAIL"
    elif gate["law_candidate_status"]:
        verdict = "FULL_STACK_LEDGER_VALIDATION_PASS_LAW_CANDIDATE"
    else:
        verdict = "FULL_STACK_LEDGER_VALIDATION_PASS_SCHEMA_ONLY_NO_LAW_CANDIDATE"

    return {
        "verdict": verdict,
        "failure_count": len(failures),
        "failures": failures,
        "gate_recompute": gate,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root", help="Directory containing full-stack ledger CSVs")
    ap.add_argument("--out", default=None, help="Optional JSON output path")
    args = ap.parse_args()

    result = validate(Path(args.root))
    text = json.dumps(result, indent=2)
    print(text)
    if args.out:
        Path(args.out).write_text(text)
    return 0 if result["verdict"].startswith("FULL_STACK_LEDGER_VALIDATION_PASS") else 2


if __name__ == "__main__":
    sys.exit(main())
