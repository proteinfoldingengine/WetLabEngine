# V1691.0 — Exact Discrete Adjoint Boundary Derivation Protocol

**Verdict:** `ADJOINT_BOUNDARY_DERIVATION_PROTOCOL_FROZEN_NO_EXECUTION`

## Why V1691 exists

V1690.13 produced a real negative result:

```text
stationary solver: survived
faithfulness gates: survived
component-resolved compatibility: failed
```

The failure was not random. It identified the missing mathematical object.

The component split was imposed after the fact:

```text
D_ΓR_Γ component projection
ρ_P event-label component assignment
Q_A gradient-proportional decomposition
```

That is not enough for a law-level identity.

The missing object is:

```text
the exact discrete adjoint boundary map
```

---

## 1. Local generated algebra

The retained sector is:

```text
G_p = ⟨B_p, ⊕_p, O3_p, H4⊥_p, S_p, Π_p⟩
```

The component space is:

```text
V_G
=
V_B
⊕
V_⊕
⊕
V_O3
⊕
V_H4
⊕
V_S
⊕
V_Π
```

and the dual space is:

```text
V_G*
=
V_B*
⊕
V_⊕*
⊕
V_O3*
⊕
V_H4*
⊕
V_S*
⊕
V_Π*
```

A component-resolved identity must live in this dual structure, not in a post-hoc scalar projection.

---

## 2. Component inner products

We must define observable inner products for each component.

### Branch component

```text
⟨X,Y⟩_B = tr(Xᵀ W_B Y)
```

### Product component

```text
⟨K,L⟩_⊕
=
E_{x,y ∈ test algebra}
⟨K(x,y), L(x,y)⟩
```

### O3 component

```text
⟨u,v⟩_O3 = uᵀ W_O3 v
```

### H4 component

```text
⟨u,v⟩_H4 = uᵀ W_H4 v
```

but on the quotient/perpendicular subspace:

```text
H4⊥ / span(B,O3)
```

### Source component

```text
⟨s,t⟩_S = sᵀ W_S t
```

### Provenance/order component

```text
⟨P,Q⟩_Π
=
weighted incidence inner product over retained-order dependencies
```

---

## 3. Residual maps

For an edge `e = p → q` with generator `A_e` and transport:

```text
T_A = Exp_R(A_e)
```

define residuals:

```text
δ_B[A] = T_A B_p − B_q
```

```text
δ_⊕[A]
=
T_A(x ⊕_p y)
−
(T_Ax ⊕_q T_Ay)
```

```text
δ_O3[A]
=
T_A O3_p
−
O3_q(T_Ax,T_Ay,T_Az)
```

```text
δ_H4[A]
=
Proj⊥_q(T_A H4⊥_p)
−
H4⊥_q
```

```text
δ_S[A]
=
T_A^S S_p
−
S_q
```

```text
δ_Π[A]
=
Incidence_Π(T_A)
−
Incidence_Π(q)
```

---

## 4. Linearized residual maps

For an admissible variation:

```text
A_e → A_e + ε Ξ_e
```

define:

```text
D_A δ_k[Ξ]
=
d/dε δ_k[A + εΞ] | ε=0
```

The adjoint is defined by:

```text
⟨D_A δ_k[Ξ], r_k⟩_k
=
⟨Ξ, (D_A δ_k)^* r_k⟩_A
```

This is the critical object.

V1690 failed because it used approximate projections instead of exact adjoints.

---

## 5. Discrete summation-by-parts

The faithfulness action is:

```text
I_faith[A]
=
Σ_edges Σ_k w_k ||δ_k[A_e]||²_k
```

Its variation is:

```text
δI_faith
=
2 Σ_edges Σ_k
⟨D_A δ_k[Ξ_e], δ_k[A_e]⟩_k
```

Using the adjoint:

```text
δI_faith
=
2 Σ_edges
⟨Ξ_e, Σ_k w_k (D_Aδ_k)^*δ_k⟩_A
```

Now the important step:

```text
rearrange edge variation sums into
interior stationarity terms
+
boundary terms over retained loop/cell comparisons
```

This is the discrete retained analogue of integration by parts.

The boundary term is not optional.

It is exactly where:

```text
Q_A
```

must come from.

---

## 6. Exact Q_A

Define:

```text
Q_A(∂C)
=
BoundaryAdjoint(
  Grad_faith
  +
  Grad_order
  +
  Grad_reg
)
```

where `∂C` is the comparison boundary.

So `Q_A` is:

```text
a boundary cochain in V_G*
```

not:

```text
a scalar correction
a fitted residual
a gradient-norm proportional patch
Q_A = E_source
```

Required:

```text
Q_A must be computed before compatibility judgment.
Q_A must have component-dual entries.
Q_A must vanish when supporting admissibility stresses vanish.
Q_A must be derived by summation-by-parts.
```

---

## 7. Derived identity

The general identity is:

```text
D_ΓR_Γ[A]
=
ρ_P(J_P[A])
+
Q_A[A]
```

Component form:

```text
D_ΓR_Γ^k[A]
=
ρ_P^k(J_P[A])
+
Q_A^k[A]
```

for:

```text
k ∈ {B, ⊕, O3, H4, S, Π}
```

The source-balanced case is only the special case:

```text
Q_A^k = 0 for all k
```

The source-free case is:

```text
Q_A = 0 and J_P = 0
```

---

## 8. Required before more Python

The next steps must be derivations:

```text
1. choose component inner products W_k
2. derive (D_A δ_B)^*
3. derive (D_A δ_⊕)^*
4. derive (D_A δ_O3)^*
5. derive (D_A δ_H4)^* on quotient/perp space
6. derive (D_A δ_S)^*
7. derive (D_A δ_Π)^*
8. derive the boundary adjoint by summation-by-parts
9. state the component-resolved identity in dual space
```

---

## 9. Future killer nulls

After the derivation, the correct nulls are:

```text
N_dual_shuffle
N_boundary_adjoint_break
N_quotient_break_H4
N_incidence_relabel_Pi
N_fake_QA
```

These attack the exact adjoint structure, not just aggregate norms.

---

## Final statement

V1691.0 freezes the mathematical reset:

```text
No more compatibility emitter patches.
Derive the exact adjoint boundary map first.
```

The next branch is:

```text
V1691.1 — Component Inner Products and Dual Space Definitions
```
