# V1698.54 - Coupled R2/R3 Interior Curvature Stationarity Test

**Verdict:** `COUPLED_R2_R3_INTERIOR_CURVATURE_STATIONARITY_FAIL_NO_LAW_CLAIM`

## Tested equation

```text
S_K(e) = S_R2(e) + S_R3(e)
```

where:

```text
S_R2(e) = sum_alpha D_e_alpha^* F2_alpha
S_R3(e) = sum_beta D_e_beta^* F3_beta
```

## Summary

```json
{
  "version": "V1698.54",
  "verdict": "COUPLED_R2_R3_INTERIOR_CURVATURE_STATIONARITY_FAIL_NO_LAW_CLAIM",
  "purpose": "Test coupled R2/R3 edge-adjoint retained curvature stationarity.",
  "row_count": 90,
  "check_count": 15,
  "pass_rate": 0.0,
  "mean_lower_than_null_rate": 0.40000000000000013,
  "min_best_null_to_valid_ratio": 0.9999999999977802,
  "mean_balance_lower_than_null_rate": 0.20000000000000004,
  "mean_valid_R2_R3_alignment_cosine": 0.28531591617843055,
  "failure_count": 15,
  "improved_over_V1698_52_R2_alone": false,
  "V1698_52_R2_alone_pass_rate_reference": 0.0,
  "improved_over_V1698_50_closed_pass_rate": false,
  "V1698_50_closed_pass_rate_reference": 0.6,
  "claim_boundary": "Coupled interior curvature stationarity diagnostic only. No final law closure.",
  "runtime_seconds": 1.287665605545044
}
```
