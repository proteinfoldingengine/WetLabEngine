# V1692.4 — Consolidated Curvature-Dual Execution Specification

**Verdict:** `CURVATURE_DUAL_EXECUTION_SPEC_FROZEN_NO_EXECUTION`

## Purpose

V1692.0–V1692.3 derived the missing pieces that V1691.8 lacked:

```text
Φ_k curvature-dual probes
E_event event-induced endomorphisms
ρ_P^k = Σ Φ_k(E_event)
```

V1692.4 freezes the execution specification for the next Python emitter.

---

## 1. Core identity

For every component:

```text
k ∈ {B, S, ⊕, O3, H4, Π}
```

the identity is:

```text
D_ΓR_Γ^k(C_i,C_j)
=
ρ_P^k(J_P,C)
+
Q_A^k(∂C)
```

where all terms live in:

```text
V_k*
```

The three terms are now defined as:

```text
D_ΓR_Γ^k
=
Φ_k[τ_curv(R_j) − R_i]
```

```text
ρ_P^k
=
Σ_events σ_e |m_e| Φ_k(E_event,e)/(M_CG_C)
```

```text
Q_A^k
=
Σ_boundary σ(C,e)τ^k_{e→C}(G_e^k)
```

---

## 2. Component probe stack

```text
Φ_B(E)      = W_B(EB_p)
Φ_S(E)      = W_S(ES_p)
Φ_H4(E)     = P⊥ᵀW_H4P⊥(EH4_p)
Φ_⊕(E)      = W_B[E(x⊕y)-D1⊕(Ex)-D2⊕(Ey)]
Φ_O3(E)     = W_O3[E(O3)-D1O3(Ex)-D2O3(Ey)-D3O3(Ez)]
Φ_Π(E)      = d_Π*[I_Π(E;Π_p)]
```

This replaces the V1691.8 gradient-template pairing.

---

## 3. Event-induced endomorphism

Every event must emit:

```text
E_event,e
=
P_e A_boundary P_e
```

or:

```text
E_event,e
=
Rep_e(A_boundary,χ_e)
```

Required event fields:

```text
event_id
event_type
incidence_covector_chi_e
event_projector_or_representation_id
orientation_sigma_e
magnitude_m_e
boundary_id
```

`ρ_P` is valid only if:

```text
Φ_k(E_event,e)
```

is emitted for each component.

Event-label-only current is rejected.

---

## 4. Required execution order

```text
1. declare component dual spaces, weights, pairs/triples, H4 projector, Π incidence
2. solve stationary A using exact adjoint gradients
3. freeze A
4. compute R_i = Ω_i − Id
5. compute E_C = τ_curv(R_j) − R_i
6. apply Φ_k to E_C to emit D_ΓR_Γ^k
7. construct E_event for every boundary event
8. apply Φ_k to E_event to emit ρ_P^k
9. construct Q_A^k by signed dual-transported boundary trace
10. compute E_k = D_k − ρ_k − Q_A_k
11. run exact-structure null suite
12. only then aggregate diagnostics
```

---

## 5. Required tables

```text
component_duals.csv
curvature_probes.csv
event_endomorphisms.csv
rho_component_currents.csv
curvature_dual_components.csv
adjoint_gradients.csv
dual_boundary_trace.csv
component_identity_residuals.csv
null_manifest.csv
run_manifest.json
```

No result is admissible without these.

---

## 6. Schema gates

### D gate

```text
D_ΓR_Γ^k emitted through Φ_k
no gradient-template pairing
τ_curv valid or explicitly common-frame declared
```

### ρ gate

```text
E_event emitted for each event
Φ_k(E_event) emitted for each component
event-label-only current rejected
```

### Q_A gate

```text
Q_A emitted by signed boundary trace
dual transport ids emitted
no Q_A = E_source
```

### H4 gate

```text
Φ_H4 uses P⊥
H4 covectors annihilate span(B,O3)
```

### Π gate

```text
Φ_Π uses oriented d_Π/d_Π*
counts-only incidence rejected
```

---

## 7. Required null suite

```text
N_curv_template_pair
N_phi_shuffle
N_product_scalar
N_O3_scalar
N_H4_probe_leak
N_Pi_count_only
N_event_label_only
N_event_projector_shuffle
N_boundary_adjoint_break
N_fake_QA
```

These attack the specific degeneracies found in V1691.8.

---

## 8. Promotion rules

```text
Level 0:
schema emitted

Level 1:
exact-adjoint stationary A and curvature-dual D/rho/Q schema pass

Level 2:
component identity beats exact-structure nulls on multi-boundary holdout

Level 3:
source-balanced special case where Q_A is independently small/zero

Level 4:
source-free special case where Q_A and J_P are independently small/zero
```

No level above 1 is allowed unless:

```text
D, ρ, and Q_A all use exact component-dual maps
and
component residuals beat exact-structure nulls.
```

---

## Next

```text
V1692.5 — Curvature-Dual Minimal Python Emitter v1
```
