# V1698.72 - Full-Stack Ledger Schema Repair and Gate Recompute Harness

**Verdict:** `FULL_STACK_SCHEMA_REPAIR_STILL_FAILS_VALIDATOR`

## Prior validator failure

```json
{
  "verdict": "FULL_STACK_LEDGER_VALIDATION_FAIL",
  "failure_count": 2,
  "failures": [
    {
      "table": "run_manifest",
      "failure": "missing_required_domains",
      "missing": [
        "open"
      ],
      "severity": "hard"
    },
    {
      "table": "run_manifest",
      "failure": "missing_required_modes",
      "missing": [
        "cycle_package_shuffle",
        "edge_package_shuffle",
        "order_shuffle",
        "source_shuffle",
        "support_shuffle"
      ],
      "severity": "hard"
    }
  ]
}
```

## Current validator result

```json
{
  "validator_returncode": 2,
  "validator_verdict": "FULL_STACK_LEDGER_VALIDATION_FAIL",
  "failure_count": 2,
  "failures": [
    {
      "table": "run_manifest",
      "failure": "missing_required_domains",
      "missing": [
        "open"
      ],
      "severity": "hard"
    },
    {
      "table": "run_manifest",
      "failure": "missing_required_modes",
      "missing": [
        "cycle_package_shuffle",
        "edge_package_shuffle",
        "order_shuffle",
        "source_shuffle",
        "support_shuffle"
      ],
      "severity": "hard"
    }
  ]
}
```

## Gate recompute

```json
{
  "verdict": "GATE_RECOMPUTE_PASS",
  "pass_rate": 1.0,
  "open_pass_rate": 0.0,
  "closed_filled_pass_rate": 1.0,
  "law_candidate_status": false,
  "failure_count": 0,
  "failures": []
}
```

## Boundary

This branch repairs the full-stack ledger schema/integrity and replaces scaffold pass rows with recomputed gate rows.

A single-mode sample ledger is not yet a full multi-null replication run.

## Next

```text
V1698.73 - Multi-Mode Full-Stack Ledger Replication Run
```
