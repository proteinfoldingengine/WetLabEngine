# V1698.28 — Retained Atlas Current Identity Test

**Verdict:** `RETAINED_ATLAS_CURRENT_IDENTITY_MIXED_NO_LAW_CLAIM`

```json
{
  "version": "V1698.28",
  "verdict": "RETAINED_ATLAS_CURRENT_IDENTITY_MIXED_NO_LAW_CLAIM",
  "purpose": "Test retained-atlas current identity residual E_p against source/order/atlas nulls without fitted coefficients.",
  "valid": {
    "mode": "valid",
    "cases": 6,
    "mean_abs_E": 3.0489645239726246,
    "median_abs_E": 2.3954065546029715,
    "global_E": 2.999999989029002,
    "mean_r2_count": 51.0,
    "mean_r3_count": 3.0
  },
  "null_summary": [
    {
      "mode": "cycle_package_shuffle",
      "cases": 6,
      "mean_abs_E": 3.0489645239791,
      "median_abs_E": 2.3954065546029715,
      "global_E": 2.999999989035478,
      "mean_r2_count": 51.0,
      "mean_r3_count": 3.0
    },
    {
      "mode": "edge_package_shuffle",
      "cases": 6,
      "mean_abs_E": 3.135259483357448,
      "median_abs_E": 2.746399857269951,
      "global_E": 2.999999992612702,
      "mean_r2_count": 51.0,
      "mean_r3_count": 3.0
    },
    {
      "mode": "order_shuffle",
      "cases": 6,
      "mean_abs_E": 3.0525458690416527,
      "median_abs_E": 2.483827909461365,
      "global_E": 2.999999989029002,
      "mean_r2_count": 51.0,
      "mean_r3_count": 3.0
    },
    {
      "mode": "source_shuffle",
      "cases": 6,
      "mean_abs_E": 3.0525458690416527,
      "median_abs_E": 2.483827909461365,
      "global_E": 2.999999989029002,
      "mean_r2_count": 51.0,
      "mean_r3_count": 3.0
    }
  ],
  "valid_lower_than_null_rate": 1.0,
  "median_lower_than_null_rate": 0.75,
  "best_null_to_valid_ratio": 1.0000000000017957,
  "claim_boundary": "Current identity diagnostic only. No law closure.",
  "runtime_seconds": 2.9364659786224365
}
```
