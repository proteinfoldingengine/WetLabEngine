# V1698.2 — Dissipative Generator Collapse Postmortem

**Verdict:** `PERTURBATION_TRAP_DISSIPATIVE_GRADIENT_TOO_SMALL_NO_LAW_CLAIM`

## Why this branch exists

V1698.1 did not merely produce a weak mixed result. It produced a mathematical collapse:

```text
classical generator ≈ dissipative generator ≈ erasure generator
```

So V1698.2 measured:

```text
cos(∇I_product, ∇D_ret)
||P_obs ∇D_ret|| / ||∇D_ret||
||∇D_ret|| / ||∇I_product||
```

## Core telemetry

```json
{
  "cases": 72,
  "mean_grad_D_to_I_norm_ratio": 4.701432437679805e-08,
  "median_grad_D_to_I_norm_ratio": 4.344651496467625e-08,
  "mean_cos_gradI_gradD": 0.01843492204539729,
  "median_cos_gradI_gradD": 0.05057718069396379,
  "mean_cos_projected_gradI_gradD": 0.01839341988569844,
  "mean_projector_visible_fraction_D": 0.9475074443964127,
  "median_projector_visible_fraction_D": 0.9885301528234688,
  "mean_projector_erased_fraction_D": 0.05249255560358725,
  "mean_preconditioned_visible_fraction_D": 0.9615686218645441,
  "mean_condition_L": 432397.269043098
}
```

## Diagnosis

```text
PERTURBATION_TRAP_DISSIPATIVE_GRADIENT_TOO_SMALL
```

## Scientific decision

Do not continue with a penalty method:

```text
min_A I_product[A] + λ D_ret[A]
```

Replace it with a constrained generator:

```text
min_A I_product[A]
subject to
M_mid[A] = M_mid_target
S_mid[A] = S_mid_target
```

The near-gauge spectral entropy/mass must define the admissible contour, not appear as a small add-on penalty.

## Next branch

```text
V1698.3 — Constrained Near-Gauge Entropy-Contour Generator Derivation
```

Required:

```text
derive ∇M_mid and ∇S_mid
construct tangent projector P_T = I - N(N^T N)^-1 N^T
update only along entropy-contour tangent directions
compare against classical and penalty methods
keep Sig_O out of the solver
```
