# V1698.57 - Retained Filling Complex Derivation

**Verdict:** `RETAINED_FILLING_COMPLEX_PROTOCOL_DERIVED_NO_EXECUTION`

## Do we need the full stack?

Yes.

The V1698.56 failure shows exactly why.

We tested Bianchi compatibility on graph cycles, but a graph cycle is not automatically a retained filled cell.

That is the wrong object.

The correct object is:

```text
retained admissible filling complex
```

Meaning:

```text
a cycle can be tested as an interior Bianchi cell only if it has retained filling evidence
```

That evidence comes from the full stack:

```text
generated retained algebra
Gamma_R transition connection
source/provenance density
support cochain
retained-order cochain
path-composition atlas consistency
cycle-holonomy consistency
retained boundary operator
signed boundary pairing
explicit retained 2-cell / 3-cell filling complex
```

## Core correction

Wrong object:

```text
graph cycle
```

Correct object:

```text
retained filled cell
```

Topology alone is insufficient.

The retained complex is:

```text
C0_R = retained generated algebra nodes / pair objects
C1_R = retained transition edges
C2_R = retained admissible filled faces
C3_R = retained admissible filled cells
```

with boundary maps:

```text
dR1: C1_R -> C0_R
dR2: C2_R -> C1_R
dR3: C3_R -> C2_R
```

## Retained face admissibility

A candidate face becomes a retained 2-cell only if:

```text
all boundary edges exist
path-composition defect is computable
source/provenance current is conserved or explicitly assigned
support cochain closes
retained-order cochain closes
the face has retained filling evidence
```

## Retained cell admissibility

A candidate 3-cell becomes retained only if:

```text
all boundary faces are retained 2-cells
cycle holonomy is computable
alternating face boundary closes
source/provenance current is zero or explicit as J_R
retained-order consistency holds across the filled faces
```

## Corrected Bianchi domain

Old test domain:

```text
all discovered graph 4-cycles
```

New test domain:

```text
only retained 3-cells with fill3(cell)=1
```

Correct identity:

```text
D_R K_R(cell) = J_R(cell)
```

Source-free interior:

```text
D_R K_R(cell) = 0
```

Residual:

```text
B_R(cell)
=
Pi_B(Alt_D_F2 - F3_cell - J_R(cell))
```

## Why the full stack is non-negotiable

Without source/provenance/order/support, the model cannot tell:

```text
interior filled cell
```

from:

```text
graph loop that merely exists
```

Without the retained boundary operator, it cannot tell:

```text
interior
```

from:

```text
boundary/exterior
```

Without Gamma_R, it cannot define path or cycle defect.

So dropping the full stack turns the model into ordinary graph topology, which is not what we are testing.

## Next branch

```text
V1698.58 - Retained Filling Complex Construction Test
```

Required:

```text
construct candidate faces
compute source/support/order circulation
assign fill2(face)
construct candidate 3-cells
assign fill3(cell)
test Bianchi residual only on retained filled cells
compare to V1698.56 graph-cycle failure
```

## Safe claim

Full stack is required because Bianchi compatibility is not a graph-cycle property. It is a retained filling-complex property requiring provenance, support, retained-order, source current, connection transport, and boundary structure.
