# V1691.1 — Component Inner Products and Dual Space Definitions

**Verdict:** `COMPONENT_DUAL_SPACES_FROZEN_NO_EXECUTION`

## Purpose

V1690 failed at component-resolved compatibility because components were projected after the fact.

V1691 requires the component dual structure first.

The local generated algebra is:

```text
G_p = ⟨B_p, ⊕_p, O3_p, H4⊥_p, S_p, Π_p⟩
```

Define the primal component space:

```text
V_G(p)
=
V_B
⊕
V_⊕
⊕
V_O3
⊕
V_H4
⊕
V_S
⊕
V_Π
```

and the dual space:

```text
V_G*(p)
=
V_B*
⊕
V_⊕*
⊕
V_O3*
⊕
V_H4*
⊕
V_S*
⊕
V_Π*
```

The component-resolved identity must be equality in these dual spaces, not scalar norm similarity.

---

## 1. Branch space `V_B`

`V_B` contains branch-frame variations:

```text
ΔB
```

with the same branch index structure as `B_p`.

Define:

```text
⟨X,Y⟩_B = tr(Xᵀ W_B Y)
```

where `W_B` is a positive semidefinite observable weight, such as retained branch confidence or branch mass.

The dual is identified by:

```text
C_B(X) = tr(C_Bᵀ W_B X)
```

So:

```text
V_B* ≅ W_B V_B
```

under this inner product.

---

## 2. Product space `V_⊕`

`V_⊕` contains bilinear product residual maps:

```text
K : V_B × V_B → V_B
```

Define a retained test-pair set:

```text
T_p = {(a,b)}
```

drawn from:

```text
branch generators
O3 directions
H4⊥ direction
source directions
```

Then:

```text
⟨K,L⟩_⊕
=
Σ_(a,b)∈T_p
ω_ab ⟨K(a,b), L(a,b)⟩_B
```

The dual space `V_⊕*` consists of weighted bilinear covectors over retained test pairs.

This is important: product compatibility is not a scalar defect. It is a bilinear covector object.

---

## 3. Associator space `V_O3`

`V_O3` contains associator variations:

```text
ΔO3
```

Define:

```text
⟨u,v⟩_O3 = uᵀ W_O3 v
```

where `W_O3` is based on retained associator scale/provenance confidence.

The dual is:

```text
V_O3* ≅ W_O3 V_O3
```

---

## 4. H4 quotient space `V_H4`

`H4⊥` does not live in the full vector space without constraints.

It lives in the quotient/perpendicular residual space:

```text
Q_H4 = V / span(B,O3)
```

Let:

```text
P⊥ = I − P_span(B,O3)
```

Then:

```text
⟨u,v⟩_H4
=
(P⊥u)ᵀ W_H4 (P⊥v)
```

The dual space must annihilate the lower-order span:

```text
φ_H4(w) = 0
for all w ∈ span(B,O3)
```

This prevents H4 from leaking back into branch/O3 evidence.

---

## 5. Source/access state `V_S`

`V_S` contains source/access/divergence variations:

```text
ΔS
```

Define:

```text
⟨s,t⟩_S = sᵀ W_S t
```

where `W_S` is derived from source mass/access confidence.

Forbidden:

```text
W_S cannot be chosen using E_source or E_stress.
```

---

## 6. Provenance/order incidence `V_Π`

`V_Π` contains retained-order incidence variations over dependencies and events.

Define:

```text
⟨P,Q⟩_Π
=
Σ_e ω_e P_e Q_e
+
Σ_paths ω_path P_path Q_path
```

where weights are derived from:

```text
ledger confidence
ordered-index validity
source provenance
dependency support
```

The dual consists of incidence covectors on dependency/order/event cochains.

Important:

```text
Π duals must preserve retained-order orientation.
```

---

## 7. Global generated-algebra inner product

For component vector:

```text
u = (u_B, u_⊕, u_O3, u_H4, u_S, u_Π)
```

define:

```text
⟨u,v⟩_G
=
Σ_k w_k ⟨u_k,v_k⟩_k
```

where:

```text
k ∈ {B, ⊕, O3, H4, S, Π}
```

Weights `w_k` must be declared before stationarity and may not be tuned using compatibility residuals.

---

## 8. Generator inner product

For generator variations:

```text
Ξ, Ζ ∈ End_R(G_p,G_q)
```

define:

```text
⟨Ξ,Ζ⟩_A = tr(Ξᵀ W_A Ζ)
```

`W_A` should eventually be induced by how `A` acts on `V_G`.

Until the induced metric is derived, identity is a minimal scaffold, but the same `W_A` must be used consistently for:

```text
gradients
stationarity
boundary adjoints
```

---

## 9. Component-resolved identity target

For each component:

```text
k ∈ {B, ⊕, O3, H4, S, Π}
```

the law object must live in the dual space:

```text
D_ΓR_Γ^k[A] ∈ V_k*
```

and:

```text
ρ_P^k(J_P[A]) + Q_A^k[A] ∈ V_k*
```

The identity is:

```text
D_ΓR_Γ^k[A]
=
ρ_P^k(J_P[A])
+
Q_A^k[A]
```

This is dual-space equality, not aggregate norm agreement.

---

## 10. Forbidden shortcuts

Do not use:

```text
component projections chosen after nulls
weights tuned to lower E_stress
H4 covectors that fail to annihilate span(B,O3)
Π covectors that ignore retained-order orientation
event-label assignment as substitute for dual derivation
```

---

## Next

```text
V1691.2 — Derive (D_A δ_B)^* and (D_A δ_S)^*
```

Branch and source adjoints are the simplest first cases before product, O3, H4, and Π.
