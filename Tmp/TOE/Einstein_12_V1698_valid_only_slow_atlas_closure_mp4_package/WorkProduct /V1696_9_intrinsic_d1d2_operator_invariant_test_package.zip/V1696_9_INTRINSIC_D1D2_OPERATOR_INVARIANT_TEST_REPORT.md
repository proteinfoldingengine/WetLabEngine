# V1696.9 — Intrinsic D1/D2 Operator Invariant Python Test

**Verdict:** `INTRINSIC_D1D2_OPERATOR_CLASS_DIAGNOSTIC_PRESENT_NO_LAW_CLAIM`

```json
{
  "class_cases": 180,
  "action_reduction_rate": 0.0,
  "coarse_class_defined_rate": 1.0,
  "mean_class_distance": 0.23836290308600788,
  "mean_coherence_score": 0.8088964288950176,
  "all_null_valid_beats_rate": 0.9854166666666667,
  "D1D2_scramble_valid_beats_rate": 0.9944444444444445,
  "D1D2_cross_swap_valid_beats_rate": 1.0,
  "commutator_zeroing_valid_beats_rate": 1.0,
  "angle_randomization_valid_beats_rate": 1.0,
  "support_shuffle_valid_beats_rate": 0.9,
  "order_scramble_valid_beats_rate": 0.9888888888888889,
  "orientation_flip_valid_beats_rate": 1.0,
  "class_broken_valid_beats_rate": 1.0
}
```
