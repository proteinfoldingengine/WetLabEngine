# V1688.80 — Single-Lineage Localized Field-Law Smoke Test

**Verdict:** `SINGLE_LINEAGE_LOCALIZED_FIELD_LAW_SMOKE_TEST_PASS_NOT_LIVE_VALIDATION`

This run generated a single internally compatible finite retained-flow toy ledger containing:

```text
nodes.csv
edges.csv
cycles.csv
cycle_node_map.csv
```

The purpose was to verify that the V1688.78 localized cycle-field contract can execute end-to-end when all required identities are present.

## Important claim boundary

This is **not** live-ledger validation.

The weak target was generated from deterministic synthetic conf/closure proxies that include native retained terms. Therefore this run is a **contract / pipeline smoke test**, not proof that the retained field law holds empirically.

## Frozen nodewise law tested

```text
weak_target(p) ≈ M0(p)
              + C_corr(p)
              + H_dir(p)
              + div_R J(p)
```

where:

```text
M0(p) = source_abs(p) + access_abs(p) + div_baseline(p)
H_dir(p) = localized native directional holonomy density
div_R J(p) = retained-order incidence continuity residual
```

## Results

```json
{
  "version": "V1688.80",
  "verdict": "SINGLE_LINEAGE_LOCALIZED_FIELD_LAW_SMOKE_TEST_PASS_NOT_LIVE_VALIDATION",
  "node_count": 100,
  "edge_count": 360,
  "cycle_count": 81,
  "cycle_node_map_rows": 324,
  "r2_M0": 0.7832301985407759,
  "r2_Ccorr": 0.9728447503572982,
  "r2_Hdir_local": 0.9942924435721523,
  "r2_full": 0.9947595234618872,
  "delta_Ccorr_over_M0": 0.18961455181652231,
  "delta_Hdir_over_Ccorr": 0.02144769321485407,
  "delta_continuity_over_Hdir": 0.00046707988973493375,
  "full_unique_over_Ccorr": 0.021914773104589003,
  "critical_null_max_unique_over_Ccorr": 0.021854694517465356,
  "observed_minus_critical_null": 6.007858712364644e-05,
  "claim_boundary": "This is a deterministic single-lineage contract/pipeline smoke test. weak_target was generated from synthetic conf/closure proxies that include native terms; therefore this is not empirical/live-ledger validation."
}
```

## Interpretation

The single-lineage ledger validates the mechanics required for the next real test:

```text
1. matching node IDs and edge endpoints
2. explicit cycles
3. cycle-to-node localization
4. localized H_dir(p)
5. retained-order incidence continuity
6. model comparison against M0 and C_corr
7. shuffle nulls
```

The observed full-basis gain over C_corr exceeds the simple shuffle nulls in this synthetic smoke test.

The next scientific step is not to celebrate this as discovery. The next step is to run the same contract on a non-constructed weak-form ledger or the live V1687 ordered-slice metrics ledger.
