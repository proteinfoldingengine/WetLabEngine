# V1698.55 - Retained Bianchi Compatibility Derivation

**Verdict:** `RETAINED_BIANCHI_COMPATIBILITY_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

Two interior stationarity attempts failed:

```text
V1698.52: R2-alone stationarity failed
V1698.54: coupled R2/R3 stationarity failed
```

That is a strong negative result.

It means the missing interior law is probably not:

```text
S_R2(e) = 0
```

and not:

```text
S_R2(e) + S_R3(e) = 0
```

## Core shift

Move from force balance:

```text
S_K(e) = 0
```

to compatibility identity:

```text
D_R K_R = 0
```

or, with provenance/source obstruction:

```text
D_R K_R = J_R
```

## Retained curvature complex

Path defect:

```text
F2(p,q,r) = T_qr T_pq - T_pr_ref
```

Cycle defect:

```text
F3(C) = product_C T - I
```

Retained curvature object:

```text
K_R = (F2, F3)
```

## Retained Bianchi identity

In a closed, filled, source-free retained interior:

```text
D_R K_R = 0
```

With source/provenance obstruction:

```text
D_R K_R = J_R
```

This is not saying the curvature defects vanish.

It says the defects are mutually compatible.

## Discrete retained Bianchi residual

For a retained 4-cycle cell:

```text
cell = (p,q,r,s,p)
```

compute path faces:

```text
F2(p,q,r)
F2(q,r,s)
F2(r,s,p)
F2(s,p,q)
```

Transport them to a common base algebra and form the alternating covariant sum:

```text
Alt_D_F2 = sum_i orientation_i Transport_i_to_base(F2_face_i)
```

Compute cycle holonomy:

```text
F3_cell = product around p->q->r->s->p - I
```

Then:

```text
B_R(cell) = Alt_D_F2 - F3_cell
```

Projected residual:

```text
B_hat_R(cell) = Pi_B(B_R(cell))
```

The closed-domain interior test should use:

```text
||B_hat_R||
```

not:

```text
||S_R2||
```

or:

```text
||S_R2 + S_R3||
```

## Why prior tests failed

R2 is not an independent law.

R3 is not merely a balancing force.

The correct interior object is an identity among defects.

## Next branch

```text
V1698.56 - Retained Bianchi Compatibility Test
```

Required:

```text
construct retained 4-cycle cells
compute F2 face defects
transport F2 defects to common base algebra
compute F3 cycle defect
compute B_R = Alt_D_F2 - F3
project trace-free
test valid vs nulls across size and invariance transforms
```

## Safe claim

The failure of R2 and R2/R3 stationarity moves the branch from force balance to compatibility identity. The next lawful object is retained Bianchi compatibility: `D_R K_R = 0` in closed source-free retained interiors, or `D_R K_R = J_R` when provenance/source current is present.
