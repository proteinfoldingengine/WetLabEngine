# V1698.56 - Retained Bianchi Compatibility Test

**Verdict:** `RETAINED_BIANCHI_COMPATIBILITY_TEST_FAIL_NO_LAW_CLAIM`

## Tested identity

```text
B_R(cell) = Alt_D_F2 - F3_cell
```

with trace-free projection:

```text
B_hat_R(cell) = Pi_B(B_R(cell))
```

## Summary

```json
{
  "version": "V1698.56",
  "verdict": "RETAINED_BIANCHI_COMPATIBILITY_TEST_FAIL_NO_LAW_CLAIM",
  "purpose": "Test retained Bianchi compatibility residual B_R(cell)=Alt_D_F2-F3_cell in closed-filled retained interiors.",
  "row_count": 90,
  "check_count": 15,
  "pass_rate": 0.0,
  "mean_lower_than_null_rate": 0.38666666666666677,
  "min_best_null_to_valid_ratio": 0.9243564134721536,
  "failure_count": 15,
  "mean_valid_cell_count": 4.0,
  "improved_over_V1698_52_R2_alone": false,
  "improved_over_V1698_54_coupled_stationarity": false,
  "improved_over_V1698_50_closed_pass_rate": false,
  "claim_boundary": "Retained Bianchi compatibility diagnostic only. No final law closure.",
  "runtime_seconds": 1.00754976272583
}
```
