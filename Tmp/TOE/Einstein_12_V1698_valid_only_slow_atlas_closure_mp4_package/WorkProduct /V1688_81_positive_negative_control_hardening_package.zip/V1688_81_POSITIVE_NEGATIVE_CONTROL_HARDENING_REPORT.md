# V1688.81 — Positive/Negative Control Hardening

**Verdict:** `CONTROL_HARDENING_PASS_HOLONOMY_SIGNAL_DETECTED_ONLY_WHEN_PRESENT`

V1688.80 proved the localized field-law pipeline executes, but the positive target was synthetic and included native retained terms. V1688.81 hardens the harness with paired controls.

## Controls

```text
positive control:
  weak target includes C_corr + localized H_dir + continuity

negative control:
  weak target includes source-flow + C_corr but not H_dir/continuity

source-only control:
  weak target includes source-flow only
```

## Main results

```json
{
  "version": "V1688.81",
  "verdict": "CONTROL_HARDENING_PASS_HOLONOMY_SIGNAL_DETECTED_ONLY_WHEN_PRESENT",
  "node_count": 144,
  "edge_count": 528,
  "cycle_count": 121,
  "positive_control": {
    "target": "weak_target_positive",
    "r2_M0": 0.9011707712942211,
    "r2_Ccorr": 0.9824174450829761,
    "r2_Hdir": 0.9975832474390155,
    "r2_full": 0.9976471755153261,
    "delta_Ccorr_over_M0": 0.08124667378875505,
    "delta_Hdir_over_Ccorr": 0.01516580235603937,
    "delta_continuity_over_Hdir": 6.392807631061537e-05,
    "holdout_full_unique_over_Ccorr": 0.02826732467749249
  },
  "negative_control": {
    "target": "weak_target_negative",
    "r2_M0": 0.9711002501670465,
    "r2_Ccorr": 0.9973937336805961,
    "r2_Hdir": 0.9973953425912334,
    "r2_full": 0.9974122420935797,
    "delta_Ccorr_over_M0": 0.026293483513549654,
    "delta_Hdir_over_Ccorr": 1.6089106372740858e-06,
    "delta_continuity_over_Hdir": 1.689950234629034e-05,
    "holdout_full_unique_over_Ccorr": -2.7375650652139427e-05
  },
  "source_only_control": {
    "target": "weak_target_source_only",
    "r2_M0": 0.9979402473797848,
    "r2_Ccorr": 0.9979416276311475,
    "r2_Hdir": 0.997945015764297,
    "r2_full": 0.9979451157794993,
    "delta_Ccorr_over_M0": 1.3802513626481883e-06,
    "delta_Hdir_over_Ccorr": 3.3881331494844957e-06,
    "delta_continuity_over_Hdir": 1.0001520234226291e-07,
    "holdout_full_unique_over_Ccorr": -6.748864346861616e-05
  },
  "positive_null": {
    "target": "weak_target_positive",
    "observed_unique_over_Ccorr": 0.015229730432349986,
    "null_mean": 0.0002506751880168001,
    "null_max": 0.0015353158479436413,
    "null_p95": 0.0007147123728805437,
    "observed_minus_null_max": 0.013694414584406345
  },
  "negative_null": {
    "target": "weak_target_negative",
    "observed_unique_over_Ccorr": 1.8508412983564426e-05,
    "null_mean": 3.787308232530595e-05,
    "null_max": 0.00018529694850777378,
    "null_p95": 0.0001061153446391405,
    "observed_minus_null_max": -0.00016678853552420936
  },
  "source_only_null": {
    "target": "weak_target_source_only",
    "observed_unique_over_Ccorr": 3.4881483518267586e-06,
    "null_mean": 3.0014130300302087e-05,
    "null_max": 0.0001811701655266562,
    "null_p95": 9.346376683590506e-05,
    "observed_minus_null_max": -0.00017768201717482945
  },
  "claim_boundary": "This remains a synthetic control hardening test. It validates that the localized field-law harness detects injected retained holonomy structure and mostly collapses on source-only controls; it is not live-ledger validation."
}
```

## Interpretation

The positive control shows localized holonomy contributes when the target actually contains retained holonomy structure.

The negative/source-only controls test whether the harness falsely invents holonomy signal from source structure alone.

This is still a synthetic test, not live validation. Its value is methodological: it confirms that the V1688.78/V1688.80 localized field-law harness is capable of distinguishing injected retained holonomy structure from targets where that structure is absent.

## Next

The next valid step is transfer to a non-constructed weak-form ledger with compatible:

```text
nodes
edges
cycles
cycle_node_map
weak_target
M0 fields
C_corr
state/Z or c_pq
```
