# V1698.49 - Signed Closure Invariance and Size Hardening

**Verdict:** `SIGNED_CLOSURE_INVARIANCE_SIZE_HARDENING_SIGNAL_PRESENT_NO_LAW_CLAIM`

## Tested residual

```text
C_signed(eta) = deltaA_R(eta) - <B_boundary, gamma_dR eta>_dR
```

## Hardening scope

```text
sizes: 3x4, 4x5, 5x6
domains: open, closed_filled
transforms: baseline, node_relabel, basis_transform, orientation_reversal, coord_embedding_shuffle
nulls: source/order/support/edge/cycle
```

## Summary

```json
{
  "version": "V1698.49",
  "verdict": "SIGNED_CLOSURE_INVARIANCE_SIZE_HARDENING_SIGNAL_PRESENT_NO_LAW_CLAIM",
  "purpose": "Harden V1698.48 signed closure residual across size, seed, null, and invariance transforms.",
  "row_count": 900,
  "check_count": 30,
  "pass_rate": 0.8333333333333334,
  "open_pass_rate": 0.9333333333333333,
  "closed_pass_rate": 0.7333333333333333,
  "mean_lower_than_null_rate": 0.9866666666666667,
  "min_best_null_to_valid_ratio": 0.6754114204375882,
  "claim_boundary": "Hardening audit only. No final law closure.",
  "runtime_seconds": 15.951523542404175
}
```
