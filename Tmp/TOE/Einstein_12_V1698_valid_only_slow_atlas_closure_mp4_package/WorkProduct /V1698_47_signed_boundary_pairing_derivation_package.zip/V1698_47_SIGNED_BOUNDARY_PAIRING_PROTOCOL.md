# V1698.47 - Signed Boundary Pairing Derivation

**Verdict:** `SIGNED_BOUNDARY_PAIRING_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

V1698.46 passed structural closure gates but failed clean open-domain residual separation.

The failed proxy was:

```text
C_stack = ||delta A_R| - |B_boundary||
```

That is not a variational boundary identity. It destroys sign, direction, orientation, and dual pairing.

## Correct object

The boundary current must be a covector acting on the boundary trace of the admissible variation:

```text
C_signed(eta)
=
delta A_R[eta]
-
<B_boundary, gamma_dR eta>_dR
```

where:

```text
gamma_dR eta
```

is the retained boundary trace of the variation.

## Boundary traces

Edge trace:

```text
gamma1_eta(e)
=
dR1(e) * <A_e_hat, eta_e>
```

Path trace:

```text
gamma2_path_eta(path)
=
dR2_path_star(path) * sum_edges_in_path <A_e_hat, eta_e>
```

Cycle trace:

```text
gamma2_cycle_eta(C)
=
dR2_cycle_star(C) * sum_edges_in_cycle orientation(e,C)<A_e_hat, eta_e>
```

Source trace:

```text
gammaS_eta(e)
=
dR1(e) * Delta_S(e) * tr_log_variation_eta(T_e)
```

## Signed boundary covectors

```text
J_dR(e) = sign(dR1(e)) * edge_residual(e)
```

```text
S_dR(e) = sign(dR1(e)) * Delta_S(e) * tr_log(T_e)
```

```text
P_dR(path) = sign(dR2_path_star(path)) * R2(path)
```

```text
C_dR(C) = sign(dR2_cycle_star(C)) * R3(C)
```

## Signed pairing

```text
Boundary_pairing(eta)
=
sum_e J_dR(e) gamma1_eta(e)
+
sum_e S_dR(e) gammaS_eta(e)
+
sum_path P_dR(path) gamma2_path_eta(path)
+
sum_cycle C_dR(C) gamma2_cycle_eta(C)
```

Closure residual:

```text
C_signed(eta)
=
deltaA_R(eta)
-
Boundary_pairing(eta)
```

## Next branch

```text
V1698.48 - Signed Boundary Pairing Closure Test
```

Required:

```text
compute signed boundary traces
compute signed boundary covectors
compute C_signed
test open/closed domains
test source/order/support/edge/cycle nulls
no fitted coefficients
```

## Safe claim

The integrated stack failed open closure because it compared scalar norms. The correct closure object is a signed dual pairing between the retained boundary current and the boundary trace of the admissible variation.
