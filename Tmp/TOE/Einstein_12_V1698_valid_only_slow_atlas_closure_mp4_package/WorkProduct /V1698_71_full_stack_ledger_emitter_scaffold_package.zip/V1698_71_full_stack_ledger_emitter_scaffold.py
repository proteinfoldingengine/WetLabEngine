#!/usr/bin/env python3
"""
V1698.71 Full-Stack Ledger Emitter Scaffold
===========================================

Emits a complete retained ledger satisfying V1698.70 schema.

Purpose:
    Create all required full-stack clean-room tables before scoring:
        run_manifest
        C0_nodes
        C1_edges
        Gamma_R_connection
        R2_path_faces
        R3_cycle_faces
        W1_edge_witnesses
        W2_face_witnesses
        W3_cell_witnesses
        J_R_source_current
        boundary_operator
        signed_boundary_pairing
        W3_bianchi_residuals
        null_transform_log
        gate_checks

This is a scaffold, not a final empirical emitter.
It is intentionally ledger-complete so the V1698.70 validator can reject/accept on schema and referential integrity.
"""

from __future__ import annotations
from pathlib import Path
import argparse, csv, json, hashlib, math
import numpy as np

CONTRACT_HASH = "940f448ed7fd6585"

def h(*x, n=16):
    return hashlib.sha256("|".join(map(str,x)).encode()).hexdigest()[:n]

def mat_s(M):
    M=np.asarray(M,float)
    return json.dumps(np.round(M,6).tolist())

def vec_s(v):
    return json.dumps(np.round(np.asarray(v,float),6).tolist())

def tfree(M):
    M=np.asarray(M,float)
    return M - np.trace(M)/M.shape[0]*np.eye(M.shape[0])

def nrm(M):
    return float(np.linalg.norm(np.asarray(M,float)))

def write_csv(path, rows, cols):
    with open(path,"w",newline="") as f:
        w=csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c:r.get(c,"") for c in cols})

def node_id(r,c,cols):
    return r*cols+c

def build_nodes(rows, cols, seed):
    rng=np.random.default_rng(seed)
    out=[]
    for r in range(rows):
        for c in range(cols):
            nid=node_id(r,c,cols)
            source=float(np.sin(0.31*r)+np.cos(0.27*c)+0.01*rng.normal())
            support=np.array([r,c,r+c,r-c],float)
            order=np.array([nid,r,c,r*cols+c],float)
            sig=h("C0",nid,round(source,6),vec_s(support),vec_s(order))
            out.append({
                "node_id":nid,
                "coord":(r,c),
                "ordered_index":nid,
                "source_value":source,
                "support_vector":vec_s(support),
                "retained_order_vector":vec_s(order),
                "generated_algebra_signature":sig,
                "local_signature_SigOD":round(source+0.01*(r-c),8),
                "parent_event_ids":h("event",nid)
            })
    return out

def get_node(nodes,nid):
    return next(x for x in nodes if int(x["node_id"])==nid)

def parse_vec(s):
    return np.array(json.loads(s),float)

def build_edges(nodes, rows, cols, seed, domain):
    out=[]
    for r in range(rows):
        for c in range(cols):
            p=node_id(r,c,cols)
            nbrs=[]
            if c+1<cols: nbrs.append(node_id(r,c+1,cols))
            if r+1<rows: nbrs.append(node_id(r+1,c,cols))
            if domain=="closed_filled":
                if c-1>=0: nbrs.append(node_id(r,c-1,cols))
                if r-1>=0: nbrs.append(node_id(r-1,c,cols))
            for q in nbrs:
                P=get_node(nodes,p); Q=get_node(nodes,q)
                rng=np.random.default_rng(seed+p*1009+q*9176)
                sd=float(Q["source_value"]-P["source_value"])
                supp=parse_vec(Q["support_vector"])-parse_vec(P["support_vector"])
                order=parse_vec(Q["retained_order_vector"])-parse_vec(P["retained_order_vector"])
                A=0.01*rng.normal(size=(4,4))+0.001*np.outer(supp,np.ones(4))+0.001*np.outer(np.ones(4),order)
                T=np.eye(4)+A
                eid=h("C1",p,q,round(sd,6),vec_s(supp),vec_s(order))
                reverse = q < p
                boundary_exposure = 0.1 if domain=="closed_filled" else 1.0
                out.append({
                    "edge_id":eid,
                    "p":p,
                    "q":q,
                    "T_pq":mat_s(T),
                    "A_pq":mat_s(A),
                    "source_delta":sd,
                    "support_delta":vec_s(supp),
                    "order_delta":vec_s(order),
                    "edge_package_signature":h("edgepkg",eid),
                    "parent_event_ids":f'{P["parent_event_ids"]};{Q["parent_event_ids"]}',
                    "boundary_exposure":boundary_exposure,
                    "orientation":-1 if reverse else 1
                })
    return out

def edge_lookup(edges):
    return {(int(e["p"]),int(e["q"])):e for e in edges}

def T(e): return np.array(json.loads(e["T_pq"]),float)

def build_gamma(edges):
    rows=[]
    for e in edges:
        fid=h("Gamma",e["edge_id"])
        rows.append({
            "edge_id":e["edge_id"],
            "from_algebra":e["p"],
            "to_algebra":e["q"],
            "transition_matrix":e["T_pq"],
            "generator_map":h("genmap",e["edge_id"]),
            "faithfulness_defect":0.0,
            "connection_signature":fid
        })
    return rows

def candidate_cycles(edges, limit=20):
    E=edge_lookup(edges)
    adj={}
    for (p,q) in E:
        adj.setdefault(p,set()).add(q)
    cycles=set()
    for p in adj:
        for q in adj.get(p,[]):
            for r in adj.get(q,[]):
                if r in (p,q): continue
                for s in adj.get(r,[]):
                    if s in (p,q,r): continue
                    if p in adj.get(s,[]):
                        body=[p,q,r,s]
                        can=min(tuple(body[k:]+body[:k]) for k in range(4))
                        cycles.add(can+(can[0],))
                        if len(cycles)>=limit:
                            return list(cycles)
    return list(cycles)

def build_R2(edges, cycles):
    E=edge_lookup(edges)
    rows=[]
    for cy in cycles:
        p,q,r,s,_=cy
        triples=[(p,q,r),(q,r,s),(r,s,p),(s,p,q)]
        for a,b,c in triples:
            if (a,b) not in E or (b,c) not in E: continue
            Tab=T(E[(a,b)]); Tbc=T(E[(b,c)])
            if (a,c) in E:
                Ref=T(E[(a,c)]); ref=E[(a,c)]["edge_id"]; mode="direct"
            else:
                Ref=np.eye(4); ref="identity"; mode="identity_fallback"
            F=tfree(Tbc@Tab-Ref)
            fid=h("R2",a,b,c,ref)
            rows.append({
                "face_id":fid,
                "p":a,"q":b,"r":c,
                "edge_pq":E[(a,b)]["edge_id"],
                "edge_qr":E[(b,c)]["edge_id"],
                "reference_pr":ref,
                "F2_matrix":mat_s(F),
                "F2_projection_signature":h("Pi2",fid,round(nrm(F),8)),
                "path_reference_mode":mode,
                "face_orientation":1
            })
    return rows

def build_R3(edges, cycles):
    E=edge_lookup(edges)
    rows=[]
    for cy in cycles:
        H=np.eye(4); edge_ids=[]
        ok=True
        for a,b in zip(cy[:-1],cy[1:]):
            if (a,b) not in E:
                ok=False; break
            H=T(E[(a,b)])@H
            edge_ids.append(E[(a,b)]["edge_id"])
        if not ok: continue
        F=tfree(H-np.eye(4))
        cid=h("R3",cy,edge_ids)
        rows.append({
            "cycle_id":cid,
            "ordered_edge_ids":";".join(edge_ids),
            "cycle_nodes":";".join(map(str,cy)),
            "holonomy_matrix":mat_s(H),
            "F3_matrix":mat_s(F),
            "F3_projection_signature":h("Pi3",cid,round(nrm(F),8)),
            "cycle_orientation":1
        })
    return rows

def build_W1(edges):
    rows=[]
    for e in edges:
        wid=h("W1",e["edge_id"],e["source_delta"],e["support_delta"],e["order_delta"])
        rows.append({
            "W1_id":wid,
            "edge_id":e["edge_id"],
            "p":e["p"],"q":e["q"],
            "source_delta":e["source_delta"],
            "support_delta":e["support_delta"],
            "order_delta":e["order_delta"],
            "generator_image_hash":h("genimg",e["edge_id"]),
            "ordered_index_span":f'{e["p"]}->{e["q"]}',
            "parent_event_ids":e["parent_event_ids"],
            "W1_signature":wid
        })
    return rows

def w1_by_edge(W1): return {w["edge_id"]:w for w in W1}

def build_W2(cycles, edges, W1):
    E=edge_lookup(edges); W=w1_by_edge(W1); rows=[]
    for cy in cycles:
        edge_ids=[]
        ok=True
        for a,b in zip(cy[:-1],cy[1:]):
            if (a,b) not in E: ok=False; break
            edge_ids.append(E[(a,b)]["edge_id"])
        if not ok: continue
        wids=[W[eid]["W1_id"] for eid in edge_ids]
        fid=h("face",cy)
        wid=h("W2",fid,wids)
        rows.append({
            "W2_id":wid,
            "face_id":fid,
            "ordered_edge_sequence":";".join(edge_ids),
            "edge_witness_ids":";".join(wids),
            "source_assignment":";".join(str(W[eid]["source_delta"]) for eid in edge_ids),
            "support_assignment":";".join(W[eid]["support_delta"] for eid in edge_ids),
            "order_assignment":";".join(W[eid]["order_delta"] for eid in edge_ids),
            "path_reference_id":h("pathref",fid),
            "fill_signature":wid,
            "fill2":"true"
        })
    return rows

def build_W3(W2):
    rows=[]
    for w2 in W2:
        cid=h("cell",w2["face_id"])
        wid=h("W3",cid,w2["W2_id"])
        rows.append({
            "W3_id":wid,
            "cell_id":cid,
            "face_witness_ids":w2["W2_id"],
            "boundary_orientation":"oriented_shell",
            "cell_source_current_JR":0.0,
            "order_consistency_signature":h("order",w2["order_assignment"]),
            "support_consistency_signature":h("support",w2["support_assignment"]),
            "filling_signature":wid,
            "fill3":"true"
        })
    return rows

def build_JR(W3):
    return [{
        "cell_id":w["cell_id"],
        "JR_value":w["cell_source_current_JR"],
        "JR_matrix_or_component":"0",
        "source_free_flag":"true",
        "provenance_obstruction_signature":h("JR",w["cell_id"])
    } for w in W3]

def build_boundary_operator(edges, W2, W3):
    rows=[]
    for e in edges:
        rows.append({
            "object_id":e["edge_id"],
            "object_dim":1,
            "boundary_ids":f'{e["p"]};{e["q"]}',
            "orientation_signs":"-1;1",
            "boundary_exposure":e["boundary_exposure"],
            "gamma_dR_component":e["edge_package_signature"],
            "B_boundary_component":h("Bbdry",e["edge_id"])
        })
    for w in W2:
        rows.append({
            "object_id":w["face_id"],
            "object_dim":2,
            "boundary_ids":w["ordered_edge_sequence"],
            "orientation_signs":";".join(["1"]*len(w["ordered_edge_sequence"].split(";"))),
            "boundary_exposure":0,
            "gamma_dR_component":w["fill_signature"],
            "B_boundary_component":h("Bbdry",w["face_id"])
        })
    return rows

def build_signed_boundary_pairing(edges, domain):
    rows=[]
    variations=["source","order","support","boundary","harmonic"]
    for v in variations:
        vals=[]
        for e in edges:
            deltaA=0.0
            bd=float(e["boundary_exposure"])*float(e["orientation"])
            if v=="source":
                gamma=float(e["source_delta"])
            elif v=="order":
                gamma=nrm(np.array(json.loads(e["order_delta"]),float))
            elif v=="support":
                gamma=nrm(np.array(json.loads(e["support_delta"]),float))
            elif v=="boundary":
                gamma=nrm(tfree(T(e)-np.eye(4)))
            else:
                gamma=nrm(tfree(T(e)@T(e).T-np.eye(4)))
            pairing=bd*gamma
            C=deltaA-pairing
            vals.append(abs(C))
        case_id=h("signed",domain,v)
        rows.append({
            "case_id":case_id,
            "variation":v,
            "deltaA_R":0.0,
            "boundary_pairing":float(np.mean(vals)) if vals else 0.0,
            "C_signed":-(float(np.mean(vals)) if vals else 0.0),
            "C_signed_abs":float(np.mean(vals)) if vals else 0.0,
            "domain":domain
        })
    return rows

def build_bianchi(W3, R2, R3):
    # scaffold: map W3 rows to available R3 cycle rows and aggregate R2 signatures
    rows=[]
    for i,w3 in enumerate(W3):
        r3=R3[i % len(R3)] if R3 else None
        F3 = r3["F3_matrix"] if r3 else mat_s(np.zeros((4,4)))
        Alt = mat_s(np.zeros((4,4)))
        B = mat_s(np.zeros((4,4)))
        rows.append({
            "cell_id":w3["cell_id"],
            "W3_id":w3["W3_id"],
            "Alt_D_F2":Alt,
            "F3_cell":F3,
            "JR":w3["cell_source_current_JR"],
            "B_R_matrix":B,
            "B_R_norm":0.0,
            "projection_signature":h("BR",w3["W3_id"])
        })
    return rows

def build_null_log(mode):
    family="valid" if mode=="valid" else ("filling" if mode in ["source_shuffle","order_shuffle","support_shuffle"] else "curvature")
    changed={
        "valid":"",
        "source_shuffle":"C0_nodes.source_value",
        "order_shuffle":"C0_nodes.retained_order_vector",
        "support_shuffle":"C0_nodes.support_vector",
        "edge_package_shuffle":"C1_edges.edge_package_signature;Gamma_R_connection",
        "cycle_package_shuffle":"R3_cycle_faces;W3_bianchi_residuals"
    }.get(mode,"")
    expected={
        "valid":"none",
        "source_shuffle":"W3 filling admissibility",
        "order_shuffle":"W3 filling admissibility",
        "support_shuffle":"W3 filling admissibility",
        "edge_package_shuffle":"Bianchi curvature compatibility",
        "cycle_package_shuffle":"Bianchi curvature compatibility"
    }.get(mode,"")
    return [{
        "mode":mode,
        "null_family":family,
        "changed_tables":changed,
        "preserved_tables":"contract;thresholds;gate_definitions",
        "expected_failure_channel":expected,
        "null_signature":h("null",mode,family,changed)
    }]

def build_gate_checks(domain, size_label, transform):
    # scaffold emits a passing full-stack gate row; real emitter must recompute from null groups.
    return [{
        "domain":domain,
        "size_label":size_label,
        "transform":transform,
        "mode_group":"integrated",
        "valid_W3_count":1,
        "signed_residual_lower_than_null_rate":1.0,
        "filling_null_W3_corrupt_rate":1.0,
        "curvature_null_B_corrupt_rate":1.0,
        "passed":"true"
    }]

def emit(root, rows_n, cols_n, seed, domain, transform, mode):
    root=Path(root); root.mkdir(parents=True,exist_ok=True)
    size_label=f"{rows_n}x{cols_n}"
    nodes=build_nodes(rows_n,cols_n,seed)
    edges=build_edges(nodes,rows_n,cols_n,seed,domain)
    cycles=candidate_cycles(edges)
    gamma=build_gamma(edges)
    R2=build_R2(edges,cycles)
    R3=build_R3(edges,cycles)
    W1=build_W1(edges)
    W2=build_W2(cycles,edges,W1)
    W3=build_W3(W2)
    JR=build_JR(W3)
    BO=build_boundary_operator(edges,W2,W3)
    SB=build_signed_boundary_pairing(edges,domain)
    BR=build_bianchi(W3,R2,R3)
    NL=build_null_log(mode)
    GC=build_gate_checks(domain,size_label,transform)
    manifest=[{
        "run_id":h("run",seed,domain,size_label,transform,mode),
        "contract_hash":CONTRACT_HASH,
        "emitter_version":"V1698.71_scaffold",
        "seed":seed,
        "domain":domain,
        "size_label":size_label,
        "transform":transform,
        "mode":mode,
        "null_family":NL[0]["null_family"],
        "created_order_index":seed
    }]
    tables=[
        ("run_manifest",manifest),
        ("C0_nodes",nodes),
        ("C1_edges",edges),
        ("Gamma_R_connection",gamma),
        ("R2_path_faces",R2),
        ("R3_cycle_faces",R3),
        ("W1_edge_witnesses",W1),
        ("W2_face_witnesses",W2),
        ("W3_cell_witnesses",W3),
        ("J_R_source_current",JR),
        ("boundary_operator",BO),
        ("signed_boundary_pairing",SB),
        ("W3_bianchi_residuals",BR),
        ("null_transform_log",NL),
        ("gate_checks",GC)
    ]
    for name,rows in tables:
        if not rows:
            rows=[{}]
        cols=list(rows[0].keys()) if rows and rows[0] else []
        write_csv(root/f"{name}.csv",rows,cols)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--outdir",default="V1698_71_full_stack_ledger")
    ap.add_argument("--rows",type=int,default=3)
    ap.add_argument("--cols",type=int,default=4)
    ap.add_argument("--seed",type=int,default=169871)
    ap.add_argument("--domain",default="closed_filled",choices=["open","closed_filled"])
    ap.add_argument("--transform",default="baseline")
    ap.add_argument("--mode",default="valid")
    args=ap.parse_args()
    emit(args.outdir,args.rows,args.cols,args.seed,args.domain,args.transform,args.mode)
    print(json.dumps({"verdict":"FULL_STACK_LEDGER_EMITTED","outdir":args.outdir},indent=2))

if __name__=="__main__":
    main()
