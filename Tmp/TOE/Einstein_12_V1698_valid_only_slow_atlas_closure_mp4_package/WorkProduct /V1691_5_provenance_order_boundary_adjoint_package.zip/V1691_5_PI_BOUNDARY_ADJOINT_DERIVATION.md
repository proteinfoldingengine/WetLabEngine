# V1691.5 — Provenance/Order Incidence Adjoint and Boundary Summation-by-Parts

**Verdict:** `PI_ADJOINT_AND_BOUNDARY_MAP_DERIVED_NO_EXECUTION`

## Purpose

V1691.2–V1691.4 derived the component adjoints for:

```text
B
S
⊕
O3
H4
```

The remaining pieces are:

```text
(D_A δ_Π)^*
```

and the exact boundary summation-by-parts map that produces:

```text
Q_A(∂C)
```

---

## 1. Provenance/order incidence space

Let `Π_p` be the retained-order provenance ledger.

Define cochains:

```text
C0 = node/component cochains over generated algebras
C1 = edge/generator cochains A_e
C2 = loop/cell comparison cochains
```

Let:

```text
d_Π
```

be the oriented incidence/coboundary operator induced by retained dependencies.

The `Π` inner product is:

```text
⟨P,Q⟩_Π
=
Σ_e ω_e P_e Q_e
+
Σ_path ω_path P_path Q_path
```

with signs inherited from retained-order incidence.

Weights are allowed to depend on:

```text
ledger confidence
source provenance
dependency support
ordered-index validity
```

They may not depend on:

```text
E_source
E_stress
null performance
```

---

## 2. Provenance/order residual

Define:

```text
δ_Π[A]_e
=
d_Π(A)_e
−
J_Π,e
```

This means:

```text
A-induced order/provenance incidence
minus
ledger current incidence
```

For an admissible variation:

```text
A → A + εΞ
```

the variation is:

```text
D_Aδ_Π[Ξ]
=
d_Π(Ξ)
```

The adjoint is defined by:

```text
⟨d_ΠΞ, R_Π⟩_Π
=
⟨Ξ, d_Π^*R_Π⟩_A
```

So:

```text
(D_Aδ_Π)^*R_Π
=
d_Π^*R_Π
```

This is the exact provenance/order incidence adjoint.

---

## 3. Discrete summation-by-parts

The action variation has edge form:

```text
δI
=
Σ_edges ⟨Ξ_e, G_e⟩_A
```

where:

```text
G_e
=
Grad_faith,e
+
Grad_order,e
+
Grad_reg,e
```

For a comparison cell or loop `C`, the boundary is:

```text
∂C = signed list of edges
```

with signs:

```text
σ(C,e) ∈ {−1,+1}
```

The boundary trace is:

```text
Tr_∂C(G)
=
Σ_{e∈∂C}
σ(C,e) τ_{e→C}(G_e)
```

where:

```text
τ_{e→C}
```

is the admissible dual transport that moves edge covectors into the common comparison-boundary dual frame.

Then:

```text
Q_A(∂C)
=
Tr_∂C(
  Grad_faith
  +
  Grad_order
  +
  Grad_reg
)
```

This is the missing exact object.

`Q_A` is not a scalar correction.

It is a boundary cochain in:

```text
V_G*
```

---

## 4. Component boundary form

For each component:

```text
k ∈ {B, ⊕, O3, H4, S, Π}
```

define:

```text
Q_A^k(∂C)
=
Σ_{e∈∂C}
σ(C,e) τ_{e→C}(G_e^k)
```

where:

```text
G_e^k
=
2w_k(D_Aδ_k)^*δ_k
```

for faithfulness components, plus order/regularity components where applicable.

The component-resolved identity is:

```text
D_ΓR_Γ^k(C)
=
ρ_P^k(J_P,C)
+
Q_A^k(∂C)
```

This is equality in:

```text
V_k*
```

not scalar norm agreement.

---

## 5. Dual transport requirement

Primal transport is:

```text
T_pq = Exp_R(A_pq)
```

Dual transport maps covectors in the reverse direction according to the component inner products.

Boundary covectors from different edges may only be summed after:

```text
dual-frame alignment
```

That is:

```text
τ_{e→C}(G_e)
```

V1690 failed partly because it summed projected objects without this exact dual transport.

---

## 6. Validity rules for Q_A

`Q_A` is valid only if it:

```text
is built from exact component adjoints
uses signed boundary incidence σ(C,e)
uses dual transport τ_e→C
does not use E_source or E_stress
vanishes when supporting edge stress covectors vanish
```

Invalid:

```text
Q_A = E_source
Q_A proportional to gradient norms only
Q_A ignoring boundary orientation
Q_A summing edge stresses without dual-frame alignment
Q_A using null performance feedback
```

---

## 7. Stationarity to boundary identity

Interior stationarity is:

```text
Grad_total_e = 0
```

on admissible interior variations.

The boundary equation is:

```text
D_ΓR_Γ(C)
−
ρ_P(J_P,C)
−
Q_A(∂C)
=
0
```

So the general identity is:

```text
D_ΓR_Γ
=
ρ_P(J_P)
+
Q_A
```

Source-balanced closure is the special case:

```text
Q_A = 0
```

Source-free closure is the special case:

```text
Q_A = 0
and
J_P = 0
```

---

## Final statement

V1691.5 derives the missing bridge:

```text
Q_A is the exact signed dual-transported boundary trace of admissibility stress.
```

This is the object V1690 lacked.

## Next

```text
V1691.6 — Consolidated Exact Component Identity and Execution Specification
```
