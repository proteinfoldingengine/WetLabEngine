# V1698.59 - Provenance-Witness Filling Rule Derivation

**Verdict:** `PROVENANCE_WITNESS_FILLING_RULE_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

V1698.58 failed because circulation-only admissibility was too weak:

```text
mean_source_order_support_fill_corrupt_rate = 0.0
```

That means source/order/support shuffles did not corrupt `fill3`.

The reason is simple:

```text
closed-loop circulation can vanish by telescoping
```

even when local provenance has been destroyed.

## Core correction

Wrong rule:

```text
fill2/fill3 certified by net circulation around a graph loop
```

Correct rule:

```text
fill2/fill3 certified by explicit retained provenance witnesses
```

A retained filling is not a graph fact.

It is a provenance fact.

## Witness objects

### Edge witness

```text
W1(p,q)
```

certifies that transition `p -> q` transports:

```text
source
support
retained-order
generated algebra image
```

with admissible local provenance.

### Face witness

```text
W2(face)
```

certifies that a face has coherent retained filling, not merely zero net circulation.

It includes:

```text
ordered edge witness chain
source assignment
support assignment
order assignment
path reference id
fill signature
```

### Cell witness

```text
W3(cell)
```

certifies that a cell is filled by admissible faces with compatible provenance/source assignment.

It includes:

```text
face witness ids
boundary orientation
cell source current J_R
order consistency signature
support consistency signature
filling signature
```

## Dependency rule

Witnesses compose by retained ordered dependency, not merely matching endpoints.

For a face:

```text
parent_event_ids(e_{i+1})
must descend from or depend on the retained event state produced by e_i
```

For a cell:

```text
shared faces/edges must match by witness id and opposite orientation
```

not just by node labels.

This is what source/order/support shuffles should break.

## Corrected admissibility

```text
fill2(face)=1
iff W2(face) exists or is constructible from dependency-consistent W1 records
```

```text
fill3(cell)=1
iff W3(cell) exists or is constructible from dependency-consistent W2 records
```

## Corrected Bianchi domain

Only test:

```text
fill3(cell)=1
```

cells.

Then:

```text
D_R K_R(cell) = J_R(cell)
```

Residual:

```text
B_R(cell)
=
Pi_B(Alt_D_F2 - F3_cell - J_R(cell))
```

Graph cycles with no W3 are not interior cells.

They are boundary/exterior objects.

## Why this preserves full stack

Without the full stack, there is no way to know whether a loop is a true retained interior cell.

The witness rule uses:

```text
generated algebra
Gamma_R transition
source/provenance density
support cochain
retained-order cochain
boundary/exterior status
Bianchi compatibility
```

## Next branch

```text
V1698.60 - Provenance-Witness Filling Construction Test
```

Required:

```text
emit W1 edge witnesses
construct W2 face witnesses by dependency composition
construct W3 cell witnesses from oriented W2 shells
apply source/order/support/edge/cycle nulls
verify nulls break witness matching
compute Bianchi residual only on W3-certified cells
```

## Safe claim

The filling complex cannot be derived from graph cycles or net circulation alone. A retained interior cell requires explicit provenance witnesses W1/W2/W3 that certify local dependency, support/order transport, source assignment, and filling identity.
