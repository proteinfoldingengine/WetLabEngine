# V1698.53 - R2/R3 Coupled Interior Curvature Stationarity Derivation

**Verdict:** `R2_R3_COUPLED_INTERIOR_CURVATURE_STATIONARITY_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

V1698.52 failed:

```text
R2_INTERIOR_STATIONARITY_TEST_FAIL_NO_LAW_CLAIM
```

The key result was:

```text
R2-alone pass_rate = 0.0
```

So R2 should not be promoted as an independent interior law.

## Correct interpretation

R2 is a path-composition compatibility component.

R3 is a cycle/holonomy compatibility component.

An interior edge belongs to both path faces and cycle loops.

Therefore the closed-domain stationarity equation should not be:

```text
S_R2(e) = 0
```

It should be:

```text
S_K(e) = S_R2(e) + S_R3(e) = 0
```

## Coupled retained curvature object

Path residual:

```text
F2_alpha = Pi2(T_qr T_pq - T_pr_ref)
```

Cycle residual:

```text
F3_beta = Pi3(product_beta T - I)
```

Coupled retained curvature:

```text
K_R = {F2_alpha, F3_beta}
```

## Interior stationarity equation

For every retained interior edge `e`:

```text
S_K(e)
=
sum_alpha D_{e,alpha}^* F2_alpha
+
sum_beta D_{e,beta}^* F3_beta
```

Stationarity requires:

```text
S_K(e) = 0
```

## Cycle adjoint

For a cycle:

```text
beta = v0 -> v1 -> ... -> vk = v0
```

with holonomy:

```text
H_beta = T_{v_{k-1}v_k} ... T_{v0v1} - I
```

If edge `e_j` varies:

```text
D_e H_beta[delta T_e]
=
T_after delta T_e T_before
```

The adjoint is:

```text
D_e^*(Y)
=
T_after^* Y T_before^*
```

## No fitted coupling

Do not introduce a fitted R2/R3 weight.

Use structural normalization only:

```text
F2 normalized by path support count
F3 normalized by cycle support count
```

Both are pulled into the same edge-cotangent space and summed there.

## Next branch

```text
V1698.54 - Coupled R2/R3 Interior Curvature Stationarity Test
```

Required:

```text
compute F2 path residuals
compute F3 cycle holonomy residuals
project both trace-free
pull both back by adjoints
sum S_K(e)=S_R2(e)+S_R3(e)
test valid vs nulls across size and invariance transforms
```

## Safe claim

R2-alone stationarity failed, so R2 should not be promoted as an independent law. The next lawful object is coupled retained curvature stationarity: the edge-adjoint balance of path-composition and cycle-holonomy defects.
