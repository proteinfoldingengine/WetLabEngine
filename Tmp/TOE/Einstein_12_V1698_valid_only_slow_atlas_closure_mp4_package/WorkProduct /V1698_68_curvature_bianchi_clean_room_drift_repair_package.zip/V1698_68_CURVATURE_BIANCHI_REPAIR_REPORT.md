# V1698.68 - Curvature Bianchi Clean-Room Drift Repair

**Verdict:** `CURVATURE_BIANCHI_REPAIR_NO_IMPROVEMENT_DRIFT_REMAINS`

## Repair rule

```text
No thresholds changed.
No null names changed.
No gate weakened.
Only curvature/Bianchi retained transition package exactness changed.
```

## Old clean-room result

```json
{
  "verdict": "REPLICATION_FAIL_NO_LAW_CLAIM",
  "pass_rate": 0.3333333333333333,
  "open_pass_rate": 0.0,
  "closed_filled_pass_rate": 0.6666666666666666
}
```

## Repaired clean-room result

```json
{
  "contract_hash": "45a923ea0421a1a3",
  "verdict": "REPLICATION_FAIL_NO_LAW_CLAIM",
  "pass_rate": 0.16666666666666666,
  "open_pass_rate": 0.0,
  "closed_filled_pass_rate": 0.3333333333333333,
  "check_count": 30,
  "checks": [
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "3x4",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "baseline",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "node_relabel",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "orientation_reversal",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "3x4",
      "transform": "basis_transform",
      "valid_W3_count": 12,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "4x5",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "baseline",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "node_relabel",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.5,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "orientation_reversal",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.75,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "4x5",
      "transform": "basis_transform",
      "valid_W3_count": 24,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "baseline",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "node_relabel",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "orientation_reversal",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "open",
      "size_label": "5x6",
      "transform": "basis_transform",
      "valid_W3_count": 0,
      "signed_residual_lower_than_null_rate": 0.6,
      "filling_null_W3_corrupt_rate": 0.0,
      "curvature_null_B_corrupt_rate": 0.0,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "baseline",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "node_relabel",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "coord_embedding_shuffle",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "orientation_reversal",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 1.0,
      "passed": true
    },
    {
      "domain": "closed_filled",
      "size_label": "5x6",
      "transform": "basis_transform",
      "valid_W3_count": 40,
      "signed_residual_lower_than_null_rate": 0.8,
      "filling_null_W3_corrupt_rate": 1.0,
      "curvature_null_B_corrupt_rate": 0.25,
      "passed": false
    }
  ]
}
```

## Gate diagnostics

```json
{
  "signed_mean": 0.7666666666666669,
  "filling_mean": 0.5,
  "curvature_mean": 0.18333333333333332,
  "signed_pass_rate": 0.8333333333333334,
  "filling_pass_rate": 0.5,
  "curvature_pass_rate": 0.16666666666666666
}
```

## Interpretation

The repair replaces pure transition-matrix curvature with retained transition-package curvature:

```text
Gamma_R edge package = T_pq + retained edge-package signature
```

This makes edge/cycle package nulls disrupt the retained curvature object rather than only changing a weak matrix proxy.

## Next

```text
V1698.69 - Clean-Room Exact Replication or Remaining Drift Postmortem
```
