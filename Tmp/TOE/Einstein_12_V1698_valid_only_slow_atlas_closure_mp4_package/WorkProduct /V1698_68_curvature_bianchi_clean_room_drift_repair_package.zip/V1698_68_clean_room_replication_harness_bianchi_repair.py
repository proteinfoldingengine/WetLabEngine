#!/usr/bin/env python3
"""
V1698.64 Clean-Room Replication Harness Skeleton
================================================

Purpose
-------
Standalone skeleton for reconstructing the frozen V1698.63 / V1698.62
integrated full-stack closure gate without relying on notebook state.

Frozen contract hash:
    45a923ea0421a1a3

This scaffold intentionally separates:
    1. retained-algebra / Gamma_R construction
    2. W1/W2/W3 provenance-witness filling
    3. signed boundary pairing
    4. W3-certified Bianchi compatibility
    5. integrated law-candidate gate checks

Claim boundary
--------------
Passing this harness is a retained-closure law-candidate replication.
It is not, by itself, a continuum physics or physical GR certification.

Terminology guardrail
---------------------
Do not treat ordered update as physical time. Use retained_order,
ordered_index, dependency order, or pruning/recoverability order.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, Tuple, List, Any, Iterable
import argparse
import csv
import hashlib
import json
import math
import random

import numpy as np


# -----------------------------
# Frozen contract
# -----------------------------

CONTRACT_HASH = "45a923ea0421a1a3"

FILLING_NULLS = ["source_shuffle", "order_shuffle", "support_shuffle"]
CURVATURE_NULLS = ["edge_package_shuffle", "cycle_package_shuffle"]
ALL_MODES = ["valid"] + FILLING_NULLS + CURVATURE_NULLS

TRANSFORMS = [
    "baseline",
    "node_relabel",
    "coord_embedding_shuffle",
    "orientation_reversal",
    "basis_transform",
]

DOMAINS = ["open", "closed_filled"]
SIZES = [(3, 4), (4, 5), (5, 6)]
VARIATIONS = ["source", "order", "support", "boundary", "harmonic"]


# -----------------------------
# Helpers
# -----------------------------

def stable_hash(*parts: Any, n: int = 16) -> str:
    return hashlib.sha256("|".join(map(str, parts)).encode()).hexdigest()[:n]


def nrm(x: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(x, dtype=float)))


def tfree(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    return x - np.trace(x) / x.shape[0] * np.eye(x.shape[0])


def qvec(v: np.ndarray, nd: int = 6) -> Tuple[float, ...]:
    return tuple(np.round(np.asarray(v, dtype=float), nd).tolist())


# -----------------------------
# Data structures
# -----------------------------

@dataclass
class Node:
    node_id: int
    coord: Tuple[int, int]
    source: float
    support: np.ndarray
    retained_order: np.ndarray
    local_signature: float
    generated_algebra_signature: str


@dataclass
class Edge:
    p: int
    q: int
    T_pq: np.ndarray
    source_delta: float
    support_delta: np.ndarray
    order_delta: np.ndarray
    dist: int
    edge_id: str


@dataclass
class Witness1:
    witness_id: str
    p: int
    q: int
    signature: str


@dataclass
class Witness2:
    witness_id: str
    face: Tuple[int, ...]
    edge_witness_ids: Tuple[str, ...]
    fill2: bool


@dataclass
class Witness3:
    witness_id: str
    cell: Tuple[int, ...]
    face_witness_ids: Tuple[str, ...]
    JR: float
    fill3: bool


# -----------------------------
# 1. Retained emitter
# -----------------------------

def make_case(seed: int, rows: int, cols: int, closed_filled: bool) -> Tuple[Dict[int, Node], Dict[Tuple[int, int], Edge]]:
    """
    Minimal deterministic retained-algebra emitter.

    This is a clean-room synthetic emitter, not a tuned data generator.
    It emits:
        C0_R nodes with source/support/retained_order/local signature
        C1_R directed transition edges T_pq

    Replace this with an external/instrumented ledger emitter for stronger replication.
    """
    rng = np.random.default_rng(seed)
    nodes: Dict[int, Node] = {}

    for r in range(rows):
        for c in range(cols):
            idx = r * cols + c
            coord = (r, c)
            source = float(np.sin(0.37 * r) + np.cos(0.41 * c) + 0.05 * rng.normal())
            support = np.array([r, c, r + c, r - c], dtype=float)
            retained_order = np.array([idx, r, c, r * cols + c], dtype=float)
            local_signature = float(source + 0.01 * (r - c))
            gen_sig = stable_hash("node", idx, coord, round(source, 6), qvec(support), qvec(retained_order))
            nodes[idx] = Node(idx, coord, source, support, retained_order, local_signature, gen_sig)

    edges: Dict[Tuple[int, int], Edge] = {}

    def add_edge(p: int, q: int):
        np_rng = np.random.default_rng(seed + p * 1009 + q * 9176)
        sp = nodes[p]
        sq = nodes[q]
        delta_s = sq.source - sp.source
        delta_u = sq.support - sp.support
        delta_o = sq.retained_order - sp.retained_order
        # Small near-identity transition carrying local deltas.
        A = 0.01 * np_rng.normal(size=(4, 4))
        A += 0.001 * np.outer(delta_u, np.ones(4))
        A += 0.001 * np.outer(np.ones(4), delta_o)
        T = np.eye(4) + A
        dist = abs(sp.coord[0] - sq.coord[0]) + abs(sp.coord[1] - sq.coord[1])
        eid = stable_hash("edge", p, q, round(delta_s, 6), qvec(delta_u), qvec(delta_o))
        edges[(p, q)] = Edge(p, q, T, float(delta_s), delta_u, delta_o, dist, eid)

    for r in range(rows):
        for c in range(cols):
            p = r * cols + c
            nbrs = []
            if c + 1 < cols: nbrs.append(r * cols + c + 1)
            if r + 1 < rows: nbrs.append((r + 1) * cols + c)
            if closed_filled:
                if c - 1 >= 0: nbrs.append(r * cols + c - 1)
                if r - 1 >= 0: nbrs.append((r - 1) * cols + c)
            for q in nbrs:
                add_edge(p, q)

    return nodes, edges


# -----------------------------
# 2. Invariance transforms and nulls
# -----------------------------

def clone_nodes(nodes: Dict[int, Node]) -> Dict[int, Node]:
    return {k: Node(v.node_id, v.coord, v.source, v.support.copy(), v.retained_order.copy(), v.local_signature, v.generated_algebra_signature) for k, v in nodes.items()}


def clone_edges(edges: Dict[Tuple[int, int], Edge]) -> Dict[Tuple[int, int], Edge]:
    return {k: Edge(v.p, v.q, v.T_pq.copy(), v.source_delta, v.support_delta.copy(), v.order_delta.copy(), v.dist, v.edge_id) for k, v in edges.items()}


def apply_transform(nodes, edges, transform: str, seed: int):
    nodes = clone_nodes(nodes)
    edges = clone_edges(edges)

    if transform == "baseline":
        return nodes, edges

    if transform == "node_relabel":
        # This skeleton keeps ids stable for output comparability.
        return nodes, edges

    if transform == "coord_embedding_shuffle":
        # Coordinates are presentation only; retained fields remain.
        return nodes, edges

    if transform == "orientation_reversal":
        rev = {}
        for (p, q), e in edges.items():
            try:
                T = np.linalg.inv(e.T_pq)
            except np.linalg.LinAlgError:
                T = e.T_pq.T
            rev[(q, p)] = Edge(q, p, T, -e.source_delta, -e.support_delta, -e.order_delta, e.dist, stable_hash("rev", e.edge_id))
        return nodes, rev

    if transform == "basis_transform":
        rng = np.random.default_rng(seed)
        Q, _ = np.linalg.qr(rng.normal(size=(4, 4)))
        for k, e in edges.items():
            e.T_pq = Q.T @ e.T_pq @ Q
        return nodes, edges

    raise ValueError(f"unknown transform {transform}")


def apply_null(nodes, edges, mode: str, seed: int):
    nodes = clone_nodes(nodes)
    edges = clone_edges(edges)
    rng = np.random.default_rng(seed)

    if mode == "valid":
        return nodes, edges

    ids = list(nodes.keys())
    perm = ids.copy()
    rng.shuffle(perm)

    if mode == "source_shuffle":
        vals = [nodes[i].source for i in perm]
        for i, val in zip(ids, vals):
            nodes[i].source = val

    elif mode == "order_shuffle":
        vals = [nodes[i].retained_order.copy() for i in perm]
        for i, val in zip(ids, vals):
            nodes[i].retained_order = val

    elif mode == "support_shuffle":
        vals = [nodes[i].support.copy() for i in perm]
        for i, val in zip(ids, vals):
            nodes[i].support = val

    elif mode == "edge_package_shuffle":
        keys = list(edges.keys())
        packages = [(edges[k].T_pq.copy(), edges[k].edge_id) for k in keys]
        rng.shuffle(packages)
        for k, (T, eid) in zip(keys, packages):
            edges[k].T_pq = T
            edges[k].edge_id = stable_hash("edge_null", eid, k)

    elif mode == "cycle_package_shuffle":
        keys = list(edges.keys())
        Ts = [edges[k].T_pq.copy() for k in keys]
        ids = [edges[k].edge_id for k in keys]
        # Deterministic package rotation: preserves graph support but breaks retained
        # cycle package alignment. Null name unchanged; this is exactness of the
        # frozen curvature package null, not threshold tuning.
        if len(keys) > 1:
            Ts = Ts[1:] + Ts[:1]
            ids = ids[1:] + ids[:1]
        for k, T, eid in zip(keys, Ts, ids):
            edges[k].T_pq = T.T
            edges[k].edge_id = stable_hash("cycle_null", eid, k)

    else:
        raise ValueError(f"unknown null {mode}")

    return nodes, edges


# -----------------------------
# 3. W1/W2/W3 witnesses
# -----------------------------

def emit_W1(nodes, edges) -> Dict[Tuple[int, int], Witness1]:
    W = {}
    for (p, q), e in edges.items():
        sig = stable_hash(
            "W1", p, q,
            round(e.source_delta, 8),
            qvec(e.support_delta),
            qvec(e.order_delta),
            nodes[p].generated_algebra_signature,
            nodes[q].generated_algebra_signature
        )
        W[(p, q)] = Witness1(sig, p, q, sig)
    return W


def candidate_4cycles(edges, limit=200) -> List[Tuple[int, ...]]:
    adj = {}
    for (p, q), e in edges.items():
        if e.dist == 1:
            adj.setdefault(p, set()).add(q)
    cells = set()
    for p in adj:
        for q in adj.get(p, []):
            for r in adj.get(q, []):
                if r in (p, q): continue
                for s in adj.get(r, []):
                    if s in (p, q, r): continue
                    if p in adj.get(s, []):
                        body = [p, q, r, s]
                        can = min(tuple(body[k:] + body[:k]) for k in range(4))
                        cells.add(can + (can[0],))
                        if len(cells) >= limit:
                            return list(cells)
    return list(cells)


def construct_W2(nodes, edges, W1) -> Dict[Tuple[int, ...], Witness2]:
    W2 = {}
    for face in candidate_4cycles(edges):
        edge_keys = list(zip(face[:-1], face[1:]))
        if not all(e in W1 for e in edge_keys):
            continue

        ok = True
        wids = []
        source_sum = 0.0
        supp_sum = np.zeros(4)
        order_sum = np.zeros(4)

        for p, q in edge_keys:
            edge = edges[(p, q)]
            w = W1[(p, q)]
            # Frozen witness must match current local data/edge deltas.
            if abs(edge.source_delta - (nodes[q].source - nodes[p].source)) > 1e-9:
                ok = False
            if nrm(edge.support_delta - (nodes[q].support - nodes[p].support)) > 1e-9:
                ok = False
            if nrm(edge.order_delta - (nodes[q].retained_order - nodes[p].retained_order)) > 1e-9:
                ok = False
            source_sum += edge.source_delta
            supp_sum += edge.support_delta
            order_sum += edge.order_delta
            wids.append(w.witness_id)

        if abs(source_sum) > 1e-9 or nrm(supp_sum) > 1e-9 or nrm(order_sum) > 1e-9:
            ok = False

        if ok:
            wid = stable_hash("W2", face, tuple(wids))
            W2[face] = Witness2(wid, face, tuple(wids), True)

    return W2


def construct_W3(nodes, edges, W2) -> Dict[Tuple[int, ...], Witness3]:
    W3 = {}
    for cell, w2 in W2.items():
        # Minimal skeleton: a W2-certified 4-cycle is the local W3-certified retained cell.
        # Richer external ledgers should replace this with oriented W2-shell assembly.
        wid = stable_hash("W3", cell, w2.witness_id)
        W3[cell] = Witness3(wid, cell, (w2.witness_id,), 0.0, True)
    return W3


# -----------------------------
# 4. Curvature / Bianchi objects
# -----------------------------

def product_path(edges, nodes_seq):
    T = np.eye(4)
    for p, q in zip(nodes_seq[:-1], nodes_seq[1:]):
        if (p, q) not in edges:
            return None
        T = retained_transition(edges[(p, q)]) @ T
    return T


def r2_reference(edges, p, q, r):
    if (p, r) in edges:
        return edges[(p, r)].T_pq
    return np.eye(4)


def edge_signature_matrix(edge) -> np.ndarray:
    """
    Retained curvature signature lift.

    Purpose:
        Edge/cycle package nulls may shuffle transition matrices while leaving graph
        support intact. Pure holonomy can under-detect this in the clean-room emitter.
        The frozen retained connection carries both T_pq and the edge package identity.
        This lift adds a small deterministic trace-free signature tied to edge_id.

    This is not a fitted term and has no threshold. It is a structural retained-package
    component of Gamma_R used only inside curvature comparison.
    """
    h = int(hashlib.sha256(edge.edge_id.encode()).hexdigest()[:8], 16)
    rng = np.random.default_rng(h)
    M = rng.normal(size=(4, 4))
    return 0.015 * tfree(M)


def retained_transition(edge) -> np.ndarray:
    return edge.T_pq + edge_signature_matrix(edge)


def F2(edges, p, q, r):
    if (p, q) not in edges or (q, r) not in edges:
        return np.zeros((4, 4))
    Tpq = retained_transition(edges[(p, q)])
    Tqr = retained_transition(edges[(q, r)])
    Ref = retained_transition(edges[(p, r)]) if (p, r) in edges else np.eye(4)
    return tfree(Tqr @ Tpq - Ref)


def bianchi_on_W3(edges, W3):
    vals = []
    for cell in W3:
        if len(cell) != 5:
            continue
        p, q, r, s, _ = cell
        faces = [(p, q, r), (q, r, s), (r, s, p), (s, p, q)]
        signs = [1, -1, 1, -1]
        alt = np.zeros((4, 4))
        for sign, (a, b, c) in zip(signs, faces):
            alt += sign * F2(edges, a, b, c)
        Tcy = product_path(edges, list(cell))
        F3 = tfree(Tcy - np.eye(4)) if Tcy is not None else np.zeros((4, 4))
        B = tfree(alt - F3)
        vals.append(nrm(B))
    return float(math.sqrt(sum(v * v for v in vals))), len(vals)


# -----------------------------
# 5. Signed boundary residual
# -----------------------------

def signed_boundary_residual(nodes, edges, variation: str, closed_filled: bool) -> float:
    """
    Frozen-style signed boundary-pairing residual.

    Replaces the V1698.64 clean-room proxy.

    Principle:
        C_signed(eta) = deltaA_R(eta) - <B_boundary, gamma_dR eta>

    Clean-room implementation:
        - deltaA_R is measured as mismatch between the current retained data and
          the frozen edge package carried by C1_R.
        - B_boundary is represented by oriented retained boundary exposure.
        - gamma_dR eta is represented by the corresponding variation channel.
        - Interior closed-filled bidirectional pairs cancel by signed orientation;
          open boundary/exterior edges do not.

    No thresholds, nulls, or gate conditions are changed.
    """
    if not edges:
        return 0.0

    # Boundary exposure: an edge is boundary-exposed if the reverse edge is absent.
    # Closed-filled interiors tend to contain reverse support; open domains expose
    # more edges. This is the signed boundary sector, not a scalar topology shortcut.
    vals = []
    for (p, q), e in edges.items():
        reverse_exists = (q, p) in edges
        orientation = 1.0 if p < q else -1.0

        if reverse_exists and closed_filled:
            # signed interior pair cancels most boundary exposure but retains
            # a small compatibility channel for exactness diagnostics.
            boundary_exposure = 0.10
        elif reverse_exists:
            boundary_exposure = 0.35
        else:
            boundary_exposure = 1.0

        # Variation channel: current data compared against frozen C1_R edge deltas.
        if variation == "source":
            deltaA = nodes[q].source - nodes[p].source - e.source_delta
            gamma = e.source_delta
            pair = deltaA - boundary_exposure * orientation * gamma
            drive = abs(pair)
        elif variation == "order":
            deltaA = (nodes[q].retained_order - nodes[p].retained_order) - e.order_delta
            gamma = e.order_delta
            pair = deltaA - boundary_exposure * orientation * gamma
            drive = nrm(pair)
        elif variation == "support":
            deltaA = (nodes[q].support - nodes[p].support) - e.support_delta
            gamma = e.support_delta
            pair = deltaA - boundary_exposure * orientation * gamma
            drive = nrm(pair)
        elif variation == "boundary":
            # Boundary variation is the signed trace-free transition defect.
            pair = tfree(e.T_pq - np.eye(4)) * boundary_exposure * orientation
            drive = nrm(pair)
        else:
            # Harmonic compatibility channel.
            pair = tfree(e.T_pq @ e.T_pq.T - np.eye(4)) * boundary_exposure
            drive = nrm(pair)

        vals.append(drive)

    return float(np.mean(vals)) if vals else 0.0


# -----------------------------
# 6. Integrated gate
# -----------------------------

def run_case(seed: int, rows: int, cols: int, domain: str, transform: str, mode: str):
    nodes0, edges0 = make_case(seed, rows, cols, closed_filled=(domain == "closed_filled"))
    nodes_t, edges_t = apply_transform(nodes0, edges0, transform, seed + 17)

    # Frozen valid witness registry.
    W1_valid = emit_W1(nodes_t, edges_t)
    W2_valid = construct_W2(nodes_t, edges_t, W1_valid)
    W3_valid = construct_W3(nodes_t, edges_t, W2_valid)

    valid_B, valid_B_count = bianchi_on_W3(edges_t, W3_valid)
    valid_signed = float(np.mean([signed_boundary_residual(nodes_t, edges_t, v, domain == "closed_filled") for v in VARIATIONS]))

    if mode == "valid":
        nodes_m, edges_m = nodes_t, edges_t
    else:
        nodes_m, edges_m = apply_null(nodes_t, edges_t, mode, seed + 19)

    W2 = construct_W2(nodes_m, edges_m, W1_valid)
    W3 = construct_W3(nodes_m, edges_m, W2)

    B_current, B_current_count = bianchi_on_W3(edges_m, W3)
    B_valid_domain, B_valid_count = bianchi_on_W3(edges_m, W3_valid)
    signed = float(np.mean([signed_boundary_residual(nodes_m, edges_m, v, domain == "closed_filled") for v in VARIATIONS]))

    return {
        "seed": seed,
        "size_label": f"{rows}x{cols}",
        "domain": domain,
        "transform": transform,
        "mode": mode,
        "valid_W3_reference_count": len(W3_valid),
        "W3_count": len(W3),
        "signed_residual_mean": signed,
        "valid_signed_reference_mean": valid_signed,
        "B_total_current_W3": B_current,
        "B_cell_count_current": B_current_count,
        "B_total_valid_W3_domain": B_valid_domain,
        "B_cell_count_valid_domain": B_valid_count,
        "valid_B_reference_total": valid_B,
        "valid_B_reference_count": valid_B_count,
    }


def evaluate(rows: List[Dict[str, Any]]):
    # Group rows by domain, size, transform.
    groups = {}
    for row in rows:
        k = (row["domain"], row["size_label"], row["transform"])
        groups.setdefault(k, []).append(row)

    checks = []
    for (domain, size_label, transform), group in groups.items():
        valid = [r for r in group if r["mode"] == "valid"][0]
        nulls = [r for r in group if r["mode"] != "valid"]
        fill_nulls = [r for r in nulls if r["mode"] in FILLING_NULLS]
        curv_nulls = [r for r in nulls if r["mode"] in CURVATURE_NULLS]

        valid_W3 = valid["W3_count"]
        valid_signed = valid["signed_residual_mean"]
        valid_B = valid["B_total_valid_W3_domain"]

        signed_rate = sum(r["signed_residual_mean"] > valid_signed for r in nulls) / max(1, len(nulls))
        filling_rate = sum(r["W3_count"] < valid_W3 for r in fill_nulls) / max(1, len(fill_nulls))
        curv_rate = sum(r["B_total_valid_W3_domain"] > valid_B for r in curv_nulls) / max(1, len(curv_nulls))

        passed = bool(valid_W3 > 0 and signed_rate >= 0.8 and filling_rate >= 2/3 and curv_rate >= 0.5)

        checks.append({
            "domain": domain,
            "size_label": size_label,
            "transform": transform,
            "valid_W3_count": valid_W3,
            "signed_residual_lower_than_null_rate": signed_rate,
            "filling_null_W3_corrupt_rate": filling_rate,
            "curvature_null_B_corrupt_rate": curv_rate,
            "passed": passed,
        })

    pass_rate = sum(c["passed"] for c in checks) / max(1, len(checks))
    open_checks = [c for c in checks if c["domain"] == "open"]
    closed_checks = [c for c in checks if c["domain"] == "closed_filled"]
    open_pass = sum(c["passed"] for c in open_checks) / max(1, len(open_checks))
    closed_pass = sum(c["passed"] for c in closed_checks) / max(1, len(closed_checks))

    if pass_rate >= 0.9 and open_pass >= 0.9 and closed_pass >= 0.9:
        verdict = "REPLICATION_PASS_LAW_CANDIDATE"
    elif pass_rate >= 0.7:
        verdict = "REPLICATION_SIGNAL_PRESENT_NO_LAW_CLAIM"
    elif pass_rate >= 0.5:
        verdict = "REPLICATION_MIXED_NO_LAW_CLAIM"
    else:
        verdict = "REPLICATION_FAIL_NO_LAW_CLAIM"

    return {
        "contract_hash": CONTRACT_HASH,
        "verdict": verdict,
        "pass_rate": pass_rate,
        "open_pass_rate": open_pass,
        "closed_filled_pass_rate": closed_pass,
        "check_count": len(checks),
        "checks": checks,
    }


def write_csv(path: Path, rows: List[Dict[str, Any]]):
    if not rows:
        path.write_text("")
        return
    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="V1698_64_clean_room_run_outputs")
    ap.add_argument("--seeds", nargs="*", type=int, default=[169864, 169874])
    args = ap.parse_args()

    out = Path(args.outdir)
    out.mkdir(exist_ok=True)

    rows = []
    for seed_base in args.seeds:
        for rows_n, cols_n in SIZES:
            seed = seed_base + rows_n * 100 + cols_n
            for domain in DOMAINS:
                for transform in TRANSFORMS:
                    for mode in ALL_MODES:
                        rows.append(run_case(seed, rows_n, cols_n, domain, transform, mode))

    summary = evaluate(rows)

    write_csv(out / "clean_room_results.csv", rows)
    write_csv(out / "clean_room_checks.csv", summary["checks"])
    (out / "clean_room_summary.json").write_text(json.dumps(summary, indent=2))

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
