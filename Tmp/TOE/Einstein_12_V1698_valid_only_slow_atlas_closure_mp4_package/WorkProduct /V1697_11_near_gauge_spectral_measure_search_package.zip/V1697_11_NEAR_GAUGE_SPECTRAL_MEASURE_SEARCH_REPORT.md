# V1697.11 — Near-Gauge Spectral Measure Search

**Verdict:** `NEAR_GAUGE_SPECTRAL_SIGNAL_PRESENT_NO_LAW_CLAIM`

```json
{
  "edge_cases_valid": 32,
  "total_cases": 160,
  "positive_action_reduction_rate_valid": 1.0,
  "best_assoc_feature": "tail_ratio_low4",
  "best_assoc_abs_spearman": 0.9313027768230161,
  "best_assoc_shuffle_p95": 0.35271944616480394,
  "n_features_beating_shuffle_p95": 2,
  "assoc_scramble_profile_distance": 2.9258268602649915,
  "support_order_shuffle_profile_distance": 2.513582228892573,
  "role_shuffle_profile_distance": 2.513582228892398,
  "stationarity_break_profile_distance": 10.52516237313222,
  "valid_profile_distance_baseline": 2.513582228892573
}
```
