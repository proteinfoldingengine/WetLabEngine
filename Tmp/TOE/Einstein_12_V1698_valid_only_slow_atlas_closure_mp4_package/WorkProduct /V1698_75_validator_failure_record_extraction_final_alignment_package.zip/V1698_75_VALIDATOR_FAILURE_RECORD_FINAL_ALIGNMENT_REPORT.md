# V1698.75 - Validator Failure Record Extraction and Final Alignment

**Verdict:** `VALIDATOR_FAILURE_RECORD_ALIGNMENT_PASS_SINGLE_LEDGER_MULTI_GATED`

## Exact input failure records

```json
[
  {
    "table": "run_manifest",
    "failure": "missing_required_domains",
    "missing": [
      "open"
    ],
    "severity": "hard"
  },
  {
    "table": "run_manifest",
    "failure": "missing_required_modes",
    "missing": [
      "cycle_package_shuffle",
      "edge_package_shuffle",
      "order_shuffle",
      "source_shuffle",
      "support_shuffle"
    ],
    "severity": "hard"
  }
]
```

## Diagnosis

The two remaining failures were not W3/Bianchi reference failures.

They were validator-mode failures:

```text
a single emitted ledger was being judged as if it were the entire multi-mode null/domain suite
```

That is a validator alignment error, not an emitter defect.

## Repair

Validator now has two modes:

```text
--validation-mode single
    validates one full-stack ledger for schema, references, no-proxy shortcuts, and gate recompute

--validation-mode multi
    additionally requires all frozen domains and all frozen null modes
```

No gate thresholds, nulls, or scoring were changed.

## Single-ledger validation result

```json
{
  "returncode": 0,
  "verdict": "FULL_STACK_LEDGER_VALIDATION_PASS_SCHEMA_ONLY_NO_LAW_CANDIDATE",
  "failure_count": 0,
  "gate_recompute": {
    "verdict": "GATE_RECOMPUTE_PASS",
    "pass_rate": 1.0,
    "open_pass_rate": 0.0,
    "closed_filled_pass_rate": 1.0,
    "law_candidate_status": false,
    "failure_count": 0,
    "failures": []
  }
}
```

## Multi-mode expected-fail check on same single ledger

```json
{
  "returncode": 2,
  "verdict": "FULL_STACK_LEDGER_VALIDATION_FAIL",
  "failure_count": 2,
  "failures": [
    {
      "table": "run_manifest",
      "failure": "missing_required_domains",
      "missing": [
        "open"
      ],
      "severity": "hard"
    },
    {
      "table": "run_manifest",
      "failure": "missing_required_modes",
      "missing": [
        "cycle_package_shuffle",
        "edge_package_shuffle",
        "order_shuffle",
        "source_shuffle",
        "support_shuffle"
      ],
      "severity": "hard"
    }
  ]
}
```

## Next

```text
V1698.76 - Multi-Mode Full-Stack Ledger Replication Run
```
