# V1698.39 — Variational Adjoint Current Invariance Audit

**Verdict:** `VARIATIONAL_ADJOINT_CURRENT_INVARIANCE_PASS_NO_LAW_CLAIM`

## Frozen action

```text
A_R = L_edge + L_R2 + L_R3 + L_source
```

with:

```text
L_source =
Σ_edges [Δ_S(p,q) · tr_log(T_pq)]²
+
Σ_boundary rho_p²
```

## Tested transforms

```text
baseline
node_relabel
basis_transform
orientation_reversal
coordinate_embedding_shuffle
```

## Summary

```json
{
  "version": "V1698.39",
  "verdict": "VARIATIONAL_ADJOINT_CURRENT_INVARIANCE_PASS_NO_LAW_CLAIM",
  "purpose": "Audit V1698.38 variational adjoint current under relabeling, basis transform, orientation reversal, and coordinate embedding shuffle.",
  "transform_checks": [
    {
      "transform": "baseline",
      "valid_mean_abs_total": 0.03058094765062691,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 3.848548950227071,
      "pass": true
    },
    {
      "transform": "basis_transform",
      "valid_mean_abs_total": 0.03058094765062691,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 3.848548950198027,
      "pass": true
    },
    {
      "transform": "coord_embedding_shuffle",
      "valid_mean_abs_total": 0.027517407441557395,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 4.486839957138103,
      "pass": true
    },
    {
      "transform": "node_relabel",
      "valid_mean_abs_total": 0.029988398439151354,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 4.063718412822771,
      "pass": true
    },
    {
      "transform": "orientation_reversal",
      "valid_mean_abs_total": 0.0311366080021358,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 4.8085736139930875,
      "pass": true
    }
  ],
  "pass_rate": 1.0,
  "min_best_null_to_valid_ratio": 3.848548950198027,
  "max_valid_transform_to_baseline_ratio": 1.0181701482196384,
  "claim_boundary": "Invariance audit only. No law closure.",
  "runtime_seconds": 8.507115125656128
}
```
