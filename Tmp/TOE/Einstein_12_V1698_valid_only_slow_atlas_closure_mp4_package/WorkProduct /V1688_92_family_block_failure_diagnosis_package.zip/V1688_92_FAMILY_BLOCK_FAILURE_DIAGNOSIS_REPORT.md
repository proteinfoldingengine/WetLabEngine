# V1688.92 — Family/Block Failure Diagnosis

**Verdict:** `FAMILY_BLOCK_FAILURE_DIAGNOSIS_COMPLETE`

V1688.91 showed the retained signal survives resolution and generator-mode holdouts, but family/block holdouts are mixed. V1688.92 diagnoses those failures.

## Summary

```json
{
  "version": "V1688.92",
  "verdict": "FAMILY_BLOCK_FAILURE_DIAGNOSIS_COMPLETE",
  "input": "V1688.91 holdout hardening",
  "n_holdouts": 19,
  "n_failures": 6,
  "failures_by_type": [
    {
      "holdout_type": "block_id",
      "n_fail": 4,
      "mean_unique": -0.040436139251202353,
      "min_unique": -0.0823604784996527,
      "mean_margin": -0.04525717166851755,
      "min_margin": -0.0863495203699061
    },
    {
      "holdout_type": "family",
      "n_fail": 2,
      "mean_unique": -0.007210944551153799,
      "min_unique": -0.0161585036955536,
      "mean_margin": -0.0095495477695683,
      "min_margin": -0.0185759985308021
    }
  ],
  "failure_causes": [
    {
      "holdout_type": "family",
      "heldout_value": "anisotropic",
      "unique_full_over_topology": 0.001736614593246,
      "observed_minus_null_max": -0.0005230970083345,
      "likely_causes": "localized_H_dir weakly coupled to weak_target in heldout regime; observed retained gain below shuffle-null maximum"
    },
    {
      "holdout_type": "family",
      "heldout_value": "grad",
      "unique_full_over_topology": -0.0161585036955536,
      "observed_minus_null_max": -0.0185759985308021,
      "likely_causes": "observed retained gain below shuffle-null maximum"
    },
    {
      "holdout_type": "block_id",
      "heldout_value": "A_anisotropic_n24_s101",
      "unique_full_over_topology": -0.0049396116608453,
      "observed_minus_null_max": -0.0080309943550744,
      "likely_causes": "localized_H_dir anticorrelates with weak_target in heldout regime; localized_H_dir weakly coupled to weak_target in heldout regime; correction_loss may be better observable than exact cycle H_dir in this regime; observed retained gain below shuffle-null maximum"
    },
    {
      "holdout_type": "block_id",
      "heldout_value": "A_grad_n16_s101",
      "unique_full_over_topology": -0.0823604784996527,
      "observed_minus_null_max": -0.0863495203699061,
      "likely_causes": "localized_H_dir anticorrelates with weak_target in heldout regime; observed retained gain below shuffle-null maximum"
    },
    {
      "holdout_type": "block_id",
      "heldout_value": "A_grad_n24_s101",
      "unique_full_over_topology": -0.0629730185129676,
      "observed_minus_null_max": -0.0668557935117709,
      "likely_causes": "localized_H_dir anticorrelates with weak_target in heldout regime; observed retained gain below shuffle-null maximum"
    },
    {
      "holdout_type": "block_id",
      "heldout_value": "B_anisotropic_n24_s101",
      "unique_full_over_topology": -0.0114714483313438,
      "observed_minus_null_max": -0.0197923784373188,
      "likely_causes": "localized_H_dir anticorrelates with weak_target in heldout regime; localized_H_dir weakly coupled to weak_target in heldout regime; observed retained gain below shuffle-null maximum"
    }
  ],
  "alternate_observable_summary": [
    {
      "observable": "exact_cycle_defect",
      "mean_unique": 0.031088783923850016,
      "min_unique": -0.0669359469951154,
      "positive_rate": 0.7333333333333333,
      "best_unique": 0.1259810527737344
    },
    {
      "observable": "correction_loss",
      "mean_unique": 0.030590443863601192,
      "min_unique": -0.12606734989241963,
      "positive_rate": 0.7333333333333333,
      "best_unique": 0.12398810131193427
    },
    {
      "observable": "H_dir_local",
      "mean_unique": 0.012995725743592697,
      "min_unique": -0.07942583284636939,
      "positive_rate": 0.6666666666666666,
      "best_unique": 0.09961945585284337
    },
    {
      "observable": "h4_perp_norm",
      "mean_unique": 0.00032140735039576374,
      "min_unique": -0.032753724590118494,
      "positive_rate": 0.6666666666666666,
      "best_unique": 0.013444140805269345
    },
    {
      "observable": "o3_norm",
      "mean_unique": -0.001732194729376572,
      "min_unique": -0.018534635548377643,
      "positive_rate": 0.4,
      "best_unique": 0.010665483822777655
    },
    {
      "observable": "continuity",
      "mean_unique": -0.0030629215724695164,
      "min_unique": -0.017435698814255662,
      "positive_rate": 0.13333333333333333,
      "best_unique": 0.00020942884597607847
    }
  ],
  "interpretation": "Family/block failures appear to be regime-dependent observable mismatch rather than resolution/generator-order failure. The next correction should test whether correction_loss/H4_perp-local observables are better retained field-law terms in failed families.",
  "claim_boundary": "Diagnostic only; no field-law closure claim."
}
```

## Key diagnostic meaning

The failures are not primarily resolution failures. They are concentrated in family/block regimes where the exact localized cycle defect is not the best observable, or where C_corr/topology controls absorb the available weak-target structure.

The alternate-observable screen identifies whether `correction_loss`, `h4_perp_norm`, or other retained local observables may be better cross-family terms than exact cycle defect alone.

## Next

Test a revised retained basis:

```text
M0 + C_corr + topology controls
+ residualized exact_cycle_defect
+ residualized correction_loss
+ residualized H4_perp/local associator terms
+ residualized continuity
```

and rerun family/block holdouts.
