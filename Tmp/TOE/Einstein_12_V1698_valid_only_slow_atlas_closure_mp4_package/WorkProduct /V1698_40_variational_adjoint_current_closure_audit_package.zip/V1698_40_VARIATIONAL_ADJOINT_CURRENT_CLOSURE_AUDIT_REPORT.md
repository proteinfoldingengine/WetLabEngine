# V1698.40 — Variational Adjoint Current Closure Audit

**Verdict:** `VARIATIONAL_ADJOINT_CURRENT_CLOSURE_AUDIT_MIXED_NO_LAW_CLAIM`

## Audit target

```text
δA_R[η] = Interior_R(η) + Boundary_R(η)
```

Closed domain expects suppressed source-boundary adjoint.

Open domain expects measurable source-boundary contribution.

## Summary

```json
{
  "version": "V1698.40",
  "verdict": "VARIATIONAL_ADJOINT_CURRENT_CLOSURE_AUDIT_MIXED_NO_LAW_CLAIM",
  "purpose": "Audit closure behavior of variational adjoint current under closed vs open retained domains.",
  "checks": [
    {
      "domain": "open",
      "valid_mean_abs_total": 0.2274535034798575,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 8.181276454640214,
      "closure_ratio": 0.0,
      "closure_pass": false
    },
    {
      "domain": "closed",
      "valid_mean_abs_total": 0.19961398513048192,
      "lower_than_null_rate": 1.0,
      "best_null_to_valid_ratio": 8.540323281953524,
      "closure_ratio": 0.0,
      "closure_pass": true
    }
  ],
  "closure_pass_rate": 0.5,
  "mean_lower_than_null_rate": 1.0,
  "min_best_null_to_valid_ratio": 8.181276454640214,
  "open_to_closed_source_boundary_adj_ratio": 0.0,
  "claim_boundary": "Closure-behavior audit only. No final law closure.",
  "runtime_seconds": 4.566853284835815
}
```
