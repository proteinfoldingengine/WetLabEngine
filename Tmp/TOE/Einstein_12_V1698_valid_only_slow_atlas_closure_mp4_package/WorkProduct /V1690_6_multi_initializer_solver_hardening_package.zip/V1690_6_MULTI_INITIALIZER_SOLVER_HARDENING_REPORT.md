# V1690.6 — Multi-Initializer Solver Hardening Audit

**Verdict:** `MULTI_INITIALIZER_SOLVER_HARDENING_PASS_NO_LAW_CLAIM`

This run hardens the V1690.5 stationary solver.

It tests:

```text
multiple admissible initializers
N_gradient_sign_flip
N_E_fit_solver
```

The valid solver optimizes only:

```text
I_Γ[A]
```

and does not use compatibility residuals as a target.

## Summary

```json
{
  "version": "V1690.6",
  "verdict": "MULTI_INITIALIZER_SOLVER_HARDENING_PASS_NO_LAW_CLAIM",
  "purpose": "Harden stationary A_pq solver with multiple admissible initializers and forbidden/null solvers.",
  "target_free_audit": true,
  "valid_solver_uses_only_I_Gamma": true,
  "stability": {
    "valid_initializer_count": 5,
    "valid_mean_stationary_pass_rate": 1.0,
    "valid_min_stationary_pass_rate": 1.0,
    "valid_mean_action_reduction": 0.023605260218835654,
    "valid_action_reduction_std": 0.0016177484936919018,
    "valid_relative_stationarity_mean": 0.05209138543375724,
    "gradient_sign_flip_pass_rate": 0.0,
    "E_fit_solver_forbidden_rate": 1.0
  },
  "null_results": [
    {
      "pipeline_id": "P_N_E_fit_solver",
      "pipeline_family": "N_E_fit_solver",
      "initializer_mode": "base",
      "edge_count": 14,
      "stationary_edge_pass_rate": 0.0,
      "mean_I_initial": 0.18577255638710474,
      "mean_I_final": 1.0747164871258974,
      "mean_action_reduction": -0.8889439307387927,
      "mean_relative_stationarity_final": 1.1778704036124013,
      "forbidden_field_rate": 1.0
    },
    {
      "pipeline_id": "P_N_gradient_sign_flip",
      "pipeline_family": "N_gradient_sign_flip",
      "initializer_mode": "base",
      "edge_count": 14,
      "stationary_edge_pass_rate": 0.0,
      "mean_I_initial": 0.18577255638710474,
      "mean_I_final": 0.18577255638710474,
      "mean_action_reduction": 0.0,
      "mean_relative_stationarity_final": 1.6477247387922318,
      "forbidden_field_rate": 0.0
    }
  ],
  "claim_boundary": "Solver hardening audit only. No retained field-law validation.",
  "runtime_seconds": 24.730994701385498
}
```

## Interpretation

This remains a solver-governance audit, not a retained-law validation. The key question is whether stationarity selection is stable and whether forbidden solvers are blocked.
