# V1688.98 — Global Audit of the Source-Coupled Cycle Law

**Verdict:** `SOURCE_COUPLED_CYCLE_LAW_PARTIAL_PASS_BLOCK_FAILURES_REMAIN`

V1688.97 found that the remaining counterexample is rescued by a source-coupled cycle term:

```text
source_abs · (|exact_cycle_defect| + |correction_loss|)
```

V1688.98 tests whether that is a global improvement or just a local patch.

## Law variants tested

```text
cycle_abs_sum
source_cycle_abs
cycle_abs_sum + source_cycle_abs
cycle_abs_sum + source_cycle_abs + C_cycle_signed
cycle_abs_sum + source_cycle_abs + C_cycle_signed + source_C_cycle
```

All terms are residualized against:

```text
M0 + C_corr + topology controls
```

inside each train/test split.

## Summary

```json
{
  "version": "V1688.98",
  "verdict": "SOURCE_COUPLED_CYCLE_LAW_PARTIAL_PASS_BLOCK_FAILURES_REMAIN",
  "input": "V1688.90R local-sector candidate",
  "best_variant": "cycle_abs_plus_source",
  "best_variant_summary": {
    "variant": "cycle_abs_plus_source",
    "n": 19,
    "mean_unique": 0.07292052955879512,
    "min_unique": -0.03813807338639563,
    "positive_rate": 0.8947368421052632,
    "mean_margin": 0.07079072513109763,
    "min_margin": -0.04006267251493978,
    "pass_rate": 0.8947368421052632
  },
  "best_variant_by_holdout_type": [
    {
      "variant": "cycle_abs_plus_source",
      "holdout_type": "block_id",
      "n": 12,
      "mean_unique": 0.07204247360740974,
      "min_unique": -0.03813807338639563,
      "positive_rate": 0.8333333333333334,
      "mean_margin": 0.06939048847661593,
      "min_margin": -0.04006267251493978,
      "pass_rate": 0.8333333333333334
    },
    {
      "variant": "cycle_abs_plus_source",
      "holdout_type": "family",
      "n": 3,
      "mean_unique": 0.06435656287991735,
      "min_unique": 0.042987290958203306,
      "positive_rate": 1.0,
      "mean_margin": 0.06315681159512758,
      "min_margin": 0.04154971563011867,
      "pass_rate": 1.0
    },
    {
      "variant": "cycle_abs_plus_source",
      "holdout_type": "generator_mode",
      "n": 2,
      "mean_unique": 0.08306271450479791,
      "min_unique": 0.06876476864398051,
      "positive_rate": 1.0,
      "mean_margin": 0.08196977499131053,
      "min_margin": 0.06823775528140497,
      "pass_rate": 1.0
    },
    {
      "variant": "cycle_abs_plus_source",
      "holdout_type": "resolution",
      "n": 2,
      "mean_unique": 0.08089263033942123,
      "min_unique": 0.078872024635124,
      "positive_rate": 1.0,
      "mean_margin": 0.07946396550173007,
      "min_margin": 0.07744276654294902,
      "pass_rate": 1.0
    }
  ],
  "cycle_abs_sum_summary": {
    "variant": "cycle_abs_sum",
    "n": 19,
    "mean_unique": 0.07271570349500629,
    "min_unique": -0.020205203354631718,
    "positive_rate": 0.8421052631578947,
    "mean_margin": 0.07118519641461006,
    "min_margin": -0.021265303071456354,
    "pass_rate": 0.8421052631578947
  },
  "n_best_variant_failures": 2,
  "best_variant_failures": [
    {
      "holdout_type": "block_id",
      "heldout_value": "B_radial_n16_s101",
      "unique_over_control": -0.016823580046093856,
      "observed_minus_null_max": -0.01944244925248806
    },
    {
      "holdout_type": "block_id",
      "heldout_value": "B_radial_n24_s101",
      "unique_over_control": -0.03813807338639563,
      "observed_minus_null_max": -0.04006267251493978
    }
  ],
  "claim_boundary": "Finite local-sector toy/candidate global audit only. No empirical validation, GR, Einstein-equation, Riemann-curvature, or physical-spacetime claim."
}
```

## Interpretation

A pass means source-coupled cycle structure is the better retained-law candidate. A partial pass means it improves the counterexample but still exposes one or more block-level limits.
