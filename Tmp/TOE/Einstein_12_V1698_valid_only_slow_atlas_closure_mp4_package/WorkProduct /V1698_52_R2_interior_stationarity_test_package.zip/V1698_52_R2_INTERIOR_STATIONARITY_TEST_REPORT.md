# V1698.52 - R2 Interior Stationarity Test

**Verdict:** `R2_INTERIOR_STATIONARITY_TEST_FAIL_NO_LAW_CLAIM`

## Tested equation

```text
S_R2(e) =
sum_alpha D_e^* Pi_R2(C_alpha - T_pr_ref)
```

## Corrections

```text
reference: direct p->r when available, otherwise leave-one-path-out
projection: trace-free admissible projection
stationarity: edge-level adjoint accumulation
```

## Summary

```json
{
  "version": "V1698.52",
  "verdict": "R2_INTERIOR_STATIONARITY_TEST_FAIL_NO_LAW_CLAIM",
  "purpose": "Test corrected R2 interior adjoint stationarity using direct/leave-one-out references and trace-free projection.",
  "row_count": 90,
  "check_count": 15,
  "pass_rate": 0.0,
  "mean_lower_than_null_rate": 0.40000000000000013,
  "min_best_null_to_valid_ratio": 0.9999999999979845,
  "failure_count": 15,
  "improved_over_V1698_50_closed_pass_rate": false,
  "V1698_50_closed_pass_rate_reference": 0.6,
  "claim_boundary": "R2 interior stationarity diagnostic only. No final law closure.",
  "runtime_seconds": 1.2703044414520264
}
```
