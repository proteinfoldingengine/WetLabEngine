# V1698.51 - R2 Interior Stationarity Derivation

**Verdict:** `R2_INTERIOR_STATIONARITY_PROTOCOL_DERIVED_NO_EXECUTION`

## Starting point

V1698.50 isolated the remaining closed-domain weakness.

In a closed-filled retained domain:

```text
B_boundary = 0
C_signed = delta A_R
```

So failure is now interior stationarity, not boundary closure.

The dominant component was:

```text
R2 path-composition action
```

## Root cause

The old R2 action was:

```text
L_R2 = sum_path ||T_qr T_pq - Rep(p,r)||^2
```

This is not yet a lawful stationarity equation because:

```text
Rep(p,r) can move with the same paths being varied
```

and because:

```text
the residual is not projected onto the admissible quotient/tangent space
```

So R2 behaves like a residual penalty, not an interior compatibility law.

## Corrected R2 object

For a path:

```text
alpha = p -> q -> r
```

define:

```text
C_alpha = T_qr T_pq
```

```text
R2_alpha = C_alpha - T_pr_ref
```

Then project into the admissible R2 sector:

```text
R2_hat_alpha = Pi_R2_alpha(R2_alpha)
```

## Interior stationarity equation

For each interior edge `e`:

```text
S_R2(e)
=
sum_{alpha contains e}
D_{e,alpha}^* Pi_R2_alpha(C_alpha - T_pr_ref)
```

Stationarity requires:

```text
S_R2(e) = 0
```

## Edge adjoints

If the edge is:

```text
e = p -> q
```

then:

```text
D_e(C_alpha)[delta T_pq] = T_qr delta T_pq
```

and the adjoint is:

```text
D_pq^*(Y) = T_qr^* Y
```

If the edge is:

```text
e = q -> r
```

then:

```text
D_e(C_alpha)[delta T_qr] = delta T_qr T_pq
```

and the adjoint is:

```text
D_qr^*(Y) = Y T_pq^*
```

## Corrected reference rule

Do not use a self-including moving average.

Allowed references:

```text
direct p->r edge reference
leave-one-path-out representative
quotient-projected representative
```

For the next execution:

```text
use direct p->r when available
otherwise use leave-one-path-out representative
```

## Corrected action

```text
L_R2_star
=
sum_alpha ||Pi_R2_alpha(C_alpha - T_pr_ref(alpha))||^2
```

Minimal first projection:

```text
Pi(X) = X - tr(X)/d I
```

This removes the trivial identity/scale direction without fitting.

## Next branch

```text
V1698.52 - R2 Interior Stationarity Test
```

Required:

```text
replace self-including R2 with R2_star
compute edge-level adjoint stationarity S_R2(e)
test closed-filled valid vs nulls
test size and invariance transforms
verify whether R2 stops dominating failures
```

## Safe claim

The remaining closed-domain obstruction is not boundary closure but interior path-composition stationarity. R2 must be treated as an adjoint compatibility equation with a lawful reference and projection, not as a self-referential residual penalty.
