#!/usr/bin/env python3
"""
V1688.85 Hardened Retained Field-Law Protocol Validator

This is a strict validator scaffold for the frozen V1688.85 protocol.
It validates schema and reports what can/cannot be claimed. It does not invent
topology controls, cycles, cycle-node maps, weak targets, or source-flow fields.
"""

import argparse, json, ast
from pathlib import Path
import numpy as np
import pandas as pd

def load_csv(path):
    return pd.read_csv(path)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--nodes", required=True)
    ap.add_argument("--edges", required=True)
    ap.add_argument("--cycles", required=True)
    ap.add_argument("--cycle_node_map", required=True)
    ap.add_argument("--out", default="V1688_85_hardened_validation_outputs")
    args = ap.parse_args()

    out = Path(args.out); out.mkdir(exist_ok=True)
    nodes = load_csv(args.nodes)
    edges = load_csv(args.edges)
    cycles = load_csv(args.cycles)
    cmap = load_csv(args.cycle_node_map)

    req_nodes = {"node_id","source_abs","access_abs","div_baseline","weak_target","C_corr"}
    req_edges = {"from_node","to_node","gamma_pq"}
    req_cycles = {"cycle_id","step","from_node","to_node"}
    req_map = {"cycle_id","node_id","weight"}

    missing = {
        "nodes": sorted(list(req_nodes - set(nodes.columns))),
        "edges": sorted(list(req_edges - set(edges.columns))),
        "cycles": sorted(list(req_cycles - set(cycles.columns))),
        "cycle_node_map": sorted(list(req_map - set(cmap.columns))),
    }

    node_ids = set(map(str, nodes["node_id"])) if "node_id" in nodes.columns else set()
    edge_endpoints = set(map(str, edges["from_node"])) | set(map(str, edges["to_node"])) if {"from_node","to_node"}.issubset(edges.columns) else set()
    cycle_endpoints = set(map(str, cycles["from_node"])) | set(map(str, cycles["to_node"])) if {"from_node","to_node"}.issubset(cycles.columns) else set()
    map_nodes = set(map(str, cmap["node_id"])) if "node_id" in cmap.columns else set()

    identity_ok = edge_endpoints.issubset(node_ids) and cycle_endpoints.issubset(node_ids) and map_nodes.issubset(node_ids)

    native_recompute = {"state","Z"}.issubset(nodes.columns)
    edge_replay = "c_pq" in edges.columns
    transport_ok = native_recompute or edge_replay

    # topology controls are not fixed, but look for common candidates
    topo_candidates = [c for c in nodes.columns if c in ["x","y","i","j","resolution","family","operator_family","slice_id"] or c.startswith("topo")]
    topology_control_available = len(topo_candidates) > 0

    blocked = any(missing[k] for k in missing) or not identity_ok or not transport_ok
    promoted_claim_blocked = blocked or not topology_control_available

    summary = {
        "version": "V1688.85",
        "schema_missing": missing,
        "identity_ok": identity_ok,
        "transport_ok": transport_ok,
        "native_recompute": native_recompute,
        "edge_scalar_replay": edge_replay,
        "topology_control_candidates": topo_candidates,
        "topology_control_available": topology_control_available,
        "blocked": blocked,
        "promoted_claim_blocked": promoted_claim_blocked,
        "verdict": "READY_FOR_EXECUTION" if not blocked else "BLOCKED_SCHEMA_OR_IDENTITY_FAILURE",
        "claim_boundary": "Even if schema passes, promoted field-law claim requires topology residualization, nulls, and holdouts."
    }
    (out/"V1688_85_VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    main()
