# V1688.96 — Admissibility Boundary Test for Remaining Counterexample

**Verdict:** `ADMISSIBILITY_GATE_FAILS_COUNTEREXAMPLE_NOT_EXCLUDED`

V1688.95 left one block as a candidate counterexample:

```text
A_grad_n16_s101
```

V1688.96 tests whether it belongs to the same retained-law regime.

## First-principles admissibility gate

The cycle-decomposition law term is:

```text
Q_cycle = |exact_cycle_defect| + |correction_loss|
```

A block is cycle-law admissible only if:

```text
corr(Q_cycle, weak_target) > 0
```

This is a sign-coupling condition, not a tuned numeric threshold.

Reason:

```text
If the retained cycle observable anticorrelates with the weak target,
then the block is not in the same retained cycle-law orientation regime.
```

## Summary

```json
{
  "version": "V1688.96",
  "verdict": "ADMISSIBILITY_GATE_FAILS_COUNTEREXAMPLE_NOT_EXCLUDED",
  "counterexample_block": "A_grad_n16_s101",
  "counterexample_row": {
    "block_id": "A_grad_n16_s101",
    "family": "grad",
    "generator_mode": "A",
    "resolution": 16,
    "n": 256,
    "K_cycle_abs_corr": 0.13513271212772848,
    "K_cycle_signed_corr": -0.06434111222016896,
    "K_exact_corr": -0.026912822272466018,
    "K_loss_corr": -0.09134908153497931,
    "K_C_corr": 0.4724860532314387,
    "K_H4_corr": 0.3162689973001495,
    "cycle_abs_std": 1.0112964246743785,
    "weak_target_std": 0.9999999999975404,
    "cycle_variance_ratio": 1.0112964246758547,
    "cycle_abs_sum_unique": -0.0064222883941147,
    "cycle_split_unique": -0.1295242453917214,
    "cycle_abs_sum_pass": false,
    "cycle_split_pass": false,
    "A_cycle_sign_admissible": true,
    "counterexample_candidate": true
  },
  "gate_definition": "A_cycle_sign_admissible iff corr(|exact_cycle_defect| + |correction_loss|, weak_target) > 0 within the generated block.",
  "gate_reason": "A retained cycle law is admissible only when the intrinsic cycle-decomposition observable has the same orientation as the weak target; otherwise it is an out-of-regime counterexample, not a law-supporting sector.",
  "gate_evaluation": {
    "n_blocks": 12,
    "n_admissible": 12,
    "n_inadmissible": 0,
    "admissible_cycle_abs_pass_rate": 0.75,
    "inadmissible_cycle_abs_pass_rate": null,
    "counterexamples_inadmissible": 0,
    "counterexamples_total": 1
  },
  "admissibility_summary": [
    {
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.07058476669745316,
      "min_unique": -0.0202052033546317,
      "pass_rate": 0.75,
      "mean_K": 0.29332398202668014
    }
  ],
  "variant_summary_by_admissibility": [
    {
      "variant": "cycle_abs_sum",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.07058476669745316,
      "min_unique": -0.0202052033546317,
      "pass_rate": 0.75
    },
    {
      "variant": "cycle_plus_assoc",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.03985127083385385,
      "min_unique": -0.1422768887073371,
      "pass_rate": 0.6666666666666666
    },
    {
      "variant": "cycle_split",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.03621360892027287,
      "min_unique": -0.1295242453917214,
      "pass_rate": 0.6666666666666666
    },
    {
      "variant": "cycle_split_plus_product",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.050966291629769844,
      "min_unique": -0.1029121541362859,
      "pass_rate": 0.75
    },
    {
      "variant": "cycle_sum",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.03839378566637688,
      "min_unique": -0.1233667406170933,
      "pass_rate": 0.6666666666666666
    },
    {
      "variant": "cycle_sum_diff",
      "A_cycle_sign_admissible": true,
      "n": 12,
      "mean_unique": 0.03621360892027287,
      "min_unique": -0.1295242453917212,
      "pass_rate": 0.6666666666666666
    }
  ],
  "claim_boundary": "This is a toy/local-sector admissibility audit. The gate is diagnostic and first-principles sign-coupling based, not a universal law closure."
}
```

## Interpretation

If the counterexample is excluded by sign admissibility while most admissible blocks pass, then the remaining failure is a regime-boundary result, not a contradiction of the cycle-decomposition law inside its admissible domain.
