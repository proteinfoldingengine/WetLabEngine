# V1688.101 — Signed Coupled-Cycle Flow Minimality and Null Hardening

**Verdict:** `SIGNED_COUPLED_CYCLE_FLOW_MINIMALITY_PASS`

V1688.100 showed the winning term was:

```text
(exact_cycle_defect + correction_loss)
·
(source_abs + access_abs + div_baseline)
```

V1688.101 tests whether that term is minimal and whether it survives stronger shuffle plus sign-flip nulls.

## Summary

```json
{
  "version": "V1688.101",
  "verdict": "SIGNED_COUPLED_CYCLE_FLOW_MINIMALITY_PASS",
  "reference_law": "law_signed_full = (exact_cycle_defect + correction_loss) * (source_abs + access_abs + div_baseline)",
  "signed_full_summary": {
    "variant": "signed_full",
    "n": 19,
    "mean_unique": 0.18370912239048878,
    "min_unique": 0.011399003659977591,
    "positive_rate": 1.0,
    "mean_margin": 0.17846326782550226,
    "min_margin": 0.004204984173989512,
    "pass_rate": 1.0
  },
  "top_variants": [
    {
      "variant": "signed_full_plus_C_oriented",
      "n": 19,
      "mean_unique": 0.18940472718239146,
      "min_unique": 0.032634076506346754,
      "positive_rate": 1.0,
      "mean_margin": 0.17960686586601646,
      "min_margin": 0.028896502608804275,
      "pass_rate": 1.0
    },
    {
      "variant": "signed_full",
      "n": 19,
      "mean_unique": 0.18370912239048878,
      "min_unique": 0.011399003659977591,
      "positive_rate": 1.0,
      "mean_margin": 0.17846326782550226,
      "min_margin": 0.004204984173989512,
      "pass_rate": 1.0
    },
    {
      "variant": "L_only_flow",
      "n": 19,
      "mean_unique": 0.18010279500704668,
      "min_unique": 0.0027507389594001452,
      "positive_rate": 1.0,
      "mean_margin": 0.17548150321551026,
      "min_margin": -0.0009497945130961805,
      "pass_rate": 0.9473684210526315
    },
    {
      "variant": "no_source",
      "n": 19,
      "mean_unique": 0.1591095778417397,
      "min_unique": -0.00470979772585034,
      "positive_rate": 0.9473684210526315,
      "mean_margin": 0.15406417646534476,
      "min_margin": -0.009054086984269683,
      "pass_rate": 0.9473684210526315
    },
    {
      "variant": "D_only_flow",
      "n": 19,
      "mean_unique": 0.10763849130554809,
      "min_unique": -0.06931401146007898,
      "positive_rate": 0.9473684210526315,
      "mean_margin": 0.10302926140464269,
      "min_margin": -0.07585368855926533,
      "pass_rate": 0.9473684210526315
    },
    {
      "variant": "unsigned_full",
      "n": 19,
      "mean_unique": 0.09942803297314202,
      "min_unique": -0.013848608947657715,
      "positive_rate": 0.9473684210526315,
      "mean_margin": 0.09493973417204676,
      "min_margin": -0.016454576476458982,
      "pass_rate": 0.9473684210526315
    }
  ],
  "minimality_deltas": [
    {
      "variant": "signed_full_plus_C_oriented",
      "mean_unique_delta_vs_signed": 0.005695604791902675,
      "pass_rate_delta_vs_signed": 0.0,
      "min_unique_delta_vs_signed": 0.021235072846369163,
      "interpretation": "stronger_than_signed"
    },
    {
      "variant": "signed_full",
      "mean_unique_delta_vs_signed": 0.0,
      "pass_rate_delta_vs_signed": 0.0,
      "min_unique_delta_vs_signed": 0.0,
      "interpretation": "reference"
    },
    {
      "variant": "L_only_flow",
      "mean_unique_delta_vs_signed": -0.003606327383442104,
      "pass_rate_delta_vs_signed": -0.052631578947368474,
      "min_unique_delta_vs_signed": -0.008648264700577446,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "no_source",
      "mean_unique_delta_vs_signed": -0.024599544548749075,
      "pass_rate_delta_vs_signed": -0.052631578947368474,
      "min_unique_delta_vs_signed": -0.01610880138582793,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "D_only_flow",
      "mean_unique_delta_vs_signed": -0.07607063108494069,
      "pass_rate_delta_vs_signed": -0.052631578947368474,
      "min_unique_delta_vs_signed": -0.08071301512005657,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "unsigned_full",
      "mean_unique_delta_vs_signed": -0.08428108941734676,
      "pass_rate_delta_vs_signed": -0.052631578947368474,
      "min_unique_delta_vs_signed": -0.025247612607635306,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "div_only",
      "mean_unique_delta_vs_signed": -0.11564550607747584,
      "pass_rate_delta_vs_signed": -0.052631578947368474,
      "min_unique_delta_vs_signed": -0.013780950311816698,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "no_div",
      "mean_unique_delta_vs_signed": -0.058530373464881685,
      "pass_rate_delta_vs_signed": -0.10526315789473684,
      "min_unique_delta_vs_signed": -0.06276285510234814,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "no_access",
      "mean_unique_delta_vs_signed": -0.07305243434605807,
      "pass_rate_delta_vs_signed": -0.10526315789473684,
      "min_unique_delta_vs_signed": -0.01768204070049928,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "access_only",
      "mean_unique_delta_vs_signed": -0.1200163665707982,
      "pass_rate_delta_vs_signed": -0.10526315789473684,
      "min_unique_delta_vs_signed": -0.016009766736959863,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "C_oriented_signed_full",
      "mean_unique_delta_vs_signed": -0.12130515609497167,
      "pass_rate_delta_vs_signed": -0.10526315789473684,
      "min_unique_delta_vs_signed": -0.05693733197272577,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "source_only",
      "mean_unique_delta_vs_signed": -0.10853451182159381,
      "pass_rate_delta_vs_signed": -0.1578947368421053,
      "min_unique_delta_vs_signed": -0.139969339125258,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "cycle_only",
      "mean_unique_delta_vs_signed": -0.14194033244661194,
      "pass_rate_delta_vs_signed": -0.21052631578947367,
      "min_unique_delta_vs_signed": -0.1347657442770709,
      "interpretation": "weaker_or_less_stable"
    },
    {
      "variant": "flow_only",
      "mean_unique_delta_vs_signed": -6.75026637705553e+21,
      "pass_rate_delta_vs_signed": -1.0,
      "min_unique_delta_vs_signed": -1.2803349702973253e+23,
      "interpretation": "weaker_or_less_stable"
    }
  ],
  "claim_boundary": "Finite toy/local-sector minimality and null-hardening test only. No external empirical validation, GR, Einstein-equation, Riemann-curvature, or physical-spacetime claim."
}
```

## Interpretation

A minimality pass means the signed cycle component and the source/access/divergence flow component are both necessary. A null-hardening pass means the term is not just benefiting from value distribution or sign-randomized leakage.
