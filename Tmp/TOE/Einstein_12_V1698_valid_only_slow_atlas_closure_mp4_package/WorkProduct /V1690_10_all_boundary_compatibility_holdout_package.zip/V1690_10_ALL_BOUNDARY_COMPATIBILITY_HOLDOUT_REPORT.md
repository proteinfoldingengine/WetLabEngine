# V1690.10 — All-Boundary Compatibility Holdout

**Verdict:** `ALL_BOUNDARY_HOLDOUT_MIXED_NO_LAW_CLAIM`

This run applies the V1690.9 corrections:

```text
all adjacent loop pairs
full comparison-boundary Q_A support
boundary-shuffle null
generator-component shuffle null
graph-level median/coverage reporting
```

## Overall summary

```json
{
  "graph_case_count": 15,
  "boundary_case_count": 35,
  "sizes_tested": [
    "2x3",
    "2x4",
    "3x3"
  ],
  "seed_count_per_size": 5,
  "stationary_pass_rate_mean": 1.0,
  "faith_edge_rate_mean": 1.0,
  "graph_advantage_median_mean": 0.017986995603511136,
  "graph_advantage_median_min": -0.3026132157845995,
  "graph_advantage_positive_rate_mean": 0.7666666666666667,
  "boundary_valid_beats_null_rate": 0.7142857142857143,
  "boundary_stress_improves_source_rate": 1.0,
  "boundary_E_stress_mean": 0.5288014131006997,
  "boundary_null_E_mean": 0.5406971502912647
}
```

## Interpretation

This remains a hardening audit, not a law validation. The question is whether the diagnostic survives once the weak single-boundary design is replaced by all-boundary coverage.
