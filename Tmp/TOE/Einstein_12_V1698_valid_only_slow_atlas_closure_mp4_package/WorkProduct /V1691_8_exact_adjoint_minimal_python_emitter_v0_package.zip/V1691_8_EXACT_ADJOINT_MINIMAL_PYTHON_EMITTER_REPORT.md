# V1691.8 — Exact-Adjoint Minimal Python Emitter v0

**Verdict:** `EXACT_ADJOINT_V0_SCHEMA_PASS_COMPONENT_IDENTITY_MIXED`

This is the first exact-adjoint emitter after the V1690 component-resolved failure.

## Summary

```json
{
  "version": "V1691.8",
  "verdict": "EXACT_ADJOINT_V0_SCHEMA_PASS_COMPONENT_IDENTITY_MIXED",
  "purpose": "Minimal exact-adjoint v0 emitter using first-order retained approximation and component-dual residuals.",
  "schema_gate": true,
  "stationarity_gate_rate": 1.0,
  "uses_exact_adjoint_rate": 1.0,
  "uses_forbidden_fields_rate": 0.0,
  "dual_space_valid_rate": 1.0,
  "component_identity_pass_rate": 0.0,
  "mean_E_component_norm": 0.001961641854018611,
  "max_E_component_norm": 0.005125462442099672,
  "promotion_level": 1,
  "claim_boundary": "Exact-adjoint minimal emitter only. No retained field-law validation.",
  "runtime_seconds": 5.9485509395599365
}
```

## Interpretation

This run verifies whether the exact-adjoint schema can be emitted with component-dual residuals and signed boundary-trace `Q_A`.

It is not a law validation run.
