# Claim Notes

C_reganchor is certified across the tested domains and tested replay/fork/registry-update rollback attack family. It is not universal over arbitrary generators, adversaries, registries, quorum systems, identity infrastructure, governance rules, roots, or ledger implementations.

No physical spacetime, GR, Einstein equations, or continuum claim is made.
