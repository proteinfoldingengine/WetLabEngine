# V992 Registry-Update Ledger Rollback/Fork Audit

## Verdict

`registry_update_ledger_rollback_anchor_certified`

Closed for V992 registry-update chain anchor: **True**

## Purpose

V991 certified an append-only one-successor registry-update ledger.

V992 tests the next boundary:

```text
Can the registry-update ledger itself be rolled back or forked?
```

## Result

| guard                              |   accepted_updates |   unsafe_accepts |
|:-----------------------------------|-------------------:|-----------------:|
| naive_local_one_successor_regchain |                  3 |                2 |
| anchored_registry_update_chain     |                  0 |                0 |

## Criteria

| criterion                                               | passed   |
|:--------------------------------------------------------|:---------|
| v991_C_regchain_freeze_is_closed                        | True     |
| naive_regchain_rejects_append_duplicate_after_canonical | True     |
| naive_regchain_accepts_rollback_conflict                | True     |
| anchored_regchain_rejects_rollback_conflict             | True     |
| anchored_regchain_rejects_stale_rollback_replay         | True     |

## Interpretation

A local one-successor edge set catches duplicate epoch updates only if its history is trusted.

If the registry-update ledger is rolled back, the edge appears unused again.

Therefore the registry-update ledger must itself be anchored.

## Updated closure

```text
C_reganchor =
  C_regchain
  + anchored registry-update ledger root
```
