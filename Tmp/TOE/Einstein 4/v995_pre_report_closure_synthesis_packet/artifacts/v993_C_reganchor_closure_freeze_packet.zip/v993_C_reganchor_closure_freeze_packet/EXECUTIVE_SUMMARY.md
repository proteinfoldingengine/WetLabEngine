# V993 Executive Summary

## Status

`C_reganchor_closure_freeze_certified`

## Current object

```text
C_reganchor = (Q_obs, S_ternary, symbol_emission_event_ledger, generator_compatibility_causal, event_freshness_credential, anchored_append_only_freshness_ledger, byzantine_fault_bound_quorum_witness, authorized_witness_identity_weight_registry, current_registry_quorum_epoch_governance, append_only_one_successor_registry_update_ledger, anchored_registry_update_ledger_root)
```

## Plain English

The registry-update history itself must be anchored. Otherwise the system can roll back and reuse an already-consumed registry-update edge.

## Key result

```text
Naive local regchain unsafe accepts: 2
Anchored regchain unsafe accepts: 0
```
