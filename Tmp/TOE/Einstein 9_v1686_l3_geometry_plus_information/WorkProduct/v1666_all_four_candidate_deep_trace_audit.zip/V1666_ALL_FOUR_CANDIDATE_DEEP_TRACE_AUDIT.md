# V1666 — All-Four Candidate Deep Trace Audit

## Trace

```text
1-736499271
```

## Verdict

```text
ALL_FOUR_TRACE_CANDIDATE_WITH_BRANCH_NULL_WEAKNESS
```

## Mapping Metrics

```json
[
  {
    "mapping": "org:group",
    "found": true,
    "candidate": true,
    "C_total": 1.0,
    "C_pairwise": 0.7277777777777777,
    "delta_C_L3": 0.27222222222222225,
    "branch_count": 6,
    "closure_events": 2,
    "total_damage": 6.0,
    "total_repair": 6.0,
    "event_count": 13,
    "event_type_counts": {
      "disruption": 6,
      "repair": 4,
      "closure": 2,
      "source": 1
    },
    "source_branch_count": 1,
    "disruption_branch_count": 4,
    "repair_recovery_branch_count": 3,
    "closure_branch_count": 1
  },
  {
    "mapping": "org:resource",
    "found": true,
    "candidate": true,
    "C_total": 1.0,
    "C_pairwise": 0.798888888888889,
    "delta_C_L3": 0.20111111111111102,
    "branch_count": 6,
    "closure_events": 2,
    "total_damage": 6.0,
    "total_repair": 6.0,
    "event_count": 13,
    "event_type_counts": {
      "disruption": 6,
      "repair": 4,
      "closure": 2,
      "source": 1
    },
    "source_branch_count": 1,
    "disruption_branch_count": 3,
    "repair_recovery_branch_count": 3,
    "closure_branch_count": 2
  },
  {
    "mapping": "org:role",
    "found": true,
    "candidate": true,
    "C_total": 1.0,
    "C_pairwise": 0.85,
    "delta_C_L3": 0.15000000000000002,
    "branch_count": 3,
    "closure_events": 2,
    "total_damage": 6.0,
    "total_repair": 6.0,
    "event_count": 13,
    "event_type_counts": {
      "disruption": 6,
      "repair": 4,
      "closure": 2,
      "source": 1
    },
    "source_branch_count": 1,
    "disruption_branch_count": 3,
    "repair_recovery_branch_count": 3,
    "closure_branch_count": 1
  },
  {
    "mapping": "organization involved",
    "found": true,
    "candidate": true,
    "C_total": 1.0,
    "C_pairwise": 0.9333333333333332,
    "delta_C_L3": 0.06666666666666676,
    "branch_count": 3,
    "closure_events": 2,
    "total_damage": 6.0,
    "total_repair": 6.0,
    "event_count": 13,
    "event_type_counts": {
      "disruption": 6,
      "repair": 4,
      "closure": 2,
      "source": 1
    },
    "source_branch_count": 1,
    "disruption_branch_count": 2,
    "repair_recovery_branch_count": 2,
    "closure_branch_count": 1
  }
]
```

## Branch Null Failure Count

```text
8
```

## Interpretation

This audit inspects the only BPIC 2013 trace that recurs as a candidate under all four organizational mappings:

```text
org:group
org:resource
org:role
organization involved
```

A trace surviving all four mappings is stronger than a single-mapping candidate.  
However, if branch nulls still pass, the candidate remains branch-structure sensitive.

## Boundary

This does not close L3.
This does not prove empirical geometry.
This does not claim physical geometry, GR, ADM, or Einstein equations.

## Next Step

If this trace has branch-null weakness, run:

```text
V1667 — Hardened Empirical Criterion Revision
```

If it survives branch nulls, run:

```text
V1667 — External Trace Replication Search
```
