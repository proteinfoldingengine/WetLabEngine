# V1663 BPIC 2013 Candidate Audit

See V1663_CANDIDATE_AUDIT_REPORT.md and v1663_result.json.
