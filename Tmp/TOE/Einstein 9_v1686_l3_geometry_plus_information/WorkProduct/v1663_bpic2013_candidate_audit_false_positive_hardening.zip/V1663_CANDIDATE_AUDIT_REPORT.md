# V1663 — BPIC 2013 Candidate Audit / False-Positive Hardening

## Verdict

```text
EMPIRICAL_CANDIDATES_FAIL_HARDENED_BRANCH_NULLS
```

## Run Summary

```text
Trace count: 7554
V1662 candidate count reported: 173
Recomputed candidate count: 173
Hardened branch null failure count: 269
```

## Hardened Branch Null Failure Counts

```json
{
  "branch_merge_null": 0,
  "branch_split_null": 173,
  "terminal_label_only_null": 0,
  "branch_label_shuffle_null": 96
}
```

## Strict Tests Within Recomputed Candidates

```json
{
  "candidate_count_min_delta_gt_0.0": 173,
  "candidate_count_min_delta_gt_0.01": 173,
  "candidate_count_min_delta_gt_0.025": 165,
  "candidate_count_min_delta_gt_0.05": 126,
  "candidate_count_min_delta_gt_0.10": 66,
  "candidate_count_source_branch_ge_3_within_candidates": 0
}
```

## Interpretation

V1663 pressure-tests V1662 with branch-structure nulls.

If branch nulls pass, the signal must be narrowed because it may depend on branch-label construction rather than robust retained multi-branch structure.

## Boundary

This does not close L3.
This does not prove empirical geometry.
This does not claim physical geometry, GR, ADM, or Einstein equations.

## Next Step

V1664 — Alternative Branch Mapping Audit.
