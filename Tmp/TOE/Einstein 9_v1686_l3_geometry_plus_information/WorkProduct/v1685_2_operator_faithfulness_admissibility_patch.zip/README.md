# V1685.2 Operator-Faithfulness Admissibility Patch

Run:

```bash
python v1685_2_operator_faithfulness_admissibility_patch.py
```

Adds the missing invariant:

```text
Π(Ji ⊕ Jj) = Π(Ji) ⊕ Π(Jj)
```

Boundary:

```text
Synthetic obstruction harness only.
No proof yet.
No empirical L3 closure.
```
