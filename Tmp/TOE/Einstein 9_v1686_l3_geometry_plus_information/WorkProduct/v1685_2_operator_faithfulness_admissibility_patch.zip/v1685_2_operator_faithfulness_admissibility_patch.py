# ============================================================
# V1685.2 — Operator-Faithfulness Admissibility Patch
# ============================================================
# Purpose:
#   V1685.1 found EFLOOR_MISSING_INVARIANT_FOUND because an
#   admissible-looking projection erased O_123.
#
#   Suspected missing invariant:
#       operator-faithfulness
#
#   A projection Π is not admissible merely because it preserves branch vectors.
#   It must also preserve the retained recombination operator:
#
#       Π(Ji ⊕ Jj) = Π(Ji) ⊕ Π(Jj)
#
#   for retained pairwise recombinations.
#
# Boundary:
#   No fitting.
#   No threshold rescue.
#   No counterterm.
#   Synthetic obstruction harness only.
# ============================================================

from __future__ import annotations

import json
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd


OUT = Path("/mnt/data/v1685_2_operator_faithfulness_admissibility")
OUT.mkdir(parents=True, exist_ok=True)

np.random.seed(16852)


@dataclass
class BranchCurrent:
    name: str
    source_id: str
    order_index: int
    support: np.ndarray
    flow: np.ndarray
    closure_weight: float

    def vector(self) -> np.ndarray:
        return self.support * self.flow * self.closure_weight


@dataclass
class RecombinedState:
    vector: np.ndarray
    sources: Tuple[str, ...]
    order_signature: Tuple[int, ...]
    branch_names: Tuple[str, ...]
    closure_weight: float


def state_from_projected_branch(b: BranchCurrent, P: np.ndarray) -> RecombinedState:
    return RecombinedState(
        vector=P @ b.vector(),
        sources=(b.source_id,),
        order_signature=(b.order_index,),
        branch_names=(b.name,),
        closure_weight=b.closure_weight,
    )


def nonassoc_recombine(a, b) -> RecombinedState:
    va = a.vector if isinstance(a, RecombinedState) else a.vector()
    vb = b.vector if isinstance(b, RecombinedState) else b.vector()

    sources_a = a.sources if isinstance(a, RecombinedState) else (a.source_id,)
    sources_b = b.sources if isinstance(b, RecombinedState) else (b.source_id,)

    order_a = a.order_signature if isinstance(a, RecombinedState) else (a.order_index,)
    order_b = b.order_signature if isinstance(b, RecombinedState) else (b.order_index,)

    branches_a = a.branch_names if isinstance(a, RecombinedState) else (a.name,)
    branches_b = b.branch_names if isinstance(b, RecombinedState) else (b.name,)

    closure_a = a.closure_weight if isinstance(a, RecombinedState) else a.closure_weight
    closure_b = b.closure_weight if isinstance(b, RecombinedState) else b.closure_weight

    overlap = np.minimum(np.abs(va), np.abs(vb))
    overlap_gate = overlap / (1.0 + overlap)

    oa = np.mean(order_a)
    ob = np.mean(order_b)
    orient = np.sign(ob - oa) if ob != oa else 0.0

    closure = (2 * closure_a * closure_b) / max(1e-12, closure_a + closure_b)

    comm = orient * overlap_gate * (np.roll(va, 1) * vb - va * np.roll(vb, -1))
    v = va + vb + closure * comm

    return RecombinedState(
        vector=v,
        sources=tuple(list(sources_a) + list(sources_b)),
        order_signature=tuple(list(order_a) + list(order_b)),
        branch_names=tuple(list(branches_a) + list(branches_b)),
        closure_weight=float(closure),
    )


def obstruction(j1: BranchCurrent, j2: BranchCurrent, j3: BranchCurrent) -> np.ndarray:
    left = nonassoc_recombine(nonassoc_recombine(j1, j2), j3)
    right = nonassoc_recombine(j1, nonassoc_recombine(j2, j3))
    return left.vector - right.vector


def operator_faithfulness_residual(P: np.ndarray, branches: List[BranchCurrent]) -> float:
    """
    Max pairwise residual:
       ||Π(Ji ⊕ Jj) - (ΠJi ⊕ ΠJj)||

    This is a structural condition, not a fitted threshold.
    We record the value and use numerical zero tolerance.
    """
    residuals = []
    for i in range(len(branches)):
        for j in range(i + 1, len(branches)):
            bi, bj = branches[i], branches[j]
            original_recombined = nonassoc_recombine(bi, bj).vector
            projected_original = P @ original_recombined

            pbi = state_from_projected_branch(bi, P)
            pbj = state_from_projected_branch(bj, P)
            recombined_projected = nonassoc_recombine(pbi, pbj).vector

            residuals.append(np.linalg.norm(projected_original - recombined_projected))
    return float(max(residuals) if residuals else 0.0)


def triple_faithfulness_residual(P: np.ndarray, branches: List[BranchCurrent]) -> float:
    """
    Triple recombination faithfulness:
       Π((J1⊕J2)⊕J3) vs (ΠJ1⊕ΠJ2)⊕ΠJ3
       Π(J1⊕(J2⊕J3)) vs ΠJ1⊕(ΠJ2⊕ΠJ3)
    """
    j1, j2, j3 = branches

    left_orig = nonassoc_recombine(nonassoc_recombine(j1, j2), j3).vector
    right_orig = nonassoc_recombine(j1, nonassoc_recombine(j2, j3)).vector

    pj1 = state_from_projected_branch(j1, P)
    pj2 = state_from_projected_branch(j2, P)
    pj3 = state_from_projected_branch(j3, P)

    left_proj = nonassoc_recombine(nonassoc_recombine(pj1, pj2), pj3).vector
    right_proj = nonassoc_recombine(pj1, nonassoc_recombine(pj2, pj3)).vector

    return float(max(
        np.linalg.norm(P @ left_orig - left_proj),
        np.linalg.norm(P @ right_orig - right_proj),
    ))


def metadata_after_projection(P: np.ndarray, branches: List[BranchCurrent]) -> Dict[str, bool]:
    projected = [P @ b.vector() for b in branches]

    nonzero = all(np.linalg.norm(x) > 1e-9 for x in projected)

    pair_dists = []
    for i in range(len(projected)):
        for j in range(i + 1, len(projected)):
            pair_dists.append(np.linalg.norm(projected[i] - projected[j]))
    distinct = all(d > 1e-9 for d in pair_dists)

    order_ok = True
    for i in range(len(projected) - 1):
        d = projected[i + 1] - projected[i]
        if np.linalg.norm(d) <= 1e-9:
            order_ok = False

    total = np.sum(projected, axis=0)
    closure_ok = np.linalg.norm(total) > 1e-9 and all(
        np.linalg.norm(total - x) > 1e-9 for x in projected
    )

    return {
        "nonzero": bool(nonzero),
        "source_identity_preserved": bool(distinct),
        "branch_identity_preserved": bool(distinct),
        "order_preserved": bool(order_ok),
        "closure_preserved": bool(closure_ok),
        "metadata_admissible": bool(nonzero and distinct and order_ok and closure_ok),
    }


def full_admissibility(P: np.ndarray, branches: List[BranchCurrent]) -> Dict[str, object]:
    meta = metadata_after_projection(P, branches)
    pair_res = operator_faithfulness_residual(P, branches)
    triple_res = triple_faithfulness_residual(P, branches)

    pair_faithful = pair_res <= 1e-9
    triple_faithful = triple_res <= 1e-9

    return {
        **meta,
        "pair_operator_faithfulness_residual": pair_res,
        "triple_operator_faithfulness_residual": triple_res,
        "pair_operator_faithful": bool(pair_faithful),
        "triple_operator_faithful": bool(triple_faithful),
        "admissible": bool(meta["metadata_admissible"] and pair_faithful and triple_faithful),
    }


def identity_projection(n: int) -> np.ndarray:
    return np.eye(n)


def coordinate_projection(n: int, keep: List[int]) -> np.ndarray:
    P = np.zeros((n, n))
    for k in keep:
        P[k, k] = 1.0
    return P


def pairwise_span_projection(branches: List[BranchCurrent], pair=(0, 1)) -> np.ndarray:
    V = np.stack([branches[pair[0]].vector(), branches[pair[1]].vector()], axis=1)
    return V @ np.linalg.pinv(V.T @ V) @ V.T


def total_closure_projection(branches: List[BranchCurrent]) -> np.ndarray:
    u = np.sum([b.vector() for b in branches], axis=0)
    u = u / max(1e-12, np.linalg.norm(u))
    return np.outer(u, u)


def random_orthogonal_projection(n: int, k: int, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    A = rng.normal(size=(n, k))
    Q, _ = np.linalg.qr(A)
    return Q @ Q.T


def obstruction_orthogonal_projection(O: np.ndarray) -> np.ndarray:
    n = len(O)
    norm = np.linalg.norm(O)
    if norm <= 1e-12:
        return np.eye(n)
    u = O / norm
    return np.eye(n) - np.outer(u, u)


def make_three_branch_config(n: int = 16, seed: int = 0) -> List[BranchCurrent]:
    rng = np.random.default_rng(seed)

    s1 = np.zeros(n); s2 = np.zeros(n); s3 = np.zeros(n)
    triple = [0, 1, 2, 3]
    p12 = [4, 5]
    p23 = [6, 7]
    p13 = [8, 9]
    u1 = [10, 11]
    u2 = [12, 13]
    u3 = [14, 15]

    s1[triple + p12 + p13 + u1] = 1
    s2[triple + p12 + p23 + u2] = 1
    s3[triple + p13 + p23 + u3] = 1

    flows = []
    for i in range(3):
        f = rng.normal(size=n)
        f += (i + 1) * np.linspace(-0.4, 0.4, n)
        flows.append(f)

    return [
        BranchCurrent("J1", "S1", 0, s1, flows[0], 1.0),
        BranchCurrent("J2", "S2", 1, s2, flows[1], 1.0),
        BranchCurrent("J3", "S3", 2, s3, flows[2], 1.0),
    ]


def evaluate_projection(name: str, P: np.ndarray, branches: List[BranchCurrent], O: np.ndarray) -> Dict[str, object]:
    adm = full_admissibility(P, branches)
    PO = P @ O
    norm_O = float(np.linalg.norm(O))
    norm_PO = float(np.linalg.norm(PO))
    erased = bool(norm_PO <= 1e-9)
    return {
        "projection": name,
        "norm_O": norm_O,
        "norm_projected_O": norm_PO,
        "erases_obstruction": erased,
        **adm,
    }


def run_harness(num_configs: int = 128, n: int = 16) -> Dict[str, object]:
    rows = []
    config_rows = []

    for seed in range(num_configs):
        branches = make_three_branch_config(n=n, seed=seed)
        O = obstruction(branches[0], branches[1], branches[2])
        norm_O = float(np.linalg.norm(O))

        projections = [
            ("identity", identity_projection(n)),
            ("total_closure_projection", total_closure_projection(branches)),
            ("pair_span_J1J2", pairwise_span_projection(branches, (0, 1))),
            ("pair_span_J1J3", pairwise_span_projection(branches, (0, 2))),
            ("pair_span_J2J3", pairwise_span_projection(branches, (1, 2))),
            ("O_orthogonal_projection", obstruction_orthogonal_projection(O)),
            ("coord_keep_all", coordinate_projection(n, list(range(n)))),
            ("coord_drop_unique_tail", coordinate_projection(n, list(range(12)))),
            ("coord_triple_overlap_only", coordinate_projection(n, [0, 1, 2, 3])),
        ]

        for k in [3, 4, 6, 8, 12]:
            projections.append((f"random_rank_{k}", random_orthogonal_projection(n, k, seed=20000 + seed * 31 + k)))

        evals = []
        for pname, P in projections:
            r = evaluate_projection(pname, P, branches, O)
            r["config_seed"] = seed
            rows.append(r)
            evals.append(r)

        metadata_adm = [r for r in evals if r["metadata_admissible"]]
        full_adm = [r for r in evals if r["admissible"]]
        metadata_adm_erasing = [r for r in metadata_adm if r["erases_obstruction"]]
        full_adm_erasing = [r for r in full_adm if r["erases_obstruction"]]
        inadmissible_erasing = [r for r in evals if (not r["admissible"]) and r["erases_obstruction"]]

        min_full_adm_norm = min([r["norm_projected_O"] for r in full_adm], default=None)
        min_meta_adm_norm = min([r["norm_projected_O"] for r in metadata_adm], default=None)

        config_rows.append({
            "config_seed": seed,
            "norm_O": norm_O,
            "metadata_admissible_projection_count": len(metadata_adm),
            "full_admissible_projection_count": len(full_adm),
            "metadata_admissible_erasing_count": len(metadata_adm_erasing),
            "full_admissible_erasing_count": len(full_adm_erasing),
            "inadmissible_erasing_count": len(inadmissible_erasing),
            "min_metadata_admissible_projected_norm": min_meta_adm_norm,
            "min_full_admissible_projected_norm": min_full_adm_norm,
        })

    df = pd.DataFrame(rows)
    cdf = pd.DataFrame(config_rows)

    df.to_csv(OUT / "v1685_2_projection_audit_rows.csv", index=False)
    cdf.to_csv(OUT / "v1685_2_config_summary.csv", index=False)

    total_full_adm = int(df["admissible"].sum())
    total_full_adm_erasing = int((df["admissible"] & df["erases_obstruction"]).sum())
    total_metadata_adm_erasing = int((df["metadata_admissible"] & df["erases_obstruction"]).sum())
    total_inadm_erasing = int(((~df["admissible"]) & df["erases_obstruction"]).sum())

    positive_lower_bound_configs = int((cdf["min_full_admissible_projected_norm"].fillna(0) > 1e-9).sum())
    all_configs_positive = positive_lower_bound_configs == len(cdf)

    if total_full_adm_erasing == 0 and all_configs_positive:
        verdict = "EFLOOR_OPERATOR_BOUNDARY_NECESSARY"
    elif total_full_adm_erasing > 0:
        verdict = "EFLOOR_MISSING_INVARIANT_FOUND"
    elif total_metadata_adm_erasing > 0 and total_full_adm_erasing == 0:
        verdict = "EFLOOR_OPERATOR_FAITHFULNESS_INVARIANT_CONFIRMED"
    else:
        verdict = "EFLOOR_UNRESOLVED"

    return {
        "document_id": "V1685_2_OPERATOR_FAITHFULNESS_ADMISSIBILITY_PATCH",
        "status": "completed",
        "verdict": verdict,
        "num_configs": num_configs,
        "projection_rows": int(len(df)),
        "total_metadata_admissible_erasing_count": total_metadata_adm_erasing,
        "total_full_admissible_projection_count": total_full_adm,
        "total_full_admissible_erasing_count": total_full_adm_erasing,
        "total_inadmissible_erasing_count": total_inadm_erasing,
        "configs_with_positive_min_full_admissible_norm": positive_lower_bound_configs,
        "all_configs_positive_lower_bound": bool(all_configs_positive),
        "mean_min_full_admissible_projected_norm": float(cdf["min_full_admissible_projected_norm"].dropna().mean()) if cdf["min_full_admissible_projected_norm"].notna().any() else None,
        "min_of_min_full_admissible_projected_norm": float(cdf["min_full_admissible_projected_norm"].dropna().min()) if cdf["min_full_admissible_projected_norm"].notna().any() else None,
        "outputs": {
            "projection_audit_rows": str(OUT / "v1685_2_projection_audit_rows.csv"),
            "config_summary": str(OUT / "v1685_2_config_summary.csv"),
        },
        "claim_boundary": "Synthetic obstruction harness with operator-faithfulness. Not a formal proof and not empirical L3 closure.",
    }


result = run_harness(num_configs=128, n=16)
(OUT / "v1685_2_result.json").write_text(json.dumps(result, indent=2))

report = f"""# V1685.2 — Operator-Faithfulness Admissibility Patch

## Verdict

```text
{result['verdict']}
```

## Summary

```json
{json.dumps(result, indent=2)}
```

## Boundary

Synthetic obstruction harness with operator-faithfulness.
Not a formal proof.
Not empirical L3 closure.
"""
(OUT / "V1685_2_OPERATOR_FAITHFULNESS_REPORT.md").write_text(report)

print(json.dumps(result, indent=2))
