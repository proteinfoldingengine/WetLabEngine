# V1686.24 Minimal Clean-Room Reproducer
# Runs the key symbolic checks in one file.

import itertools
import json
from pathlib import Path
import sympy as sp

OUT = Path("/mnt/data/v1686_24_clean_room_replication_run")
OUT.mkdir(parents=True, exist_ok=True)

def roll_down(v):
    return sp.Matrix([v[-1], *v[:-1]])

def roll_up(v):
    return sp.Matrix([*v[1:], v[0]])

def phi(x, y, gamma):
    rx = roll_down(x)
    uy = roll_up(y)
    return sp.Matrix([gamma * (rx[i] * y[i] - x[i] * uy[i]) for i in range(len(x))])

def recombine(x, y, gamma):
    return x + y + phi(x, y, gamma)

def associator_gated(j1, j2, j3, g12, g23, gL, gR):
    return sp.simplify(
        recombine(recombine(j1, j2, g12), j3, gL)
        - recombine(j1, recombine(j2, j3, g23), gR)
    )

def make_vectors(n, masks, prefix):
    vectors = []
    symbols = []
    for bi, mask in enumerate(masks):
        entries = []
        for k, active in enumerate(mask):
            if active:
                s = sp.symbols(f"{prefix}{bi+1}_{k}", nonzero=True)
                symbols.append(s)
                entries.append(s)
            else:
                entries.append(sp.Integer(0))
        vectors.append(sp.Matrix(entries))
    return vectors, symbols

def classify_sector(sector_id, masks):
    n = len(masks[0])
    g12,g23,gL,gR = sp.symbols(f"g12_{sector_id} g23_{sector_id} gL_{sector_id} gR_{sector_id}", nonzero=True)
    J, symbols = make_vectors(n, masks, f"x{sector_id}_")
    J1,J2,J3 = J
    O = associator_gated(J1,J2,J3,g12,g23,gL,gR)
    M = sp.Matrix.hstack(J1,J2,J3,O)
    B = sp.Matrix.hstack(J1,J2,J3)

    minor_found = False
    minor_rows = None
    for rows in itertools.combinations(range(n), 4):
        det = sp.factor(M[list(rows), :].det())
        if det != 0:
            minor_found = True
            minor_rows = rows
            break

    vals = {}
    for idx, s in enumerate(symbols):
        vals[s] = sp.Integer(((idx * 3 + 2) % 7) - 3) or sp.Integer(2)
    vals[g12] = sp.Rational(2,3)
    vals[g23] = sp.Rational(5,4)
    vals[gL] = sp.Rational(7,5)
    vals[gR] = sp.Rational(3,2)

    rank_B = int(B.subs(vals).rank())
    rank_aug = int(M.subs(vals).rank())
    rank_lift = rank_aug - rank_B

    return {
        "sector_id": sector_id,
        "masks": ["".join(map(str,m)) for m in masks],
        "symbolic_minor_found": minor_found,
        "minor_rows": str(minor_rows),
        "rank_B": rank_B,
        "rank_aug": rank_aug,
        "rank_lift": rank_lift,
        "classification": "CERTIFIED_GENERIC" if minor_found and rank_lift > 0 else "UNRESOLVED"
    }

sectors = [
    [[1,1,0,1],[1,0,1,1],[0,1,1,1]],
    [[1,1,1,0],[1,1,0,1],[1,0,1,1]],
    [[1,1,0,1],[1,1,1,0],[0,1,1,1]],
    [[1,0,1,1],[0,1,1,1],[1,1,1,0]],
    [[1,1,1,1],[1,1,1,1],[1,1,1,1]],
    [[1,1,1,0,1],[1,1,0,1,1],[1,0,1,1,1]],
    [[1,1,0,1,0],[1,0,1,1,1],[0,1,1,1,1]],
    [[1,1,1,0,0],[1,1,0,1,0],[1,0,1,0,1]],
    [[1,1,0,0,1],[1,0,1,1,0],[1,0,1,0,1]],
    [[1,1,1,1,0],[1,1,1,0,1],[1,1,0,1,1]],
]

rows = [classify_sector(i, s) for i, s in enumerate(sectors)]
certified = sum(1 for r in rows if r["classification"] == "CERTIFIED_GENERIC")
result = {
    "document_id": "V1686_24_MINIMAL_CLEAN_ROOM_REPRODUCER",
    "status": "completed",
    "sector_count": len(rows),
    "certified_generic_count": certified,
    "certified_generic_rate": certified / len(rows),
    "verdict": "PASS" if certified == len(rows) else "PARTIAL_OR_FAIL",
    "rows": rows,
}

(OUT / "v1686_24_minimal_reproducer_result.json").write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
