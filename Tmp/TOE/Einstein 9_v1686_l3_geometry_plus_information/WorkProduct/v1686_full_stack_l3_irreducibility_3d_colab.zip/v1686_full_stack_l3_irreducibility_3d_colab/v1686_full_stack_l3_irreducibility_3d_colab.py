# ============================================================
# V1686 Full-Stack L3 Irreducibility 3D Simulation
# ============================================================
# Colab-ready, self-contained.
#
# Purpose:
#   Genesis Pin
#   -> pruning-order / provenance admissibility
#   -> L1/L2 pairwise retained closure
#   -> L3 three-branch recombination
#   -> operator-faithful projection audit
#   -> epsilon-floor persistence from associator obstruction
#
# Main claim visualized:
#   L3 is not merely a geometric layer.
#   It is geometry-plus-information:
#   a third-order retained-current associator obstruction contributes
#   irreducible information that honest/operator-faithful projections cannot erase.
#
# Boundary:
#   Synthetic mechanism/audit simulation only.
#   No empirical L3 claim.
#   No physical spacetime / GR / ADM claim.
#   No universal theorem over all operators.
# ============================================================

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Tuple, List

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

DOCUMENT_ID = "V1686_FULL_STACK_L3_IRREDUCIBILITY_3D_SIMULATION"
OUT = Path("/content/v1686_full_stack_l3_irreducibility_3d")
OUT.mkdir(parents=True, exist_ok=True)

SEED = 168631
rng = np.random.default_rng(SEED)

N = 52
ORDERED_SLICES = 34
DPI = 140
SAVE_GIF = True
SAVE_PNG_KEYFRAMES = True
SAVE_CSV = True
GIF_FPS = 7

MARGIN = {
    "branch_norm": 1e-8,
    "branch_separation": 1e-8,
    "rank_lift": 1,
    "assoc_norm": 1e-8,
}

print(f"Output directory: {OUT}")


@dataclass
class GenesisPin:
    root_anchor: str
    quorum_required: int
    witness_count: int
    pinned: bool
    note: str


@dataclass
class BranchCurrent:
    name: str
    source_id: str
    retained_order: int
    support: np.ndarray
    flow: np.ndarray
    closure_weight: float
    provenance_valid: bool = True

    def vector(self) -> np.ndarray:
        return self.support * self.flow * self.closure_weight


@dataclass
class RecombinedState:
    vector: np.ndarray
    sources: Tuple[str, ...]
    retained_order_signature: Tuple[int, ...]
    branch_names: Tuple[str, ...]
    closure_weight: float
    provenance_valid: bool


# ============================================================
# FIELD HELPERS
# ============================================================

def make_grid(n: int = N):
    axis = np.linspace(-1.0, 1.0, n)
    X, Y = np.meshgrid(axis, axis)
    return X, Y

X, Y = make_grid(N)


def gaussian2d(cx, cy, sx, sy, amp=1.0):
    return amp * np.exp(-(((X - cx) ** 2) / (2 * sx ** 2) + ((Y - cy) ** 2) / (2 * sy ** 2)))


def normalize_field(z: np.ndarray, eps: float = 1e-12):
    m = np.max(np.abs(z))
    if m < eps:
        return z.copy()
    return z / m


def smooth_support(center_x, center_y, radius, softness=0.075):
    r = np.sqrt((X - center_x) ** 2 + (Y - center_y) ** 2)
    return 1.0 / (1.0 + np.exp((r - radius) / softness))


def ring_support(radius=0.62, width=0.16, softness=0.04):
    r = np.sqrt(X**2 + Y**2)
    outer = 1.0 / (1.0 + np.exp((r - (radius + width)) / softness))
    inner = 1.0 / (1.0 + np.exp((r - (radius - width)) / softness))
    return outer * (1 - inner)


def laplacian(z: np.ndarray):
    return (
        np.roll(z, 1, axis=0) + np.roll(z, -1, axis=0)
        + np.roll(z, 1, axis=1) + np.roll(z, -1, axis=1)
        - 4 * z
    )


def curvature_like(z: np.ndarray):
    return normalize_field(-laplacian(z))


def branch_rank(vectors: List[np.ndarray], tol=1e-9):
    M = np.stack([v.reshape(-1) for v in vectors], axis=1)
    return int(np.linalg.matrix_rank(M, tol=tol))


def rank_lift(branch_vectors_flat: List[np.ndarray], assoc_flat: np.ndarray):
    B = np.stack(branch_vectors_flat, axis=1)
    BA = np.column_stack([B, assoc_flat])
    return int(np.linalg.matrix_rank(BA, tol=1e-9) - np.linalg.matrix_rank(B, tol=1e-9))


def residual_to_span(x: np.ndarray, basis: List[np.ndarray]):
    B = np.stack([b.reshape(-1) for b in basis], axis=1)
    xf = x.reshape(-1)
    coeff = np.linalg.pinv(B) @ xf
    proj = B @ coeff
    res = xf - proj
    return res.reshape(x.shape), float(np.linalg.norm(res)), coeff


# ============================================================
# GENESIS / PROVENANCE / BRANCH CONSTRUCTION
# ============================================================

def create_genesis_pin() -> GenesisPin:
    return GenesisPin(
        root_anchor="ROOT:GENESIS_ANCHOR_000",
        quorum_required=3,
        witness_count=3,
        pinned=True,
        note="Synthetic genesis pin: provenance root required before retained recombination is admissible."
    )


def create_branch_currents() -> List[BranchCurrent]:
    S1 = np.maximum(smooth_support(-0.34, -0.14, 0.72), 0.45 * ring_support())
    S2 = np.maximum(smooth_support(0.34, -0.12, 0.72), 0.45 * ring_support())
    S3 = np.maximum(smooth_support(0.02, 0.42, 0.72), 0.45 * ring_support())

    F1 = (
        1.10 * gaussian2d(-0.45, -0.20, 0.24, 0.34)
        - 0.52 * gaussian2d(0.30, 0.34, 0.30, 0.22)
        + 0.18 * np.sin(3.0 * np.pi * X) * np.cos(2.0 * np.pi * Y)
    )
    F2 = (
        1.05 * gaussian2d(0.42, -0.18, 0.25, 0.35)
        - 0.46 * gaussian2d(-0.28, 0.34, 0.28, 0.24)
        + 0.20 * np.cos(2.6 * np.pi * X) * np.sin(2.2 * np.pi * Y)
    )
    F3 = (
        1.02 * gaussian2d(0.02, 0.44, 0.34, 0.24)
        - 0.38 * gaussian2d(0.02, -0.46, 0.28, 0.25)
        + 0.22 * np.sin(2.2 * np.pi * (X + Y))
    )

    F1 = normalize_field(F1)
    F2 = normalize_field(F2)
    F3 = normalize_field(F3)

    return [
        BranchCurrent("J1", "SOURCE_A", 0, S1, F1, 1.0),
        BranchCurrent("J2", "SOURCE_B", 1, S2, F2, 1.0),
        BranchCurrent("J3", "SOURCE_C", 2, S3, F3, 1.0),
    ]


# ============================================================
# RETAINED RECOMBINATION OPERATOR
# ============================================================

def overlap_gate(a: np.ndarray, b: np.ndarray):
    overlap = np.minimum(np.abs(a), np.abs(b))
    return overlap / (1.0 + overlap)


def retained_order_orientation(sig_a: Tuple[int, ...], sig_b: Tuple[int, ...]):
    oa = float(np.mean(sig_a))
    ob = float(np.mean(sig_b))
    if ob > oa:
        return 1.0
    if ob < oa:
        return -1.0
    return 0.0


def harmonic_closure_weight(ca: float, cb: float):
    return (2.0 * ca * cb) / max(1e-12, ca + cb)


def kernel_order_overlap(a: np.ndarray, b: np.ndarray):
    roll_a = 0.5 * (np.roll(a, 1, axis=0) + np.roll(a, 1, axis=1))
    roll_b = 0.5 * (np.roll(b, -1, axis=0) + np.roll(b, -1, axis=1))
    return roll_a * b - a * roll_b


def as_state(obj) -> RecombinedState:
    if isinstance(obj, RecombinedState):
        return obj
    if isinstance(obj, BranchCurrent):
        return RecombinedState(
            vector=obj.vector(),
            sources=(obj.source_id,),
            retained_order_signature=(obj.retained_order,),
            branch_names=(obj.name,),
            closure_weight=obj.closure_weight,
            provenance_valid=obj.provenance_valid,
        )
    raise TypeError(type(obj))


def retained_recombine(a, b) -> RecombinedState:
    A = as_state(a)
    B = as_state(b)

    orient = retained_order_orientation(A.retained_order_signature, B.retained_order_signature)
    closure = harmonic_closure_weight(A.closure_weight, B.closure_weight)
    gate = overlap_gate(A.vector, B.vector)
    phi = closure * orient * gate * kernel_order_overlap(A.vector, B.vector)
    v = A.vector + B.vector + phi

    return RecombinedState(
        vector=v,
        sources=tuple(list(A.sources) + list(B.sources)),
        retained_order_signature=tuple(list(A.retained_order_signature) + list(B.retained_order_signature)),
        branch_names=tuple(list(A.branch_names) + list(B.branch_names)),
        closure_weight=float(closure),
        provenance_valid=bool(A.provenance_valid and B.provenance_valid),
    )


def associator_obstruction(J1, J2, J3):
    left = retained_recombine(retained_recombine(J1, J2), J3)
    right = retained_recombine(J1, retained_recombine(J2, J3))
    return left.vector - right.vector


# ============================================================
# PROJECTION / ADMISSIBILITY AUDITS
# ============================================================

def project_field_lowpass(z: np.ndarray, keep_radius=0.24):
    F = np.fft.fftshift(np.fft.fft2(z))
    n, m = z.shape
    yy, xx = np.ogrid[-1:1:n*1j, -1:1:m*1j]
    rr = np.sqrt(xx**2 + yy**2)
    mask = (rr <= keep_radius).astype(float)
    return np.real(np.fft.ifft2(np.fft.ifftshift(F * mask)))


def project_branch(branch: BranchCurrent, keep_radius=0.24) -> BranchCurrent:
    return BranchCurrent(
        name=branch.name,
        source_id=branch.source_id,
        retained_order=branch.retained_order,
        support=np.clip(project_field_lowpass(branch.support, keep_radius), 0, None),
        flow=project_field_lowpass(branch.flow, keep_radius),
        closure_weight=branch.closure_weight,
        provenance_valid=branch.provenance_valid,
    )


def operator_faithfulness_gap(branches: List[BranchCurrent], keep_radius=0.24):
    gaps = {}
    for (i, j) in [(0, 1), (0, 2), (1, 2)]:
        Ji, Jj = branches[i], branches[j]
        lhs = project_field_lowpass(retained_recombine(Ji, Jj).vector, keep_radius)
        Pi = project_branch(Ji, keep_radius)
        Pj = project_branch(Jj, keep_radius)
        rhs = retained_recombine(Pi, Pj).vector
        gaps[f"{Ji.name}{Jj.name}"] = float(np.linalg.norm(lhs - rhs))
    return gaps


def admissibility_metrics(branches: List[BranchCurrent], O123: np.ndarray):
    vectors = [b.vector().reshape(-1) for b in branches]
    assoc_flat = O123.reshape(-1)

    norms = [float(np.linalg.norm(v)) for v in vectors]
    separations = []
    for i in range(3):
        for j in range(i + 1, 3):
            separations.append(float(np.linalg.norm(vectors[i] - vectors[j])))

    r_branch = branch_rank([b.vector() for b in branches])
    r_lift = rank_lift(vectors, assoc_flat)
    assoc_norm = float(np.linalg.norm(assoc_flat))
    residual, residual_norm, coeff = residual_to_span(O123, [b.vector() for b in branches])
    relative_residual = residual_norm / max(1e-12, assoc_norm)

    return {
        "branch_norm_min": float(min(norms)),
        "branch_separation_min": float(min(separations)),
        "branch_rank": int(r_branch),
        "associator_norm": assoc_norm,
        "associator_span_residual_norm": float(residual_norm),
        "associator_span_relative_residual": float(relative_residual),
        "rank_lift": int(r_lift),
        "rank_lift_positive": bool(r_lift > 0),
        "NOOCI_supported": bool(r_lift > 0 and residual_norm > MARGIN["assoc_norm"]),
    }


# ============================================================
# ORDERED SLICE SIMULATION
# ============================================================

def emergence_weight(ordered_index: int, center: float, sharpness: float = 0.35):
    x = (ordered_index - center) * sharpness
    return 1.0 / (1.0 + np.exp(-x))


def compute_slice(branches: List[BranchCurrent], ordered_index: int):
    J1, J2, J3 = branches
    w1 = emergence_weight(ordered_index, 3, 0.75)
    w2 = emergence_weight(ordered_index, 8, 0.75)
    w3 = emergence_weight(ordered_index, 15, 0.75)

    B1 = BranchCurrent(J1.name, J1.source_id, J1.retained_order, J1.support, J1.flow, w1)
    B2 = BranchCurrent(J2.name, J2.source_id, J2.retained_order, J2.support, J2.flow, w2)
    B3 = BranchCurrent(J3.name, J3.source_id, J3.retained_order, J3.support, J3.flow, w3)

    pair12 = retained_recombine(B1, B2).vector
    pair23 = retained_recombine(B2, B3).vector
    pair13 = retained_recombine(B1, B3).vector
    pair_mean = (pair12 + pair23 + pair13) / 3.0

    O123 = associator_obstruction(B1, B2, B3)
    geom_field = curvature_like(pair_mean)
    info_field = normalize_field(O123)
    l3_field = normalize_field(0.78 * geom_field + 0.55 * info_field)

    projected_l3 = project_field_lowpass(l3_field, keep_radius=0.20)
    epsilon_floor_field = l3_field - projected_l3

    metrics = admissibility_metrics([B1, B2, B3], O123)
    proj_gap = operator_faithfulness_gap([B1, B2, B3], keep_radius=0.20)
    metrics["operator_faithfulness_gap_max_lowpass_projection"] = float(max(proj_gap.values()))
    metrics["epsilon_floor_norm"] = float(np.linalg.norm(epsilon_floor_field))
    metrics["ordered_index"] = int(ordered_index)
    metrics["w1"] = float(w1)
    metrics["w2"] = float(w2)
    metrics["w3"] = float(w3)

    return {
        "B": [B1, B2, B3],
        "pair_mean": pair_mean,
        "geom_field": geom_field,
        "O123": O123,
        "info_field": info_field,
        "l3_field": l3_field,
        "projected_l3": projected_l3,
        "epsilon_floor_field": epsilon_floor_field,
        "metrics": metrics,
    }


# ============================================================
# 3D RENDERING
# ============================================================

def add_surface(ax, Z, title, zlim=(-1.15, 1.15), cmap="viridis"):
    ax.plot_surface(X, Y, Z, cmap=cmap, linewidth=0, antialiased=True, alpha=0.92)
    ax.set_title(title, fontsize=9)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_zticks([])
    ax.set_zlim(*zlim)
    ax.view_init(elev=32, azim=-58)


def add_text_panel(ax, lines, title="Audit"):
    ax.axis("off")
    ax.set_title(title, fontsize=10, loc="left")
    ax.text(0.02, 0.98, "\n".join(lines), va="top", ha="left", fontsize=8, family="monospace", transform=ax.transAxes)


def render_keyframe(branches, ordered_index: int, path: Path):
    state = compute_slice(branches, ordered_index)
    m = state["metrics"]

    fig = plt.figure(figsize=(15, 9))

    ax1 = fig.add_subplot(2, 3, 1, projection="3d")
    add_surface(ax1, normalize_field(sum([b.vector() for b in state["B"]])), "Genesis-certified retained branches", cmap="viridis")

    ax2 = fig.add_subplot(2, 3, 2, projection="3d")
    add_surface(ax2, state["geom_field"], "L1/L2 pairwise geometry-like closure", cmap="plasma")

    ax3 = fig.add_subplot(2, 3, 3, projection="3d")
    add_surface(ax3, state["info_field"], "O_123 information-bearing associator", cmap="coolwarm")

    ax4 = fig.add_subplot(2, 3, 4, projection="3d")
    add_surface(ax4, state["l3_field"], "L3 = geometry + retained information", cmap="magma")

    ax5 = fig.add_subplot(2, 3, 5, projection="3d")
    add_surface(ax5, normalize_field(state["epsilon_floor_field"]), "epsilon-floor after projection attempt", cmap="inferno")

    ax6 = fig.add_subplot(2, 3, 6)
    lines = [
        f"document: {DOCUMENT_ID}",
        f"ordered_index: {ordered_index}",
        "",
        "Genesis Pin:",
        "  ROOT:GENESIS_ANCHOR_000",
        "  quorum: 3/3 PASS",
        "",
        "Admissibility:",
        f"  branch_rank: {m['branch_rank']}",
        f"  rank_lift: {m['rank_lift']}  {'PASS' if m['rank_lift_positive'] else 'FAIL'}",
        f"  NOOCI: {'PASS' if m['NOOCI_supported'] else 'FAIL'}",
        "",
        "Obstruction:",
        f"  ||O_123||: {m['associator_norm']:.4f}",
        f"  residual/span: {m['associator_span_relative_residual']:.4f}",
        f"  epsilon-floor norm: {m['epsilon_floor_norm']:.4f}",
        "",
        "Projection audit:",
        f"  lowpass op-faith gap: {m['operator_faithfulness_gap_max_lowpass_projection']:.4f}",
        "",
        "Interpretation:",
        "  L3 is not removed.",
        "  epsilon-floor marks irreducible",
        "  third-order retained information.",
    ]
    add_text_panel(ax6, lines, "Full-stack audit")

    fig.suptitle("V1686 Full-Stack L3 Irreducibility Simulation — Geometry + Information", fontsize=13, y=0.98)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(path, dpi=DPI)
    plt.close(fig)

    return state


def render_animation(branches, gif_path: Path):
    fig = plt.figure(figsize=(13, 7))
    ax_main = fig.add_subplot(1, 2, 1, projection="3d")
    ax_info = fig.add_subplot(1, 2, 2)
    ax_info.axis("off")

    def update(frame_idx):
        ax_main.clear()
        ax_info.clear()
        ax_info.axis("off")

        state = compute_slice(branches, frame_idx)
        m = state["metrics"]
        Z = state["l3_field"]

        ax_main.plot_surface(X, Y, Z, cmap="magma", linewidth=0, antialiased=True, alpha=0.93)
        ax_main.set_title("L3 ordered emergence: geometry + irreducible retained information", fontsize=10)
        ax_main.set_xticks([])
        ax_main.set_yticks([])
        ax_main.set_zticks([])
        ax_main.set_zlim(-1.15, 1.15)
        ax_main.view_init(elev=32, azim=-60 + 1.4 * frame_idx)

        lines = [
            "V1686 Full-Stack L3 Irreducibility",
            "",
            f"ordered_index: {frame_idx}",
            "",
            "Stack:",
            "  Genesis Pin: PASS",
            "  provenance: PASS",
            "  pairwise closure: active",
            "  triple recombination: active" if frame_idx > 14 else "  triple recombination: emerging",
            "",
            "Associator audit:",
            f"  ||O_123|| = {m['associator_norm']:.4f}",
            f"  rank_lift = {m['rank_lift']}",
            f"  NOOCI = {'PASS' if m['NOOCI_supported'] else 'WAIT'}",
            f"  epsilon-floor norm = {m['epsilon_floor_norm']:.4f}",
            "",
            "Meaning:",
            "  three-way retained recombination",
            "  creates an independent direction",
            "  not reducible to pairwise branches.",
            "",
            "Claim boundary:",
            "  synthetic mechanism demo only",
        ]
        ax_info.text(0.02, 0.98, "\n".join(lines), va="top", ha="left", fontsize=9, family="monospace")
        return []

    anim = FuncAnimation(fig, update, frames=ORDERED_SLICES, interval=1000 / GIF_FPS, blit=False)
    anim.save(gif_path, writer=PillowWriter(fps=GIF_FPS))
    plt.close(fig)


def make_metric_plots(df: pd.DataFrame):
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df["ordered_index"], df["associator_norm"], label="||O_123||")
    ax.plot(df["ordered_index"], df["epsilon_floor_norm"], label="epsilon-floor norm")
    ax.plot(df["ordered_index"], df["associator_span_relative_residual"], label="residual/span")
    ax.set_xlabel("ordered_index")
    ax.set_ylabel("diagnostic value")
    ax.set_title("V1686 diagnostics across ordered slices")
    ax.legend()
    ax.grid(True, alpha=0.25)
    fig.tight_layout()
    fig.savefig(OUT / "v1686_metric_diagnostics.png", dpi=DPI)
    plt.close(fig)


# ============================================================
# MAIN RUN
# ============================================================

def run():
    genesis = create_genesis_pin()
    branches = create_branch_currents()

    print("==============================")
    print("V1686 FULL-STACK L3 IRREDUCIBILITY SIMULATION")
    print("==============================")
    print(f"Genesis pinned: {genesis.pinned}, quorum {genesis.witness_count}/{genesis.quorum_required}")

    rows = []
    keyframes = [0, 6, 12, 18, 24, ORDERED_SLICES - 1]

    for ordered_index in range(ORDERED_SLICES):
        state = compute_slice(branches, ordered_index)
        rows.append(state["metrics"])

        if SAVE_PNG_KEYFRAMES and ordered_index in keyframes:
            render_keyframe(branches, ordered_index, OUT / f"v1686_keyframe_ordered_{ordered_index:03d}.png")

    df = pd.DataFrame(rows)

    if SAVE_CSV:
        df.to_csv(OUT / "v1686_ordered_slice_metrics.csv", index=False)

    make_metric_plots(df)

    if SAVE_GIF:
        render_animation(branches, OUT / "v1686_l3_irreducibility_full_stack.gif")

    final = df.iloc[-1].to_dict()
    verdict = (
        "FULL_STACK_L3_GEOMETRY_PLUS_INFORMATION_DEMO_PASS"
        if final["NOOCI_supported"] and final["rank_lift"] > 0
        else "FULL_STACK_L3_DEMO_INCONCLUSIVE"
    )

    def clean_value(v):
        if isinstance(v, (np.floating, float)):
            return float(v)
        if isinstance(v, (np.integer, int)):
            return int(v)
        if isinstance(v, (np.bool_, bool)):
            return bool(v)
        return v

    result = {
        "document_id": DOCUMENT_ID,
        "status": "completed",
        "verdict": verdict,
        "genesis": asdict(genesis),
        "final_ordered_slice_metrics": {k: clean_value(v) for k, v in final.items()},
        "interpretation": {
            "L3_status": "not eliminated; reclassified",
            "core_claim": "L3 behaves as a geometry-plus-information layer in this synthetic full-stack audit.",
            "epsilon_floor_meaning": "epsilon-floor persists as a lower-bound route from an irreducible third-order retained-current associator obstruction.",
            "operator_boundary": "metadata-only projection is insufficient; admissible projection must be operator-faithful.",
        },
        "outputs": {
            "metrics_csv": str(OUT / "v1686_ordered_slice_metrics.csv"),
            "metric_plot": str(OUT / "v1686_metric_diagnostics.png"),
            "gif": str(OUT / "v1686_l3_irreducibility_full_stack.gif") if SAVE_GIF else None,
            "keyframes": [str(OUT / f"v1686_keyframe_ordered_{k:03d}.png") for k in keyframes],
        },
        "claim_boundary": "Synthetic full-stack audit simulation only. Not empirical L3, not physical geometry, not GR/ADM.",
    }

    (OUT / "v1686_full_stack_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1686 Full-Stack L3 Irreducibility 3D Simulation

## Verdict

```text
{verdict}
```

## Core finding visualized

```text
L3 is not merely geometric.
L3 is geometry-plus-information:
a third-order retained-current associator obstruction contributes
irreducible information that operator-faithful admissible projection cannot erase.
```

## Final ordered-slice metrics

```json
{json.dumps(result['final_ordered_slice_metrics'], indent=2)}
```

## Boundary

Synthetic full-stack audit simulation only.
No empirical L3 claim.
No physical geometry / GR / ADM claim.
"""
    (OUT / "V1686_FULL_STACK_REPORT.md").write_text(report)

    print("\n==============================")
    print("RESULT")
    print("==============================")
    print(json.dumps(result, indent=2))
    print(f"\nOutputs saved to: {OUT}")


if __name__ == "__main__":
    run()
