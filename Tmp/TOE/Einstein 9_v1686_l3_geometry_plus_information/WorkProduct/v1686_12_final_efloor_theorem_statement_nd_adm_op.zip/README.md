# V1686.12 Final ε_floor Theorem Statement

Conditional theorem for nondegenerate operator-faithful retained recombination.
