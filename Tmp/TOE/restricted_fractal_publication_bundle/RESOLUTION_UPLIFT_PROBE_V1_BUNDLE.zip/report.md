# Resolution Uplift Probe v1

Goal:
Test whether the earlier scale-consistency results were being limited mainly by the small support size (20 points).

Method:
- compute branch field as before
- upsample field by factor 4 via interpolation
- rerun scale-slope estimation on the upsampled support

## Summary
 threshold_frac  mean_fine_slope  std_fine_slope  mean_upsampled_slope  std_upsampled_slope  mean_slope_shift  std_slope_shift  n_rows
            0.3         0.883411        0.032659              0.853369             0.018201         -0.030042         0.024672     100
            0.4         0.783652        0.034588              0.766201             0.020133         -0.017452         0.024627     100
            0.5         0.662364        0.059254              0.699771             0.020259          0.037407         0.045302     100
            0.6         0.617657        0.026052              0.619383             0.036914          0.001726         0.027905     100

## Read
If the upsampled field preserves similar slope structure with lower artifacts, that supports the view that finite-size limitations were constraining the earlier renormalization tests.
