# Consensus Effective-Dimension Band

This note extracts the strongest shared band across the three most aligned observables:

- raw_support
- persistent_support
- change_support

## Observable bands
        observable  band_lo  band_hi  mean_center
    change_support 0.508147 0.919429     0.714711
persistent_support 0.588411 0.918929     0.737507
       raw_support 0.581819 0.914760     0.731469

## Consensus summary
                               core_observables  consensus_lo  consensus_hi  has_consensus_overlap
raw_support, persistent_support, change_support      0.588411       0.91476                   True

## Read
If the strongest observables share a common overlap band, that is the cleanest candidate for a restricted effective-dimension core band.
