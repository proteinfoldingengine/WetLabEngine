# Fractal Reality Campaign v1

This campaign measures branch-support scaling across:
- multiple seeds
- multiple iterations
- multiple thresholds
- multiple partition scales

## Summary by threshold
 threshold_frac  mean_scale_slope  std_scale_slope  n_fits
           0.25          0.911554         0.027895     100
           0.30          0.881918         0.032393     100
           0.35          0.825019         0.057087     100
           0.40          0.783924         0.035272     100
           0.45          0.723273         0.030390     100
           0.50          0.661125         0.059039     100
           0.55          0.636696         0.046574     100
           0.60          0.613931         0.029488     100
           0.65          0.596905         0.032456     100
           0.70          0.577396         0.031185     100

## Summary by time
 t  mean_scale_slope  std_scale_slope  n_fits
 0          0.748987         0.124057      50
 1          0.767112         0.125217      50
 2          0.773668         0.127881      50
 3          0.771606         0.130671      50
 4          0.765624         0.124395      50
 5          0.750942         0.126165      50
 6          0.738782         0.122488      50
 7          0.725991         0.114216      50
 8          0.717817         0.111625      50
 9          0.709919         0.112569      50
10          0.707405         0.110374      50
11          0.703659         0.115958      50
12          0.700982         0.113355      50
13          0.702127         0.119291      50
14          0.696572         0.121015      50
15          0.695358         0.119284      50
16          0.691655         0.117971      50
17          0.687971         0.121443      50
18          0.684704         0.121039      50
19          0.682603         0.120767      50

## Candidate plateau thresholds
 threshold_frac  mean_scale_slope  std_scale_slope  n_fits
           0.25          0.911554         0.027895     100
           0.30          0.881918         0.032393     100
           0.35          0.825019         0.057087     100
           0.40          0.783924         0.035272     100
           0.45          0.723273         0.030390     100
           0.50          0.661125         0.059039     100
           0.55          0.636696         0.046574     100
           0.60          0.613931         0.029488     100
           0.65          0.596905         0.032456     100
           0.70          0.577396         0.031185     100

## Read
A threshold band with:
- nontrivial mean slope
- low slope variance across seeds / time
would be the first serious evidence of a stable effective dimension regime.
