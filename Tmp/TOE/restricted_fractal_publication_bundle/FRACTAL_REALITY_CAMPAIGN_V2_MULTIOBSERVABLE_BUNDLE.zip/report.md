# Fractal Reality Campaign v2 — Multiple Observables

Goal:
Test whether the scale-consistent effective-dimension signal survives across more than one branch observable.

Observables:
- raw_support
- energy_support
- change_support
- persistent_support

## Summary
        observable  threshold_frac  mean_scale_slope  std_scale_slope  n_fits
    change_support            0.30          0.863284         0.056145     100
    change_support            0.35          0.811172         0.065739     100
    change_support            0.40          0.771464         0.063718     100
    change_support            0.45          0.708548         0.071522     100
    change_support            0.50          0.647745         0.078974     100
    change_support            0.55          0.612175         0.081539     100
    change_support            0.60          0.588590         0.080443     100
    energy_support            0.30          0.638320         0.047681     100
    energy_support            0.35          0.614411         0.028733     100
    energy_support            0.40          0.602806         0.033369     100
    energy_support            0.45          0.590681         0.032678     100
    energy_support            0.50          0.571016         0.038802     100
    energy_support            0.55          0.535455         0.054964     100
    energy_support            0.60          0.494196         0.065783     100
persistent_support            0.30          0.887848         0.031081     100
persistent_support            0.35          0.830565         0.053566     100
persistent_support            0.40          0.790360         0.037967     100
persistent_support            0.45          0.730647         0.030203     100
persistent_support            0.50          0.667926         0.059660     100
persistent_support            0.55          0.640794         0.044728     100
persistent_support            0.60          0.614406         0.025994     100
       raw_support            0.30          0.881873         0.032887     100
       raw_support            0.35          0.823859         0.055530     100
       raw_support            0.40          0.783398         0.035624     100
       raw_support            0.45          0.723273         0.030390     100
       raw_support            0.50          0.659231         0.058986     100
       raw_support            0.55          0.636602         0.047475     100
       raw_support            0.60          0.612048         0.030229     100

## Observable bands
        observable  band_lo  band_hi  mean_center
    change_support 0.508147 0.919429     0.714711
    energy_support 0.428412 0.686001     0.578126
persistent_support 0.588411 0.918929     0.737507
       raw_support 0.581819 0.914760     0.731469

## Read
If several observables produce overlapping effective-dimension bands, then the scaling signal belongs more to the system than to one hand-picked measurement.
