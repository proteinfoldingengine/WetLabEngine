# Consensus Band Resolution Uplift v1

## Observable uplift overlap bands
        observable  fine_band_lo  fine_band_hi  upsampled_band_lo  upsampled_band_hi  overlap_lo  overlap_hi  has_overlap
    change_support      0.507602      0.916526           0.643231           0.945442    0.643231    0.916526         True
persistent_support      0.586736      0.919662           0.678002           0.952966    0.678002    0.919662         True
       raw_support      0.576785      0.913492           0.671289           0.947480    0.671289    0.913492         True

## Consensus uplift band
 consensus_lo  consensus_hi  has_consensus  n_observables
     0.678002      0.913492           True              3

This tests whether the shared effective-dimension core band survives resolution uplift across the strongest observables.
