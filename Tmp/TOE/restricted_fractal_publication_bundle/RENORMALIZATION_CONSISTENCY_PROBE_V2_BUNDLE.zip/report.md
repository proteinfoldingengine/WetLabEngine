# Renormalization Consistency Probe v2

This extends the first renormalization check by testing multiple coarse-graining factors.

## Summary
 threshold_frac  block_factor  mean_fine_slope  std_fine_slope  mean_coarse_slope  std_coarse_slope  mean_slope_gap  std_slope_gap  n_rows
            0.3             2         0.825214        0.047164           0.933977          0.025007        0.108763       0.040334     100
            0.3             4         0.825214        0.047164           0.660964          0.000000       -0.164250       0.047164     100
            0.3             5         0.825214        0.047164                NaN               NaN             NaN            NaN       0
            0.4             2         0.689345        0.048154           0.854089          0.037560        0.164744       0.032218     100
            0.4             4         0.689345        0.048154           0.660964          0.000000       -0.028381       0.048154     100
            0.4             5         0.689345        0.048154                NaN               NaN             NaN            NaN       0
            0.5             2         0.526997        0.076273           0.712409          0.074195        0.185413       0.015138     100
            0.5             4         0.526997        0.076273           0.660964          0.000000        0.133967       0.076273     100
            0.5             5         0.526997        0.076273                NaN               NaN             NaN            NaN       0
            0.6             2         0.479696        0.036398           0.657138          0.035419        0.177442       0.032660     100
            0.6             4         0.479696        0.036398           0.678942          0.124843        0.199246       0.149194     100
            0.6             5         0.479696        0.036398                NaN               NaN             NaN            NaN       0

## Read
This asks whether the scaling signal survives more than one coarse-graining choice.
A modest slope gap across several block factors is stronger evidence for genuine scale-consistency than a single block-size result.
