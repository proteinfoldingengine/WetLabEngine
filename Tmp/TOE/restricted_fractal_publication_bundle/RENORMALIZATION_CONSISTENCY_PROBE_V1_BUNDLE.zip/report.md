# Renormalization Consistency Probe v1

Goal:
Check whether branch-support scaling survives coarse-graining.

Method:
- compute fine support slope
- coarse-grain support by block size 2
- recompute support slope
- compare fine vs coarse slopes

## Summary
 threshold_frac  mean_fine_slope  std_fine_slope  mean_coarse_slope  std_coarse_slope  mean_slope_gap  std_slope_gap  n_rows
            0.3         0.783179        0.054132           0.847202          0.034297        0.064024       0.048651     100
            0.4         0.641762        0.049007           0.752190          0.048087        0.110429       0.041097     100
            0.5         0.483265        0.072076           0.575897          0.091431        0.092631       0.028817     100
            0.6         0.459855        0.053249           0.535879          0.062148        0.076023       0.061547     100

## Read
A small slope gap and stable fine/coarse agreement would support a renormalization-style consistency reading.
