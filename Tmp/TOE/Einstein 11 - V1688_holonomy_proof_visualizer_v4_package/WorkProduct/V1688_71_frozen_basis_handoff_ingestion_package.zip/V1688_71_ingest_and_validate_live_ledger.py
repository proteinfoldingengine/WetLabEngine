#!/usr/bin/env python3
"""V1688.71 live-ledger ingestion wrapper.
Stops unless a real V1687 ordered-slice metrics ledger with nodes/edges/cycles is supplied.
"""
from pathlib import Path
import sys, json
REQUIRED = {
    "nodes": ["node_id","sector_id","retained_order_index","source_abs","access_abs","div_baseline","weak_target","B_vec","O3_vec","H4_perp_vec"],
    "edges": ["from_node","to_node","gamma_pq"],
    "cycles": ["cycle_id"]
}
print(json.dumps({"status":"validator_wrapper_ready","required":REQUIRED,"note":"Run against supplied live V1687 ledger files; do not use toy ledgers."}, indent=2))
sys.exit(0)
