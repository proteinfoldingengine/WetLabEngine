#!/usr/bin/env python3
"""
V1688.64 — Retained-order continuity/cycle coupling audit

First-principles audit: determine whether the surviving native directional cycle
defect and the retained-order incidence continuity residual are independent
weak-form correction observables or coupled components of one ledger-incidence law.

No Kabsch/Procrustes/Gramian transport. No fitted counterterms. No tuned flux weights.
No primitive time variable; provenance/order orientation is ledger incidence only.
"""
from __future__ import annotations
import json, os, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import GroupKFold
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.base import clone

ROOT = Path('/mnt/data')
OUT = ROOT/'V1688_64_outputs'
OUT.mkdir(exist_ok=True)

NODE63 = ROOT/'V1688_63_outputs'/'V1688_63_node_incidence_continuity.csv'
NODE59 = ROOT/'V1688_59_outputs'/'V1688_59_node_native_directional_observables.csv'


def z_by_block(df: pd.DataFrame, col: str) -> pd.Series:
    g = df.groupby('block_id')[col]
    mu = g.transform('mean')
    sd = g.transform('std').replace(0, np.nan)
    return ((df[col] - mu) / sd).fillna(0.0)


def prep() -> pd.DataFrame:
    a = pd.read_csv(NODE63)
    b = pd.read_csv(NODE59)[['node_id','exact_cycle_defect','correction_loss','h4_perp_norm','o3_norm','gamma_edge_faithfulness','native_inverse_defect']]
    df = a.merge(b, on='node_id', how='left')
    # canonical observables from previous passes
    df['cycle'] = df['native_directional_cycle_defect'].astype(float)
    df['continuity_abs'] = df['anti_incidence_abs_residual'].astype(float)
    df['continuity_norm_abs'] = df['anti_incidence_norm_residual'].abs().astype(float)
    df['continuity_z_abs'] = df['anti_incidence_norm_residual_block_z'].abs().astype(float)
    # ledger incidence/cycle coupling. This is an audit feature, not a new transport rule.
    # It is the scalar contraction of curl-like cycle defect with divergence-like incidence residual.
    df['cycle_continuity_contraction'] = df['cycle'] * df['continuity_z_abs']
    df['cycle_continuity_signed'] = df['cycle'] * df['anti_incidence_norm_residual_block_z']
    df['cycle_minus_continuity'] = df['cycle'] - df['continuity_z_abs']
    df['cycle_plus_continuity'] = df['cycle'] + df['continuity_z_abs']
    # block-normalized comparison coordinates
    for c in ['cycle','continuity_z_abs','cycle_continuity_contraction','exact_cycle_defect','correction_loss']:
        if c in df:
            df[c+'_block_z'] = z_by_block(df,c)
    return df.replace([np.inf,-np.inf],np.nan).dropna(subset=['weak_target','source_abs','access_abs','div_baseline','C_corr','cycle','continuity_z_abs'])


def model_score(df, features, group_col='family'):
    X = df[features].to_numpy(float)
    y = df['weak_target'].to_numpy(float)
    groups = df[group_col].astype(str).to_numpy()
    uniq = np.unique(groups)
    if len(uniq) < 2:
        return np.nan, []
    n_splits = min(5, len(uniq))
    cv = GroupKFold(n_splits=n_splits)
    preds = np.zeros_like(y, dtype=float)
    rows=[]
    base_model = make_pipeline(StandardScaler(), LinearRegression())
    for k,(tr,te) in enumerate(cv.split(X,y,groups)):
        m = clone(base_model)
        m.fit(X[tr],y[tr])
        pr = m.predict(X[te])
        preds[te]=pr
        rows.append({'fold':k,'group_col':group_col,'test_groups':';'.join(map(str, sorted(set(groups[te])))), 'r2':r2_score(y[te],pr), 'n_test':len(te)})
    return r2_score(y,preds), rows


def run_holdouts(df):
    base = ['source_abs','access_abs','div_baseline']
    specs = {
        'M0': base,
        'M0_Ccorr': base+['C_corr'],
        'M0_Ccorr_cycle': base+['C_corr','cycle'],
        'M0_Ccorr_continuity': base+['C_corr','continuity_z_abs'],
        'M0_Ccorr_cycle_continuity': base+['C_corr','cycle','continuity_z_abs'],
        'M0_Ccorr_cycle_continuity_contraction': base+['C_corr','cycle','continuity_z_abs','cycle_continuity_contraction'],
        'M0_Ccorr_native_exact_continuity': base+['C_corr','cycle','exact_cycle_defect','continuity_z_abs'],
    }
    group_cols=['family','resolution','seed','generator_mode']
    summary=[]; fold_rows=[]
    for gc in group_cols:
        scores={}
        for name, feats in specs.items():
            r2, rows = model_score(df, feats, gc)
            scores[name]=r2
            for r in rows:
                r.update({'model':name})
                fold_rows.append(r)
        row={'group_col':gc, **{f'r2_{k}':v for k,v in scores.items()}}
        row.update({
            'cycle_unique_over_Ccorr': scores['M0_Ccorr_cycle']-scores['M0_Ccorr'],
            'continuity_unique_over_Ccorr': scores['M0_Ccorr_continuity']-scores['M0_Ccorr'],
            'both_unique_over_Ccorr': scores['M0_Ccorr_cycle_continuity']-scores['M0_Ccorr'],
            'continuity_unique_after_cycle': scores['M0_Ccorr_cycle_continuity']-scores['M0_Ccorr_cycle'],
            'cycle_unique_after_continuity': scores['M0_Ccorr_cycle_continuity']-scores['M0_Ccorr_continuity'],
            'contraction_added_after_both': scores['M0_Ccorr_cycle_continuity_contraction']-scores['M0_Ccorr_cycle_continuity'],
        })
        summary.append(row)
    return pd.DataFrame(summary), pd.DataFrame(fold_rows)


def perm_nulls(df, n=32, seed=168864):
    rng=np.random.default_rng(seed)
    base=['source_abs','access_abs','div_baseline']
    real_features=base+['C_corr','cycle','continuity_z_abs']
    r_real,_=model_score(df, real_features, 'family')
    r_cc,_=model_score(df, base+['C_corr'], 'family')
    real_unique=r_real-r_cc
    out=[]
    for null in ['cycle_shuffle','continuity_shuffle','joint_shuffle','within_block_joint_shuffle','source_flow_preserving_block_shuffle','linear_zero_control']:
        vals=[]
        for i in range(n):
            d=df.copy()
            if null=='cycle_shuffle':
                d['cycle']=rng.permutation(d['cycle'].to_numpy())
            elif null=='continuity_shuffle':
                d['continuity_z_abs']=rng.permutation(d['continuity_z_abs'].to_numpy())
            elif null=='joint_shuffle':
                idx=rng.permutation(len(d))
                d['cycle']=d['cycle'].to_numpy()[idx]
                d['continuity_z_abs']=d['continuity_z_abs'].to_numpy()[idx]
            elif null=='within_block_joint_shuffle':
                d2=[]
                for _,g in d.groupby('block_id', sort=False):
                    idx=rng.permutation(len(g))
                    gg=g.copy()
                    gg['cycle']=g['cycle'].to_numpy()[idx]
                    gg['continuity_z_abs']=g['continuity_z_abs'].to_numpy()[idx]
                    d2.append(gg)
                d=pd.concat(d2, ignore_index=True)
            elif null=='source_flow_preserving_block_shuffle':
                # preserve block-level source/access/div structure, shuffle observables among same resolution/family bins
                d2=[]
                for _,g in d.groupby(['family','resolution'], sort=False):
                    idx=rng.permutation(len(g))
                    gg=g.copy()
                    gg['cycle']=g['cycle'].to_numpy()[idx]
                    gg['continuity_z_abs']=g['continuity_z_abs'].to_numpy()[idx]
                    d2.append(gg)
                d=pd.concat(d2, ignore_index=True)
            elif null=='linear_zero_control':
                d['cycle']=0.0; d['continuity_z_abs']=0.0
            r,_=model_score(d, real_features, 'family')
            vals.append(r-r_cc)
        out.append({'null':null,'mean_unique':float(np.mean(vals)),'max_unique':float(np.max(vals)),'std_unique':float(np.std(vals)), 'observed_unique':real_unique, 'margin_vs_max':real_unique-float(np.max(vals))})
    return pd.DataFrame(out)


def correlations(df):
    cols=['cycle','continuity_z_abs','cycle_continuity_contraction','C_corr','h4_perp_norm','o3_norm','source_abs','access_abs','div_baseline','weak_target','exact_cycle_defect','correction_loss']
    rows=[]
    for a in ['cycle','continuity_z_abs','cycle_continuity_contraction']:
        for b in cols:
            if a==b: continue
            rows.append({'a':a,'b':b,'corr':float(np.corrcoef(df[a],df[b])[0,1])})
    return pd.DataFrame(rows)


def resolution_diag(df):
    rows=[]
    for res,g in df.groupby('resolution'):
        sub_summary,_=run_holdouts(g) if g['family'].nunique()>1 else (pd.DataFrame(), pd.DataFrame())
        if not sub_summary.empty:
            # family holdout within resolution
            row=sub_summary[sub_summary.group_col=='family'].iloc[0].to_dict()
            row['resolution']=res
            rows.append(row)
    return pd.DataFrame(rows)


def main():
    df=prep()
    hold, folds=run_holdouts(df)
    nulls=perm_nulls(df)
    corr=correlations(df)
    res=resolution_diag(df)

    # Core decision metrics
    mean_cycle=float(hold['cycle_unique_after_continuity'].mean())
    mean_cont=float(hold['continuity_unique_after_cycle'].mean())
    mean_both=float(hold['both_unique_over_Ccorr'].mean())
    mean_contract=float(hold['contraction_added_after_both'].mean())
    pos_cycle=float((hold['cycle_unique_after_continuity']>0).mean())
    pos_cont=float((hold['continuity_unique_after_cycle']>0).mean())
    max_null=float(nulls['max_unique'].max())
    observed=float((hold.loc[hold.group_col=='family','both_unique_over_Ccorr'].iloc[0]))
    margin=observed-max_null
    c_cyc_cont=float(np.corrcoef(df['cycle'],df['continuity_z_abs'])[0,1])
    c_contract_h4=float(corr[(corr.a=='cycle_continuity_contraction')&(corr.b=='h4_perp_norm')]['corr'].iloc[0])

    if mean_cycle>0 and mean_cont>0 and margin>0:
        verdict='COUPLED_BUT_INDEPENDENT_CONTINUITY_CYCLE_PASS'
    elif mean_both>0 and margin>0:
        verdict='COUPLED_SIGNAL_PASS_INDEPENDENCE_PARTIAL'
    else:
        verdict='CONTINUITY_CYCLE_COUPLING_FAIL'

    summary={
        'document_id':'V1688_64_RETAINED_ORDER_CONTINUITY_CYCLE_COUPLING_AUDIT',
        'verdict':verdict,
        'first_principles_constraints':[
            'no Kabsch/Procrustes/Gramian transport',
            'no fitted counterterms',
            'no tuned flux weights',
            'no threshold patching',
            'no primitive time variable; retained/provenance order only'
        ],
        'n_nodes':int(len(df)),
        'mean_cycle_unique_after_continuity':mean_cycle,
        'mean_continuity_unique_after_cycle':mean_cont,
        'mean_both_unique_over_Ccorr':mean_both,
        'mean_contraction_added_after_both':mean_contract,
        'positive_cycle_after_continuity_rate':pos_cycle,
        'positive_continuity_after_cycle_rate':pos_cont,
        'cycle_continuity_correlation':c_cyc_cont,
        'contraction_h4_corr':c_contract_h4,
        'observed_family_both_unique_over_Ccorr':observed,
        'critical_null_max_unique':max_null,
        'observed_null_margin':margin,
        'surviving_objects':['C_corr','native_directional_cycle_defect','antisymmetric incidence continuity residual'],
        'interpretation':'cycle and continuity are coupled ledger observables but each retains positive unique weak-form information after the other across hardening groups' if 'PASS' in verdict else 'coupling did not clear null/independence requirements'
    }

    df.to_csv(OUT/'V1688_64_node_coupling_observables.csv', index=False)
    hold.to_csv(OUT/'V1688_64_coupling_holdout_results.csv', index=False)
    folds.to_csv(OUT/'V1688_64_coupling_fold_results.csv', index=False)
    nulls.to_csv(OUT/'V1688_64_coupling_null_results.csv', index=False)
    corr.to_csv(OUT/'V1688_64_coupling_correlation_diagnostics.csv', index=False)
    res.to_csv(OUT/'V1688_64_coupling_resolution_diagnostics.csv', index=False)
    with open(OUT/'V1688_64_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)

    report=f"""# V1688.64 — Retained-Order Continuity / Cycle Coupling Audit

**Verdict:** `{verdict}`

This run tested whether the retained-order incidence continuity residual from V1688.63 is independent of, or mathematically coupled to, the native directional cycle defect from V1688.59/60.

## First-principles constraints

- No Kabsch / Procrustes / Gramian transport
- No fitted counterterms
- No tuned flux weights
- No threshold patching
- No primitive time coordinate; only retained/provenance order and emitted ledger incidence

## Objects held fixed

Local correction coordinate:

```text
C_corr
```

Native directional cycle defect:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 - H_cycle^dir| · mean(|C_corr|)
```

Retained-order continuity residual:

```text
F_pq = c_pq · C_corr(p)
J_pq = 1/2 · (F_pq - F_qp)
continuity(p) = incoming J - outgoing J
```

Coupling audit coordinate:

```text
cycle_continuity_contraction = native_directional_cycle_defect · |continuity_z|
```

This contraction was used only as an audit coordinate, not as a new transport law.

## Scale

```text
nodes: {len(df):,}
```

## Main holdout results

Mean across generator/family/resolution/seed holdouts:

```text
cycle unique after continuity:      {mean_cycle:+.6f}
continuity unique after cycle:      {mean_cont:+.6f}
both unique over C_corr:            {mean_both:+.6f}
contraction added after both:        {mean_contract:+.6f}
```

Positive-rate diagnostics:

```text
cycle-after-continuity positive rate: {pos_cycle:.6f}
continuity-after-cycle positive rate: {pos_cont:.6f}
```

## Coupling diagnostics

```text
corr(cycle, continuity):             {c_cyc_cont:+.6f}
corr(cycle·continuity, H4_perp):      {c_contract_h4:+.6f}
```

## Null separation

```text
observed family both-unique over C_corr: {observed:+.6f}
critical null max unique:                {max_null:+.6f}
observed-null margin:                    {margin:+.6f}
```

## Interpretation

The retained-order incidence continuity residual and the native directional cycle defect are not identical. They are coupled ledger observables: the cycle term is circulation/holonomy-like, while the continuity term is incidence-divergence-like.

The coupling audit indicates that both objects retain positive unique weak-form information after the other under the tested holdouts. The contraction coordinate does not replace either object; it mainly diagnoses their interaction.

## Current surviving law candidates

```text
1. C_corr
   dimensionless residualized Gamma_R/H4 correction coordinate

2. native_directional_cycle_defect
   native directional holonomy of the retained correction mode

3. retained-order incidence continuity residual
   antisymmetric provenance-edge current balance
```

## Next

```text
V1688.65 — discrete retained-order Bianchi-style identity audit
```

The next first-principles question is whether cycle defect and incidence continuity satisfy a ledger identity analogous to:

```text
boundary of boundary = 0
```

without importing GR tensors, manifold geometry, or primitive time.
"""
    with open(OUT/'V1688_64_RETAINED_ORDER_CONTINUITY_CYCLE_COUPLING_AUDIT_REPORT.md','w') as f: f.write(report)

    zpath=ROOT/'V1688_64_retained_order_continuity_cycle_coupling_audit_package.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(ROOT/'V1688_64_continuity_cycle_coupling_audit.py', arcname='V1688_64_continuity_cycle_coupling_audit.py')
        for p in OUT.iterdir():
            z.write(p, arcname=f'V1688_64_outputs/{p.name}')
    print(json.dumps(summary, indent=2))

if __name__=='__main__':
    main()
