# V1688.5 Operator-Induced Transport Law

Transport derived from retained recombination bracketings. No GR claim.
