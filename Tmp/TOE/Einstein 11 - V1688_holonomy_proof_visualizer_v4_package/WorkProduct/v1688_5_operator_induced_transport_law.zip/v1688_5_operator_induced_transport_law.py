
from pathlib import Path
import json, numpy as np, pandas as pd

OUT = Path("/mnt/data/v1688_5_operator_induced_transport_law_outputs")
OUT.mkdir(parents=True, exist_ok=True)

GRID_SIZES = [28, 40, 52]
EPS = 1e-12
SEED = 16885

def g2(X,Y,cx,cy,s=.75):
    return np.exp(-((X-cx)**2+(Y-cy)**2)/(2*s*s))

def nf(F):
    m=np.max(np.abs(F))
    return F if m<EPS else F/m

def recombine(a,b,mode="nonlinear"):
    if mode=="linear":
        return a+b
    rd=.5*(np.roll(a,1,0)+np.roll(a,1,1))
    ru=.5*(np.roll(b,-1,0)+np.roll(b,-1,1))
    ov=np.minimum(np.abs(a),np.abs(b))/(1+np.minimum(np.abs(a),np.abs(b)))
    return a+b+.35*ov*(rd*b-a*ru)

def h4(J,mode="nonlinear"):
    J1,J2,J3,J4=J
    return recombine(recombine(recombine(J1,J2,mode),J3,mode),J4,mode)-recombine(J1,recombine(J2,recombine(J3,J4,mode),mode),mode)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode),C,mode)-recombine(A,recombine(B,C,mode),mode)

def corr(a,b):
    a=np.asarray(a); b=np.asarray(b)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

def make_sources(n):
    xs=np.linspace(-3,3,n)
    ys=np.linspace(-3,3,n)
    X,Y=np.meshgrid(xs,ys)
    centers=[(-1.6,-1.1),(1.55,-1.0),(-1.15,1.55),(1.35,1.45)]
    J=[]
    for k,(cx,cy) in enumerate(centers):
        F=g2(X,Y,cx,cy)+.1*np.sin((k+2)*X+.3*k)*np.cos((k+1.5)*Y-.2*k)
        J.append(nf(F))
    return xs,ys,X,Y,np.array(J)

def local_patch(n, ix, iy, rad=2):
    P=np.zeros((n,n))
    for a in range(max(0,iy-rad),min(n,iy+rad+1)):
        for b in range(max(0,ix-rad),min(n,ix+rad+1)):
            d2=(a-iy)**2+(b-ix)**2
            P[a,b]=np.exp(-d2/(2*(rad/1.4+EPS)**2))
    return nf(P)

def bracketing_transport_delta(J, P, mode="nonlinear"):
    # perturbation P is transported through the two canonical L4 bracketings
    J1,J2,J3,J4=J

    # left bracketing transport contribution of perturbation placed into J1
    left_base = recombine(recombine(recombine(J1,J2,mode),J3,mode),J4,mode)
    left_pert = recombine(recombine(recombine(J1+P,J2,mode),J3,mode),J4,mode)
    d_left = left_pert-left_base

    # right bracketing transport contribution of same perturbation
    right_base = recombine(J1,recombine(J2,recombine(J3,J4,mode),mode),mode)
    right_pert = recombine(J1+P,recombine(J2,recombine(J3,J4,mode),mode),mode)
    d_right = right_pert-right_base

    # operator-induced loop defect
    return d_left-d_right

def local_lower_order_features(J, ix, iy, window=3, mode="nonlinear"):
    H4=np.abs(h4(J,mode))
    O3=sum(np.abs(o) for o in [
        assoc3(J[0],J[1],J[2],mode),
        assoc3(J[0],J[1],J[3],mode),
        assoc3(J[0],J[2],J[3],mode),
        assoc3(J[1],J[2],J[3],mode)
    ])
    pair=np.abs(np.sum(J,0))
    y0,y1=max(0,iy-window),min(H4.shape[0],iy+window+1)
    x0,x1=max(0,ix-window),min(H4.shape[1],ix+window+1)
    return {
        "rho4_local": float(np.mean(H4[y0:y1,x0:x1])),
        "o3_local": float(np.mean(O3[y0:y1,x0:x1])),
        "pair_local": float(np.mean(pair[y0:y1,x0:x1])),
    }

def audit_grid(n, condition):
    xs,ys,X,Y,J=make_sources(n)
    mode="linear" if condition=="linear_operator" else "nonlinear"
    rng=np.random.default_rng(SEED+n)

    if condition=="source_label_shuffle":
        J=J.copy()
        rng.shuffle(J, axis=0)

    H4field=np.abs(h4(J,mode))
    if condition=="h4_density_shuffle":
        # only use shuffled density for comparison labels, transport still operator-derived
        flat=H4field.ravel().copy()
        rng.shuffle(flat)
        H4_measure=flat.reshape(H4field.shape)
    else:
        H4_measure=H4field

    # sample interior points
    pts=[]
    for ix in np.linspace(5,n-6,7,dtype=int):
        for iy in np.linspace(5,n-6,7,dtype=int):
            pts.append((int(ix),int(iy)))

    rows=[]
    for ix,iy in pts:
        P=local_patch(n,ix,iy,rad=2)
        defect=bracketing_transport_delta(J,P,mode=mode)
        # local defect energy near original patch and global defect norm
        loc=local_lower_order_features(J,ix,iy,window=3,mode=mode)
        y0,y1=max(0,iy-4),min(n,iy+5)
        x0,x1=max(0,ix-4),min(n,ix+5)
        defect_local=float(np.mean(np.abs(defect[y0:y1,x0:x1])))
        defect_global=float(np.linalg.norm(defect)/(n*n))
        rho4_measure=float(np.mean(H4_measure[y0:y1,x0:x1]))
        rows.append({
            "grid_n":n,
            "condition":condition,
            "ix":ix,
            "iy":iy,
            "rho4_local":rho4_measure,
            "o3_local":loc["o3_local"],
            "pair_local":loc["pair_local"],
            "operator_loop_defect_local":defect_local,
            "operator_loop_defect_global":defect_global
        })
    return pd.DataFrame(rows)

conditions=[
    "real",
    "linear_operator",
    "source_label_shuffle",
    "h4_density_shuffle"
]

allrows=[]
summaries=[]
for n in GRID_SIZES:
    for cond in conditions:
        df=audit_grid(n,cond)
        allrows.append(df)
        summaries.append({
            "grid_n":n,
            "condition":cond,
            "point_count":len(df),
            "corr_rho4_operator_loop_defect_local":corr(df.rho4_local,df.operator_loop_defect_local),
            "corr_o3_operator_loop_defect_local":corr(df.o3_local,df.operator_loop_defect_local),
            "corr_pair_operator_loop_defect_local":corr(df.pair_local,df.operator_loop_defect_local),
            "mean_operator_loop_defect_local":float(df.operator_loop_defect_local.mean()),
            "mean_operator_loop_defect_global":float(df.operator_loop_defect_global.mean())
        })

full=pd.concat(allrows,ignore_index=True)
summ=pd.DataFrame(summaries)
full.to_csv(OUT/"v1688_5_operator_transport_rows.csv",index=False)
summ.to_csv(OUT/"v1688_5_summary.csv",index=False)

group=summ.groupby("condition").agg(
    mean_corr=("corr_rho4_operator_loop_defect_local","mean"),
    min_corr=("corr_rho4_operator_loop_defect_local","min"),
    std_corr=("corr_rho4_operator_loop_defect_local","std"),
    mean_defect=("mean_operator_loop_defect_local","mean")
).reset_index()
group.to_csv(OUT/"v1688_5_grouped.csv",index=False)

real=group[group.condition=="real"].iloc[0].to_dict()
nulls=group[group.condition!="real"]
best_null=float(nulls.mean_corr.max())
margin=float(real["mean_corr"]-best_null)

if real["mean_corr"]>0.45 and margin>0.10:
    verdict="L4_OPERATOR_TRANSPORT_BRIDGE_SUPPORTED"
elif real["mean_corr"]>0.25 and margin>0.03:
    verdict="L4_OPERATOR_TRANSPORT_BRIDGE_PARTIAL"
else:
    verdict="L4_OPERATOR_TRANSPORT_BRIDGE_NOT_SUPPORTED"

result={
    "document_id":"V1688_5_OPERATOR_INDUCED_TRANSPORT_LAW",
    "status":"completed",
    "verdict":verdict,
    "real_mean_corr":float(real["mean_corr"]),
    "best_null_mean_corr":best_null,
    "real_minus_best_null_margin":margin,
    "condition_grouped":group.to_dict(orient="records"),
    "outputs":{
        "rows":str(OUT/"v1688_5_operator_transport_rows.csv"),
        "summary":str(OUT/"v1688_5_summary.csv"),
        "grouped":str(OUT/"v1688_5_grouped.csv")
    },
    "claim_boundary":"Operator-induced loop-defect proxy only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
(OUT/"v1688_5_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_5_OPERATOR_INDUCED_TRANSPORT_LAW_REPORT.md").write_text("# V1688.5 Operator-Induced Transport Law\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
