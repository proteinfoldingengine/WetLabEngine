# V1688.5 Operator-Induced Transport Law

```json
{
  "document_id": "V1688_5_OPERATOR_INDUCED_TRANSPORT_LAW",
  "status": "completed",
  "verdict": "L4_OPERATOR_TRANSPORT_BRIDGE_NOT_SUPPORTED",
  "real_mean_corr": 0.05176758578241967,
  "best_null_mean_corr": 0.32014965873775875,
  "real_minus_best_null_margin": -0.26838207295533906,
  "condition_grouped": [
    {
      "condition": "h4_density_shuffle",
      "mean_corr": 0.32014965873775875,
      "min_corr": -0.000984535900972982,
      "std_corr": 0.3203514363575665,
      "mean_defect": 0.00036045131843735826
    },
    {
      "condition": "linear_operator",
      "mean_corr": 0.0,
      "min_corr": 0.0,
      "std_corr": 0.0,
      "mean_defect": 1.768785653576822e-17
    },
    {
      "condition": "real",
      "mean_corr": 0.05176758578241967,
      "min_corr": -0.14689564407216596,
      "std_corr": 0.18236280201659,
      "mean_defect": 0.00036045131843735826
    },
    {
      "condition": "source_label_shuffle",
      "mean_corr": 0.2450837753464845,
      "min_corr": -0.08212501565233449,
      "std_corr": 0.2856687666364286,
      "mean_defect": 0.00035198926801493466
    }
  ],
  "outputs": {
    "rows": "/mnt/data/v1688_5_operator_induced_transport_law_outputs/v1688_5_operator_transport_rows.csv",
    "summary": "/mnt/data/v1688_5_operator_induced_transport_law_outputs/v1688_5_summary.csv",
    "grouped": "/mnt/data/v1688_5_operator_induced_transport_law_outputs/v1688_5_grouped.csv"
  },
  "claim_boundary": "Operator-induced loop-defect proxy only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
```
