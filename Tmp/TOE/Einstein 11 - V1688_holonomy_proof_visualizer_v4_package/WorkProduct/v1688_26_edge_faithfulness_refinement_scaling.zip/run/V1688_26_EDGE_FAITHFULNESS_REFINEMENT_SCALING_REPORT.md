# V1688.26 — Edge-Faithfulness Refinement Scaling

```json
{
  "document_id": "V1688_26_EDGE_FAITHFULNESS_REFINEMENT_SCALING",
  "status": "completed",
  "verdict": "EDGE_FAITHFULNESS_REFINEMENT_SCALING_NOT_SUPPORTED",
  "mean_delta_edge_real": 0.7277797973014118,
  "min_delta_edge_real": 0.28275236008633864,
  "positive_delta_rate_real": NaN,
  "mean_delta_edge_shuffle": 0.005522772896468247,
  "real_minus_shuffle_margin": 0.7222570244049435,
  "log_delta_vs_log_dx_slope": -0.16513550018498793,
  "grid_grouped": [
    {
      "condition": "edge_shuffle",
      "ngrid": 5,
      "config_count": 12,
      "dx": 0.25,
      "mean_R2_flow": 0.31766254511175596,
      "mean_R2_flow_edge": 0.4072078540638909,
      "mean_delta_edge": 0.08954530895213496,
      "min_delta_edge": -0.13322182540749528,
      "positive_delta_rate": 0.8333333333333334
    },
    {
      "condition": "edge_shuffle",
      "ngrid": 6,
      "config_count": 12,
      "dx": 0.20000000000000004,
      "mean_R2_flow": 0.28813062149826313,
      "mean_R2_flow_edge": 0.2403400234482652,
      "mean_delta_edge": -0.04779059804999797,
      "min_delta_edge": -1.1809356540864822,
      "positive_delta_rate": 0.8333333333333334
    },
    {
      "condition": "edge_shuffle",
      "ngrid": 7,
      "config_count": 12,
      "dx": 0.16666666666666666,
      "mean_R2_flow": 0.27322557038385803,
      "mean_R2_flow_edge": 0.27440859306794513,
      "mean_delta_edge": 0.0011830226840871354,
      "min_delta_edge": -0.27902939947024896,
      "positive_delta_rate": 0.6666666666666666
    },
    {
      "condition": "edge_shuffle",
      "ngrid": 8,
      "config_count": 12,
      "dx": 0.14285714285714285,
      "mean_R2_flow": 0.2464395931525424,
      "mean_R2_flow_edge": 0.21327556965779912,
      "mean_delta_edge": -0.03316402349474327,
      "min_delta_edge": -0.4854314622789674,
      "positive_delta_rate": 0.5833333333333334
    },
    {
      "condition": "edge_shuffle",
      "ngrid": 9,
      "config_count": 12,
      "dx": 0.125,
      "mean_R2_flow": 0.23564268334652164,
      "mean_R2_flow_edge": 0.253482837737382,
      "mean_delta_edge": 0.01784015439086038,
      "min_delta_edge": -0.036907013580760206,
      "positive_delta_rate": 0.75
    },
    {
      "condition": "linear_control",
      "ngrid": 7,
      "config_count": 1,
      "dx": 0.16666666666666666,
      "mean_R2_flow": 0.0,
      "mean_R2_flow_edge": 0.0,
      "mean_delta_edge": 0.0,
      "min_delta_edge": 0.0,
      "positive_delta_rate": 0.0
    },
    {
      "condition": "real",
      "ngrid": 5,
      "config_count": 12,
      "dx": 0.25,
      "mean_R2_flow": 0.31766254511175596,
      "mean_R2_flow_edge": 1.0,
      "mean_delta_edge": 0.682337454888244,
      "min_delta_edge": 0.28275236008633864,
      "positive_delta_rate": 1.0
    },
    {
      "condition": "real",
      "ngrid": 6,
      "config_count": 12,
      "dx": 0.20000000000000004,
      "mean_R2_flow": 0.28813062149826313,
      "mean_R2_flow_edge": 1.0,
      "mean_delta_edge": 0.7118693785017368,
      "min_delta_edge": 0.4257985481520278,
      "positive_delta_rate": 1.0
    },
    {
      "condition": "real",
      "ngrid": 7,
      "config_count": 12,
      "dx": 0.16666666666666666,
      "mean_R2_flow": 0.27322557038385803,
      "mean_R2_flow_edge": 1.0,
      "mean_delta_edge": 0.726774429616142,
      "min_delta_edge": 0.5779397819541603,
      "positive_delta_rate": 1.0
    },
    {
      "condition": "real",
      "ngrid": 8,
      "config_count": 12,
      "dx": 0.14285714285714285,
      "mean_R2_flow": 0.2464395931525424,
      "mean_R2_flow_edge": 1.0,
      "mean_delta_edge": 0.7535604068474576,
      "min_delta_edge": 0.5881817011540416,
      "positive_delta_rate": 1.0
    },
    {
      "condition": "real",
      "ngrid": 9,
      "config_count": 12,
      "dx": 0.125,
      "mean_R2_flow": 0.23564268334652164,
      "mean_R2_flow_edge": 1.0,
      "mean_delta_edge": 0.7643573166534784,
      "min_delta_edge": 0.5745569584516201,
      "positive_delta_rate": 1.0
    }
  ],
  "outputs": {
    "rows": "/mnt/data/v1688_26_edge_faithfulness_refinement_scaling_outputs/v1688_26_refinement_rows.csv",
    "summary": "/mnt/data/v1688_26_edge_faithfulness_refinement_scaling_outputs/v1688_26_summary.csv",
    "grouped_by_grid": "/mnt/data/v1688_26_edge_faithfulness_refinement_scaling_outputs/v1688_26_grouped_by_grid.csv"
  },
  "claim_boundary": "Toy edge-faithfulness refinement scaling only; no continuum theorem / ADM derivation / GR / physical spacetime claim."
}
```
