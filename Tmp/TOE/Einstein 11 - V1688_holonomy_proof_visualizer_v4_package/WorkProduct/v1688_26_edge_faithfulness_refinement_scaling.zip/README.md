# V1688.26 Edge-Faithfulness Refinement Scaling

Toy refinement scaling for L3/O3 edge-faithfulness flow law. No ADM/GR claim.
