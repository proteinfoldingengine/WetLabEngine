
# ============================================================
# V1688.26 — Edge-Faithfulness Continuum / Refinement Scaling
# ============================================================
# Purpose:
#   Test whether the bounded L3/O3 edge-faithfulness same-slice flow law
#   persists under graph/dimension refinement.
#
# Boundary:
#   Toy retained-flow refinement scaling only.
#   No continuum theorem / ADM derivation / GR / physical spacetime claim.
# ============================================================

from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_26_edge_faithfulness_refinement_scaling_outputs")
OUT.mkdir(parents=True, exist_ok=True)
EPS = 1e-12

def recombine(x,y,mode="nonlinear"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if mode=="linear":
        return x+y
    rd=np.r_[x[-1],x[:-1]]
    ru=np.r_[y[1:],y[0]]
    ov=np.minimum(np.abs(x),np.abs(y))/(1+np.minimum(np.abs(x),np.abs(y)))
    return x+y+.35*ov*(rd*y-x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode),C,mode)-recombine(A,recombine(B,C,mode),mode)

def normalize(v):
    n=np.linalg.norm(v)
    return v if n<EPS else v/n

def make_sector(i,j,ngrid,dim=12,seed=0,mode="nonlinear"):
    # refinement-aware coordinates: same physical domain, finer retained grid
    x=i/(ngrid-1)
    y=j/(ngrid-1)
    a=np.linspace(0,2*np.pi,dim,endpoint=False)
    B=[]
    for k in range(4):
        phase=2.1*x+1.7*y+.63*k+.03*seed
        v=np.sin((k+1)*a+phase)+.35*np.cos((k+2)*a-.9*x+.7*y+.05*seed)
        center=int((2*k + np.floor(dim*x) + 2*np.floor(dim*y) + seed) % dim)
        bump=np.zeros(dim); bump[center]=1; bump[(center+1)%dim]=.55; bump[(center-1)%dim]=.35
        v+=.55*bump
        B.append(normalize(v))
    O3=[
        assoc3(B[0],B[1],B[2],mode),
        assoc3(B[0],B[1],B[3],mode),
        assoc3(B[0],B[2],B[3],mode),
        assoc3(B[1],B[2],B[3],mode)
    ]
    return {"B":B,"O3":O3,"source":np.sum(np.stack(B),axis=0)}

def transport(P,Q):
    return np.stack(Q["B"],axis=1) @ np.linalg.pinv(np.stack(P["B"],axis=1))

def build(ngrid,dim,seed,mode):
    S={(i,j):make_sector(i,j,ngrid,dim,seed,mode) for i in range(ngrid) for j in range(ngrid)}
    T={}
    for p in S:
        i,j=p
        for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
            if q in S:
                T[(p,q)]=transport(S[p],S[q])
    return S,T

def edge_faith(Tpq,P,Q,mode):
    G=P["B"]+P["O3"]
    vals=[]
    for a in range(len(G)):
        for b in range(a+1,len(G)):
            vals.append(np.linalg.norm(Tpq@recombine(G[a],G[b],mode)-recombine(Tpq@G[a],Tpq@G[b],mode)))
    return float(np.mean(vals))

def local_row(i,j,S,T,mode,dx):
    p=(i,j); src=S[p]["source"]
    diffs=[]; edges=[]
    for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
        if q in S:
            diffs.append((T[(q,p)]@S[q]["source"]-src)/dx)
            edges.append(edge_faith(T[(p,q)],S[p],S[q],mode))
    flow=float(np.linalg.norm(np.mean(np.stack(diffs),axis=0)))
    edge=float(np.mean(edges))
    # scale edge with dx as candidate finite-difference correction
    edge_scaled=edge/dx
    target=flow + 0.15*edge_scaled
    return {
        "target":target,
        "flow_div":flow,
        "source_norm":float(np.linalg.norm(src)),
        "edge_faithfulness":edge,
        "edge_scaled":edge_scaled,
        "dx":dx
    }

def dataset(ngrid,dim,seed,mode,condition):
    S,T=build(ngrid,dim,seed,mode)
    dx=1.0/(ngrid-1)
    rows=[]
    for i in range(1,ngrid-1):
        for j in range(1,ngrid-1):
            rows.append(local_row(i,j,S,T,mode,dx))
    df=pd.DataFrame(rows)
    df["ngrid"]=ngrid; df["dim"]=dim; df["seed"]=seed; df["mode"]=mode; df["condition"]=condition
    rng=np.random.default_rng(26000+ngrid*100+dim*10+seed)
    if condition=="edge_shuffle":
        e=df.edge_scaled.values.copy(); rng.shuffle(e); df["edge_scaled"]=e
    return df

def standardize(X):
    X=np.asarray(X,float)
    mu=X.mean(axis=0); sd=X.std(axis=0); sd[sd<EPS]=1.0
    return (X-mu)/sd

def fit(y,X):
    y=np.asarray(y,float)
    X=standardize(np.asarray(X,float))
    X=np.c_[np.ones(len(X)),X]
    return X@(np.linalg.pinv(X)@y)

def r2(y,p):
    y=np.asarray(y,float); p=np.asarray(p,float)
    ssr=float(np.sum((y-p)**2)); sst=float(np.sum((y-y.mean())**2))
    return 0.0 if sst<EPS else float(1-ssr/sst)

def eval_sub(sub):
    y=sub.target.values
    p0=fit(y,sub[["flow_div","source_norm"]].values)
    p1=fit(y,sub[["flow_div","source_norm","edge_scaled"]].values)
    return r2(y,p0), r2(y,p1), r2(y,p1)-r2(y,p0)

dfs=[]
for condition in ["real","edge_shuffle"]:
    for ngrid in [5,6,7,8,9]:
        for dim in [10,12,14,16]:
            for seed in range(3):
                dfs.append(dataset(ngrid,dim,seed,"nonlinear",condition))
dfs.append(dataset(7,12,0,"linear","linear_control"))

df=pd.concat(dfs,ignore_index=True)
df.to_csv(OUT/"v1688_26_refinement_rows.csv",index=False)

summary=[]
for keys,sub in df.groupby(["condition","mode","ngrid","dim","seed"]):
    condition,mode,ngrid,dim,seed=keys
    r0,r1,delta=eval_sub(sub)
    summary.append({
        "condition":condition,"mode":mode,"ngrid":int(ngrid),"dim":int(dim),"seed":int(seed),
        "dx":float(1/(int(ngrid)-1)),
        "n":int(len(sub)),
        "R2_flow":r0,
        "R2_flow_edge":r1,
        "delta_edge":delta,
        "mean_edge_scaled":float(sub.edge_scaled.mean())
    })

summ=pd.DataFrame(summary)
summ.to_csv(OUT/"v1688_26_summary.csv",index=False)

group=summ.groupby(["condition","ngrid"]).agg(
    config_count=("condition","count"),
    dx=("dx","mean"),
    mean_R2_flow=("R2_flow","mean"),
    mean_R2_flow_edge=("R2_flow_edge","mean"),
    mean_delta_edge=("delta_edge","mean"),
    min_delta_edge=("delta_edge","min"),
    positive_delta_rate=("delta_edge",lambda x: float(np.mean(np.asarray(x)>0)))
).reset_index()
group.to_csv(OUT/"v1688_26_grouped_by_grid.csv",index=False)

real=group[group.condition=="real"].sort_values("ngrid")
shuf=group[group.condition=="edge_shuffle"].sort_values("ngrid")

mean_delta=float(real.mean_delta_edge.mean())
min_delta=float(real.min_delta_edge.min())
positive_rate=float(np.mean(summ[(summ.condition=="real") & (summ.mode=="nonlinear")].delta_edge>0))
shuffle_mean=float(shuf.mean_delta_edge.mean())
margin=float(mean_delta-shuffle_mean)

# crude scaling trend of delta vs dx
x=np.log(real.dx.values)
y=np.log(np.maximum(real.mean_delta_edge.values, EPS))
slope=float(np.polyfit(x,y,1)[0]) if len(x)>=2 else 0.0

if mean_delta>0.20 and min_delta>0.05 and positive_rate>=0.95 and margin>0.15:
    verdict="EDGE_FAITHFULNESS_REFINEMENT_SCALING_SUPPORTED"
elif mean_delta>0.05 and positive_rate>=0.80 and margin>0.03:
    verdict="EDGE_FAITHFULNESS_REFINEMENT_SCALING_PARTIAL"
else:
    verdict="EDGE_FAITHFULNESS_REFINEMENT_SCALING_NOT_SUPPORTED"

result={
    "document_id":"V1688_26_EDGE_FAITHFULNESS_REFINEMENT_SCALING",
    "status":"completed",
    "verdict":verdict,
    "mean_delta_edge_real":mean_delta,
    "min_delta_edge_real":min_delta,
    "positive_delta_rate_real":positive_rate,
    "mean_delta_edge_shuffle":shuffle_mean,
    "real_minus_shuffle_margin":margin,
    "log_delta_vs_log_dx_slope":slope,
    "grid_grouped":group.to_dict(orient="records"),
    "outputs":{
        "rows":str(OUT/"v1688_26_refinement_rows.csv"),
        "summary":str(OUT/"v1688_26_summary.csv"),
        "grouped_by_grid":str(OUT/"v1688_26_grouped_by_grid.csv")
    },
    "claim_boundary":"Toy edge-faithfulness refinement scaling only; no continuum theorem / ADM derivation / GR / physical spacetime claim."
}

(OUT/"v1688_26_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_26_EDGE_FAITHFULNESS_REFINEMENT_SCALING_REPORT.md").write_text("# V1688.26 — Edge-Faithfulness Refinement Scaling\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
