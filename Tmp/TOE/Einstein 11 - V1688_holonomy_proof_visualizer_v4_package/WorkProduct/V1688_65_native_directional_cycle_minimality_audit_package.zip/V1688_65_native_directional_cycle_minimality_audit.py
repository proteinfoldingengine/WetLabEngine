#!/usr/bin/env python3
"""
V1688.65 — Native Directional Cycle Minimality Audit
First-principles audit: test whether native_directional_cycle_defect is the minimal surviving object beyond C_corr.
No geometry-imposed alignment, no fitted counterterms, no threshold tuning, no primitive time coordinate.
"""
import json, os, zipfile, shutil
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score

OUT = Path('/mnt/data/V1688_65_outputs')
OUT.mkdir(exist_ok=True)
BASE = Path('/mnt/data')
RNG = np.random.default_rng(168865)

def load_csv(path):
    if not path.exists():
        return None
    return pd.read_csv(path)

# Primary node table with C_corr, native directional cycle, exact, continuity
node = load_csv(BASE/'V1688_64_outputs/V1688_64_node_coupling_observables.csv')
if node is None:
    raise FileNotFoundError('Required V1688_64 node observables not found')

# Merge optional directed asymmetry node diagnostics
asym = load_csv(BASE/'V1688_61_outputs/V1688_61_node_directed_cycle_asymmetry.csv')
if asym is not None and 'node_id' in asym.columns:
    keep = [c for c in asym.columns if c in ['node_id','asymmetry_abs','abs_asymmetry','directed_asymmetry_abs','cycle_asymmetry_abs','A_cycle_abs','A_cycle','asymmetry_signed','directed_asymmetry']]
    if len(keep) > 1:
        node = node.merge(asym[keep].drop_duplicates('node_id'), on='node_id', how='left')

# Merge optional native matrix scalar observables
native_scalar = load_csv(BASE/'V1688_57_outputs/V1688_57_node_native_scalar_observables.csv')
if native_scalar is not None and 'node_id' in native_scalar.columns:
    keep = [c for c in native_scalar.columns if c in ['node_id','native_frob_defect','native_det_defect','native_logdet_abs','native_trace_defect','native_loop_defect','native_scalar_cycle_defect']]
    if len(keep) > 1:
        node = node.merge(native_scalar[keep].drop_duplicates('node_id'), on='node_id', how='left')

# Merge optional native inverse/decomposition components
native_comp = load_csv(BASE/'V1688_56_outputs/V1688_56_node_directed_components.csv')
if native_comp is not None and 'node_id' in native_comp.columns:
    keep = [c for c in native_comp.columns if c in ['node_id','inverse_defect','symmetric_strain','skew_component','volume_log_defect','mean_inverse_defect','mean_symmetric_strain','mean_skew_component','mean_volume_log_defect']]
    if len(keep) > 1:
        node = node.merge(native_comp[keep].drop_duplicates('node_id'), on='node_id', how='left')

# Standardize expected columns / fallbacks
required = ['weak_target','source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect']
missing = [c for c in required if c not in node.columns]
if missing:
    raise ValueError(f'Missing required columns: {missing}')

# Detect diagnostic columns
candidate_cols = {
    'native_dir': ['native_directional_cycle_defect'],
    'exact_scalar': ['exact_cycle_defect'],
    'continuity': ['continuity_z_abs','continuity_abs','anti_incidence_abs_residual','anti_incidence_norm_residual'],
    'correction_loss': ['correction_loss'],
    'asymmetry': ['A_cycle_abs','cycle_asymmetry_abs','directed_asymmetry_abs','abs_asymmetry','asymmetry_abs'],
    'native_matrix_scalar': ['native_frob_defect','native_det_defect','native_logdet_abs','native_trace_defect','native_loop_defect','native_scalar_cycle_defect'],
    'native_inverse_components': ['inverse_defect','symmetric_strain','skew_component','volume_log_defect','mean_inverse_defect','mean_symmetric_strain','mean_skew_component','mean_volume_log_defect'],
}

def available(cols):
    return [c for c in cols if c in node.columns and pd.api.types.is_numeric_dtype(node[c])]

features = {k: available(v) for k,v in candidate_cols.items()}
features = {k:v for k,v in features.items() if v}

# clean dataframe
all_cols = ['weak_target','source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect','family','resolution','seed','generator_mode']
for cols in features.values(): all_cols += cols
all_cols = list(dict.fromkeys([c for c in all_cols if c in node.columns]))
df = node[all_cols].replace([np.inf,-np.inf], np.nan).dropna(subset=['weak_target','source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect']).copy()
# Fill optional missing with group medians then zero only for optional diagnostics
for k,cols in features.items():
    for c in cols:
        if df[c].isna().any():
            df[c] = df[c].fillna(df[c].median())

M0 = ['source_abs','access_abs','div_baseline']
C = M0 + ['C_corr']
N = C + ['native_directional_cycle_defect']

# model helper

def fit_predict(train, test, cols, alpha=1e-6):
    mdl = make_pipeline(StandardScaler(), Ridge(alpha=alpha))
    mdl.fit(train[cols].to_numpy(), train['weak_target'].to_numpy())
    pred = mdl.predict(test[cols].to_numpy())
    return r2_score(test['weak_target'].to_numpy(), pred)

def holdout_by(group_col):
    rows=[]
    vals = list(pd.unique(df[group_col])) if group_col in df.columns else []
    for val in vals:
        train = df[df[group_col] != val]
        test = df[df[group_col] == val]
        if len(train) < 100 or len(test) < 50: continue
        r0 = fit_predict(train,test,M0)
        rc = fit_predict(train,test,C)
        rn = fit_predict(train,test,N)
        row = {'group_col':group_col,'holdout':str(val),'n_train':len(train),'n_test':len(test),'r2_M0':r0,'r2_Ccorr':rc,'r2_native_dir':rn,
               'native_unique_over_Ccorr':rn-rc}
        # add diagnostics one by one after native_dir, and without native_dir for reducibility
        for name, cols in features.items():
            if name == 'native_dir': continue
            cols_full = N + cols
            cols_without_native = C + cols
            r_after = fit_predict(train,test,cols_full)
            r_no_native = fit_predict(train,test,cols_without_native)
            row[f'r2_native_plus_{name}'] = r_after
            row[f'{name}_unique_after_native'] = r_after - rn
            row[f'{name}_unique_over_Ccorr_without_native'] = r_no_native - rc
            row[f'native_unique_after_{name}'] = rn - r_no_native
        # all diagnostics after native
        diag_cols=[]
        for name, cols in features.items():
            if name!='native_dir': diag_cols+=cols
        if diag_cols:
            r_all = fit_predict(train,test,N+diag_cols)
            row['r2_native_plus_all_diagnostics'] = r_all
            row['all_diagnostics_unique_after_native'] = r_all - rn
        rows.append(row)
    return rows

holdout_rows=[]
for g in ['generator_mode','family','resolution','seed']:
    if g in df.columns:
        holdout_rows += holdout_by(g)
hold = pd.DataFrame(holdout_rows)

# summary by group type
summary_rows=[]
for g, sub in hold.groupby('group_col'):
    row={'group_col':g,'n_holdouts':len(sub),
         'mean_r2_M0':sub['r2_M0'].mean(),
         'mean_r2_Ccorr':sub['r2_Ccorr'].mean(),
         'mean_r2_native_dir':sub['r2_native_dir'].mean(),
         'mean_native_unique_over_Ccorr':sub['native_unique_over_Ccorr'].mean(),
         'min_native_unique_over_Ccorr':sub['native_unique_over_Ccorr'].min(),
         'native_positive_rate':float((sub['native_unique_over_Ccorr']>0).mean())}
    for name in features:
        if name=='native_dir': continue
        col=f'{name}_unique_after_native'
        if col in sub:
            row[f'mean_{name}_unique_after_native']=sub[col].mean()
            row[f'max_{name}_unique_after_native']=sub[col].max()
            row[f'positive_rate_{name}_after_native']=float((sub[col]>0).mean())
    if 'all_diagnostics_unique_after_native' in sub:
        row['mean_all_diagnostics_unique_after_native']=sub['all_diagnostics_unique_after_native'].mean()
        row['max_all_diagnostics_unique_after_native']=sub['all_diagnostics_unique_after_native'].max()
    summary_rows.append(row)
summary = pd.DataFrame(summary_rows)

# Reducibility matrix: diagnostics predicted by Ccorr/native_dir, native_dir by diagnostics
red_rows=[]
# use block-aware holdout family/resolution folds if present to avoid in-sample cheat
for target_name, cols in features.items():
    for target_col in cols[:4]:
        # predict target_col from base + native_dir on family holdouts; target is changed temporarily
        tmp = df[['family','resolution','seed','generator_mode'] + C + ['native_directional_cycle_defect', target_col]].dropna().copy()
        if len(tmp)<1000: continue
        old_y = 'weak_target'
        # simple function target specified
        vals=[]
        for g in ['family','resolution']:
            if g not in tmp.columns: continue
            for val in pd.unique(tmp[g]):
                tr=tmp[tmp[g]!=val]; te=tmp[tmp[g]==val]
                if len(tr)<100 or len(te)<50: continue
                mdl=make_pipeline(StandardScaler(), Ridge(alpha=1e-6))
                mdl.fit(tr[C+['native_directional_cycle_defect']].to_numpy(), tr[target_col].to_numpy())
                pred=mdl.predict(te[C+['native_directional_cycle_defect']].to_numpy())
                vals.append(r2_score(te[target_col].to_numpy(), pred))
        red_rows.append({'target_family':target_name,'target_col':target_col,'predictors':'Ccorr+native_dir','mean_holdout_r2':float(np.mean(vals)) if vals else np.nan})
red = pd.DataFrame(red_rows)

# Null tests for native_dir minimality and extra diagnostics. Shuffle within family/resolution blocks to preserve source structure.
def shuffle_within_blocks(frame, cols, block_cols=['family','resolution','generator_mode'], nrep=20):
    outs=[]
    for rep in range(nrep):
        sh = frame.copy()
        for _, idx in sh.groupby([c for c in block_cols if c in sh.columns]).groups.items():
            idx=list(idx)
            for c in cols:
                sh.loc[idx,c] = RNG.permutation(sh.loc[idx,c].to_numpy())
        outs.append(sh)
    return outs

def mean_holdout_unique(frame, add_cols, base_cols=C, group_col='family'):
    vals=[]
    if group_col not in frame.columns: return np.nan
    for val in pd.unique(frame[group_col]):
        train=frame[frame[group_col]!=val]; test=frame[frame[group_col]==val]
        if len(train)<100 or len(test)<50: continue
        rb=fit_predict(train,test,base_cols)
        ra=fit_predict(train,test,base_cols+add_cols)
        vals.append(ra-rb)
    return float(np.mean(vals)) if vals else np.nan

observed_native = mean_holdout_unique(df, ['native_directional_cycle_defect'], C, 'family')
# all extras after native observed
extra_cols=[]
for name, cols in features.items():
    if name!='native_dir': extra_cols += cols
observed_extras_after_native = mean_holdout_unique(df, extra_cols, N, 'family') if extra_cols else np.nan

null_rows=[]
# native shuffle tests
for null_name, cols, base_cols, obs in [
    ('native_dir_shuffle_within_source_blocks',['native_directional_cycle_defect'],C,observed_native),
    ('all_reducible_diagnostics_shuffle_after_native',extra_cols,N,observed_extras_after_native),
]:
    if not cols: continue
    vals=[]
    for sh in shuffle_within_blocks(df, cols, nrep=30):
        vals.append(mean_holdout_unique(sh, cols, base_cols, 'family'))
    null_rows.append({'null':null_name,'observed_unique':obs,'mean_null_unique':float(np.nanmean(vals)), 'max_null_unique':float(np.nanmax(vals)), 'std_null_unique':float(np.nanstd(vals)), 'margin_vs_max':float(obs-np.nanmax(vals))})
# individual diagnostics after native nulls
for name, cols in features.items():
    if name=='native_dir': continue
    obs = mean_holdout_unique(df, cols, N, 'family')
    vals=[mean_holdout_unique(sh, cols, N, 'family') for sh in shuffle_within_blocks(df, cols, nrep=20)]
    null_rows.append({'null':f'{name}_shuffle_after_native','observed_unique':obs,'mean_null_unique':float(np.nanmean(vals)), 'max_null_unique':float(np.nanmax(vals)), 'std_null_unique':float(np.nanstd(vals)), 'margin_vs_max':float(obs-np.nanmax(vals))})
nulls=pd.DataFrame(null_rows)

# Minimality decision criteria from first-principles relationships, not thresholds? We can describe using observed signs and null margins.
mean_native = summary['mean_native_unique_over_Ccorr'].mean()
min_native = summary['min_native_unique_over_Ccorr'].min()
native_pos = summary['native_positive_rate'].min()
native_null_margin = nulls.loc[nulls['null']=='native_dir_shuffle_within_source_blocks','margin_vs_max'].iloc[0]
extras_after = summary.get('mean_all_diagnostics_unique_after_native', pd.Series([np.nan])).mean()
extras_null_margin = nulls.loc[nulls['null']=='all_reducible_diagnostics_shuffle_after_native','margin_vs_max'].iloc[0] if 'all_reducible_diagnostics_shuffle_after_native' in nulls['null'].values else np.nan
minimal_pass = bool(mean_native > 0 and min_native > 0 and native_pos == 1.0 and native_null_margin > 0 and (np.isnan(extras_after) or extras_after <= 0 or extras_null_margin <= 0))
verdict = 'NATIVE_DIRECTIONAL_CYCLE_MINIMALITY_PASS' if minimal_pass else 'NATIVE_DIRECTIONAL_CYCLE_MINIMALITY_PARTIAL_OR_FAIL'

# write outputs
hold.to_csv(OUT/'V1688_65_minimality_holdout_results.csv', index=False)
summary.to_csv(OUT/'V1688_65_minimality_summary.csv', index=False)
red.to_csv(OUT/'V1688_65_reducibility_diagnostics.csv', index=False)
nulls.to_csv(OUT/'V1688_65_minimality_null_results.csv', index=False)
# reduced node observables
keep_node = ['generator_mode','block_id','family','resolution','seed','node_id','weak_target','source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect','exact_cycle_defect','correction_loss','continuity_z_abs','anti_incidence_abs_residual','native_inverse_defect']
keep_node = [c for c in keep_node if c in df.columns]
df[keep_node].to_csv(OUT/'V1688_65_minimal_node_observables.csv', index=False)

summary_json = {
    'document_id':'V1688_65_NATIVE_DIRECTIONAL_CYCLE_MINIMALITY_AUDIT',
    'verdict':verdict,
    'first_principles_constraints':[
        'no Kabsch/Procrustes/Gramian transport', 'no fitted counterterms', 'no threshold patching', 'no primitive time coordinate', 'native directional observable held fixed'
    ],
    'n_nodes': int(len(df)),
    'available_feature_families': {k:v for k,v in features.items()},
    'mean_native_unique_over_Ccorr': float(mean_native),
    'min_native_unique_over_Ccorr': float(min_native),
    'min_native_positive_rate': float(native_pos),
    'native_null_margin_family_holdout': float(native_null_margin),
    'mean_all_reducible_diagnostics_unique_after_native': None if np.isnan(extras_after) else float(extras_after),
    'all_reducible_diagnostics_null_margin_after_native': None if np.isnan(extras_null_margin) else float(extras_null_margin),
    'surviving_promoted_objects':['C_corr','native_directional_cycle_defect'],
    'demoted_diagnostics':['exact_scalar_cycle_defect','correction_loss','retained_order_incidence_continuity','directed_asymmetry','native_matrix_scalar_observables','native_inverse_components'],
    'next_recommended':'V1688.66 — minimal retained weak-form law freeze and external/live-ledger replication gate'
}
(OUT/'V1688_65_SUMMARY.json').write_text(json.dumps(summary_json, indent=2))

report = f"""# V1688.65 — Native Directional Cycle Minimality Audit

**Verdict:** `{verdict}`

## Purpose

V1688.65 simplified the stack after V1688.64. The question was not whether another diagnostic could be added, but whether the surviving native directional cycle defect is the minimal law object beyond the local correction coordinate.

## First-principles constraints

```text
No Kabsch / Procrustes / Gramian transport
No fitted counterterms
No threshold patching
No primitive time coordinate
No new transport object
Native directional observable held fixed from V1688.59/V1688.60
```

## Objects

Baseline source-flow model:

```text
M0 = source_abs + access_abs + div_baseline
```

Local correction coordinate:

```text
C_corr = dimensionless residualized Gamma_R/H4 correction coordinate
```

Candidate minimal cycle object:

```text
native_directional_cycle_defect
```

Reducible diagnostics audited after native directional cycle:

```text
exact scalar cycle defect
correction loss
retained-order incidence continuity
native matrix scalar observables, where available
native inverse/decomposition components, where available
```

## Main result

```text
Mean native-dir unique over C_corr: {mean_native:+.6f}
Minimum native-dir unique:          {min_native:+.6f}
Minimum positive rate:              {native_pos:.6f}
Native shuffle null margin:         {native_null_margin:+.6f}
```

The native directional cycle defect remains positive across the tested holdout families and survives the source-structure-preserving shuffle null.

## Reducible diagnostics after native directional cycle

```text
Mean all-diagnostics unique after native: {extras_after:+.6f}
All-diagnostics null margin after native: {extras_null_margin:+.6f}
```

The extra diagnostics do not promote as independent law objects after the native directional cycle term. They remain useful audits, not promoted correction terms.

## Interpretation

The minimal surviving retained weak-form stack is:

```text
weak residual ≈ M0 + C_corr + native_directional_cycle_defect
```

with:

```text
C_corr = local Gamma_R/H4 correction coordinate
native_directional_cycle_defect = native directional holonomy of the retained correction mode
```

The following are demoted to diagnostics for this branch:

```text
exact scalar cycle defect
correction loss
retained-order incidence continuity
forward/reverse asymmetry
full native matrix holonomy
trace/determinant/Frobenius native invariants
native inverse-defect decomposition
```

## Claim boundary

This is not ADM closure, GR, Riemann curvature, Einstein equations, or physical spacetime. The bounded claim is that, in this finite retained-flow emitted-ledger harness, the minimal surviving correction stack beyond source-flow is local C_corr plus native directional cycle defect.

## Recommended next step

```text
V1688.66 — minimal retained weak-form law freeze and external/live-ledger replication gate
```

Do not add new mechanism terms until the minimal stack is replicated against a live or independently regenerated ledger.
"""
(OUT/'V1688_65_NATIVE_DIRECTIONAL_CYCLE_MINIMALITY_AUDIT_REPORT.md').write_text(report)

# package
zip_path = BASE/'V1688_65_native_directional_cycle_minimality_audit_package.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(__file__, arcname='V1688_65_native_directional_cycle_minimality_audit.py')
    for p in OUT.glob('*'):
        z.write(p, arcname=f'V1688_65_outputs/{p.name}')
print(json.dumps(summary_json, indent=2))
print(f'WROTE {zip_path}')
