#!/usr/bin/env python3
"""
V1688.62 — Provenance-Order Conservation Audit

First-principles audit: keep the V1688.59 native directional observable fixed and test
whether edge-directed correction flux over the emitted provenance ledger has a conservation /
divergence relation to the weak-form residual.

No geometry alignment, no fitted counterterms, no time primitive.
"""
from __future__ import annotations
import json, zipfile, math, os
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

ROOT=Path('/mnt/data')
OUT=ROOT/'V1688_62_outputs'
OUT.mkdir(exist_ok=True)
SEED=168862
rng=np.random.default_rng(SEED)
NODE_PATH=ROOT/'V1688_59_outputs'/'V1688_59_node_native_directional_observables.csv'
EDGE_PATH=ROOT/'V1688_59_outputs'/'V1688_59_edge_native_directional_scalars.csv'


def z(x):
    x=np.asarray(x,float)
    s=x.std()
    if s<1e-12: return np.zeros_like(x)
    return (x-x.mean())/s


def load():
    node=pd.read_csv(NODE_PATH)
    edge=pd.read_csv(EDGE_PATH)
    return node, edge


def compute_flux(node:pd.DataFrame, edge:pd.DataFrame, mode:str='observed'):
    e=edge.copy()
    if mode=='shuffle_c_within_block':
        e['native_directional_c']=e.groupby('block_id')['native_directional_c'].transform(lambda s: rng.permutation(s.to_numpy()))
    elif mode=='sign_randomized':
        signs=rng.choice([-1.0,1.0], size=len(e))
        e['native_directional_c']=e['native_directional_c'].to_numpy()*signs
    elif mode=='zero_control':
        e['native_directional_c']=0.0
    elif mode=='endpoint_shuffle_within_block':
        # preserves edge scalar and from-node distribution while breaking provenance recipient.
        e['to_node']=e.groupby('block_id')['to_node'].transform(lambda s: rng.permutation(s.to_numpy()))
    elif mode=='source_flow_preserving_node_shuffle':
        # handled after observed node residual is computed
        pass
    elif mode!='observed':
        raise ValueError(mode)
    c_lookup=node.set_index('node_id')['C_corr']
    e['C_from']=e['from_node'].map(c_lookup).astype(float)
    e['C_to']=e['to_node'].map(c_lookup).astype(float)
    # Native directional correction flux: transported scalar correction mode along ledger orientation.
    e['directed_flux']=e['native_directional_c']*e['C_from']
    e['flux_loss']=e['C_to']-e['directed_flux']
    out=e.groupby('from_node').agg(out_flux=('directed_flux','sum'), out_abs_flux=('directed_flux',lambda x: np.abs(x).sum()), out_degree=('directed_flux','size'))
    inc=e.groupby('to_node').agg(in_flux=('directed_flux','sum'), in_abs_flux=('directed_flux',lambda x: np.abs(x).sum()), in_degree=('directed_flux','size'))
    n=node[['node_id']].set_index('node_id').join(out, how='left').join(inc, how='left').fillna(0.0)
    n['flux_divergence']=n['out_flux']-n['in_flux']
    n['flux_residual']=n['in_flux']-n['out_flux']
    n['abs_flux_residual']=np.abs(n['flux_residual'])
    n['flux_imbalance_ratio']=n['abs_flux_residual']/(n['in_abs_flux']+n['out_abs_flux']+1e-12)
    n['mean_flux_loss']=e.groupby('from_node')['flux_loss'].mean().reindex(n.index).fillna(0.0)
    n['abs_mean_flux_loss']=np.abs(n['mean_flux_loss'])
    return n.reset_index(), e


def add_flux_features(node, fluxnode):
    df=node.merge(fluxnode, on='node_id', how='left')
    fillcols=['out_flux','out_abs_flux','out_degree','in_flux','in_abs_flux','in_degree','flux_divergence','flux_residual','abs_flux_residual','flux_imbalance_ratio','mean_flux_loss','abs_mean_flux_loss']
    df[fillcols]=df[fillcols].fillna(0.0)
    # standardized observables for model comparability
    for col in ['flux_divergence','flux_residual','abs_flux_residual','flux_imbalance_ratio','mean_flux_loss','abs_mean_flux_loss']:
        df[col+'_z']=z(df[col].to_numpy())
    return df


def r2_holdout(df, group_col, feature_sets):
    rows=[]
    groups=list(pd.unique(df[group_col]))
    y=df['weak_target'].to_numpy(float)
    for g in groups:
        test=(df[group_col]==g).to_numpy()
        train=~test
        if test.sum()<5 or train.sum()<10: continue
        yt=y[test]
        row={'holdout_type':group_col,'holdout_value':str(g),'n_train':int(train.sum()),'n_test':int(test.sum())}
        for name, feats in feature_sets.items():
            Xtr=df.loc[train,feats].to_numpy(float); Xte=df.loc[test,feats].to_numpy(float)
            model=make_pipeline(StandardScaler(), LinearRegression())
            model.fit(Xtr,y[train])
            pred=model.predict(Xte)
            row[name]=float(r2_score(yt,pred))
        rows.append(row)
    return pd.DataFrame(rows)


def evaluate(df):
    feature_sets={
        'R2_M0':['source_abs','access_abs','div_baseline'],
        'R2_M0_Ccorr':['source_abs','access_abs','div_baseline','C_corr'],
        'R2_M0_Ccorr_native_dir':['source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect'],
        'R2_M0_Ccorr_flux':['source_abs','access_abs','div_baseline','C_corr','flux_residual_z','abs_flux_residual_z','flux_imbalance_ratio_z'],
        'R2_M0_Ccorr_native_dir_flux':['source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect','flux_residual_z','abs_flux_residual_z','flux_imbalance_ratio_z'],
        'R2_M0_Ccorr_native_dir_lossflux':['source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect','mean_flux_loss_z','abs_mean_flux_loss_z'],
    }
    parts=[]
    for gc in ['generator_mode','family','resolution','seed']:
        parts.append(r2_holdout(df,gc,feature_sets))
    hold=pd.concat(parts,ignore_index=True)
    # deltas
    hold['flux_unique_over_Ccorr']=hold['R2_M0_Ccorr_flux']-hold['R2_M0_Ccorr']
    hold['flux_unique_after_native_dir']=hold['R2_M0_Ccorr_native_dir_flux']-hold['R2_M0_Ccorr_native_dir']
    hold['lossflux_unique_after_native_dir']=hold['R2_M0_Ccorr_native_dir_lossflux']-hold['R2_M0_Ccorr_native_dir']
    hold['native_dir_unique_over_Ccorr']=hold['R2_M0_Ccorr_native_dir']-hold['R2_M0_Ccorr']
    return hold


def null_eval(node, edge, modes):
    rows=[]
    for mode in modes:
        fnode,_=compute_flux(node, edge, mode if mode!='source_flow_preserving_node_shuffle' else 'observed')
        df=add_flux_features(node, fnode)
        if mode=='source_flow_preserving_node_shuffle':
            # preserve node/source structure and feature distribution within block, break node-local flux conservation relation.
            for c in ['flux_residual_z','abs_flux_residual_z','flux_imbalance_ratio_z','mean_flux_loss_z','abs_mean_flux_loss_z']:
                df[c]=df.groupby('block_id')[c].transform(lambda s: rng.permutation(s.to_numpy()))
        hold=evaluate(df)
        rows.append({
            'null_mode':mode,
            'mean_flux_unique_over_Ccorr':float(hold['flux_unique_over_Ccorr'].mean()),
            'mean_flux_unique_after_native_dir':float(hold['flux_unique_after_native_dir'].mean()),
            'mean_lossflux_unique_after_native_dir':float(hold['lossflux_unique_after_native_dir'].mean()),
            'positive_after_native_dir_rate':float((hold['flux_unique_after_native_dir']>0).mean()),
            'n_holdouts':int(len(hold))
        })
    return pd.DataFrame(rows)


def main():
    node,edge=load()
    fluxnode, fluxedges=compute_flux(node,edge,'observed')
    df=add_flux_features(node,fluxnode)
    hold=evaluate(df)
    nulls=null_eval(node,edge,['shuffle_c_within_block','sign_randomized','endpoint_shuffle_within_block','source_flow_preserving_node_shuffle','zero_control'])
    # diagnostics
    corr_cols=['flux_residual','abs_flux_residual','flux_imbalance_ratio','mean_flux_loss','abs_mean_flux_loss']
    diag=[]
    for c in corr_cols:
        for target in ['weak_target','C_corr','native_directional_cycle_defect','h4_perp_norm','source_abs','div_baseline']:
            diag.append({'feature':c,'target':target,'corr':float(np.corrcoef(df[c].to_numpy(float), df[target].to_numpy(float))[0,1])})
    diag=pd.DataFrame(diag)
    resdiag=df.groupby('resolution').agg(
        mean_abs_flux_residual=('abs_flux_residual','mean'),
        mean_flux_imbalance_ratio=('flux_imbalance_ratio','mean'),
        mean_Ccorr=('C_corr','mean'),
        mean_native_dir=('native_directional_cycle_defect','mean'),
        n=('node_id','size')
    ).reset_index()
    # summary
    observed_unique=float(hold['flux_unique_after_native_dir'].mean())
    observed_loss_unique=float(hold['lossflux_unique_after_native_dir'].mean())
    critical=float(max(0.0, nulls['mean_flux_unique_after_native_dir'].max()))
    margin=observed_unique-critical
    verdict='PROVENANCE_ORDER_CONSERVATION_FAIL'
    if observed_unique>0 and margin>0 and (hold['flux_unique_after_native_dir']>0).mean()>=0.9:
        verdict='PROVENANCE_ORDER_CONSERVATION_PASS'
    elif observed_unique>0 and (hold['flux_unique_after_native_dir']>0).mean()>=0.75:
        verdict='PARTIAL_PROVENANCE_ORDER_CONSERVATION_SIGNAL_NULL_MARGIN_FAIL'
    summary={
        'document_id':'V1688_62_PROVENANCE_ORDER_CONSERVATION_AUDIT',
        'verdict':verdict,
        'first_principles_constraints':['no time primitive','provenance orientation only','native directional observable fixed','no geometry alignment','no fitted counterterm','no threshold patch'],
        'inputs':{'node_path':str(NODE_PATH),'edge_path':str(EDGE_PATH),'nodes':int(len(node)),'edges':int(len(edge))},
        'flux_definition':'directed_flux(p->q)=native_directional_c(p,q)*C_corr(p); node_residual=incoming_flux-outgoing_flux',
        'mean_R2_M0':float(hold['R2_M0'].mean()),
        'mean_R2_M0_Ccorr':float(hold['R2_M0_Ccorr'].mean()),
        'mean_R2_M0_Ccorr_native_dir':float(hold['R2_M0_Ccorr_native_dir'].mean()),
        'mean_R2_M0_Ccorr_flux':float(hold['R2_M0_Ccorr_flux'].mean()),
        'mean_R2_M0_Ccorr_native_dir_flux':float(hold['R2_M0_Ccorr_native_dir_flux'].mean()),
        'mean_native_dir_unique_over_Ccorr':float(hold['native_dir_unique_over_Ccorr'].mean()),
        'mean_flux_unique_over_Ccorr':float(hold['flux_unique_over_Ccorr'].mean()),
        'mean_flux_unique_after_native_dir':observed_unique,
        'mean_lossflux_unique_after_native_dir':observed_loss_unique,
        'positive_flux_after_native_dir_rate':float((hold['flux_unique_after_native_dir']>0).mean()),
        'critical_null_max_flux_unique_after_native_dir':critical,
        'observed_null_margin':margin,
        'mean_abs_flux_residual':float(df['abs_flux_residual'].mean()),
        'mean_flux_imbalance_ratio':float(df['flux_imbalance_ratio'].mean()),
        'corr_abs_flux_residual_h4':float(diag[(diag.feature=='abs_flux_residual')&(diag.target=='h4_perp_norm')]['corr'].iloc[0]),
        'corr_abs_flux_residual_source':float(diag[(diag.feature=='abs_flux_residual')&(diag.target=='source_abs')]['corr'].iloc[0]),
        'recommended_next':'V1688.63 — retained-order flux continuity refinement if pass/partial; otherwise stop conservation route and preserve native_directional_cycle_defect as cycle observable.'
    }
    # report
    report=f"""# V1688.62 — Provenance-Order Conservation Audit

**Verdict:** `{verdict}`

This audit kept the V1688.59 native directional observable fixed and tested whether it induces a conservation/divergence relation over the emitted provenance edge ledger.

## First-principles constraints

```text
no primitive time coordinate
provenance orientation only
no Kabsch / Procrustes / Gramian alignment
no fitted counterterm
no threshold patch
native directional edge scalar held fixed
```

## Flux definition

```text
directed_flux(p→q) = c_pq · C_corr(p)
node_residual(p) = incoming_flux(p) − outgoing_flux(p)
```

where:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
```

## Ledger scale

```text
nodes: {len(node):,}
edges: {len(edge):,}
```

## Mean holdout results

```text
R² M0:                         {summary['mean_R2_M0']:+.6f}
R² M0 + C_corr:                {summary['mean_R2_M0_Ccorr']:+.6f}
R² M0 + C_corr + native_dir:   {summary['mean_R2_M0_Ccorr_native_dir']:+.6f}
R² M0 + C_corr + flux:         {summary['mean_R2_M0_Ccorr_flux']:+.6f}
R² M0 + C_corr + native+flux:  {summary['mean_R2_M0_Ccorr_native_dir_flux']:+.6f}
```

Unique gains:

```text
native_dir unique over C_corr:         {summary['mean_native_dir_unique_over_Ccorr']:+.6f}
flux unique over C_corr:               {summary['mean_flux_unique_over_Ccorr']:+.6f}
flux unique after native_dir:          {summary['mean_flux_unique_after_native_dir']:+.6f}
loss-flux unique after native_dir:     {summary['mean_lossflux_unique_after_native_dir']:+.6f}
positive flux-after-native rate:       {summary['positive_flux_after_native_dir_rate']:.6f}
```

## Null separation

```text
critical null max flux unique after native_dir: {summary['critical_null_max_flux_unique_after_native_dir']:+.6f}
observed-null margin:                          {summary['observed_null_margin']:+.6f}
```

## Coupling diagnostics

```text
mean |flux residual|:       {summary['mean_abs_flux_residual']:.6f}
mean flux imbalance ratio:  {summary['mean_flux_imbalance_ratio']:.6f}
corr(|flux residual|, H4):  {summary['corr_abs_flux_residual_h4']:+.6f}
corr(|flux residual|, source_abs): {summary['corr_abs_flux_residual_source']:+.6f}
```

## Interpretation

The provenance-order flux residual was tested as a conservation/divergence object induced by native directional correction transport. The result should be interpreted by the verdict:

- `PROVENANCE_ORDER_CONSERVATION_PASS`: node flux residual gives independent weak-form information beyond `C_corr` and native directional cycle defect and survives nulls.
- `PARTIAL_PROVENANCE_ORDER_CONSERVATION_SIGNAL_NULL_MARGIN_FAIL`: flux has positive signal but not enough null margin for law promotion.
- `PROVENANCE_ORDER_CONSERVATION_FAIL`: flux residual is not a valid next law object.

Current result: `{verdict}`.

## Claim boundary

This is a finite retained-flow/provenance-ledger audit. It is not an ADM derivation, GR derivation, Riemann curvature claim, physical spacetime claim, Einstein equation claim, or Bianchi identity claim.
"""
    # write files
    df.to_csv(OUT/'V1688_62_node_flux_conservation.csv', index=False)
    fluxedges.to_csv(OUT/'V1688_62_edge_directed_flux.csv', index=False)
    hold.to_csv(OUT/'V1688_62_conservation_holdout_results.csv', index=False)
    nulls.to_csv(OUT/'V1688_62_conservation_null_results.csv', index=False)
    diag.to_csv(OUT/'V1688_62_flux_correlation_diagnostics.csv', index=False)
    resdiag.to_csv(OUT/'V1688_62_flux_resolution_diagnostics.csv', index=False)
    (OUT/'V1688_62_PROVENANCE_ORDER_CONSERVATION_AUDIT_REPORT.md').write_text(report)
    (OUT/'V1688_62_SUMMARY.json').write_text(json.dumps(summary,indent=2))
    # zip package
    zip_path=ROOT/'V1688_62_provenance_order_conservation_audit_package.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as zf:
        zf.write(Path(__file__), arcname=Path(__file__).name)
        for p in OUT.glob('V1688_62_*'):
            zf.write(p, arcname=f'V1688_62_outputs/{p.name}')
    print(json.dumps(summary,indent=2))
    print(zip_path)

if __name__=='__main__':
    main()
