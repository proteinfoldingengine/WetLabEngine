# V1688.62 — Provenance-Order Conservation Audit

**Verdict:** `PARTIAL_PROVENANCE_ORDER_CONSERVATION_SIGNAL_NULL_MARGIN_FAIL`

This audit kept the V1688.59 native directional observable fixed and tested whether it induces a conservation/divergence relation over the emitted provenance edge ledger.

## First-principles constraints

```text
no primitive time coordinate
provenance orientation only
no Kabsch / Procrustes / Gramian alignment
no fitted counterterm
no threshold patch
native directional edge scalar held fixed
```

## Flux definition

```text
directed_flux(p→q) = c_pq · C_corr(p)
node_residual(p) = incoming_flux(p) − outgoing_flux(p)
```

where:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
```

## Ledger scale

```text
nodes: 29,696
edges: 114,176
```

## Mean holdout results

```text
R² M0:                         +0.001215
R² M0 + C_corr:                +0.081050
R² M0 + C_corr + native_dir:   +0.134398
R² M0 + C_corr + flux:         +0.126823
R² M0 + C_corr + native+flux:  +0.151178
```

Unique gains:

```text
native_dir unique over C_corr:         +0.053348
flux unique over C_corr:               +0.045773
flux unique after native_dir:          +0.016781
loss-flux unique after native_dir:     -0.000826
positive flux-after-native rate:       1.000000
```

## Null separation

```text
critical null max flux unique after native_dir: +0.021802
observed-null margin:                          -0.005022
```

## Coupling diagnostics

```text
mean |flux residual|:       0.925867
mean flux imbalance ratio:  0.306692
corr(|flux residual|, H4):  +0.179291
corr(|flux residual|, source_abs): +0.071121
```

## Interpretation

The provenance-order flux residual was tested as a conservation/divergence object induced by native directional correction transport. The result should be interpreted by the verdict:

- `PROVENANCE_ORDER_CONSERVATION_PASS`: node flux residual gives independent weak-form information beyond `C_corr` and native directional cycle defect and survives nulls.
- `PARTIAL_PROVENANCE_ORDER_CONSERVATION_SIGNAL_NULL_MARGIN_FAIL`: flux has positive signal but not enough null margin for law promotion.
- `PROVENANCE_ORDER_CONSERVATION_FAIL`: flux residual is not a valid next law object.

Current result: `PARTIAL_PROVENANCE_ORDER_CONSERVATION_SIGNAL_NULL_MARGIN_FAIL`.

## Claim boundary

This is a finite retained-flow/provenance-ledger audit. It is not an ADM derivation, GR derivation, Riemann curvature claim, physical spacetime claim, Einstein equation claim, or Bianchi identity claim.
