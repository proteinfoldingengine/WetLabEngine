# V1688 Holonomy Proof Visualizer V2 — Colab Ready

This package contains a one-cell Colab notebook and standalone Python script for the V1688 native directional holonomy proof visualization.

## Files

- `V1688_holonomy_proof_visualizer_v2_one_cell.ipynb` — one-cell Colab notebook.
- `V1688_holonomy_proof_visualizer_v2_colab_one_cell.py` — same code as standalone Python.
- `V1688_holonomy_proof_visualizer_v2_outputs/` — generated static image, GIF, CSVs, JSON, and README.

## What it visualizes

Native directional holonomy is generated edge-by-edge from:

```text
T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = Π_loop c_pq
defect = |1 − H_cycle^dir| · mean(|C_corr|)
```

It also shows L3/O3 and L4/H4_perp glyphs, the retained correction mode Z, holonomy accumulation, and antisymmetric incidence continuity.

## Boundary

This is a finite retained-flow proof visualization, not a GR/Einstein derivation. The displayed smoothed curve is only a readability projection of the discrete provenance cycle; the proof object is the explicit edge product.
