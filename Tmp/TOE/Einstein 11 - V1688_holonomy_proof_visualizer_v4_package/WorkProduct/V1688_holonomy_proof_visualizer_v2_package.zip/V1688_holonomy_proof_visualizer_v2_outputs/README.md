# V1688 Holonomy Proof Visualizer V2

This Colab-ready one-cell proof visualizer shows native directional holonomy being produced by first-principles retained recombination transport.

## Core equations

```text
T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 − H_cycle^dir| · mean(|C_corr|)
```

## Output metrics

```json
{
  "source_mode": "loaded_uploaded_proof_object",
  "H_cycle_dir": -8.391724974435526e-05,
  "native_directional_cycle_defect": 0.7592170453934196,
  "mean_abs_C_corr": 0.7591533393330485,
  "reverse_H_cycle_dir": 4.1341329217371486e-05,
  "reverse_directional_cycle_defect": 0.7591219549249206,
  "orientation_asymmetry_abs": 9.509046849898173e-05,
  "edge_count": 8,
  "node_count": 8,
  "max_abs_continuity_residual": 0.1744454081561017,
  "interpretation": "Directed native holonomy is produced by the action of native recombination transport on the retained correction mode Z around an explicit provenance cycle. The display-smoothed curve is only a visualization of the discrete provenance cycle."
}
```

## Science boundary

This is a finite retained-flow proof visualization. It does not claim GR, Einstein equations, Riemann curvature, or physical spacetime.

The smoothed curve is display interpolation only. The proof object is the explicit discrete provenance cycle edge product.
