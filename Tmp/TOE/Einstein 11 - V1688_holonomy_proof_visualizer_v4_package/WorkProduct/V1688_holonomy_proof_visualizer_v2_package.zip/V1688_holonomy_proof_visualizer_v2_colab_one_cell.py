
# V1688 Holonomy Proof Visualizer V2 — Colab one-cell runnable
# First-principles retained directional holonomy proof visualization
#
# Produces:
#   V1688_v2_static_proof.png
#   V1688_v2_holonomy_animation.gif
#   V1688_v2_metrics.json
#   V1688_v2_nodes.csv / edges.csv / cycle_steps.csv / continuity.csv
#
# This is a proof visualizer, not a claim of GR/Einstein derivation.
# It visualizes the native directional holonomy object:
#   T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
#   c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
#   H_cycle^dir = Π_loop c_pq
#   defect = |1 − H_cycle^dir| · mean(|C_corr|)
#
# No Kabsch/Gramian/Procrustes alignment, no reversible full-matrix holonomy requirement,
# no fitted counterterm, no primitive time coordinate.

import os, json, math, ast, warnings
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import animation
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

warnings.filterwarnings("ignore")

# -----------------------------
# Config
# -----------------------------
OUT = Path("V1688_holonomy_proof_visualizer_v2_outputs")
OUT.mkdir(exist_ok=True)

SEED = 168859
N_NODES = 8
DIM = 4

# Visual palette
BG = "#05070d"
PANEL = "#0b1020"
GRID = "#1f3554"
TEXT = "#f2f6ff"
MUTED = "#a9b5c7"
CYAN = "#4ee7ff"
BLUE = "#3b82f6"
GOLD = "#ffd65a"
ORANGE = "#ffb347"
VIOLET = "#b877ff"
MAGENTA = "#ff6bd6"
RED = "#ff6b6b"
GREEN = "#7ef29a"
WHITE = "#ffffff"

# -----------------------------
# Helpers
# -----------------------------
def parse_vec(x):
    if isinstance(x, np.ndarray):
        return x.astype(float)
    if isinstance(x, list):
        return np.array(x, dtype=float)
    if isinstance(x, str):
        return np.array(ast.literal_eval(x), dtype=float)
    raise TypeError(f"Cannot parse vector {type(x)}")

def unit(v, eps=1e-12):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    if n < eps:
        return np.zeros_like(v)
    return v / n

def roll(v):
    return np.roll(np.asarray(v, dtype=float), 1)

def native_transport(dx, q_state, gamma):
    dx = np.asarray(dx, dtype=float)
    q_state = np.asarray(q_state, dtype=float)
    return dx + gamma * (roll(dx) * q_state - dx * roll(q_state))

def directional_scalar(Zp, Zq, q_state, gamma):
    TpZ = native_transport(Zp, q_state, gamma)
    denom = (np.linalg.norm(TpZ) * np.linalg.norm(Zq)) + 1e-12
    return float(np.dot(Zq, TpZ) / denom), TpZ

def maybe_load_existing():
    """
    If the proof CSVs are present in the runtime, load them.
    This allows exact replay of the uploaded V1688 proof object.
    Otherwise, generate a deterministic native recombination proof dataset.
    """
    candidates = [
        ("V1688_holonomy_proof_nodes.csv", "V1688_holonomy_proof_edges.csv", "V1688_holonomy_proof_cycle_steps.csv", "V1688_holonomy_proof_metrics.json"),
        ("V1688_holonomy_proof_nodes(1).csv", "V1688_holonomy_proof_edges(1).csv", "V1688_holonomy_proof_cycle_steps(1).csv", "V1688_holonomy_proof_metrics(1).json"),
        ("/mnt/data/V1688_holonomy_proof_nodes(1).csv", "/mnt/data/V1688_holonomy_proof_edges(1).csv", "/mnt/data/V1688_holonomy_proof_cycle_steps(1).csv", "/mnt/data/V1688_holonomy_proof_metrics(1).json"),
    ]
    for nf, ef, sf, mf in candidates:
        if Path(nf).exists() and Path(ef).exists() and Path(sf).exists():
            nodes = pd.read_csv(nf)
            edges = pd.read_csv(ef)
            steps = pd.read_csv(sf)
            metrics = {}
            if Path(mf).exists():
                with open(mf, "r") as f:
                    metrics = json.load(f)
            return nodes, edges, steps, metrics, "loaded_uploaded_proof_object"
    return None, None, None, {}, "generated_deterministic_proof_object"

def generate_deterministic_proof():
    rng = np.random.default_rng(SEED)
    n = N_NODES

    # 3D cycle: discrete provenance cycle embedded for display only.
    # The proof uses edge products, not a smooth curve.
    theta = np.linspace(0, 2*np.pi, n, endpoint=False)
    radius = 2.6 + 0.25*np.sin(3*theta)
    x = radius*np.cos(theta)
    y = radius*np.sin(theta)
    z = 0.55*np.sin(2*theta + 0.4)

    states = []
    O3 = []
    H4 = []
    Z = []
    Ccorr = []

    for i in range(n):
        # Local retained branch state in ambient DIM space.
        s = rng.normal(size=DIM)
        s = unit(s)

        # L3 associator-like direction: not arbitrary geometry, a deterministic roll-derived obstruction proxy.
        o = roll(s) - np.roll(s, -1)
        o = unit(o)

        # L4_perp: independent residual direction, orthogonalized against state and O3.
        h_raw = rng.normal(size=DIM) + 0.25*np.roll(o, 1)
        for b in [s, o]:
            h_raw = h_raw - np.dot(h_raw, b) * b
        h = unit(h_raw)

        # Correction mode dominated by H4_perp with smaller O3 component.
        zz = unit(0.35*o + 1.00*h)

        # Deterministic correction coordinate magnitude.
        cc = float(0.55 + 0.22*np.sin(theta[i] + 0.7) + 0.08*rng.normal())

        states.append(s); O3.append(o); H4.append(h); Z.append(zz); Ccorr.append(cc)

    nodes = pd.DataFrame({
        "node_id": [f"p{i}" for i in range(n)],
        "x": x, "y": y, "z": z,
        "C_corr": Ccorr,
        "state": [v.tolist() for v in states],
        "Z": [v.tolist() for v in Z],
        "O3": [v.tolist() for v in O3],
        "H4_perp": [v.tolist() for v in H4],
    })

    edges = []
    partial = 1.0
    steps = []
    for i in range(n):
        j = (i + 1) % n
        gamma = float(0.22*np.tanh(np.dot(states[i], states[j])) + 0.12*np.sin(theta[i]-theta[j]))
        c, TpZ = directional_scalar(Z[i], Z[j], states[j], gamma)
        partial *= c
        defect = abs(1.0 - partial) * float(np.mean(np.abs(Ccorr)))
        edges.append({"from_node": f"p{i}", "to_node": f"p{j}", "gamma_pq": gamma, "c_pq": c})
        steps.append({
            "step": i+1, "from_node": f"p{i}", "to_node": f"p{j}",
            "gamma_pq": gamma, "c_pq": c,
            "H_cycle_partial": partial,
            "directional_defect_partial": defect,
            "transport_norm": float(np.linalg.norm(TpZ)),
            "Z_alignment_raw": float(np.dot(Z[j], TpZ)),
        })

    edges = pd.DataFrame(edges)
    steps = pd.DataFrame(steps)
    H = float(steps["H_cycle_partial"].iloc[-1])
    mean_abs_C = float(np.mean(np.abs(Ccorr)))
    metrics = {
        "H_cycle_dir": H,
        "native_directional_cycle_defect": abs(1 - H) * mean_abs_C,
        "mean_abs_C_corr": mean_abs_C,
        "edge_count": int(n),
        "node_count": int(n),
        "interpretation": "Directed native holonomy is produced by native recombination transport acting on the retained correction mode Z around an explicit provenance cycle."
    }
    return nodes, edges, steps, metrics

nodes, edges, steps, metrics, source_mode = maybe_load_existing()
if nodes is None:
    nodes, edges, steps, metrics = generate_deterministic_proof()

# Parse vectors.
node_index = {r["node_id"]: idx for idx, r in nodes.iterrows()}
states = {r["node_id"]: parse_vec(r["state"]) for _, r in nodes.iterrows()}
Zs = {r["node_id"]: parse_vec(r["Z"]) for _, r in nodes.iterrows()}
O3s = {r["node_id"]: parse_vec(r["O3"]) for _, r in nodes.iterrows()}
H4s = {r["node_id"]: parse_vec(r["H4_perp"]) for _, r in nodes.iterrows()}
Ccorr = {r["node_id"]: float(r["C_corr"]) for _, r in nodes.iterrows()}
pos = {r["node_id"]: np.array([float(r["x"]), float(r["y"]), float(r["z"])]) for _, r in nodes.iterrows()}

# Recompute edge scalars from native equation to validate/replay.
edge_records = []
partial = 1.0
step_records = []
for k, er in edges.iterrows():
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c, TpZ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    partial *= c
    defect = abs(1 - partial) * float(np.mean(np.abs(list(Ccorr.values()))))
    edge_records.append({
        "from_node": p, "to_node": q, "gamma_pq": gamma, "c_pq": c,
        "transport_norm": float(np.linalg.norm(TpZ)),
        "Z_alignment_raw": float(np.dot(Zs[q], TpZ)),
    })
    step_records.append({
        "step": k+1, "from_node": p, "to_node": q, "gamma_pq": gamma,
        "c_pq": c, "H_cycle_partial": partial,
        "directional_defect_partial": defect,
        "transport_norm": float(np.linalg.norm(TpZ)),
        "Z_alignment_raw": float(np.dot(Zs[q], TpZ)),
    })

edges = pd.DataFrame(edge_records)
steps = pd.DataFrame(step_records)
mean_abs_C = float(np.mean(np.abs(list(Ccorr.values()))))
H_final = float(steps["H_cycle_partial"].iloc[-1])
defect_final = float(abs(1 - H_final) * mean_abs_C)

# Reverse diagnostic: reverse traversal is not assumed inverse.
reverse_product = 1.0
for _, er in edges.iloc[::-1].iterrows():
    p, q = er["to_node"], er["from_node"]
    gamma = float(er["gamma_pq"])  # same ledger magnitude for display diagnostic; not treated as inverse.
    c_rev, _ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    reverse_product *= c_rev
reverse_defect = float(abs(1 - reverse_product) * mean_abs_C)
orientation_asym = float(abs(defect_final - reverse_defect))

# Incidence continuity from reciprocal native directional flux.
# For each cycle edge, compute forward and reverse native scalars and antisymmetric current.
continuity = {nid: 0.0 for nid in nodes["node_id"]}
flux_records = []
for _, er in edges.iterrows():
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c_fwd, _ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    c_rev, _ = directional_scalar(Zs[q], Zs[p], states[p], gamma)
    F_pq = c_fwd * Ccorr[p]
    F_qp = c_rev * Ccorr[q]
    J = 0.5 * (F_pq - F_qp)
    continuity[p] -= J
    continuity[q] += J
    flux_records.append({"from_node": p, "to_node": q, "c_pq": c_fwd, "c_qp": c_rev, "F_pq": F_pq, "F_qp": F_qp, "J_pq": J})

continuity_df = pd.DataFrame([{"node_id": k, "continuity_residual": v} for k, v in continuity.items()])
flux_df = pd.DataFrame(flux_records)

# Metrics output.
metrics_out = {
    "source_mode": source_mode,
    "H_cycle_dir": H_final,
    "native_directional_cycle_defect": defect_final,
    "mean_abs_C_corr": mean_abs_C,
    "reverse_H_cycle_dir": reverse_product,
    "reverse_directional_cycle_defect": reverse_defect,
    "orientation_asymmetry_abs": orientation_asym,
    "edge_count": int(len(edges)),
    "node_count": int(len(nodes)),
    "max_abs_continuity_residual": float(np.max(np.abs(list(continuity.values())))),
    "interpretation": (
        "Directed native holonomy is produced by the action of native recombination transport "
        "on the retained correction mode Z around an explicit provenance cycle. "
        "The display-smoothed curve is only a visualization of the discrete provenance cycle."
    )
}

# Save data.
nodes.to_csv(OUT / "V1688_v2_nodes.csv", index=False)
edges.to_csv(OUT / "V1688_v2_edges.csv", index=False)
steps.to_csv(OUT / "V1688_v2_cycle_steps.csv", index=False)
flux_df.to_csv(OUT / "V1688_v2_antisymmetric_flux.csv", index=False)
continuity_df.to_csv(OUT / "V1688_v2_continuity.csv", index=False)
with open(OUT / "V1688_v2_metrics.json", "w") as f:
    json.dump(metrics_out, f, indent=2)

# -----------------------------
# Visualization helpers
# -----------------------------
def setup_3d(ax, title=None):
    ax.set_facecolor(BG)
    ax.grid(False)
    for pane in [ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane]:
        pane.set_alpha(0.08)
        pane.set_facecolor(GRID)
        pane.set_edgecolor(CYAN)
    ax.tick_params(colors=MUTED, labelsize=7)
    ax.set_xlabel("display x", color=MUTED, labelpad=-2)
    ax.set_ylabel("display y", color=MUTED, labelpad=-2)
    ax.set_zlabel("display z", color=MUTED, labelpad=-2)
    if title:
        ax.set_title(title, color=TEXT, fontsize=13, pad=12)
    ax.view_init(elev=24, azim=-62)

def draw_arrow3d(ax, start, vec, color, lw=2.0, alpha=1.0, length_scale=1.0, label=None):
    start = np.asarray(start)
    vec = np.asarray(vec) * length_scale
    ax.quiver(
        start[0], start[1], start[2],
        vec[0], vec[1], vec[2],
        color=color, linewidth=lw, alpha=alpha, arrow_length_ratio=0.25, normalize=False
    )
    if label:
        end = start + vec
        ax.text(end[0], end[1], end[2], label, color=color, fontsize=8)

def draw_cycle(ax, active_step=None, trail_steps=None, show_vectors=True, show_smooth=True):
    ids = list(nodes["node_id"])
    P = np.array([pos[nid] for nid in ids])

    # Display-smoothed curve: interpolation only. Proof uses discrete edges.
    if show_smooth:
        PP = np.vstack([P, P[0]])
        # simple linear dense interpolation to avoid claiming geometric spline.
        dense = []
        for i in range(len(PP)-1):
            for t in np.linspace(0, 1, 8, endpoint=False):
                dense.append((1-t)*PP[i] + t*PP[i+1])
        dense.append(PP[-1])
        dense = np.array(dense)
        ax.plot(dense[:,0], dense[:,1], dense[:,2], color=GOLD, lw=1.1, alpha=0.30)

    # Edges.
    for i, er in edges.iterrows():
        p, q = er["from_node"], er["to_node"]
        a, b = pos[p], pos[q]
        col = GOLD
        lw = 2.0
        alpha = 0.72
        if active_step is not None and i == active_step:
            col, lw, alpha = ORANGE, 5.0, 1.0
        elif trail_steps is not None and i in trail_steps:
            col, lw, alpha = GREEN, 3.0, 0.95
        ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]], color=col, lw=lw, alpha=alpha)
        mid = 0.63*a + 0.37*b
        direction = unit(b - a) * 0.16
        draw_arrow3d(ax, mid, direction, col, lw=lw, alpha=alpha)

    # Nodes.
    ax.scatter(P[:,0], P[:,1], P[:,2], s=60, c=CYAN, edgecolors=WHITE, linewidths=0.6, alpha=0.97)
    for nid in ids:
        p = pos[nid]
        ax.text(p[0]+0.03, p[1]+0.03, p[2]+0.07, nid, color=TEXT, fontsize=8)

    # Local L3/L4/Z glyphs projected from first 3 components.
    if show_vectors:
        for nid in ids:
            p = pos[nid]
            o = unit(O3s[nid][:3]) * 0.30
            h = unit(H4s[nid][:3]) * 0.32
            z = unit(Zs[nid][:3]) * 0.45
            draw_arrow3d(ax, p, o, ORANGE, lw=1.2, alpha=0.42)
            draw_arrow3d(ax, p, h, VIOLET, lw=1.4, alpha=0.55)
            draw_arrow3d(ax, p, z, MAGENTA, lw=2.2, alpha=0.92)

def text_panel(ax):
    ax.set_facecolor(PANEL)
    ax.axis("off")
    ax.text(0.02, 0.96, "Retained Bridge: V2 runnable proof object", color=CYAN, fontsize=17, va="top", family="monospace")
    y = 0.84
    blocks = [
        ("Local generated algebra", "G_p = span(B_p, O3_p, H4_perp_p)", GOLD),
        ("Native recombination transport", "T_pq(dx) = dx + gamma_pq [roll(dx)⊙q − dx⊙roll(q)]", GOLD),
        ("Correction direction", "Z_p = unit(0.35·O3_p + 1.0·H4_perp_p)", VIOLET),
        ("Directional edge scalar", "c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)", GOLD),
        ("Cycle holonomy produced", "H_cycle^dir = Π_loop c_pq", CYAN),
        ("Native directional defect", "defect = |1 − H_cycle^dir| · mean(|C_corr|)", RED),
    ]
    for title, body, col in blocks:
        ax.text(0.02, y, title, color=col, fontsize=11, va="top", family="monospace")
        ax.text(0.02, y-0.045, body, color=TEXT, fontsize=9.2, va="top", family="monospace")
        y -= 0.13
    ax.text(0.02, 0.06, "No Kabsch/Gramian alignment • No reversible full-matrix requirement • Directed retained-order cycle",
            color="#9cecff", fontsize=9.0, family="monospace")

def plot_accumulation(ax, upto=None):
    ax.set_facecolor(PANEL)
    if upto is None:
        data = steps.copy()
    else:
        data = steps.iloc[:upto+1].copy()
    ax.plot(steps["step"], steps["directional_defect_partial"], color=GRID, lw=1.0, alpha=0.5)
    if len(data):
        ax.plot(data["step"], data["directional_defect_partial"], color=CYAN, marker="o", lw=2.0)
        ax.scatter([data["step"].iloc[-1]], [data["directional_defect_partial"].iloc[-1]], color=ORANGE, s=55, zorder=10)
    ax.set_title("Holonomy defect accumulates edge-by-edge", color=TEXT, fontsize=11)
    ax.set_xlabel("cycle step", color=MUTED)
    ax.set_ylabel("partial defect", color=MUTED)
    ax.tick_params(colors=MUTED, labelsize=8)
    for spine in ax.spines.values():
        spine.set_color(CYAN)
        spine.set_alpha(0.7)
    ax.grid(alpha=0.15, color=GRID)

def continuity_panel(ax):
    ax.set_facecolor(PANEL)
    ax.axis("off")
    ax.text(0.02, 0.94, "Retained-order incidence continuity", color=CYAN, fontsize=13, family="monospace", va="top")
    ax.text(0.02, 0.80, "F_pq = c_pq · C_corr(p)", color=TEXT, fontsize=10, family="monospace")
    ax.text(0.02, 0.68, "J_pq = 1/2 · (F_pq − F_qp)", color=TEXT, fontsize=10, family="monospace")
    ax.text(0.02, 0.56, "continuity(p) = incoming J − outgoing J", color=TEXT, fontsize=10, family="monospace")
    # Simple node residual bar.
    vals = continuity_df["continuity_residual"].values
    maxv = max(np.max(np.abs(vals)), 1e-9)
    ax.text(0.02, 0.40, "node residual gauge", color=GOLD, fontsize=10, family="monospace")
    for i, row in continuity_df.iterrows():
        x0 = 0.18 + i * 0.09
        v = float(row["continuity_residual"]) / maxv
        col = RED if v > 0 else BLUE
        ax.plot([x0, x0], [0.18, 0.18 + 0.16*v], color=col, lw=4, solid_capstyle="round")
        ax.text(x0-0.018, 0.10, row["node_id"], color=MUTED, fontsize=8, rotation=45)
    ax.text(0.02, 0.02, "Continuity is derived from antisymmetric reciprocal provenance-edge current.",
            color="#9cecff", fontsize=8.3, family="monospace")

def metrics_panel(ax):
    ax.set_facecolor(PANEL)
    ax.axis("off")
    ax.text(0.02, 0.92, "Computed proof metrics", color=GOLD, fontsize=12, family="monospace")
    lines = [
        f"source mode: {source_mode}",
        f"H_cycle^dir = {H_final:+.6e}",
        f"native directional defect = {defect_final:.6f}",
        f"reverse defect diagnostic = {reverse_defect:.6f}",
        f"|forward − reverse| = {orientation_asym:.6e}",
        f"mean(|C_corr|) = {mean_abs_C:.6f}",
        f"nodes = {len(nodes)}, edges = {len(edges)}",
    ]
    y = 0.78
    for line in lines:
        ax.text(0.02, y, line, color=TEXT, fontsize=9.2, family="monospace")
        y -= 0.095
    ax.text(0.02, 0.06, "Interpretation: directed native holonomy is produced by the correction mode over explicit provenance cycles.",
            color="#9cecff", fontsize=8.2, family="monospace", wrap=True)

# -----------------------------
# Static plate
# -----------------------------
fig = plt.figure(figsize=(18, 10.2), facecolor=BG)
gs = fig.add_gridspec(3, 4, width_ratios=[1.38, 1.0, 1.0, 1.0], height_ratios=[1.16, 0.92, 0.75], wspace=0.22, hspace=0.22)

ax3d = fig.add_subplot(gs[:, 0], projection="3d")
setup_3d(ax3d, "3D L3/L4 provenance cycle topology")
draw_cycle(ax3d, active_step=None, trail_steps=set(range(len(edges))), show_vectors=True)
ax3d.text2D(0.02, 0.03, "Gold path = explicit discrete provenance cycle\nOrange = L3/O3, Violet = L4/H4_perp, Magenta = Z correction mode\nSmoothed curve is display-only; proof uses edge product.", transform=ax3d.transAxes, color="#9cecff", fontsize=8)

axText = fig.add_subplot(gs[0, 1:3])
text_panel(axText)

axPlot = fig.add_subplot(gs[0, 3])
plot_accumulation(axPlot)

axCont = fig.add_subplot(gs[1, 1])
continuity_panel(axCont)

axMetrics = fig.add_subplot(gs[1, 2])
metrics_panel(axMetrics)

axInterp = fig.add_subplot(gs[1, 3])
axInterp.set_facecolor(PANEL); axInterp.axis("off")
axInterp.text(0.02, 0.92, "Scientific interpretation", color=GOLD, fontsize=12, family="monospace")
interp = (
    "The model does not produce reversible geometric holonomy as a primitive.\n\n"
    "It produces directed native holonomy of the retained correction mode Z.\n\n"
    "That holonomy is generated edge-by-edge by native recombination transport over an explicit provenance cycle."
)
axInterp.text(0.02, 0.74, interp, color=TEXT, fontsize=9.5, family="monospace", va="top", linespacing=1.5)
axInterp.text(0.02, 0.08, "Boundary: visualization is a finite retained-flow proof object, not a GR/Einstein derivation.",
              color="#9cecff", fontsize=8.4, family="monospace")

axSteps = fig.add_subplot(gs[2, 1:])
axSteps.set_facecolor(PANEL)
colors = [GREEN if x > 0 else RED for x in steps["c_pq"]]
axSteps.bar(steps["step"], steps["c_pq"], color=colors, alpha=0.85)
axSteps.axhline(0, color=WHITE, lw=0.8, alpha=0.5)
axSteps.set_title("Directional edge scalars c_pq whose product produces H_cycle^dir", color=TEXT, fontsize=11)
axSteps.set_xlabel("cycle step", color=MUTED)
axSteps.set_ylabel("c_pq", color=MUTED)
axSteps.tick_params(colors=MUTED, labelsize=8)
for spine in axSteps.spines.values():
    spine.set_color(CYAN); spine.set_alpha(0.7)
axSteps.grid(alpha=0.12, color=GRID)

fig.suptitle("V1688 Native Directional Holonomy — First-Principles Proof Visualization V2", color=TEXT, fontsize=18, y=0.98)
fig.savefig(OUT / "V1688_v2_static_proof.png", dpi=180, facecolor=BG, bbox_inches="tight")
plt.close(fig)

# -----------------------------
# Animation: synchronized cycle traversal
# -----------------------------
def make_frame(frame_idx):
    fig = plt.figure(figsize=(14.5, 8.0), facecolor=BG)
    gs = fig.add_gridspec(2, 3, width_ratios=[1.45, 1.0, 1.0], height_ratios=[1.2, 0.95], wspace=0.25, hspace=0.25)

    active = min(frame_idx, len(edges)-1)
    trail = set(range(active+1))

    ax = fig.add_subplot(gs[:,0], projection="3d")
    setup_3d(ax, "Holonomy generated around explicit provenance cycle")
    draw_cycle(ax, active_step=active, trail_steps=trail, show_vectors=True)

    er = edges.iloc[active]
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c = float(er["c_pq"])
    TpZ = native_transport(Zs[p], states[q], gamma)
    # Draw current transported vector from q location for visibility.
    draw_arrow3d(ax, pos[q], unit(TpZ[:3])*0.62, WHITE, lw=3.2, alpha=0.95, label="T_pq Z_p")
    ax.text2D(0.02, 0.06, f"active edge: {p} → {q}\nγ_pq={gamma:+.4f}, c_pq={c:+.4f}", transform=ax.transAxes, color=GOLD, fontsize=10, family="monospace")

    axEq = fig.add_subplot(gs[0,1])
    axEq.set_facecolor(PANEL); axEq.axis("off")
    axEq.text(0.03, 0.94, "Current native transport step", color=CYAN, fontsize=13, family="monospace")
    lines = [
        "T_pq(dx) = dx + gamma_pq [roll(dx)⊙q − dx⊙roll(q)]",
        "",
        f"edge = {p} → {q}",
        f"gamma_pq = {gamma:+.6f}",
        f"c_pq = {c:+.6f}",
        "",
        "c_pq compares transported Z_p with Z_q.",
        "Reverse edge is not assumed inverse."
    ]
    y = 0.82
    for line in lines:
        axEq.text(0.03, y, line, color=TEXT if line else MUTED, fontsize=9.2, family="monospace")
        y -= 0.09

    axAcc = fig.add_subplot(gs[0,2])
    plot_accumulation(axAcc, upto=active)
    partH = float(steps["H_cycle_partial"].iloc[active])
    partD = float(steps["directional_defect_partial"].iloc[active])
    axAcc.text(0.05, 0.06, f"partial H={partH:+.6e}\npartial defect={partD:.6f}", transform=axAcc.transAxes, color=GOLD, fontsize=9.5, family="monospace")

    axBar = fig.add_subplot(gs[1,1:])
    axBar.set_facecolor(PANEL)
    cols = []
    for i, val in enumerate(steps["c_pq"]):
        if i <= active:
            cols.append(GREEN if val > 0 else RED)
        else:
            cols.append(GRID)
    axBar.bar(steps["step"], steps["c_pq"], color=cols, alpha=0.9)
    axBar.axhline(0, color=WHITE, lw=0.8, alpha=0.5)
    axBar.set_title("Edge scalars already multiplied into H_cycle^dir", color=TEXT, fontsize=11)
    axBar.set_xlabel("cycle step", color=MUTED)
    axBar.set_ylabel("c_pq", color=MUTED)
    axBar.tick_params(colors=MUTED, labelsize=8)
    for spine in axBar.spines.values():
        spine.set_color(CYAN); spine.set_alpha(0.7)
    axBar.grid(alpha=0.10, color=GRID)

    fig.suptitle("Directed native holonomy being generated — V1688 V2", color=TEXT, fontsize=16)
    return fig

frames = []
for frame_idx in range(len(edges)):
    figf = make_frame(frame_idx)
    frame_path = OUT / f"frame_{frame_idx:03d}.png"
    figf.savefig(frame_path, dpi=130, facecolor=BG, bbox_inches="tight")
    plt.close(figf)
    frames.append(frame_path)

# Make GIF with pillow if available.
try:
    from PIL import Image
    imgs = [Image.open(p).convert("P", palette=Image.ADAPTIVE) for p in frames]
    imgs[0].save(OUT / "V1688_v2_holonomy_animation.gif", save_all=True, append_images=imgs[1:], duration=950, loop=0)
except Exception as e:
    print("GIF creation skipped:", e)

# Write README.
readme = f"""# V1688 Holonomy Proof Visualizer V2

This Colab-ready one-cell proof visualizer shows native directional holonomy being produced by first-principles retained recombination transport.

## Core equations

```text
T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 − H_cycle^dir| · mean(|C_corr|)
```

## Output metrics

```json
{json.dumps(metrics_out, indent=2)}
```

## Science boundary

This is a finite retained-flow proof visualization. It does not claim GR, Einstein equations, Riemann curvature, or physical spacetime.

The smoothed curve is display interpolation only. The proof object is the explicit discrete provenance cycle edge product.
"""
with open(OUT / "README.md", "w") as f:
    f.write(readme)

print("V1688 V2 proof visualizer complete.")
print("Outputs written to:", OUT.resolve())
print(json.dumps(metrics_out, indent=2))
