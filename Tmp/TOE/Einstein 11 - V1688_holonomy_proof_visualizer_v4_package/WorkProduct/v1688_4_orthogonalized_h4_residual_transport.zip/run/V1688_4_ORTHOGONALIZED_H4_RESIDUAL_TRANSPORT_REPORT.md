# V1688.4 Orthogonalized H4 Residual Transport

```json
{
  "document_id": "V1688_4_ORTHOGONALIZED_H4_RESIDUAL_TRANSPORT",
  "status": "completed",
  "verdict": "L4_ORTHOGONAL_CURVATURE_BRIDGE_NOT_SUPPORTED",
  "real_mean_corr": 0.12954104725656532,
  "best_orthogonal_null_mean_corr": 0.01970481826390524,
  "real_minus_best_null_margin": 0.10983622899266007,
  "orthogonal_fraction_mean": 0.5277256090277894,
  "condition_grouped": [
    {
      "condition": "orthogonal_phase",
      "mean_corr": 0.01970481826390524,
      "min_corr": -0.06746828294539553,
      "std_corr": 0.10450554341478292,
      "mean_K_hol": 0.3833371029636629,
      "orthogonal_fraction_mean": 0.5277256090277894
    },
    {
      "condition": "orthogonal_real",
      "mean_corr": 0.12954104725656532,
      "min_corr": 0.10977531532207405,
      "std_corr": 0.019082815594113362,
      "mean_K_hol": 0.3693223973711179,
      "orthogonal_fraction_mean": 0.5277256090277894
    },
    {
      "condition": "orthogonal_roll",
      "mean_corr": -0.09210780308588036,
      "min_corr": -0.09900118547786048,
      "std_corr": 0.006075760678055427,
      "mean_K_hol": 0.349330490400196,
      "orthogonal_fraction_mean": 0.5277256090277894
    },
    {
      "condition": "orthogonal_shuffle",
      "mean_corr": -0.10746104918763899,
      "min_corr": -0.1985852353594289,
      "std_corr": 0.09424224630512762,
      "mean_K_hol": 0.3923474457037019,
      "orthogonal_fraction_mean": 0.5277256090277894
    }
  ],
  "outputs": {
    "loop_rows": "/mnt/data/v1688_4_orthogonalized_h4_residual_transport_outputs/v1688_4_loop_rows.csv",
    "summary": "/mnt/data/v1688_4_orthogonalized_h4_residual_transport_outputs/v1688_4_summary.csv",
    "grouped": "/mnt/data/v1688_4_orthogonalized_h4_residual_transport_outputs/v1688_4_grouped.csv"
  },
  "claim_boundary": "Orthogonalized H4 residual holonomy proxy only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
```
