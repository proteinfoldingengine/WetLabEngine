# V1688.4 Orthogonalized H4 Residual Transport

Removes lower-order/source-predictable component before holonomy proxy test.
