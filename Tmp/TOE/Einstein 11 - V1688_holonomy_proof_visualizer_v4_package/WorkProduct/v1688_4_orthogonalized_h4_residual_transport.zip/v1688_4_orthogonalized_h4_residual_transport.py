
from pathlib import Path
import json, numpy as np, pandas as pd

OUT = Path("/mnt/data/v1688_4_orthogonalized_h4_residual_transport_outputs")
OUT.mkdir(parents=True, exist_ok=True)

GRID_SIZES = [32, 48, 64]
EPS = 1e-12
SEED = 16884

def g2(X,Y,cx,cy,s=.75):
    return np.exp(-((X-cx)**2+(Y-cy)**2)/(2*s*s))

def nf(F):
    m=np.max(np.abs(F))
    return F if m<EPS else F/m

def recombine(a,b,mode="nonlinear"):
    if mode=="linear":
        return a+b
    rd=.5*(np.roll(a,1,0)+np.roll(a,1,1))
    ru=.5*(np.roll(b,-1,0)+np.roll(b,-1,1))
    ov=np.minimum(np.abs(a),np.abs(b))/(1+np.minimum(np.abs(a),np.abs(b)))
    return a+b+.35*ov*(rd*b-a*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode),C,mode)-recombine(A,recombine(B,C,mode),mode)

def h4(J,mode="nonlinear"):
    J1,J2,J3,J4=J
    return recombine(recombine(recombine(J1,J2,mode),J3,mode),J4,mode)-recombine(J1,recombine(J2,recombine(J3,J4,mode),mode),mode)

def grad(F,dx):
    fy,fx=np.gradient(F,dx,dx)
    return fx,fy

def curl(Ax,Ay,dx):
    _,ayx=np.gradient(Ay,dx,dx)
    ax_y,_=np.gradient(Ax,dx,dx)
    return ayx-ax_y

def corr(a,b):
    a=np.asarray(a); b=np.asarray(b)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

def sample(F,xs,ys,x,y):
    if x<=xs[0] or x>=xs[-1] or y<=ys[0] or y>=ys[-1]:
        return 0.0
    ix=np.searchsorted(xs,x)-1
    iy=np.searchsorted(ys,y)-1
    ix=np.clip(ix,0,len(xs)-2)
    iy=np.clip(iy,0,len(ys)-2)
    x0,x1=xs[ix],xs[ix+1]
    y0,y1=ys[iy],ys[iy+1]
    tx=(x-x0)/(x1-x0+EPS)
    ty=(y-y0)/(y1-y0+EPS)
    return float((1-tx)*(1-ty)*F[iy,ix]+tx*(1-ty)*F[iy,ix+1]+(1-tx)*ty*F[iy+1,ix]+tx*ty*F[iy+1,ix+1])

def lineint(f,cx,cy,r,steps=12):
    xs,ys,Ax,Ay=f["xs"],f["ys"],f["Ax"],f["Ay"]
    pts=[]
    for t in np.linspace(-r,r,steps,endpoint=False): pts.append((cx+t,cy-r))
    for t in np.linspace(-r,r,steps,endpoint=False): pts.append((cx+r,cy+t))
    for t in np.linspace(r,-r,steps,endpoint=False): pts.append((cx+t,cy+r))
    for t in np.linspace(r,-r,steps,endpoint=False): pts.append((cx-r,cy+t))
    pts.append(pts[0])
    total=0.0
    for (x0,y0),(x1,y1) in zip(pts[:-1],pts[1:]):
        xm,ym=(x0+x1)/2,(y0+y1)/2
        total += sample(Ax,xs,ys,xm,ym)*(x1-x0)+sample(Ay,xs,ys,xm,ym)*(y1-y0)
    return abs(float(total))

def avg(F,xs,ys,cx,cy,r):
    mask=((xs[None,:]>=cx-r)&(xs[None,:]<=cx+r)&(ys[:,None]>=cy-r)&(ys[:,None]<=cy+r))
    return float(np.mean(F[mask])) if np.any(mask) else 0.0

def make_sources(n):
    xs=np.linspace(-3,3,n)
    ys=np.linspace(-3,3,n)
    X,Y=np.meshgrid(xs,ys)
    dx=xs[1]-xs[0]
    centers=[(-1.6,-1.1),(1.55,-1.0),(-1.15,1.55),(1.35,1.45)]
    J=[]
    for k,(cx,cy) in enumerate(centers):
        F=g2(X,Y,cx,cy)+.1*np.sin((k+2)*X+.3*k)*np.cos((k+1.5)*Y-.2*k)
        J.append(nf(F))
    return xs,ys,X,Y,dx,np.array(J)

def orthogonal_residual(target, basis_fields):
    # Regress target against lower-order/source fields and return residual.
    y=target.ravel()
    B=np.stack([b.ravel() for b in basis_fields],axis=1)
    coeff=np.linalg.pinv(B)@y
    pred=B@coeff
    res=y-pred
    return res.reshape(target.shape), pred.reshape(target.shape), coeff

def h4_null(residual, kind, n):
    rng=np.random.default_rng(SEED+n)
    if kind=="orthogonal_real":
        return residual.copy()
    if kind=="orthogonal_shuffle":
        flat=residual.ravel().copy()
        rng.shuffle(flat)
        return flat.reshape(residual.shape)
    if kind=="orthogonal_roll":
        return np.roll(np.roll(residual,n//3,axis=0),n//4,axis=1)
    if kind=="orthogonal_phase":
        F=np.fft.fft2(residual)
        amp=np.abs(F)
        ph=rng.uniform(-np.pi,np.pi,F.shape)
        ph[:2,:2]=np.angle(F[:2,:2])
        return np.real(np.fft.ifft2(amp*np.exp(1j*ph)))
    raise ValueError(kind)

def compute(n,condition):
    xs,ys,X,Y,dx,J=make_sources(n)
    pair=np.sum(J,0)
    O3_fields=[assoc3(J[0],J[1],J[2]),assoc3(J[0],J[1],J[3]),assoc3(J[0],J[2],J[3]),assoc3(J[1],J[2],J[3])]
    O3_density=sum(np.abs(o) for o in O3_fields)
    H4=h4(J)
    H4_abs=np.abs(H4)

    # Lower-order/source basis. This is intentionally broad.
    dpx,dpy=grad(nf(pair),dx)
    dox,doy=grad(nf(O3_density),dx)
    basis=[
        np.ones_like(pair),
        nf(np.abs(pair)),
        nf(O3_density),
        nf(pair**2),
        nf(O3_density**2),
        nf(np.sqrt(dpx*dpx+dpy*dpy)),
        nf(np.sqrt(dox*dox+doy*doy)),
    ]
    H4_res, H4_pred, coeff=orthogonal_residual(nf(H4_abs),basis)
    rho=np.abs(h4_null(H4_res,condition,n))
    rho=rho/(np.mean(rho)+EPS)

    # Construct transport using lower-order field + only orthogonalized residual.
    phi=np.log1p(np.abs(pair))+.15*nf(O3_density)+.22*nf(rho)
    px,py=grad(phi,dx)
    rx,ry=grad(nf(rho),dx)

    # residual-driven connection-like field
    Ax=-py+.35*ry
    Ay=px-.35*rx
    K=np.abs(curl(Ax,Ay,dx))

    return {
        "xs":xs,"ys":ys,"rho":rho,"Ax":Ax,"Ay":Ay,"K":K,
        "orthogonal_residual_norm":float(np.linalg.norm(H4_res)),
        "lower_order_pred_norm":float(np.linalg.norm(H4_pred)),
        "h4_abs_norm":float(np.linalg.norm(nf(H4_abs))),
        "orthogonal_fraction":float(np.linalg.norm(H4_res)/(np.linalg.norm(nf(H4_abs))+EPS))
    }

def audit(n,condition):
    f=compute(n,condition)
    rows=[]
    for r in [.35,.50,.65]:
        for cx in np.linspace(-1.8,1.8,7):
            for cy in np.linspace(-1.8,1.8,7):
                rows.append({
                    "grid_n":n,
                    "condition":condition,
                    "r":r,
                    "cx":cx,
                    "cy":cy,
                    "holonomy_abs":lineint(f,float(cx),float(cy),r),
                    "rho4_orth_avg":avg(f["rho"],f["xs"],f["ys"],float(cx),float(cy),r),
                    "K_abs_avg":avg(f["K"],f["xs"],f["ys"],float(cx),float(cy),r),
                    "orthogonal_fraction":f["orthogonal_fraction"]
                })
    return pd.DataFrame(rows)

conditions=["orthogonal_real","orthogonal_shuffle","orthogonal_roll","orthogonal_phase"]
allrows=[]
sums=[]
for n in GRID_SIZES:
    for cond in conditions:
        df=audit(n,cond)
        allrows.append(df)
        sums.append({
            "grid_n":n,
            "condition":cond,
            "corr_orthH4_holonomy_abs":corr(df.rho4_orth_avg,df.holonomy_abs),
            "corr_K_holonomy_abs":corr(df.K_abs_avg,df.holonomy_abs),
            "mean_holonomy_abs":float(df.holonomy_abs.mean()),
            "orthogonal_fraction_mean":float(df.orthogonal_fraction.mean())
        })

full=pd.concat(allrows,ignore_index=True)
summ=pd.DataFrame(sums)
full.to_csv(OUT/"v1688_4_loop_rows.csv",index=False)
summ.to_csv(OUT/"v1688_4_summary.csv",index=False)

group=summ.groupby("condition").agg(
    mean_corr=("corr_orthH4_holonomy_abs","mean"),
    min_corr=("corr_orthH4_holonomy_abs","min"),
    std_corr=("corr_orthH4_holonomy_abs","std"),
    mean_K_hol=("corr_K_holonomy_abs","mean"),
    orthogonal_fraction_mean=("orthogonal_fraction_mean","mean")
).reset_index()
group.to_csv(OUT/"v1688_4_grouped.csv",index=False)

real=group[group.condition=="orthogonal_real"].iloc[0].to_dict()
nulls=group[group.condition!="orthogonal_real"]
best_null=float(nulls.mean_corr.max())
margin=float(real["mean_corr"]-best_null)

if real["mean_corr"]>0.25 and margin>0.05:
    verdict="L4_ORTHOGONAL_CURVATURE_BRIDGE_SUPPORTED"
elif real["mean_corr"]>0.15 and margin>0:
    verdict="L4_ORTHOGONAL_CURVATURE_BRIDGE_PARTIAL"
else:
    verdict="L4_ORTHOGONAL_CURVATURE_BRIDGE_NOT_SUPPORTED"

result={
    "document_id":"V1688_4_ORTHOGONALIZED_H4_RESIDUAL_TRANSPORT",
    "status":"completed",
    "verdict":verdict,
    "real_mean_corr":float(real["mean_corr"]),
    "best_orthogonal_null_mean_corr":best_null,
    "real_minus_best_null_margin":margin,
    "orthogonal_fraction_mean":float(real["orthogonal_fraction_mean"]),
    "condition_grouped":group.to_dict(orient="records"),
    "outputs":{
        "loop_rows":str(OUT/"v1688_4_loop_rows.csv"),
        "summary":str(OUT/"v1688_4_summary.csv"),
        "grouped":str(OUT/"v1688_4_grouped.csv")
    },
    "claim_boundary":"Orthogonalized H4 residual holonomy proxy only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
(OUT/"v1688_4_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_4_ORTHOGONALIZED_H4_RESIDUAL_TRANSPORT_REPORT.md").write_text("# V1688.4 Orthogonalized H4 Residual Transport\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
