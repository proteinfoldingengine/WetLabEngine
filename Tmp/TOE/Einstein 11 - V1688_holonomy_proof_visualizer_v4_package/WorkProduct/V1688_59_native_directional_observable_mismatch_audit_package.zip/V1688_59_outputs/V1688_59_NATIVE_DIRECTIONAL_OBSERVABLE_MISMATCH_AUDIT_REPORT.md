# V1688.59 — Native Directional Observable Mismatch Audit

## Verdict

```text
NATIVE_DIRECTIONAL_OBSERVABLE_PASS
```

## Purpose

V1688.57 showed that full native matrix invariants — Frobenius, determinant, trace — did not derive the surviving scalar exact-cycle defect. V1688.58 showed that the failure was not caused by missing operator closure of `G_p`.

V1688.59 therefore tested a narrower first-principles possibility: the surviving scalar cycle defect may be a **directional observable** of native recombination transport, not a full-matrix observable.

## First-principles constraints

```text
No Kabsch / Procrustes / Gramian transport
No fitted counterterm
No threshold patch
No time primitive
No external geometry imposed as law
```

## Native directional observable

The local correction direction was defined inside the frozen generated algebra:

```text
Z_p = unit(edge_resid_vs_M0 · O3_p + h4_resid_vs_M0 · H4_perp_p)
```

Native transport remained the recombination Jacobian:

```text
T_pq(dx) = dx + gamma_pq · [roll(dx) ⊙ q - dx ⊙ roll(q)]
```

Directional edge scalar:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
```

Directional cycle observable:

```text
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 - H_cycle^dir| · mean(|C_corr|)
```

## Ledger scale

```text
nodes:           29696
edge scalars:    114176
cycles composed: 27440
mean rank(G_p):  4.000000
mean cond(G_p):  9.949596
```

## Derivation test

```text
mean R²(native directional observables → exact_cycle_defect): +0.400578
mean R²(native directional observables → correction_loss):    +0.298953
cycle corr(native_directional_defect, exact_cycle_defect):    +0.612634
```

## Weak-form explanatory test

Mean group-holdout results:

```text
R² M0:                         +0.001215
R² M0 + C_corr:                +0.081050
R² M0 + C_corr + exact:        +0.114433
R² M0 + C_corr + native_dir:   +0.134398
R² M0 + C_corr + exact + dir:  +0.136570

exact unique over C_corr:      +0.033383
native_dir unique over Ccorr:  +0.053348
native_dir added after exact:  +0.022137
positive native_dir rate:      1.000000
```

## Nulls

```text
critical null max native-dir unique: +0.000000
observed-null margin:               +0.053348
```

| null_mode                        |   mean_native_dir_unique_over_Ccorr |   mean_native_dir_added_after_exact |   positive_unique_rate |   rows |
|:---------------------------------|------------------------------------:|------------------------------------:|-----------------------:|-------:|
| global_directional_shuffle       |                        -1.69484e-05 |                        -2.9639e-05  |               0.636364 |     11 |
| within_block_directional_shuffle |                        -6.82328e-05 |                        -8.42575e-05 |               0.545455 |     11 |
| source_flow_preserving_shuffle   |                        -0.000117769 |                        -0.000129642 |               0.181818 |     11 |
| linear_zero_control              |                         2.01859e-17 |                        -1.00929e-17 |               0.181818 |     11 |

## Interpretation

The native directional observable succeeds where the full-matrix native invariants failed. The scalar action of native recombination transport on the correction direction `Z_p` partially derives the surviving exact-cycle defect and improves the weak-form residual beyond `C_corr` and beyond the exact scalar cycle feature.

This does not mean GR closure. It means the correct native observable is likely directional: the correction mode sees the connection differently than full trace/determinant/Frobenius matrix summaries.

## Claim boundary

This is a finite retained-flow emitted-ledger harness result. It is not an ADM derivation, GR closure, Riemann curvature result, Einstein equation result, or physical spacetime claim.

## Next

```text
V1688.60 — native directional cycle-basis and subdivision hardening
```

The next test should ask whether the native directional scalar survives orientation reversal, cycle-basis change, 2x2 macro-cycle subdivision, and source-flow-preserving nulls without using external geometric alignment.
