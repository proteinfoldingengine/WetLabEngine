#!/usr/bin/env python3
"""
V1688.59 — Native Directional Observable Mismatch Audit
=======================================================

First-principles question:
Can the surviving scalar signed-projection exact-cycle defect be recovered as a
native directional observable of the recombination Jacobian, rather than as a
full matrix trace/determinant/Frobenius invariant?

No Kabsch / Procrustes / Gramian transport. No fitted counterterm. No threshold
patch. No time primitive.

Native transport:
    T_pq(dx) = dx + gamma_pq * (roll(dx) * q - dx * roll(q))

Correction direction inside the frozen generated algebra:
    Z_p = unit(edge_resid_vs_M0 * O3_p + h4_resid_vs_M0 * H4_perp_p)

Native directional edge scalar:
    c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)

Native directional cycle observable:
    H_cycle^dir = product_loop c_pq
    dir_cycle_defect = |1 - H_cycle^dir| * mean(|C_corr| on cycle)
"""
from __future__ import annotations

import json, zipfile, math
from pathlib import Path
from typing import Dict, Tuple, List
import numpy as np
import pandas as pd

ROOT=Path('/mnt/data')
OUT=ROOT/'V1688_59_outputs'
OUT.mkdir(exist_ok=True)
NODE_PATH=ROOT/'V1688_52_outputs'/'V1688_52_node_table.csv'
EDGE_PATH=ROOT/'V1688_52_outputs'/'V1688_52_provenance_edge_table.csv'
CYCLE_PATH=ROOT/'V1688_52_outputs'/'V1688_52_graph_cycle_decomposition.csv'
STATE_COLS=['raw_source','grad_x','grad_y','laplacian']
M0_COLS=['source_abs','access_abs','div_baseline']
TARGET='weak_target'
EPS=1e-12

def roll(v): return np.roll(v,1)
def K(x,y): return roll(x)*y - x*roll(y)
def normalize(v):
    n=float(np.linalg.norm(v))
    return v/(n+EPS), n

def local_components(s: np.ndarray) -> Tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray,int,float]:
    b0,_=normalize(s)
    b1,_=normalize(roll(s))
    o3,_=normalize(K(b0,b1))
    base=np.column_stack([b0,b1,o3])
    h_raw=K(o3, roll(o3))
    h_perp=h_raw - base @ (np.linalg.pinv(base,rcond=1e-10) @ h_raw)
    h_perp,hn=normalize(h_perp)
    G=np.column_stack([b0,b1,o3,h_perp])
    U,S,_=np.linalg.svd(G, full_matrices=False)
    rank=int(np.sum(S>1e-9))
    cond=float(S[0]/S[rank-1]) if rank>0 and S[rank-1]>EPS else float('inf')
    return b0,b1,o3,h_perp,rank,cond

def jacobian_matrix(q_state: np.ndarray, gamma: float):
    d=q_state.size
    R=np.roll(np.eye(d),1,axis=0)
    return np.eye(d) + gamma*(np.diag(q_state)@R - np.diag(roll(q_state)))

def r2(y,yhat):
    y=np.asarray(y,float); yhat=np.asarray(yhat,float)
    return 1 - float(np.sum((y-yhat)**2))/(float(np.sum((y-y.mean())**2))+EPS)

def fit_r2(train,test,cols,target=TARGET):
    Xtr=train[cols].to_numpy(float); Xte=test[cols].to_numpy(float)
    ytr=train[target].to_numpy(float); yte=test[target].to_numpy(float)
    Xtr=np.column_stack([np.ones(len(Xtr)),Xtr]); Xte=np.column_stack([np.ones(len(Xte)),Xte])
    beta=np.linalg.pinv(Xtr,rcond=1e-10)@ytr
    return r2(yte,Xte@beta)

def holdouts(df, group_cols):
    models={
        'M0': M0_COLS,
        'M0_Ccorr': M0_COLS+['C_corr'],
        'M0_exact': M0_COLS+['C_corr','exact_cycle_defect'],
        'M0_native_dir': M0_COLS+['C_corr','native_directional_cycle_defect'],
        'M0_exact_native_dir': M0_COLS+['C_corr','exact_cycle_defect','native_directional_cycle_defect'],
        'M0_native_loop': M0_COLS+['C_corr','native_loop_defect'] if 'native_loop_defect' in df.columns else M0_COLS+['C_corr'],
    }
    rows=[]
    for gc in group_cols:
        vals=sorted(df[gc].dropna().unique(), key=lambda x: str(x))
        for v in vals:
            tr=df[df[gc]!=v]; te=df[df[gc]==v]
            if len(tr)<20 or len(te)<20: continue
            rec={'group_type':gc,'holdout':v,'n_train':len(tr),'n_test':len(te)}
            for name,cols in models.items(): rec['R2_'+name]=fit_r2(tr,te,cols)
            rec['delta_Ccorr']=rec['R2_M0_Ccorr']-rec['R2_M0']
            rec['exact_unique_over_Ccorr']=rec['R2_M0_exact']-rec['R2_M0_Ccorr']
            rec['native_dir_unique_over_Ccorr']=rec['R2_M0_native_dir']-rec['R2_M0_Ccorr']
            rec['native_dir_added_after_exact']=rec['R2_M0_exact_native_dir']-rec['R2_M0_exact']
            rec['native_dir_total_over_M0']=rec['R2_M0_native_dir']-rec['R2_M0']
            rows.append(rec)
    return pd.DataFrame(rows)

def derivation_holdouts(cycles, group_cols):
    cols=['native_directional_cycle_defect','native_directional_holonomy','native_directional_mean_c']
    rows=[]
    for gc in group_cols:
        for v in sorted(cycles[gc].dropna().unique(), key=lambda x: str(x)):
            tr=cycles[cycles[gc]!=v]; te=cycles[cycles[gc]==v]
            if len(tr)<20 or len(te)<20: continue
            rec={'group_type':gc,'holdout':v,'n_train':len(tr),'n_test':len(te)}
            rec['R2_native_dir_to_exact']=fit_r2(tr,te,cols,target='exact_cycle_defect')
            rec['R2_native_dir_to_loss']=fit_r2(tr,te,cols,target='correction_loss')
            rows.append(rec)
    return pd.DataFrame(rows)

def compute(null_mode=None, seed=0):
    rng=np.random.default_rng(seed)
    nodes=pd.read_csv(NODE_PATH)
    edges=pd.read_csv(EDGE_PATH)
    cycles=pd.read_csv(CYCLE_PATH)
    # Preserve target tables but alter only specified native components.
    if null_mode=='gamma_shuffle':
        edges['gamma_used']=rng.permutation(edges['gamma_edge_defect_raw'].to_numpy(float))
    elif null_mode=='gamma_zero_linear_control':
        edges['gamma_used']=0.0
    else:
        edges['gamma_used']=edges['gamma_edge_defect_raw'].astype(float)
    if null_mode=='edge_endpoint_shuffle':
        edges['to_node']=rng.permutation(edges['to_node'].to_numpy())
    if null_mode=='branch_state_shuffle':
        for c in STATE_COLS:
            nodes[c]=rng.permutation(nodes[c].to_numpy(float))
    if null_mode=='correction_direction_shuffle':
        nodes['edge_resid_vs_M0']=rng.permutation(nodes['edge_resid_vs_M0'].to_numpy(float))
        nodes['h4_resid_vs_M0']=rng.permutation(nodes['h4_resid_vs_M0'].to_numpy(float))
    node_ids=nodes.node_id.tolist()
    c_map=dict(zip(nodes.node_id, nodes.C_corr.astype(float)))
    state_map={}
    z_map={}
    rank_map={}; cond_map={}
    # native direction constructed from O3/H4 axes only; B axes define algebra but do not define correction direction.
    for row in nodes.itertuples(index=False):
        s=np.array([getattr(row,c) for c in STATE_COLS], dtype=float)
        b0,b1,o3,h,rank,cond=local_components(s)
        z = float(row.edge_resid_vs_M0)*o3 + float(row.h4_resid_vs_M0)*h
        z,zn=normalize(z)
        if zn < 1e-12: z=np.zeros_like(s)
        state_map[row.node_id]=s; z_map[row.node_id]=z; rank_map[row.node_id]=rank; cond_map[row.node_id]=cond
    edge_scalar={}
    edge_rows=[]
    for row in edges.itertuples(index=False):
        p=row.from_node; q=row.to_node
        if p not in z_map or q not in z_map: continue
        zp=z_map[p]; zq=z_map[q]
        if np.linalg.norm(zp)<EPS or np.linalg.norm(zq)<EPS: continue
        J=jacobian_matrix(state_map[q], float(row.gamma_used))
        tz=J@zp
        denom=float(np.linalg.norm(tz)*np.linalg.norm(zq)+EPS)
        c=float(np.dot(zq,tz)/denom)
        edge_scalar[(p,q)]=c
        edge_rows.append({'from_node':p,'to_node':q,'block_id':row.block_id,'generator_mode':row.generator_mode,'gamma_used':float(row.gamma_used),'native_directional_c':c})
    edge_df=pd.DataFrame(edge_rows)
    cycle_rows=[]
    by_node={nid:[] for nid in node_ids}
    for row in cycles.itertuples(index=False):
        ns=[row.n0,row.n1,row.n2,row.n3,row.n0]
        cs=[]; ok=True
        for a,b in zip(ns[:-1],ns[1:]):
            if (a,b) not in edge_scalar: ok=False; break
            cs.append(edge_scalar[(a,b)])
        if not ok: continue
        hol=float(np.prod(cs))
        vals=[abs(c_map[n]) for n in ns[:-1]]
        # Uses only emitted C_corr scale on the cycle, as exact scalar cycle did.
        mean_abs_c=float(np.mean(vals))
        d=float(abs(1-hol)*mean_abs_c)
        rec={'generator_mode':row.generator_mode,'block_id':row.block_id,'family': str(row.block_id).split('_')[1] if '_' in str(row.block_id) else None,
             'cycle_id':row.cycle_id,'n0':row.n0,'n1':row.n1,'n2':row.n2,'n3':row.n3,
             'native_directional_holonomy':hol,'native_directional_cycle_defect':d,
             'native_directional_mean_c':float(np.mean(cs)), 'native_directional_min_c':float(np.min(cs)),
             'mean_abs_C':mean_abs_c,
             'exact_cycle_defect':row.exact_cycle_defect,'correction_loss':row.correction_loss,'combined_cycle_signal':row.combined_cycle_signal}
        # family/res/seed/gen from n0 lookup later easier by node table map
        cycle_rows.append(rec)
        for n in ns[:-1]: by_node[n].append(d)
    cycle_df=pd.DataFrame(cycle_rows)
    nodes['G_rank']=nodes.node_id.map(rank_map).astype(float)
    nodes['G_condition']=nodes.node_id.map(cond_map).astype(float)
    nodes['native_directional_cycle_defect']=[float(np.mean(by_node[n])) if by_node[n] else 0.0 for n in node_ids]
    nodes['native_directional_cycle_incident_count']=[len(by_node[n]) for n in node_ids]
    # include old native loop from V55 if available for comparison
    old_path=ROOT/'V1688_55_outputs'/'V1688_55_native_node_table.csv'
    if old_path.exists() and null_mode is None:
        old=pd.read_csv(old_path, usecols=['node_id','native_loop_defect','native_inverse_defect'])
        nodes=nodes.merge(old, on='node_id', how='left')
    # Add metadata to cycle rows by joining n0 node metadata
    meta_cols=['node_id','family','resolution','seed']
    nmeta=nodes[meta_cols].rename(columns={'node_id':'n0'})
    if len(cycle_df):
        cycle_df=cycle_df.merge(nmeta,on='n0',how='left', suffixes=('', '_node'))
        if 'family_node' in cycle_df.columns:
            cycle_df['family']=cycle_df['family'].fillna(cycle_df['family_node']) if 'family' in cycle_df.columns else cycle_df['family_node']
            cycle_df=cycle_df.drop(columns=[c for c in ['family_node'] if c in cycle_df.columns])
    meta={'null_mode':null_mode or 'observed','nodes':int(len(nodes)),'edges_input':int(len(edges)),'edge_scalars':int(len(edge_df)),'cycles_input':int(len(cycles)),'cycles_composed':int(len(cycle_df)),
          'mean_rank':float(nodes.G_rank.mean()),'mean_condition':float(nodes.G_condition.replace([np.inf,-np.inf],np.nan).mean()),
          'mean_native_directional_defect':float(cycle_df.native_directional_cycle_defect.mean()) if len(cycle_df) else None}
    return nodes, edge_df, cycle_df, meta

def main():
    nodes, edge_df, cycles, meta=compute(None,168859)
    nodes.to_csv(OUT/'V1688_59_node_native_directional_observables.csv', index=False)
    edge_df.to_csv(OUT/'V1688_59_edge_native_directional_scalars.csv', index=False)
    cycles.to_csv(OUT/'V1688_59_cycle_native_directional_observables.csv', index=False)
    model_df=nodes[nodes.native_directional_cycle_incident_count>0].copy()
    hold=holdouts(model_df,['generator_mode','family','resolution','seed'])
    hold.to_csv(OUT/'V1688_59_weakform_directional_holdouts.csv', index=False)
    deriv=derivation_holdouts(cycles,['generator_mode','family','resolution','seed'])
    deriv.to_csv(OUT/'V1688_59_directional_derivation_holdouts.csv', index=False)
    # correlations
    corr_cols=['native_directional_cycle_defect','native_directional_holonomy','native_directional_mean_c','exact_cycle_defect','correction_loss','combined_cycle_signal']
    corr=cycles[corr_cols].corr(numeric_only=True).reset_index().rename(columns={'index':'feature'})
    corr.to_csv(OUT/'V1688_59_cycle_correlation_diagnostics.csv', index=False)
    null_modes=['gamma_shuffle','edge_endpoint_shuffle','branch_state_shuffle','correction_direction_shuffle','gamma_zero_linear_control']
    null_rows=[]
    for i,m in enumerate(null_modes):
        nn,_,_,nm=compute(m,900+i)
        ndf=nodes.copy()
        ndf['native_directional_cycle_defect']=nn['native_directional_cycle_defect'].to_numpy(float)
        ndf=ndf[ndf.native_directional_cycle_incident_count>0].copy()
        nh=holdouts(ndf,['generator_mode','family','resolution','seed'])
        null_rows.append({'null_mode':m,'mean_native_dir_unique_over_Ccorr':float(nh.native_dir_unique_over_Ccorr.mean()),
                          'mean_native_dir_added_after_exact':float(nh.native_dir_added_after_exact.mean()),
                          'positive_unique_rate':float((nh.native_dir_unique_over_Ccorr>0).mean()),
                          'rows':int(len(nh)),'cycles_composed':nm['cycles_composed']})
    nulls=pd.DataFrame(null_rows)
    nulls.to_csv(OUT/'V1688_59_directional_null_results.csv', index=False)
    # resolution summary
    res=hold[hold.group_type=='resolution'].groupby('holdout').agg(
        mean_R2_M0=('R2_M0','mean'), mean_R2_Ccorr=('R2_M0_Ccorr','mean'),
        mean_exact_unique=('exact_unique_over_Ccorr','mean'), mean_native_dir_unique=('native_dir_unique_over_Ccorr','mean'),
        mean_native_dir_added_after_exact=('native_dir_added_after_exact','mean')).reset_index().rename(columns={'holdout':'resolution_holdout'})
    res.to_csv(OUT/'V1688_59_resolution_directional_results.csv', index=False)
    mean_native=float(hold.native_dir_unique_over_Ccorr.mean())
    mean_added=float(hold.native_dir_added_after_exact.mean())
    mean_exact=float(hold.exact_unique_over_Ccorr.mean())
    pos=float((hold.native_dir_unique_over_Ccorr>0).mean())
    crit=float(nulls.mean_native_dir_unique_over_Ccorr.max())
    margin=mean_native-crit
    deriv_mean=float(deriv.R2_native_dir_to_exact.mean())
    corr_exact=float(cycles[['native_directional_cycle_defect','exact_cycle_defect']].corr().iloc[0,1])
    # Verdict
    if deriv_mean>0 and mean_native>0 and margin>0 and mean_added>=0:
        verdict='NATIVE_DIRECTIONAL_OBSERVABLE_PASS'
    elif deriv_mean>0 or mean_native>0:
        verdict='PARTIAL_NATIVE_DIRECTIONAL_OBSERVABLE_SIGNAL_NOT_CLOSED'
    else:
        verdict='NATIVE_DIRECTIONAL_OBSERVABLE_DERIVATION_FAIL'
    summary={'document_id':'V1688_59_NATIVE_DIRECTIONAL_OBSERVABLE_MISMATCH_AUDIT','verdict':verdict,
             'first_principles_constraints':{'no_kabsch':True,'no_procrustes':True,'no_gramian_transport':True,'no_fitted_counterterm':True,'no_time_primitive':True},
             'definition':{'Z_p':'unit(edge_resid_vs_M0*O3_p + h4_resid_vs_M0*H4_perp_p)',
                           'c_pq':'<Z_q,T_pq Z_p>/(||T_pq Z_p||||Z_q||)',
                           'cycle_defect':'|1-prod(c_pq)|*mean(|C_corr|)'},
             'meta':meta,
             'model_results':{'mean_R2_M0':float(hold.R2_M0.mean()),'mean_R2_M0_Ccorr':float(hold.R2_M0_Ccorr.mean()),
                              'mean_R2_M0_exact':float(hold.R2_M0_exact.mean()),'mean_R2_M0_native_dir':float(hold.R2_M0_native_dir.mean()),
                              'mean_exact_unique_over_Ccorr':mean_exact,'mean_native_dir_unique_over_Ccorr':mean_native,
                              'mean_native_dir_added_after_exact':mean_added,'positive_native_dir_unique_rate':pos},
             'derivation':{'mean_R2_native_dir_to_exact_cycle_defect':deriv_mean,
                           'mean_R2_native_dir_to_correction_loss':float(deriv.R2_native_dir_to_loss.mean()),
                           'cycle_corr_native_dir_exact':corr_exact},
             'nulls':{'critical_null_max_mean_native_dir_unique':crit,'observed_minus_critical_null_margin':margin,'null_modes':null_rows},
             'claim_boundary':'Finite retained-flow emitted-ledger harness; not ADM/GR/Riemann/Einstein/physical spacetime closure.',
             'next':'V1688.60 depends on verdict: if pass, harden native directional scalar under cycle-basis/subdivision; if fail/partial, freeze scalar exact-cycle defect as empirical observable pending richer native observable derivation.'}
    (OUT/'V1688_59_SUMMARY.json').write_text(json.dumps(summary,indent=2))
    report=f"""# V1688.59 — Native Directional Observable Mismatch Audit

## Verdict

```text
{verdict}
```

## Purpose

V1688.57 showed that full native matrix invariants — Frobenius, determinant, trace — did not derive the surviving scalar exact-cycle defect. V1688.58 showed that this was not because `G_p` failed operator closure.

V1688.59 therefore tested the next first-principles possibility: the surviving scalar cycle defect may be a **directional observable** of native transport, not a full-matrix observable.

## First-principles constraints

```text
No Kabsch / Procrustes / Gramian transport
No fitted counterterm
No threshold patch
No time primitive
No external geometry imposed as law
```

## Native directional observable

The local correction direction was defined inside the frozen generated algebra:

```text
Z_p = unit(edge_resid_vs_M0 · O3_p + h4_resid_vs_M0 · H4_perp_p)
```

Native transport remained the recombination Jacobian:

```text
T_pq(dx) = dx + gamma_pq · [roll(dx) ⊙ q - dx ⊙ roll(q)]
```

Directional edge scalar:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
```

Directional cycle observable:

```text
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 - H_cycle^dir| · mean(|C_corr|)
```

## Ledger scale

```text
nodes:           {meta['nodes']}
edges input:     {meta['edges_input']}
edge scalars:    {meta['edge_scalars']}
cycles input:    {meta['cycles_input']}
cycles composed: {meta['cycles_composed']}
mean rank(G_p):  {meta['mean_rank']:.6f}
mean cond(G_p):  {meta['mean_condition']:.6f}
```

## Derivation test

```text
mean R²(native directional observables → exact_cycle_defect): {deriv_mean:+.6f}
cycle corr(native_directional_defect, exact_cycle_defect):    {corr_exact:+.6f}
```

## Weak-form explanatory test

Mean group-holdout results:

```text
R² M0:                         {summary['model_results']['mean_R2_M0']:+.6f}
R² M0 + C_corr:                {summary['model_results']['mean_R2_M0_Ccorr']:+.6f}
R² M0 + C_corr + exact:        {summary['model_results']['mean_R2_M0_exact']:+.6f}
R² M0 + C_corr + native_dir:   {summary['model_results']['mean_R2_M0_native_dir']:+.6f}

exact unique over C_corr:      {mean_exact:+.6f}
native_dir unique over Ccorr:  {mean_native:+.6f}
native_dir added after exact:  {mean_added:+.6f}
positive native_dir rate:      {pos:.6f}
```

## Nulls

```text
critical null max native-dir unique: {crit:+.6f}
observed-null margin:               {margin:+.6f}
```

{nulls.to_markdown(index=False)}

## Interpretation

This test asks whether the scalar exact-cycle defect can be understood as the action of native recombination transport on the correction direction itself.

The bounded result is captured by the verdict above. If the directional observable explains exact-cycle defect and improves weak-form residual beyond `C_corr` while clearing nulls, it becomes the preferred native scalar observable. If not, the scalar exact-cycle defect remains a surviving empirical compatibility observable that has not yet been derived from the current native transport representation.

## Claim boundary

This is a finite retained-flow emitted-ledger harness result. It is not an ADM derivation, GR closure, Riemann curvature result, Einstein equation result, or physical spacetime claim.
"""
    (OUT/'V1688_59_NATIVE_DIRECTIONAL_OBSERVABLE_MISMATCH_AUDIT_REPORT.md').write_text(report)
    zip_path=ROOT/'V1688_59_native_directional_observable_mismatch_audit_package.zip'
    files=[Path(__file__),OUT/'V1688_59_NATIVE_DIRECTIONAL_OBSERVABLE_MISMATCH_AUDIT_REPORT.md',OUT/'V1688_59_SUMMARY.json',
           OUT/'V1688_59_node_native_directional_observables.csv',OUT/'V1688_59_edge_native_directional_scalars.csv',OUT/'V1688_59_cycle_native_directional_observables.csv',OUT/'V1688_59_weakform_directional_holdouts.csv',OUT/'V1688_59_directional_derivation_holdouts.csv',OUT/'V1688_59_cycle_correlation_diagnostics.csv',OUT/'V1688_59_directional_null_results.csv',OUT/'V1688_59_resolution_directional_results.csv']
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for f in files: z.write(f,arcname=f.relative_to(ROOT))
    print(json.dumps(summary,indent=2))
    print(zip_path)
if __name__=='__main__': main()
