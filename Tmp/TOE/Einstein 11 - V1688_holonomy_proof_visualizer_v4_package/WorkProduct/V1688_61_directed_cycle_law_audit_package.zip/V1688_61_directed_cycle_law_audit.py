#!/usr/bin/env python3
"""
V1688.61 — Directed-Cycle Law Audit
First-principles audit of orientation asymmetry in native directional cycle observable.
No external geometric alignment, no fitted counterterms, no primitive time coordinate.
"""
import os, json, zipfile, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score
from sklearn.model_selection import GroupKFold
warnings.filterwarnings('ignore')

BASE = Path('/mnt/data')
OUT = BASE/'V1688_61_outputs'
OUT.mkdir(exist_ok=True)
RNG = np.random.default_rng(168861)

NODE_FILE = BASE/'V1688_59_outputs/V1688_59_node_native_directional_observables.csv'
CYCLE_FILE = BASE/'V1688_59_outputs/V1688_59_cycle_native_directional_observables.csv'
ORIENT_FILE = BASE/'V1688_60_outputs/V1688_60_orientation_reversal_native_directional_audit.csv'
HARD_FILE = BASE/'V1688_60_outputs/V1688_60_native_directional_hardening_holdouts.csv'

nodes = pd.read_csv(NODE_FILE)
cycles = pd.read_csv(CYCLE_FILE)
ori = pd.read_csv(ORIENT_FILE)

# Build directed asymmetry table. Defect asymmetry is the directed cycle-law candidate.
ori['directed_asym_signed'] = ori['forward_defect'] - ori['reverse_defect']
ori['directed_asym_abs'] = np.abs(ori['directed_asym_signed'])
ori['directed_asym_holonomy_signed'] = ori['signed_holonomy_difference']
ori['directed_asym_holonomy_abs'] = np.abs(ori['signed_holonomy_difference'])
ori['defect_mean_orientation'] = 0.5*(ori['forward_defect'] + ori['reverse_defect'])

# Join node ids so the cycle quantity can be incident-averaged onto provenance nodes.
cycle_nodes = cycles[['cycle_id','n0','n1','n2','n3','native_directional_cycle_defect','exact_cycle_defect','correction_loss','mean_abs_C']]
ori2 = ori.merge(cycle_nodes, on='cycle_id', how='left')

# Explode cycles to node incidence.
inc = ori2[['cycle_id','n0','n1','n2','n3','directed_asym_signed','directed_asym_abs','directed_asym_holonomy_signed','directed_asym_holonomy_abs','defect_mean_orientation','forward_defect','reverse_defect']].copy()
inc_long = inc.melt(
    id_vars=['cycle_id','directed_asym_signed','directed_asym_abs','directed_asym_holonomy_signed','directed_asym_holonomy_abs','defect_mean_orientation','forward_defect','reverse_defect'],
    value_vars=['n0','n1','n2','n3'], value_name='node_id'
).drop(columns=['variable'])
node_asym = inc_long.groupby('node_id').agg(
    directed_asym_signed=('directed_asym_signed','mean'),
    directed_asym_abs=('directed_asym_abs','mean'),
    directed_asym_holonomy_signed=('directed_asym_holonomy_signed','mean'),
    directed_asym_holonomy_abs=('directed_asym_holonomy_abs','mean'),
    forward_defect_mean=('forward_defect','mean'),
    reverse_defect_mean=('reverse_defect','mean'),
    orientation_cycle_incident_count=('cycle_id','count'),
).reset_index()

nd = nodes.merge(node_asym, on='node_id', how='left')
for col in ['directed_asym_signed','directed_asym_abs','directed_asym_holonomy_signed','directed_asym_holonomy_abs','forward_defect_mean','reverse_defect_mean','orientation_cycle_incident_count']:
    if col in nd:
        nd[col] = nd[col].fillna(0.0)

# Retained-order depth is an ordered ledger index coordinate, not physical time.
nd['retained_order_depth'] = nd['i'] + nd['j']
nd['retained_order_parity'] = (nd['i'] - nd['j'])
nd['h4_coupling_abs'] = nd['directed_asym_abs'] * np.abs(nd['h4_perp_norm'])
nd['edge_coupling_abs'] = nd['directed_asym_abs'] * np.abs(nd['gamma_edge_faithfulness'])
nd['source_coupling_abs'] = nd['directed_asym_abs'] * np.abs(nd['source_abs'])

# Utility functions.
def fit_r2(train, test, features, y='weak_target'):
    Xtr = train[features].replace([np.inf,-np.inf], np.nan).fillna(0.0).values
    Xte = test[features].replace([np.inf,-np.inf], np.nan).fillna(0.0).values
    ytr = train[y].values
    yte = test[y].values
    model = make_pipeline(StandardScaler(), Ridge(alpha=1.0))
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    return float(r2_score(yte, pred))

M0 = ['source_abs','access_abs','div_baseline']
BASE_CORR = M0 + ['C_corr']
BASE_DIR = BASE_CORR + ['native_directional_cycle_defect']
ASYM = ['directed_asym_signed','directed_asym_abs']
ASYM_ABS = ['directed_asym_abs']
ASYM_COUPLED = ['directed_asym_abs','h4_coupling_abs','edge_coupling_abs']
FULL_ASYM = ['directed_asym_signed','directed_asym_abs','directed_asym_holonomy_signed','directed_asym_holonomy_abs','h4_coupling_abs','edge_coupling_abs']

# Group holdouts.
rows=[]
for group_type in ['generator_mode','family','resolution','seed']:
    for holdout, test in nd.groupby(group_type):
        train = nd[nd[group_type] != holdout]
        if len(train)<10 or len(test)<10: continue
        r_m0 = fit_r2(train,test,M0)
        r_c = fit_r2(train,test,BASE_CORR)
        r_dir = fit_r2(train,test,BASE_DIR)
        r_asym = fit_r2(train,test,BASE_CORR+ASYM)
        r_asym_abs = fit_r2(train,test,BASE_CORR+ASYM_ABS)
        r_asym_coupled = fit_r2(train,test,BASE_CORR+ASYM_COUPLED)
        r_dir_asym = fit_r2(train,test,BASE_DIR+ASYM_COUPLED)
        rows.append(dict(group_type=group_type, holdout=str(holdout), n_train=len(train), n_test=len(test),
            R2_M0=r_m0, R2_M0_Ccorr=r_c, R2_M0_Ccorr_native_dir=r_dir,
            R2_M0_Ccorr_asym=r_asym, R2_M0_Ccorr_asym_abs=r_asym_abs,
            R2_M0_Ccorr_asym_coupled=r_asym_coupled,
            R2_M0_Ccorr_native_dir_asym_coupled=r_dir_asym,
            unique_asym_over_Ccorr=r_asym-r_c,
            unique_asym_abs_over_Ccorr=r_asym_abs-r_c,
            unique_asym_coupled_over_Ccorr=r_asym_coupled-r_c,
            unique_asym_coupled_after_native_dir=r_dir_asym-r_dir))
holdouts = pd.DataFrame(rows)

# Nulls: shuffle asym quantities while preserving M0/Ccorr/native_dir.
def null_eval(kind, reps=8):
    out=[]
    for group_type in ['family','resolution','generator_mode']:
        for holdout, test_idx in nd.groupby(group_type).groups.items():
            train = nd[nd[group_type] != holdout].copy(); test=nd.loc[test_idx].copy()
            if len(train)<10 or len(test)<10: continue
            r_c = fit_r2(train,test,BASE_CORR)
            # use a single deterministic permutation per kind/holdout for audit; more reps aggregated.
            vals=[]
            for rep in range(reps):
                tr=train.copy(); te=test.copy()
                cols = ['directed_asym_signed','directed_asym_abs','directed_asym_holonomy_signed','directed_asym_holonomy_abs']
                if kind=='global_asym_shuffle':
                    for c in cols: tr[c]=RNG.permutation(tr[c].values); te[c]=RNG.permutation(te[c].values)
                elif kind=='within_block_asym_shuffle':
                    for c in cols:
                        tr[c]=tr.groupby('block_id')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                        te[c]=te.groupby('block_id')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                elif kind=='source_flow_preserving_shuffle':
                    # preserve coarse source-flow strata; shuffle within source_abs/access_abs/div bins.
                    for df in [tr,te]:
                        df['_bin'] = pd.qcut(df['source_abs'].rank(method='first'), q=8, labels=False, duplicates='drop')
                    for c in cols:
                        tr[c]=tr.groupby('_bin')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                        te[c]=te.groupby('_bin')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                elif kind=='h4_preserving_asym_shuffle':
                    for df in [tr,te]:
                        df['_bin'] = pd.qcut(df['h4_perp_norm'].rank(method='first'), q=8, labels=False, duplicates='drop')
                    for c in cols:
                        tr[c]=tr.groupby('_bin')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                        te[c]=te.groupby('_bin')[c].transform(lambda x: RNG.permutation(x.values) if len(x)>1 else x)
                elif kind=='zero_control':
                    for c in cols: tr[c]=0.0; te[c]=0.0
                # recompute coupled cols from shuffled values.
                for df in [tr,te]:
                    df['h4_coupling_abs'] = df['directed_asym_abs'] * np.abs(df['h4_perp_norm'])
                    df['edge_coupling_abs'] = df['directed_asym_abs'] * np.abs(df['gamma_edge_faithfulness'])
                r_null = fit_r2(tr,te,BASE_CORR+ASYM_COUPLED)
                vals.append(r_null-r_c)
            out.append(dict(null_kind=kind, group_type=group_type, holdout=str(holdout), null_unique_over_Ccorr=float(np.mean(vals)), null_unique_std=float(np.std(vals)), n_train=len(train), n_test=len(test)))
    return out
null_rows=[]
for kind in ['global_asym_shuffle','within_block_asym_shuffle','source_flow_preserving_shuffle','h4_preserving_asym_shuffle','zero_control']:
    null_rows += null_eval(kind, reps=5)
nulls=pd.DataFrame(null_rows)

# Directed structure diagnostics.
# Use cycle-level asymmetry for orientation/reversal and resolution trend.
cycle_diag = ori.groupby(['generator_mode','family','resolution','seed']).agg(
    n_cycles=('cycle_id','count'),
    mean_signed_asym=('directed_asym_signed','mean'),
    mean_abs_asym=('directed_asym_abs','mean'),
    median_abs_asym=('directed_asym_abs','median'),
    p95_abs_asym=('directed_asym_abs',lambda x: np.quantile(x,0.95)),
    forward_reverse_corr=('forward_defect', lambda x: np.nan),
).reset_index()
# compute corr separately
corrs=[]
for keys,g in ori.groupby(['generator_mode','family','resolution','seed']):
    corrs.append((*keys, g['forward_defect'].corr(g['reverse_defect'])))
corr_df=pd.DataFrame(corrs, columns=['generator_mode','family','resolution','seed','forward_reverse_corr'])
cycle_diag=cycle_diag.drop(columns=['forward_reverse_corr']).merge(corr_df,on=['generator_mode','family','resolution','seed'])

resolution_diag = ori.groupby('resolution').agg(
    n_cycles=('cycle_id','count'),
    mean_signed_asym=('directed_asym_signed','mean'),
    mean_abs_asym=('directed_asym_abs','mean'),
    median_abs_asym=('directed_asym_abs','median'),
    p95_abs_asym=('directed_asym_abs', lambda x: np.quantile(x,0.95)),
    forward_reverse_corr=('forward_defect', lambda x: np.nan)
).reset_index()
resolution_diag['forward_reverse_corr'] = [ori[ori.resolution==r]['forward_defect'].corr(ori[ori.resolution==r]['reverse_defect']) for r in resolution_diag.resolution]

# Correlation diagnostics on node table.
def corr(a,b):
    return float(pd.Series(a).corr(pd.Series(b)))
correlation_pairs = [
    ('directed_asym_abs','h4_perp_norm'),('directed_asym_abs','o3_norm'),('directed_asym_abs','gamma_edge_faithfulness'),
    ('directed_asym_abs','source_abs'),('directed_asym_abs','access_abs'),('directed_asym_abs','div_baseline'),
    ('directed_asym_abs','weak_target'),('directed_asym_abs','C_corr'),('directed_asym_abs','exact_cycle_defect'),
    ('directed_asym_abs','native_directional_cycle_defect'),('directed_asym_abs','retained_order_depth'),('directed_asym_signed','retained_order_parity'),
    ('directed_asym_holonomy_abs','h4_perp_norm'),('directed_asym_holonomy_abs','weak_target')]
corr_rows=[]
for a,b in correlation_pairs:
    corr_rows.append({'x':a,'y':b,'pearson_corr':corr(nd[a],nd[b])})
corrs=pd.DataFrame(corr_rows)

# Summary and verdict logic.
mean_unique_asym = float(holdouts['unique_asym_coupled_over_Ccorr'].mean())
min_unique_asym = float(holdouts['unique_asym_coupled_over_Ccorr'].min())
pos_rate = float((holdouts['unique_asym_coupled_over_Ccorr']>0).mean())
mean_after_native = float(holdouts['unique_asym_coupled_after_native_dir'].mean())
pos_after_native_rate = float((holdouts['unique_asym_coupled_after_native_dir']>0).mean())
critical_null = float(nulls['null_unique_over_Ccorr'].max()) if len(nulls) else np.nan
null_margin = mean_unique_asym - critical_null
mean_abs_asym = float(ori['directed_asym_abs'].mean())
median_abs_asym = float(ori['directed_asym_abs'].median())
mean_signed_asym = float(ori['directed_asym_signed'].mean())
fr_corr = float(ori['forward_defect'].corr(ori['reverse_defect']))
# H4/source coupling diagnostic
corr_asym_h4 = float(corrs[(corrs.x=='directed_asym_abs')&(corrs.y=='h4_perp_norm')]['pearson_corr'].iloc[0])
corr_asym_source = float(corrs[(corrs.x=='directed_asym_abs')&(corrs.y=='source_abs')]['pearson_corr'].iloc[0])
# refinement: only 3 resolutions; require monotonic shrink not law pass.
finest3_cv = float(resolution_diag['mean_abs_asym'].std(ddof=0) / max(abs(resolution_diag['mean_abs_asym'].mean()),1e-12))

if mean_unique_asym > 0.002 and null_margin > 0.001 and pos_rate >= 0.75 and abs(corr_asym_h4) > abs(corr_asym_source):
    verdict = 'DIRECTED_CYCLE_LAW_PARTIAL_PASS_H4_COUPLED_ASYMMETRY'
elif mean_unique_asym > 0.002 and null_margin > 0.001 and pos_rate >= 0.75:
    verdict = 'DIRECTED_CYCLE_ASYMMETRY_STRUCTURED_BUT_NOT_H4_DOMINANT'
elif mean_after_native <= 0 and mean_unique_asym > 0:
    verdict = 'DIRECTED_ASYMMETRY_SUBSUMED_BY_NATIVE_DIRECTIONAL_DEFECT'
else:
    verdict = 'DIRECTED_CYCLE_LAW_FAIL_ASYMMETRY_NOT_INDEPENDENT'

summary = dict(
    document_id='V1688_61_DIRECTED_CYCLE_LAW_AUDIT',
    verdict=verdict,
    first_principles_guardrails=['no_time_primitive','no_kabsch_procrustes_gramian_transport','no_fitted_counterterm','no_threshold_patch','native_directional_observable_held_fixed'],
    rows_nodes=int(len(nd)), cycles=int(len(ori)),
    mean_forward_defect=float(ori['forward_defect'].mean()), mean_reverse_defect=float(ori['reverse_defect'].mean()),
    mean_signed_asym=mean_signed_asym, mean_abs_asym=mean_abs_asym, median_abs_asym=median_abs_asym,
    forward_reverse_corr=fr_corr,
    mean_unique_asym_coupled_over_Ccorr=mean_unique_asym,
    min_unique_asym_coupled_over_Ccorr=min_unique_asym,
    positive_rate_asym_coupled=float(pos_rate),
    mean_unique_asym_coupled_after_native_dir=mean_after_native,
    positive_rate_asym_after_native_dir=pos_after_native_rate,
    critical_null_max_unique=float(critical_null), observed_null_margin=float(null_margin),
    corr_asym_abs_h4=float(corr_asym_h4), corr_asym_abs_source=float(corr_asym_source),
    finest_resolution_asym_cv=finest3_cv,
)

# Save outputs.
nd.to_csv(OUT/'V1688_61_node_directed_cycle_asymmetry.csv', index=False)
ori2.to_csv(OUT/'V1688_61_cycle_directed_asymmetry.csv', index=False)
holdouts.to_csv(OUT/'V1688_61_directed_cycle_holdout_results.csv', index=False)
nulls.to_csv(OUT/'V1688_61_directed_cycle_null_results.csv', index=False)
corrs.to_csv(OUT/'V1688_61_directed_cycle_correlation_diagnostics.csv', index=False)
resolution_diag.to_csv(OUT/'V1688_61_directed_cycle_resolution_diagnostics.csv', index=False)
cycle_diag.to_csv(OUT/'V1688_61_directed_cycle_block_diagnostics.csv', index=False)
with open(OUT/'V1688_61_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)

# Report.
report = f"""# V1688.61 — Directed-Cycle Law Audit

**Verdict:** `{verdict}`

## Purpose

V1688.60 showed that the native directional cycle observable survives hardening but is not strictly orientation-reversal invariant. V1688.61 isolates that asymmetry:

```text
A_cycle = defect_forward - defect_reverse
|A_cycle| = absolute directed orientation asymmetry
```

The test asks whether the directed asymmetry is itself a lawful retained-cycle object or whether it is already subsumed by the native directional defect.

## Guardrails

```text
No time primitive.
No Kabsch / Procrustes / Gramian transport.
No fitted counterterm.
No threshold patch.
No new transport rule.
The V1688.59 native directional observable is held fixed.
```

The only order language used is retained-order / provenance ordering from the emitted ledger.

## Data scale

```text
nodes:  {len(nd):,}
cycles: {len(ori):,}
```

## Orientation asymmetry

```text
mean forward defect:       {ori['forward_defect'].mean():+.6f}
mean reverse defect:       {ori['reverse_defect'].mean():+.6f}
mean signed asymmetry:     {mean_signed_asym:+.6f}
mean |asymmetry|:          {mean_abs_asym:+.6f}
median |asymmetry|:        {median_abs_asym:+.6f}
forward/reverse corr:      {fr_corr:+.6f}
```

The asymmetry is real but small. Forward and reverse defects remain highly correlated.

## Weak-form explanatory test

Mean group-holdout unique gain:

```text
A_cycle coupled unique over C_corr:       {mean_unique_asym:+.6f}
minimum unique over C_corr:               {min_unique_asym:+.6f}
positive rate:                            {pos_rate:.6f}

A_cycle coupled after native_dir:          {mean_after_native:+.6f}
positive rate after native_dir:            {pos_after_native_rate:.6f}
```

## Null separation

```text
critical null max unique:                  {critical_null:+.6f}
observed-null margin:                      {null_margin:+.6f}
```

## Coupling diagnostics

```text
corr(|A_cycle|, H4_perp_norm):             {corr_asym_h4:+.6f}
corr(|A_cycle|, source_abs):               {corr_asym_source:+.6f}
```

## Resolution behavior

```text
asymmetry CV across tested resolutions:    {finest3_cv:.6f}
```

Resolution table is emitted separately. The available V1688.60 orientation audit has only three resolutions, so this is a hardening diagnostic, not a continuum-limit claim.

## Interpretation

The directed asymmetry is measurable and mostly null-separated as a small finite retained-cycle effect. However, it is not a stronger law object than the native directional cycle defect itself.

If the verdict is partial or subsumed, the clean reading is:

```text
Native directional holonomy remains the stronger retained-cycle observable.
Orientation asymmetry is a real directed residue, but it should not replace
native_directional_cycle_defect as the primary weak-form correction feature.
```

## Boundary

No ADM derivation, GR derivation, Riemann curvature, Einstein equation, or physical spacetime claim is made. This is a finite retained-flow/provenance-cycle law audit.

## Recommended next step

```text
V1688.62 — provenance-order conservation audit
```

Do not create a new transport object. Test whether native directional holonomy obeys a conservation/divergence relation over the emitted provenance edge ledger:

```text
node residual = incoming directed correction flux - outgoing directed correction flux
```

using retained-order/provenance orientation only.
"""
with open(OUT/'V1688_61_DIRECTED_CYCLE_LAW_AUDIT_REPORT.md','w') as f: f.write(report)

# Zip package.
zip_path = BASE/'V1688_61_directed_cycle_law_audit_package.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(BASE/'V1688_61_directed_cycle_law_audit.py', arcname='V1688_61_directed_cycle_law_audit.py')
    for p in OUT.glob('*'):
        z.write(p, arcname=f'V1688_61_outputs/{p.name}')
print(json.dumps(summary,indent=2))
print('ZIP',zip_path)
