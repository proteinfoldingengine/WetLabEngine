# V1688.61 — Directed-Cycle Law Audit

**Verdict:** `DIRECTED_CYCLE_LAW_FAIL_ASYMMETRY_NOT_INDEPENDENT`

## Purpose

V1688.60 showed that the native directional cycle observable survives hardening but is not strictly orientation-reversal invariant. V1688.61 isolates that asymmetry:

```text
A_cycle = defect_forward - defect_reverse
|A_cycle| = absolute directed orientation asymmetry
```

The test asks whether the directed asymmetry is itself a lawful retained-cycle object or whether it is already subsumed by the native directional defect.

## Guardrails

```text
No time primitive.
No Kabsch / Procrustes / Gramian transport.
No fitted counterterm.
No threshold patch.
No new transport rule.
The V1688.59 native directional observable is held fixed.
```

The only order language used is retained-order / provenance ordering from the emitted ledger.

## Data scale

```text
nodes:  29,696
cycles: 27,440
```

## Orientation asymmetry

```text
mean forward defect:       +0.603092
mean reverse defect:       +0.603262
mean signed asymmetry:     -0.000170
mean |asymmetry|:          +0.013922
median |asymmetry|:        +0.004878
forward/reverse corr:      +0.996594
```

The asymmetry is real but small. Forward and reverse defects remain highly correlated.

## Weak-form explanatory test

Mean group-holdout unique gain:

```text
A_cycle coupled unique over C_corr:       +0.046157
minimum unique over C_corr:               +0.016660
positive rate:                            1.000000

A_cycle coupled after native_dir:          +0.029749
positive rate after native_dir:            1.000000
```

## Null separation

```text
critical null max unique:                  +0.045425
observed-null margin:                      +0.000733
```

## Coupling diagnostics

```text
corr(|A_cycle|, H4_perp_norm):             +0.126060
corr(|A_cycle|, source_abs):               +0.124407
```

## Resolution behavior

```text
asymmetry CV across tested resolutions:    0.330653
```

Resolution table is emitted separately. The available V1688.60 orientation audit has only three resolutions, so this is a hardening diagnostic, not a continuum-limit claim.

## Interpretation

The directed asymmetry is measurable and mostly null-separated as a small finite retained-cycle effect. However, it is not a stronger law object than the native directional cycle defect itself.

If the verdict is partial or subsumed, the clean reading is:

```text
Native directional holonomy remains the stronger retained-cycle observable.
Orientation asymmetry is a real directed residue, but it should not replace
native_directional_cycle_defect as the primary weak-form correction feature.
```

## Boundary

No ADM derivation, GR derivation, Riemann curvature, Einstein equation, or physical spacetime claim is made. This is a finite retained-flow/provenance-cycle law audit.

## Recommended next step

```text
V1688.62 — provenance-order conservation audit
```

Do not create a new transport object. Test whether native directional holonomy obeys a conservation/divergence relation over the emitted provenance edge ledger:

```text
node residual = incoming directed correction flux - outgoing directed correction flux
```

using retained-order/provenance orientation only.
