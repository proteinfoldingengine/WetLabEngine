#!/usr/bin/env python3
"""
V1688.69 Live-Ledger Contract Validator and Transfer Skeleton
First-principles only: validates live V1687 ordered-slice ledger inputs and stops unless the required ledger objects are present.

Usage:
  python V1688_69_live_ledger_validator.py --nodes nodes.csv --edges edges.csv --cycles cycles.csv --outdir V1688_69_live_transfer_outputs
"""
import argparse, json, math, os, sys
from pathlib import Path
import numpy as np
import pandas as pd

NODE_REQUIRED = ['node_id','sector_id','retained_order_index','source_abs','access_abs','div_baseline','weak_target']
EDGE_REQUIRED = ['from_node','to_node','gamma_pq']
VECTOR_COLS = ['B_vec','O3_vec','H4_perp_vec']


def parse_vec(x):
    if isinstance(x, (list, tuple, np.ndarray)):
        return np.array(x, dtype=float)
    if pd.isna(x):
        raise ValueError('empty vector')
    s=str(x).strip()
    if s.startswith('['):
        return np.array(json.loads(s), dtype=float)
    # support pipe/comma/space delimiters
    for sep in ['|', ',', ' ']:
        if sep in s:
            vals=[v for v in s.replace(';',sep).split(sep) if v!='']
            return np.array([float(v) for v in vals], dtype=float)
    return np.array([float(s)], dtype=float)


def rank_of_G(row):
    vecs=[]
    for col in VECTOR_COLS:
        vecs.append(parse_vec(row[col]))
    dims=[len(v) for v in vecs]
    if len(set(dims)) != 1:
        raise ValueError(f'vector dimension mismatch {dims}')
    G=np.column_stack(vecs)
    return int(np.linalg.matrix_rank(G)), float(np.linalg.cond(G)) if G.shape[0] >= G.shape[1] and np.linalg.matrix_rank(G)==G.shape[1] else float('inf')


def validate(nodes_path, edges_path, cycles_path, outdir):
    out=Path(outdir); out.mkdir(parents=True, exist_ok=True)
    checks=[]
    def add(name, passed, detail=''):
        checks.append({'check':name,'passed':bool(passed),'detail':str(detail)})

    nodes=pd.read_csv(nodes_path)
    edges=pd.read_csv(edges_path)
    cycles=pd.read_csv(cycles_path)

    add('nodes_table_present', True, nodes_path)
    add('edges_table_present', True, edges_path)
    add('cycles_table_present', True, cycles_path)

    for c in NODE_REQUIRED + VECTOR_COLS:
        add(f'nodes_has_{c}', c in nodes.columns, 'required')
    for c in EDGE_REQUIRED:
        add(f'edges_has_{c}', c in edges.columns, 'required')

    if not all(ch['passed'] for ch in checks):
        pd.DataFrame(checks).to_csv(out/'V1688_69_validation_checks.csv', index=False)
        raise SystemExit('TRANSFER_BLOCKED: missing required columns')

    add('node_id_unique', not nodes['node_id'].duplicated().any(), f"duplicates={nodes['node_id'].duplicated().sum()}")
    node_ids=set(nodes['node_id'].astype(str))
    missing_from=~edges['from_node'].astype(str).isin(node_ids)
    missing_to=~edges['to_node'].astype(str).isin(node_ids)
    add('edge_from_nodes_exist', not missing_from.any(), f'missing={int(missing_from.sum())}')
    add('edge_to_nodes_exist', not missing_to.any(), f'missing={int(missing_to.sum())}')
    for c in ['source_abs','access_abs','div_baseline','weak_target']:
        vals=pd.to_numeric(nodes[c], errors='coerce')
        add(f'nodes_{c}_numeric', vals.notna().all(), f'nonnumeric={int(vals.isna().sum())}')
    g=pd.to_numeric(edges['gamma_pq'], errors='coerce')
    add('gamma_pq_numeric', g.notna().all(), f'nonnumeric={int(g.isna().sum())}')

    # reciprocal edge availability for incidence continuity
    pairs=set(zip(edges['from_node'].astype(str), edges['to_node'].astype(str)))
    reciprocal=sum((b,a) in pairs for a,b in pairs)/max(len(pairs),1)
    add('reciprocal_edge_rate_positive', reciprocal>0, f'reciprocal_rate={reciprocal:.6f}')

    # Rank audit sample/all if small enough
    ranks=[]; conds=[]; bad=0
    for _,row in nodes.iterrows():
        try:
            r,c=rank_of_G(row); ranks.append(r); conds.append(c)
        except Exception as e:
            bad+=1
    add('vectors_parseable', bad==0, f'bad_rows={bad}')
    if ranks:
        add('G_rank_nonzero', min(ranks)>0, f'min_rank={min(ranks)}, mean_rank={np.mean(ranks):.6f}')
        pd.DataFrame({'rank':ranks,'condition':conds}).to_csv(out/'V1688_69_Gp_rank_condition_audit.csv', index=False)

    # Cycle form checks
    cycle_cols=set(cycles.columns)
    has_ordered_nodes='ordered_nodes' in cycle_cols and 'cycle_id' in cycle_cols
    has_edge_rows=all(c in cycle_cols for c in ['cycle_id','step_index','from_node','to_node'])
    add('cycle_form_valid', has_ordered_nodes or has_edge_rows, f'columns={list(cycles.columns)}')
    if has_edge_rows:
        cyc_missing_from=~cycles['from_node'].astype(str).isin(node_ids)
        cyc_missing_to=~cycles['to_node'].astype(str).isin(node_ids)
        add('cycle_edge_nodes_exist', not (cyc_missing_from.any() or cyc_missing_to.any()), f'missing_from={int(cyc_missing_from.sum())}, missing_to={int(cyc_missing_to.sum())}')

    checks_df=pd.DataFrame(checks)
    checks_df.to_csv(out/'V1688_69_validation_checks.csv', index=False)
    summary={
        'verdict':'LIVE_LEDGER_VALIDATION_PASS' if checks_df['passed'].all() else 'LIVE_LEDGER_VALIDATION_FAIL_TRANSFER_BLOCKED',
        'nodes':int(len(nodes)), 'edges':int(len(edges)), 'cycles_rows':int(len(cycles)),
        'reciprocal_edge_rate':float(reciprocal),
        'all_checks_passed':bool(checks_df['passed'].all())
    }
    (out/'V1688_69_validation_summary.json').write_text(json.dumps(summary, indent=2))
    if not checks_df['passed'].all():
        raise SystemExit(summary['verdict'])
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--nodes', required=True)
    ap.add_argument('--edges', required=True)
    ap.add_argument('--cycles', required=True)
    ap.add_argument('--outdir', default='V1688_69_live_transfer_outputs')
    args=ap.parse_args()
    validate(args.nodes, args.edges, args.cycles, args.outdir)
