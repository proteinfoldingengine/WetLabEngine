# V1688.17 Retained Groupoid Curvature Protocol

Defines basepoint-normalized retained curvature and D_Gamma R_Gamma before simulation.
