# V1688.17 — Retained Groupoid Curvature Protocol

**Project:** Retained Bridge / Recoverability Geometry  
**Branch:** V1688 retained-connection / curvature-bridge program  
**Status:** mathematical protocol definition before next simulation  
**Claim level:** protocol / theorem-route only; no curvature theorem, no GR/ADM claim

---

## 1. Executive Verdict

```text
RETAINED_GROUPOID_CURVATURE_PROTOCOL_DEFINED
```

V1688.13–V1688.16 found that raw Gamma_R loop defects do not satisfy Bianchi-like compatibility.

That failure should now be reinterpreted carefully.

It may not mean:

```text
no compatibility law exists.
```

It may mean:

```text
compatibility was tested before defining covariant comparison.
```

The previous test effectively summed loop-defect vectors from different retained local algebras:

```text
R_R(cell_1) ∈ G_1
R_R(cell_2) ∈ G_2
R_R(cell_3) ∈ G_3
```

But if the local objects are generated retained recombination algebras, not one global vector space with a canonical identification, then raw summation is not mathematically valid.

The next object must be:

```text
basepoint-normalized retained curvature
```

and the next operator must be:

```text
D_Gamma R_Gamma
```

a retained covariant exterior defect.

---

## 2. Corrected Diagnosis

Current known result:

```text
Gamma_R gives nonlinear retained loop defects.
L3/O3 is the dominant driver.
L4/H4_perp adds a robust independent correction.
Compatibility closure failed under raw vector summation.
```

Corrected diagnosis:

```text
The failure may be a category / basepoint / gauge-comparison error,
not a proof that compatibility is impossible.
```

Why:

```text
Gamma_R transports between generated retained algebras G_p → G_q.
Loop defects based at different p live in different endomorphism spaces.
```

So the correct object is not:

```text
Σ R_R(loop_i)
```

The correct object is:

```text
Σ Ad_{T_{p_i→b}} R_Gamma(p_i; gamma_i)
```

where every loop defect is transported / conjugated into a common base algebra before comparison.

---

## 3. Retained Groupoid Structure

Let each retained sector \(p\) carry a generated retained recombination algebra:

\[
G_p
\]

with objects:

```text
branches B_p
L3 associators O_{3,p}
L4 hyper-associator residual H_{4,p}
provenance/order labels Λ_p
```

Let Gamma_R provide admissible transports:

\[
T_{p\to q}:G_p\to G_q
\]

for retained-adjacent sectors \(p,q\).

These transports form a groupoid-like structure:

```text
objects: generated retained algebras G_p
morphisms: admissible transports T_{p→q}
composition: retained-order transport composition
identity: Id_{G_p}
inverse: admissible or pseudo-inverse transport T_{q→p}
```

Thus:

\[
\Gamma_R
\]

is not merely a vector-bundle connection. It is better treated as a connection over a retained algebra groupoid.

---

## 4. Basepoint-Normalized Holonomy

For a closed retained loop:

\[
\gamma:p_0\to p_1\to \cdots \to p_n=p_0
\]

define the basepoint holonomy:

\[
\mathrm{Hol}_{p_0}(\gamma)
=
T_{p_{n-1}\to p_0}
\cdots
T_{p_1\to p_2}
T_{p_0\to p_1}
\]

This is an endomorphism:

\[
\mathrm{Hol}_{p_0}(\gamma):G_{p_0}\to G_{p_0}.
\]

Now define the retained curvature-like endomorphism defect:

\[
R_\Gamma(p_0;\gamma)
=
\mathrm{Hol}_{p_0}(\gamma)-I_{G_{p_0}}.
\]

This replaces the older vector defect:

\[
R_R(\gamma)x=T_\gamma x-x.
\]

The older object is a probe of \(R_\Gamma\) on a vector \(x\), but the curvature-like object itself is the endomorphism defect:

\[
R_\Gamma.
\]

---

## 5. Covariant Comparison of Loop Defects

Suppose there are loops \(\gamma_i\) based at different sectors \(p_i\).

Each defect lives in:

\[
R_\Gamma(p_i;\gamma_i)\in \operatorname{End}(G_{p_i}).
\]

To compare them at a common base \(b\), choose admissible transport:

\[
T_{p_i\to b}:G_{p_i}\to G_b.
\]

Then define the transported defect:

\[
\operatorname{Ad}_{T_{p_i\to b}}
R_\Gamma(p_i;\gamma_i)
=
T_{p_i\to b}
R_\Gamma(p_i;\gamma_i)
T_{b\to p_i}.
\]

This is an endomorphism of \(G_b\):

\[
\operatorname{End}(G_b).
\]

Only after this conjugation are neighboring loop defects comparable.

---

## 6. Retained Covariant Exterior Defect

Define the retained covariant exterior defect over a higher cell \(C\):

\[
D_\Gamma R_\Gamma(C;b)
=
\sum_{\gamma_i\in\partial C}
\sigma_i
\operatorname{Ad}_{T_{p_i\to b}}
R_\Gamma(p_i;\gamma_i)
\]

where:

```text
γ_i      = oriented boundary loops / faces
p_i      = base of γ_i
b        = common retained base sector
σ_i      = orientation sign
T        = Gamma_R admissible transport
```

This is the correct Bianchi-like object to test.

Not:

```text
raw sum of loop vectors.
```

But:

```text
covariant boundary composition of basepoint-normalized retained holonomy defects.
```

---

## 7. Source / Provenance Current

The compatibility law may be source-free:

\[
D_\Gamma R_\Gamma=0
\]

or source-active:

\[
D_\Gamma R_\Gamma=J_P.
\]

Here:

\[
J_P
\]

is a retained provenance/source-order current through the higher cell.

Candidate \(J_P\) components:

```text
source-current flux imbalance
provenance-label transport mismatch
retained-order flux through cell boundary
generated-algebra faithfulness leakage
entropy/order gradient residual
repair/current conservation residual
```

This may explain why raw Bianchi-like cancellation failed:

```text
the tested cells may not be source-free.
```

A nonzero \(D_\Gamma R_\Gamma\) may not be a failure if it matches \(J_P\).

---

## 8. Corrected Compatibility Equations

There are now two lawful compatibility equations.

### 8.1 Source-Free Retained Cell

\[
J_P=0
\]

then:

\[
D_\Gamma R_\Gamma=0.
\]

This is the closest retained analog of a Bianchi-like compatibility condition.

### 8.2 Source / Provenance Active Cell

\[
J_P\neq 0
\]

then:

\[
D_\Gamma R_\Gamma=J_P.
\]

This is the more likely form for Retained Bridge, because provenance/order flow is not optional.

---

## 9. Relation to Earlier ADM-Like Flow

Earlier Retained Bridge work had ADM-like / same-slice flow signals:

```text
momentum-like closure supported
flow-only predicted momentum-like branch
curvature-only failed
weak-form / ADM-like same-slice constraints showed signal
R_conf vs C_surplus corr ≈ 0.749
R² ≈ 0.561
continuum scaling residual p ≈ 2 in prior ladder
```

This suggests that ADM-like behavior may come from:

```text
source/provenance current conservation
```

rather than from raw holonomy cancellation.

Thus the likely bridge is:

```text
Gamma_R loop defect
→ retained groupoid curvature R_Gamma
→ covariant exterior defect D_Gamma R_Gamma
→ provenance/source current J_P
→ same-slice constraint balance
→ ADM-like flow comparison
```

Not:

```text
H4 density → curvature → ADM.
```

---

## 10. Why V1688.13–16 May Have Failed

The previous tests likely failed because they used:

```text
raw vector summation of local loop defects
```

instead of:

```text
basepoint-normalized endomorphism comparison.
```

Failure mode:

```text
R_R(loop_i)x_i live in different G_i.
Adding them assumes a canonical global gauge that was never defined.
```

Corrected requirement:

```text
transport / conjugate every loop defect into a common base algebra before summing.
```

This is why the previous B_R residual near 1.0 may not be a true negative.

It may be measuring gauge/basepoint mismatch.

---

## 11. New Simulation Target

The next executable should be:

```text
V1688.18 — Basepoint-Normalized D_Gamma R_Gamma Test
```

Steps:

```text
1. Build retained-sector graph.
2. Construct generated algebras G_p.
3. Construct Gamma_R transports T_{p→q}.
4. For each plaquette loop γ_p, compute Hol_p(γ_p).
5. Define R_Gamma(p;γ)=Hol_p(γ)-I_p.
6. Choose common base b for a higher cell.
7. Conjugate each R_Gamma into End(G_b).
8. Compute D_Gamma R_Gamma.
9. Test source-free closure D_Gamma R_Gamma≈0.
10. If not zero, construct candidate J_P.
11. Test D_Gamma R_Gamma≈J_P.
```

---

## 12. Pass / Fail Logic

### PASS-A: Source-Free Compatibility

```text
D_Gamma R_Gamma norm is small
and decreases under refinement.
```

### PASS-B: Source-Balanced Compatibility

```text
D_Gamma R_Gamma is not small,
but is predicted by J_P better than null currents.
```

### FAIL

```text
D_Gamma R_Gamma remains large,
does not refine,
and is not explained by any first-principles provenance/source current.
```

### DEGENERATE

```text
Holonomies collapse to identity or transport maps become singular / non-faithful.
```

---

## 13. What This Changes

V1688.17 changes the next question.

Old question:

```text
Do raw Gamma_R loop defects cancel?
```

New question:

```text
Do basepoint-normalized retained curvature endomorphisms satisfy
a covariant compatibility law, possibly source-balanced by J_P?
```

This is a much better bridge to ADM-like structure.

---

## 14. Final Status

```text
V1688.17 defines the retained groupoid curvature protocol.

The next simulation should not repeat raw Bianchi-like residual tests.

It should compute basepoint-normalized holonomy,
define R_Gamma as an endomorphism defect,
construct D_Gamma R_Gamma by covariant transport/conjugation,
and test whether D_Gamma R_Gamma = 0 or D_Gamma R_Gamma = J_P.
```
