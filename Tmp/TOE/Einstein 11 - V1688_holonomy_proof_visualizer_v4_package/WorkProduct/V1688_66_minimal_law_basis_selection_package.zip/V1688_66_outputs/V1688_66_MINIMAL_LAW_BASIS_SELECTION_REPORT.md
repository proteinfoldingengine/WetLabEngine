# V1688.66 — Minimal Law Basis Selection

**Verdict:** `MINIMAL_LAW_BASIS_SELECTED_NATIVE_DIRECTIONAL_PLUS_CONTINUITY`

## Purpose

Select the smallest first-principles retained weak-form basis from the fixed candidate set:

```text
C_corr
native_directional_cycle_defect
retained-order incidence continuity
correction_loss
exact scalar cycle defect
```

No new mechanism was added. No Kabsch, Procrustes, Gramian alignment, fitted counterterm, tuned flux weight, threshold patching, or primitive time coordinate was used.

## Selected basis

```text
weak_target ≈ M0
          + C_corr
          + native_directional_cycle_defect
          + retained_order_incidence_continuity
```

where:

```text
M0 = source_abs + access_abs + div_baseline
C_corr = dimensionless residualized Gamma_R/H4 correction coordinate
native_directional_cycle_defect = native T_pq action on correction direction around provenance cycles
retained_order_incidence_continuity = antisymmetric reciprocal provenance-edge current residual
```

## Core results

```text
Mean R² M0:                     +0.001215
Mean R² M0 + C_corr:            +0.081050
Mean R² selected basis:         +0.139600
Mean unique over C_corr:        +0.058550
Minimum unique over C_corr:     +0.036683
Positive holdout rate:          1.000000
Worst selected null margin:     +0.006065
```

## Why this basis, not the larger set?

`native_directional_cycle_defect` remains the dominant promoted object. But V1688.65 was correct that it was not fully minimal by itself. The only first-principles diagnostic that still adds consistently after native directional cycle is retained-order incidence continuity.

Incremental audit:

| comparison                     | base                  | super                                              |   mean_increment |   min_increment |   positive_rate |
|:-------------------------------|:----------------------|:---------------------------------------------------|-----------------:|----------------:|----------------:|
| native over Ccorr              | C_corr_only           | native_dir                                         |      0.0533478   |     0.0301334   |        1        |
| continuity after native        | native_dir            | native_dir+continuity                              |      0.00520182  |     0.000444286 |        1        |
| correction_loss after selected | native_dir+continuity | native_dir+continuity+correction_loss              |      0.000913386 |    -0.00782979  |        0.727273 |
| exact_scalar after selected    | native_dir+continuity | native_dir+continuity+exact_scalar                 |      0.000727579 |    -0.00136905  |        0.727273 |
| all remaining after selected   | native_dir+continuity | native_dir+continuity+correction_loss+exact_scalar |      0.000907725 |    -0.00692027  |        0.636364 |

After selecting native directional cycle + continuity, the remaining additions are small and not consistently positive:

```text
correction_loss after selected: mean +0.000913, positive rate 0.727
exact_scalar after selected:    mean +0.000728, positive rate 0.727
all remaining after selected:   mean +0.000907, positive rate 0.727
```

So `correction_loss` and `exact_scalar` remain diagnostics, not promoted basis elements.

## Feature unique-given-others audit

| feature         |   mean_unique_given_others |   min_unique_given_others |   positive_rate |
|:----------------|---------------------------:|--------------------------:|----------------:|
| continuity      |                0.00195175  |               0.000987556 |        1        |
| correction_loss |                0.000180146 |              -0.00761682  |        0.727273 |
| exact_scalar    |               -5.66094e-06 |              -0.00356912  |        0.636364 |
| native_dir      |                0.0146646   |               0.00581705  |        1        |

## Group hardening for selected basis

| group_col      |   mean_unique |   min_unique |   positive_rate |   mean_r2_selected |
|:---------------|--------------:|-------------:|----------------:|-------------------:|
| family         |     0.0592479 |    0.0377937 |               1 |           0.140109 |
| generator_mode |     0.053738  |    0.0366835 |               1 |           0.132056 |
| resolution     |     0.0591056 |    0.0509578 |               1 |           0.140124 |
| seed           |     0.0611308 |    0.0586043 |               1 |           0.145338 |

## Null audit

| null                                                  |   observed_unique |   mean_null_unique |   max_null_unique |   margin_vs_max |
|:------------------------------------------------------|------------------:|-------------------:|------------------:|----------------:|
| global_selected_shuffle                               |        0.0585496  |       -0.000102486 |      -6.16401e-05 |      0.0586113  |
| source_flow_block_selected_shuffle                    |        0.0585496  |       -0.000112489 |      -4.86437e-05 |      0.0585983  |
| within_generator_family_selected_shuffle              |        0.0585496  |       -0.000146048 |      -7.87411e-05 |      0.0586284  |
| V65_inherited_native_dir_shuffle_within_source_blocks |        0.0546585  |       -2.61348e-06 |       0.000185846 |      0.0544727  |
| V65_inherited_continuity_shuffle_after_native         |        0.00624208 |       -0.000141841 |       0.000177004 |      0.00606507 |

## Interpretation

The minimal retained weak-form law basis is now:

```text
M0 + C_corr + native_directional_cycle_defect + retained_order_incidence_continuity
```

This does not mean continuity is stronger than the native directional cycle. It is weaker. But it survives as the smallest additional retained-order incidence term after the native cycle object.

## Boundary

This is a finite retained-flow toy-harness result. It does not establish ADM, GR, Riemann curvature, Einstein equations, physical spacetime, or continuum closure.

## Next

`V1688.67 — Freeze retained weak-form minimal basis and test transfer/live-ledger availability.`
