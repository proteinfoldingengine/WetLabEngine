# V1688.66 minimal law basis selection harness
# Generated from fixed V1688.65 observables; see report and CSV outputs.
