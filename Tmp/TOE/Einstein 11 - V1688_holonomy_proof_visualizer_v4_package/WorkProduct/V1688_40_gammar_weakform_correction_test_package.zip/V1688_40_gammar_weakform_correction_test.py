#!/usr/bin/env python3
"""
V1688.40 — Gamma_R Correction Test Against Rebuilt Weak-Form Target

Bounded clean-room retained-flow toy harness.

Goal
----
Use the rebuilt weak-form target

    weak_target = |conf_proxy - closure_surplus|

and test whether Gamma_R / L3-O3 / L4-H4_perp correction features improve
held-out prediction beyond the source-flow baseline M0.

Guardrails
----------
- conf_proxy and closure_surplus define the target, but are NOT used in M0 or
  correction models. They appear only in diagnostic/upper-bound controls.
- No physical spacetime, ADM equation, GR tensor, Riemann curvature, Einstein
  equation, or Bianchi identity is assumed.
- Ordered dimension is retained refinement / same-slice construction only.
- Corrections must survive nulls to count.
"""
from __future__ import annotations

import json, math, zipfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import RidgeCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

OUTDIR = Path('/mnt/data/V1688_40_outputs')
OUTDIR.mkdir(parents=True, exist_ok=True)

SEEDS = [101, 202, 303, 404]
RESOLUTIONS = [24, 32, 40]
OPERATOR_FAMILIES = ['gradient_retained', 'laplacian_retained', 'mixed_retained']
RIDGE_ALPHAS = np.logspace(-5, 3, 17)


def roll(a: np.ndarray, dx: int, dy: int) -> np.ndarray:
    return np.roll(np.roll(a, dx, axis=0), dy, axis=1)


def gradx(a: np.ndarray) -> np.ndarray:
    return 0.5 * (roll(a, -1, 0) - roll(a, 1, 0))


def grady(a: np.ndarray) -> np.ndarray:
    return 0.5 * (roll(a, 0, -1) - roll(a, 0, 1))


def lap(a: np.ndarray) -> np.ndarray:
    return roll(a, -1, 0) + roll(a, 1, 0) + roll(a, 0, -1) + roll(a, 0, 1) - 4.0 * a


def div(jx: np.ndarray, jy: np.ndarray) -> np.ndarray:
    return gradx(jx) + grady(jy)


def z(a: np.ndarray) -> np.ndarray:
    return (a - np.mean(a)) / (np.std(a) + 1e-12)


def smooth_random_field(n: int, rng: np.random.Generator, passes: int = 4) -> np.ndarray:
    a = rng.normal(size=(n, n))
    for _ in range(passes):
        a = 0.50 * a + 0.125 * (roll(a, 1, 0) + roll(a, -1, 0) + roll(a, 0, 1) + roll(a, 0, -1))
    return z(a)


def norm_rows(x: np.ndarray) -> np.ndarray:
    return np.sqrt(np.sum(x * x, axis=-1))


def local_sector_vectors(fields: Dict[str, np.ndarray]) -> np.ndarray:
    """B_p local branches: retained same-slice source/access/flow sectors."""
    s = fields['source']
    a = fields['accessibility']
    db = fields['div_baseline']
    jx = fields['jx']
    jy = fields['jy']
    smag = fields['source_grad_mag']
    # B_p has six local branch channels. These are allowed source-flow channels,
    # not conf_proxy/closure_surplus.
    return np.stack([z(s), z(a), z(db), z(jx), z(jy), z(smag)], axis=-1)


def compose_local(x: np.ndarray, y: np.ndarray, gate: np.ndarray) -> np.ndarray:
    """Retained local recombination operation x ⊕_p y.

    This is a deterministic bilinear retained recombination, not a fitted target
    counterterm. gate is sector-local accessibility/conductance information.
    """
    return x + y + 0.075 * gate[..., None] * (x * np.roll(y, 1, axis=-1) - y * np.roll(x, -1, axis=-1))


def transport(vec: np.ndarray, mu: np.ndarray, dx: int, dy: int) -> np.ndarray:
    """Nearest-neighbor Gamma_R transport from p to q.

    Uses local conductance-weighted retained shift plus a small connection term
    from conductance gradient. The form is deterministic and independent of the
    weak target.
    """
    shifted = roll(vec, dx, dy)
    dmu = roll(mu, dx, dy) - mu
    return shifted + 0.05 * dmu[..., None] * np.roll(vec, 1, axis=-1)


def build_fields(n: int, seed: int, family: str) -> Dict[str, np.ndarray]:
    rng = np.random.default_rng(seed + 1000 * OPERATOR_FAMILIES.index(family) + 168840)
    source = smooth_random_field(n, rng, passes=5)
    provenance = smooth_random_field(n, rng, passes=3)
    sx, sy = gradx(source), grady(source)
    smag = np.sqrt(sx*sx + sy*sy)
    sl = lap(source)
    access = 1.0 / (1.0 + np.exp(0.65*z(sl) + 0.40*z(smag) - 0.12*z(provenance)))
    conductance = np.exp(-0.45*z(smag) + 0.18*z(provenance))

    if family == 'gradient_retained':
        jx = -conductance * sx
        jy = -conductance * sy
    elif family == 'laplacian_retained':
        jx = -conductance * gradx(source - 0.30*sl)
        jy = -conductance * grady(source - 0.30*sl)
    elif family == 'mixed_retained':
        swirl_x = grady(provenance)
        swirl_y = -gradx(provenance)
        jx = -conductance * sx + 0.20 * access * swirl_x
        jy = -conductance * sy + 0.20 * access * swirl_y
    else:
        raise ValueError(f'unknown family {family}')

    divj = div(jx, jy)
    div_baseline = z(divj + 0.22*source + 0.10*sl)

    # Weak-form ingredients. Used only to define weak_target and upper-bound controls.
    closure_surplus = z(divj + 0.46*source - 0.18*sl + 0.10*z(np.sqrt(jx*jx + jy*jy)))
    conf_proxy = z(-lap(np.log(access + 1e-6)) + 0.16*z(smag) + 0.04*z(lap(lap(source))))
    weak_target = np.abs(conf_proxy - closure_surplus)
    weak_target = z(np.log1p(weak_target))

    return dict(source=source, provenance=provenance, sx=sx, sy=sy,
                source_grad_mag=smag, source_lap=sl, accessibility=access,
                conductance=conductance, jx=jx, jy=jy, divj=divj,
                div_baseline=div_baseline, closure_surplus=closure_surplus,
                conf_proxy=conf_proxy, weak_target=weak_target)


def gammar_o3_h4_features(fields: Dict[str, np.ndarray]) -> Dict[str, np.ndarray]:
    B = local_sector_vectors(fields)
    gate = z(fields['accessibility'] * fields['conductance'])
    mu = fields['conductance']

    # O3/L3 associator sector: (x⊕y)⊕z - x⊕(y⊕z), averaged over cyclic local branches.
    x = B
    y = np.roll(B, 1, axis=-1)
    w = np.roll(B, 2, axis=-1)
    o3_vec = compose_local(compose_local(x, y, gate), w, gate) - compose_local(x, compose_local(y, w, gate), gate)
    o3_norm = z(norm_rows(o3_vec))

    # Gamma_R edge-faithfulness: transport must preserve local recombination.
    defects = []
    for dx, dy in [(1,0), (-1,0), (0,1), (0,-1)]:
        lhs = transport(compose_local(x, y, gate), mu, dx, dy)
        tx = transport(x, mu, dx, dy)
        ty = transport(y, mu, dx, dy)
        rhs_gate = roll(gate, dx, dy)
        rhs = compose_local(tx, ty, rhs_gate)
        defects.append(norm_rows(lhs - rhs))
    edge_faithfulness = z(np.mean(np.stack(defects, axis=0), axis=0))

    # H4: fourth-order hyper-associator / pentagon-like residual.
    u = np.roll(B, 3, axis=-1)
    left = compose_local(compose_local(compose_local(x, y, gate), w, gate), u, gate)
    right = compose_local(x, compose_local(y, compose_local(w, u, gate), gate), gate)
    mid = compose_local(compose_local(x, compose_local(y, w, gate), gate), u, gate)
    h4_raw_vec = left - right + 0.5 * (mid - left)

    # Orthogonalize H4 against span(B + O3) locally over all rows/channels.
    H = h4_raw_vec.reshape(-1, h4_raw_vec.shape[-1])
    design = np.concatenate([B.reshape(-1, B.shape[-1]), o3_vec.reshape(-1, o3_vec.shape[-1])], axis=1)
    design = np.concatenate([np.ones((design.shape[0], 1)), design], axis=1)
    beta = np.linalg.lstsq(design, H, rcond=None)[0]
    h4_perp_vec = (H - design @ beta).reshape(h4_raw_vec.shape)
    h4_perp_norm = z(norm_rows(h4_perp_vec))

    return dict(edge_faithfulness=edge_faithfulness, o3_norm=o3_norm, h4_perp_norm=h4_perp_norm)


def make_dataset() -> pd.DataFrame:
    frames = []
    for n in RESOLUTIONS:
        for seed in SEEDS:
            for family in OPERATOR_FAMILIES:
                f = build_fields(n, seed, family)
                c = gammar_o3_h4_features(f)
                data = {
                    'weak_target': f['weak_target'].reshape(-1),
                    'source_abs': np.abs(z(f['source'])).reshape(-1),
                    'access_abs': np.abs(z(f['accessibility'])).reshape(-1),
                    'div_baseline': z(f['div_baseline']).reshape(-1),
                    'edge_faithfulness': c['edge_faithfulness'].reshape(-1),
                    'O3_norm': c['o3_norm'].reshape(-1),
                    'H4_perp_norm': c['h4_perp_norm'].reshape(-1),
                    # diagnostics / upper-bound only; never in correction models
                    'conf_proxy': f['conf_proxy'].reshape(-1),
                    'closure_surplus': f['closure_surplus'].reshape(-1),
                    'resolution': n,
                    'seed': seed,
                    'operator_family': family,
                }
                frames.append(pd.DataFrame(data))
    return pd.concat(frames, ignore_index=True)


def fit_score(df: pd.DataFrame, features: List[str], target='weak_target', seed=0) -> Dict[str, float]:
    X = df[features].to_numpy(float)
    y = df[target].to_numpy(float)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.35, random_state=seed)
    model = Pipeline([('scale', StandardScaler()), ('ridge', RidgeCV(alphas=RIDGE_ALPHAS))])
    model.fit(Xtr, ytr)
    pred = model.predict(Xte)
    return {'r2': float(r2_score(yte, pred)), 'rmse': float(math.sqrt(mean_squared_error(yte, pred)))}


def shuffle_cols(df: pd.DataFrame, cols: List[str], rng: np.random.Generator) -> pd.DataFrame:
    out = df.copy()
    for col in cols:
        out[col] = rng.permutation(out[col].to_numpy())
    return out


def source_flow_preserving_null(df: pd.DataFrame, cols: List[str], rng: np.random.Generator) -> pd.DataFrame:
    out = df.copy()
    score = z(0.50*out['div_baseline'].to_numpy() + 0.30*out['source_abs'].to_numpy() + 0.20*out['access_abs'].to_numpy())
    bins = pd.qcut(score, q=12, labels=False, duplicates='drop')
    for col in cols:
        vals = out[col].to_numpy().copy()
        for b in np.unique(bins):
            idx = np.where(bins == b)[0]
            vals[idx] = rng.permutation(vals[idx])
        out[col] = vals
    return out


def transport_randomized_null(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    out = df.copy()
    for col in ['edge_faithfulness','O3_norm','H4_perp_norm']:
        out[col] = rng.normal(float(out[col].mean()), float(out[col].std() + 1e-12), size=len(out))
    return out


def linear_recombination_control(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    out = df.copy()
    B = out[['source_abs','access_abs','div_baseline']].to_numpy(float)
    B = (B - B.mean(axis=0)) / (B.std(axis=0) + 1e-12)
    for col in ['edge_faithfulness','O3_norm','H4_perp_norm']:
        w = rng.normal(size=B.shape[1])
        out[col] = z(B @ w)
    return out


def branch_label_shuffle(df: pd.DataFrame, rng: np.random.Generator) -> pd.DataFrame:
    out = df.copy()
    # Break operator family alignment and within-family correction order while retaining feature marginals.
    out['operator_family'] = rng.permutation(out['operator_family'].to_numpy())
    for col in ['edge_faithfulness','O3_norm','H4_perp_norm']:
        out[col] = rng.permutation(out[col].to_numpy())
    return out


def evaluate(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, Dict[str, object]]:
    models = {
        'M0_source_access_div': ['source_abs','access_abs','div_baseline'],
        'M1_M0_plus_Gamma_R_edge': ['source_abs','access_abs','div_baseline','edge_faithfulness'],
        'M2_M0_plus_O3_L3': ['source_abs','access_abs','div_baseline','O3_norm'],
        'M3_M0_plus_H4_perp_L4': ['source_abs','access_abs','div_baseline','H4_perp_norm'],
        'M4_M0_plus_edge_O3_H4': ['source_abs','access_abs','div_baseline','edge_faithfulness','O3_norm','H4_perp_norm'],
        'UPPER_BOUND_M0_plus_conf_closure_DIAGNOSTIC_ONLY': ['source_abs','access_abs','div_baseline','conf_proxy','closure_surplus'],
    }
    cells = []
    for (n, seed, family), g in df.groupby(['resolution','seed','operator_family']):
        row = {'resolution': n, 'seed': seed, 'operator_family': family}
        for name, feats in models.items():
            s = fit_score(g, feats, seed=seed+n)
            row[f'{name}_r2'] = s['r2']
            row[f'{name}_rmse'] = s['rmse']
        base = row['M0_source_access_div_r2']
        for name in list(models.keys())[1:]:
            row[f'delta_r2_{name}'] = row[f'{name}_r2'] - base
        cells.append(row)
    cell_df = pd.DataFrame(cells)

    # Whole-dataset null conditions.
    rng = np.random.default_rng(168840)
    conditions = {'observed': df}
    conditions['edge_faithfulness_shuffle'] = shuffle_cols(df, ['edge_faithfulness'], rng)
    conditions['O3_shuffle'] = shuffle_cols(df, ['O3_norm'], rng)
    conditions['H4_perp_shuffle'] = shuffle_cols(df, ['H4_perp_norm'], rng)
    conditions['source_flow_preserving_null'] = source_flow_preserving_null(df, ['edge_faithfulness','O3_norm','H4_perp_norm'], rng)
    conditions['branch_label_shuffle'] = branch_label_shuffle(df, rng)
    conditions['transport_randomized_null'] = transport_randomized_null(df, rng)
    conditions['linear_recombination_control'] = linear_recombination_control(df, rng)

    null_rows = []
    for cond, cdf in conditions.items():
        base_score = fit_score(cdf, models['M0_source_access_div'], seed=168840)['r2']
        for model_name, feats in models.items():
            s = fit_score(cdf, feats, seed=168840)
            null_rows.append({'condition': cond, 'model': model_name, 'r2': s['r2'], 'rmse': s['rmse'], 'delta_vs_M0': s['r2'] - base_score})
    null_df = pd.DataFrame(null_rows)

    # Summary by operator/resolution for refinement/operator variation.
    summary_rows = []
    for keys, g in cell_df.groupby(['resolution','operator_family']):
        n, family = keys
        out = {'resolution': n, 'operator_family': family, 'n_cells': len(g)}
        for col in [c for c in cell_df.columns if c.endswith('_r2') or c.startswith('delta_r2_')]:
            out[f'mean_{col}'] = float(g[col].mean())
        summary_rows.append(out)
    refinement_df = pd.DataFrame(summary_rows)

    mean_r2 = {k: float(cell_df[f'{k}_r2'].mean()) for k in models}
    mean_delta = {k.replace('delta_r2_',''): float(cell_df[k].mean()) for k in cell_df.columns if k.startswith('delta_r2_')}
    positive_gain_rate = {k.replace('delta_r2_',''): float((cell_df[k] > 0).mean()) for k in cell_df.columns if k.startswith('delta_r2_')}

    obs_null = null_df[null_df.condition == 'observed'].set_index('model')
    null_margins = {}
    corresponding = {
        'M1_M0_plus_Gamma_R_edge': 'edge_faithfulness_shuffle',
        'M2_M0_plus_O3_L3': 'O3_shuffle',
        'M3_M0_plus_H4_perp_L4': 'H4_perp_shuffle',
        'M4_M0_plus_edge_O3_H4': 'source_flow_preserving_null',
    }
    for model, cond in corresponding.items():
        observed_delta = float(obs_null.loc[model, 'delta_vs_M0'])
        null_delta = float(null_df[(null_df.condition == cond) & (null_df.model == model)]['delta_vs_M0'].iloc[0])
        sf_delta = float(null_df[(null_df.condition == 'source_flow_preserving_null') & (null_df.model == model)]['delta_vs_M0'].iloc[0])
        null_margins[model] = {'observed_delta_vs_M0': observed_delta,
                               f'{cond}_delta_vs_M0': null_delta,
                               'source_flow_preserving_delta_vs_M0': sf_delta,
                               'margin_vs_corresponding_null': observed_delta - null_delta,
                               'margin_vs_source_flow_preserving_null': observed_delta - sf_delta}

    degenerate = bool(mean_r2['M0_source_access_div'] >= 0.99)
    # Conservative pass logic: mean gain > 0, positive in >=2/3 cells, positive corresponding null margin, positive source-flow margin.
    passes = {}
    for model in ['M1_M0_plus_Gamma_R_edge','M2_M0_plus_O3_L3','M3_M0_plus_H4_perp_L4','M4_M0_plus_edge_O3_H4']:
        passes[model] = bool((mean_delta[model] > 0.0) and (positive_gain_rate[model] >= 2/3) and
                             (null_margins[model]['margin_vs_corresponding_null'] > 0.0) and
                             (null_margins[model]['margin_vs_source_flow_preserving_null'] > 0.0) and not degenerate)
    if degenerate:
        verdict = 'DEGENERATE_M0_SATURATED_TARGET_UNSUITABLE'
    elif any(passes.values()):
        strong = [k for k,v in passes.items() if v]
        verdict = 'GAMMAR_WEAK_FORM_CORRECTION_PASS_' + '_'.join(strong)
    elif any((mean_delta[m] > 0.0 and positive_gain_rate[m] > 0.50) for m in passes):
        verdict = 'PARTIAL_WEAK_CORRECTION_HINT_NOT_CLOSED'
    else:
        verdict = 'FAIL_NO_GAMMAR_L3_L4_CORRECTION_BEYOND_M0'

    info = {
        'document_id': 'V1688_40_GAMMAR_WEAK_FORM_CORRECTION_TEST',
        'status': 'executed',
        'verdict': verdict,
        'target': 'weak_target = z(log1p(abs(conf_proxy - closure_surplus)))',
        'excluded_from_models': ['conf_proxy', 'closure_surplus'],
        'M0': models['M0_source_access_div'],
        'model_stack': {k:v for k,v in models.items() if not k.startswith('UPPER')},
        'upper_bound_diagnostic_only': models['UPPER_BOUND_M0_plus_conf_closure_DIAGNOSTIC_ONLY'],
        'seeds': SEEDS,
        'resolutions': RESOLUTIONS,
        'operator_families': OPERATOR_FAMILIES,
        'n_samples': int(len(df)),
        'mean_r2': mean_r2,
        'mean_delta_r2_vs_M0': mean_delta,
        'positive_gain_rate': positive_gain_rate,
        'null_margins': null_margins,
        'pass_flags': passes,
        'M0_degenerate_saturation_flag_R2_ge_0p99': degenerate,
        'claim_boundary': 'Finite retained-flow mathematical toy harness only; no ADM derivation, GR, Riemann curvature, physical spacetime, Einstein equations, or Bianchi identity claim.'
    }
    return cell_df, null_df, refinement_df, info


def write_outputs(df, cell_df, null_df, refinement_df, info):
    df.to_csv(OUTDIR/'V1688_40_rows.csv', index=False)
    cell_df.to_csv(OUTDIR/'V1688_40_model_cell_results.csv', index=False)
    null_df.to_csv(OUTDIR/'V1688_40_null_results.csv', index=False)
    refinement_df.to_csv(OUTDIR/'V1688_40_operator_refinement_summary.csv', index=False)
    with open(OUTDIR/'V1688_40_SUMMARY.json','w') as f:
        json.dump(info, f, indent=2)

    report = []
    report.append('# V1688.40 — Gamma_R Correction Test Against Rebuilt Weak-Form Target\n')
    report.append(f"**Status:** executed  \n**Verdict:** `{info['verdict']}`\n")
    report.append('## Purpose\n')
    report.append('Test whether Gamma_R / L3-O3 / L4-H4_perp correction features improve the rebuilt weak-form target beyond the source-flow baseline.\n')
    report.append('## Target and guardrail\n')
    report.append('Target: `weak_target = z(log1p(abs(conf_proxy - closure_surplus)))`.\n\n')
    report.append('`conf_proxy` and `closure_surplus` define the target but are excluded from M0 and all correction models. They are included only in an upper-bound diagnostic control.\n')
    report.append('## Model stack\n')
    for k,v in info['model_stack'].items():
        report.append(f'- `{k}`: `{v}`\n')
    report.append('\n## Mean held-out R²\n')
    report.append('```json\n' + json.dumps(info['mean_r2'], indent=2) + '\n```\n')
    report.append('\n## Mean ΔR² over M0\n')
    report.append('```json\n' + json.dumps(info['mean_delta_r2_vs_M0'], indent=2) + '\n```\n')
    report.append('\n## Positive-gain rate across seed/resolution/operator-family cells\n')
    report.append('```json\n' + json.dumps(info['positive_gain_rate'], indent=2) + '\n```\n')
    report.append('\n## Null margins\n')
    report.append('```json\n' + json.dumps(info['null_margins'], indent=2) + '\n```\n')
    report.append('\n## Pass flags\n')
    report.append('```json\n' + json.dumps(info['pass_flags'], indent=2) + '\n```\n')
    report.append('\n## Readout\n')
    if info['verdict'].startswith('GAMMAR'):
        report.append('At least one Gamma_R/L3/L4 correction feature improved M0 and survived the corresponding shuffle and source-flow-preserving null under the conservative pass rule.\n')
    elif info['verdict'].startswith('PARTIAL'):
        report.append('At least one correction feature showed a positive mean gain or positive cell-rate hint, but the evidence did not satisfy the conservative null-survival rule for closure.\n')
    elif info['verdict'].startswith('DEGENERATE'):
        report.append('M0 saturated the target near R² = 1.0, so the rebuilt target is unsuitable for correction testing.\n')
    else:
        report.append('No Gamma_R / O3 / H4 correction feature established independent explanatory power beyond M0 in this harness.\n')
    report.append('\n## Required nulls covered\n')
    for x in ['edge-faithfulness shuffle','O3 shuffle','H4_perp shuffle','branch-label shuffle','source-flow-preserving null','transport-randomized null','linear recombination control','operator-family variation','resolution/refinement ladder']:
        report.append(f'- {x}\n')
    report.append('\n## Claim boundary\n')
    report.append(info['claim_boundary'] + '\n')
    report.append('\n## Recommended next step\n')
    if info['verdict'].startswith('GAMMAR'):
        report.append('V1688.41 should replicate the passing correction in a stricter clean-room harness with additional operator families and leave-one-family-out validation.\n')
    else:
        report.append('V1688.41 should audit whether the weak-form target is still too directly source-flow dominated, before any further correction claim. Do not invent new synthetic targets.\n')
    (OUTDIR/'V1688_40_GAMMAR_WEAK_FORM_CORRECTION_TEST_REPORT.md').write_text(''.join(report))

    zip_path = Path('/mnt/data/V1688_40_gammar_weakform_correction_test_package.zip')
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        zf.write('/mnt/data/V1688_40_gammar_weakform_correction_test.py', arcname='V1688_40_gammar_weakform_correction_test.py')
        for p in OUTDIR.glob('V1688_40*'):
            zf.write(p, arcname=f'V1688_40_outputs/{p.name}')
    return zip_path


def main():
    df = make_dataset()
    cell_df, null_df, refinement_df, info = evaluate(df)
    zip_path = write_outputs(df, cell_df, null_df, refinement_df, info)
    print(json.dumps(info, indent=2))
    print(f'ZIP: {zip_path}')


if __name__ == '__main__':
    main()
