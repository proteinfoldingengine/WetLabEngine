# V1688.40 — Gamma_R Correction Test Against Rebuilt Weak-Form Target
**Status:** executed  
**Verdict:** `GAMMAR_WEAK_FORM_CORRECTION_PASS_M1_M0_plus_Gamma_R_edge_M3_M0_plus_H4_perp_L4`
## Purpose
Test whether Gamma_R / L3-O3 / L4-H4_perp correction features improve the rebuilt weak-form target beyond the source-flow baseline.
## Target and guardrail
Target: `weak_target = z(log1p(abs(conf_proxy - closure_surplus)))`.

`conf_proxy` and `closure_surplus` define the target but are excluded from M0 and all correction models. They are included only in an upper-bound diagnostic control.
## Model stack
- `M0_source_access_div`: `['source_abs', 'access_abs', 'div_baseline']`
- `M1_M0_plus_Gamma_R_edge`: `['source_abs', 'access_abs', 'div_baseline', 'edge_faithfulness']`
- `M2_M0_plus_O3_L3`: `['source_abs', 'access_abs', 'div_baseline', 'O3_norm']`
- `M3_M0_plus_H4_perp_L4`: `['source_abs', 'access_abs', 'div_baseline', 'H4_perp_norm']`
- `M4_M0_plus_edge_O3_H4`: `['source_abs', 'access_abs', 'div_baseline', 'edge_faithfulness', 'O3_norm', 'H4_perp_norm']`

## Mean held-out R²
```json
{
  "M0_source_access_div": 0.13880801410470206,
  "M1_M0_plus_Gamma_R_edge": 0.14423539110750871,
  "M2_M0_plus_O3_L3": 0.09272744991766965,
  "M3_M0_plus_H4_perp_L4": 0.15085080500590797,
  "M4_M0_plus_edge_O3_H4": 0.03960574630684327,
  "UPPER_BOUND_M0_plus_conf_closure_DIAGNOSTIC_ONLY": 0.1537681287818027
}
```

## Mean ΔR² over M0
```json
{
  "M1_M0_plus_Gamma_R_edge": 0.00542737700280667,
  "M2_M0_plus_O3_L3": -0.04608056418703238,
  "M3_M0_plus_H4_perp_L4": 0.012042790901205913,
  "M4_M0_plus_edge_O3_H4": -0.09920226779785876,
  "UPPER_BOUND_M0_plus_conf_closure_DIAGNOSTIC_ONLY": 0.014960114677100666
}
```

## Positive-gain rate across seed/resolution/operator-family cells
```json
{
  "M1_M0_plus_Gamma_R_edge": 0.8055555555555556,
  "M2_M0_plus_O3_L3": 0.6944444444444444,
  "M3_M0_plus_H4_perp_L4": 0.8333333333333334,
  "M4_M0_plus_edge_O3_H4": 0.75,
  "UPPER_BOUND_M0_plus_conf_closure_DIAGNOSTIC_ONLY": 0.7777777777777778
}
```

## Null margins
```json
{
  "M1_M0_plus_Gamma_R_edge": {
    "observed_delta_vs_M0": 0.00963817996415317,
    "edge_faithfulness_shuffle_delta_vs_M0": 9.428117436138805e-05,
    "source_flow_preserving_delta_vs_M0": 0.00027327146990441253,
    "margin_vs_corresponding_null": 0.009543898789791783,
    "margin_vs_source_flow_preserving_null": 0.009364908494248758
  },
  "M2_M0_plus_O3_L3": {
    "observed_delta_vs_M0": 0.004385667041523433,
    "O3_shuffle_delta_vs_M0": -6.385907127515189e-05,
    "source_flow_preserving_delta_vs_M0": 0.00018088936278048973,
    "margin_vs_corresponding_null": 0.004449526112798585,
    "margin_vs_source_flow_preserving_null": 0.004204777678742944
  },
  "M3_M0_plus_H4_perp_L4": {
    "observed_delta_vs_M0": 0.015967447048518157,
    "H4_perp_shuffle_delta_vs_M0": -2.4757559117016825e-05,
    "source_flow_preserving_delta_vs_M0": 0.0002767461099612012,
    "margin_vs_corresponding_null": 0.015992204607635174,
    "margin_vs_source_flow_preserving_null": 0.015690700938556956
  },
  "M4_M0_plus_edge_O3_H4": {
    "observed_delta_vs_M0": 0.018248219695450207,
    "source_flow_preserving_null_delta_vs_M0": 0.0006708468084103414,
    "source_flow_preserving_delta_vs_M0": 0.0006708468084103414,
    "margin_vs_corresponding_null": 0.017577372887039866,
    "margin_vs_source_flow_preserving_null": 0.017577372887039866
  }
}
```

## Pass flags
```json
{
  "M1_M0_plus_Gamma_R_edge": true,
  "M2_M0_plus_O3_L3": false,
  "M3_M0_plus_H4_perp_L4": true,
  "M4_M0_plus_edge_O3_H4": false
}
```

## Readout
At least one Gamma_R/L3/L4 correction feature improved M0 and survived the corresponding shuffle and source-flow-preserving null under the conservative pass rule.

## Required nulls covered
- edge-faithfulness shuffle
- O3 shuffle
- H4_perp shuffle
- branch-label shuffle
- source-flow-preserving null
- transport-randomized null
- linear recombination control
- operator-family variation
- resolution/refinement ladder

## Claim boundary
Finite retained-flow mathematical toy harness only; no ADM derivation, GR, Riemann curvature, physical spacetime, Einstein equations, or Bianchi identity claim.

## Recommended next step
V1688.41 should replicate the passing correction in a stricter clean-room harness with additional operator families and leave-one-family-out validation.
