# V1688 Native Directional Holonomy Proof Visualizer

Run:

```bash
python V1688_holonomy_proof_visualizer.py
```

This generates:

- `V1688_holonomy_proof_static.png` — static proof panel
- `V1688_holonomy_generation.gif` — animated generation of directed native holonomy
- `V1688_holonomy_proof_metrics.json` — computed holonomy and defect values
- `V1688_holonomy_proof_nodes.csv` — emitted node/provenance states
- `V1688_holonomy_proof_edges.csv` — directed provenance edges with gamma and c_pq
- `V1688_holonomy_proof_cycle_steps.csv` — stepwise holonomy accumulation

Strict guardrails:

- No Kabsch / Procrustes / Gramian alignment.
- No reversible full-matrix holonomy requirement.
- No fitted counterterms.
- No primitive time coordinate.
- Directed loop follows retained/provenance order.

Core equations:

```text
G_p = span(B_p, O3_p, H4_perp_p)

T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]

c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)

H_cycle^dir = Π_loop c_pq

native_directional_cycle_defect = |1 − H_cycle^dir| · mean(|C_corr|)
```

Interpretation:

```text
The model does not produce reversible geometric holonomy as a primitive.
It produces directed native holonomy of the retained correction mode over explicit provenance cycles.
```
