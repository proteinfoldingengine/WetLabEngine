#!/usr/bin/env python3
"""
V1688 Native Directional Holonomy — Runnable Python Proof Visualization
========================================================================

Purpose
-------
A standalone, first-principles visual/proof harness for the Retained Bridge
native directional holonomy result.

It demonstrates, in a finite retained-flow toy ledger, how directed native
holonomy is generated from:

    1. local generated algebras G_p = span(B_p, O3_p, H4_perp_p)
    2. native recombination transport
       T_pq(dx) = dx + gamma_pq * [roll(dx) * q - dx * roll(q)]
    3. correction direction Z_p built from Gamma_R/H4 correction components
    4. directional edge scalar
       c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
    5. directed cycle holonomy
       H_cycle^dir = product_loop c_pq
    6. native directional cycle defect
       |1 - H_cycle^dir| * mean(|C_corr|)

Strict guardrails
-----------------
- No Kabsch / Procrustes / Gramian alignment.
- No reversible full-matrix holonomy requirement.
- No fitted counterterms.
- No primitive time coordinate.
- The directed loop follows retained/provenance order.

Outputs
-------
Creates an output directory with:

    V1688_holonomy_proof_metrics.json
    V1688_holonomy_proof_nodes.csv
    V1688_holonomy_proof_edges.csv
    V1688_holonomy_proof_cycle_steps.csv
    V1688_holonomy_proof_static.png
    V1688_holonomy_generation.gif

Dependencies
------------
Python 3.9+
numpy, pandas, matplotlib, pillow

Usage
-----
python V1688_holonomy_proof_visualizer.py

Optional:
python V1688_holonomy_proof_visualizer.py --outdir ./holonomy_demo --seed 1688 --n-nodes 8
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from mpl_toolkits.mplot3d.art3d import Line3DCollection


EPS = 1e-12


def roll(v: np.ndarray, shift: int = 1) -> np.ndarray:
    """Native roll operator used in the recombination kernel."""
    return np.roll(v, shift)


def unit(v: np.ndarray) -> np.ndarray:
    n = float(np.linalg.norm(v))
    if n < EPS:
        return np.zeros_like(v)
    return v / n


def native_kernel(dx: np.ndarray, q: np.ndarray) -> np.ndarray:
    """K(dx, q) = roll(dx) ⊙ q − dx ⊙ roll(q)."""
    return roll(dx) * q - dx * roll(q)


def native_transport(dx: np.ndarray, q: np.ndarray, gamma_pq: float) -> np.ndarray:
    """Native recombination transport T_pq(dx)."""
    return dx + gamma_pq * native_kernel(dx, q)


def directional_scalar(Zp: np.ndarray, Zq: np.ndarray, q_state: np.ndarray, gamma_pq: float) -> Tuple[float, np.ndarray]:
    """Compute c_pq and the transported correction direction T_pq Z_p."""
    Tz = native_transport(Zp, q_state, gamma_pq)
    denom = np.linalg.norm(Tz) * np.linalg.norm(Zq)
    if denom < EPS:
        return 0.0, Tz
    c = float(np.dot(Zq, Tz) / denom)
    return c, Tz


def make_basis_from_state(x: np.ndarray, phase: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Construct a local generated algebra basis from retained branch/current,
    L3-like associator, and H4_perp-like independent correction direction.

    This is a finite toy generated algebra, not a physical spacetime tangent space.
    """
    d = len(x)
    b1 = unit(x)
    b2 = unit(roll(x) - np.mean(x))

    # L3-like non-pairwise associator direction: a native commutator-like residue.
    o3 = native_kernel(b1, b2)
    if np.linalg.norm(o3) < EPS:
        o3 = np.eye(d)[0]
    o3 = unit(o3)

    # L4-like hyper-associator residual, orthogonalized against B + O3.
    raw_h4 = native_kernel(o3, b1 + 0.35 * np.sin(phase) * b2)
    B = np.column_stack([b1, b2, o3])
    coeff, *_ = np.linalg.lstsq(B, raw_h4, rcond=None)
    h4_perp = raw_h4 - B @ coeff
    if np.linalg.norm(h4_perp) < EPS:
        # deterministic fallback orthogonal vector if local degeneracy occurs
        candidate = np.eye(d)[-1]
        coeff, *_ = np.linalg.lstsq(B, candidate, rcond=None)
        h4_perp = candidate - B @ coeff
    h4_perp = unit(h4_perp)

    G = np.column_stack([b1, b2, o3, h4_perp])
    return b1, b2, o3, h4_perp, G


@dataclass
class Node:
    node_id: str
    pos: np.ndarray
    state: np.ndarray
    B1: np.ndarray
    B2: np.ndarray
    O3: np.ndarray
    H4: np.ndarray
    G: np.ndarray
    C_corr: float
    Z: np.ndarray


@dataclass
class Edge:
    from_node: str
    to_node: str
    gamma_pq: float
    c_pq: float


def build_demo_ledger(seed: int = 1688, n_nodes: int = 8, dim: int = 4) -> Tuple[Dict[str, Node], List[Edge], List[str]]:
    """
    Build an explicit provenance cycle ledger.

    The ledger is intentionally small and inspectable for peer review.
    Directed order is the cycle order; reverse traversal is not assumed to be inverse.
    """
    rng = np.random.default_rng(seed)
    angles = np.linspace(0, 2 * np.pi, n_nodes, endpoint=False)

    nodes: Dict[str, Node] = {}
    for i, th in enumerate(angles):
        # 3D visible position: tilted loop with retained-order height variation.
        pos = np.array([np.cos(th), np.sin(th), 0.32 * np.sin(2 * th)])

        # Native retained state in dim=4, smoothly varying + small deterministic perturbation.
        state = np.array([
            np.cos(th) + 0.15 * np.sin(3 * th),
            np.sin(th) + 0.12 * np.cos(2 * th),
            np.cos(2 * th + 0.4),
            np.sin(3 * th - 0.2),
        ], dtype=float)
        state += 0.025 * rng.normal(size=dim)
        state = unit(state)

        b1, b2, o3, h4, G = make_basis_from_state(state, phase=th)

        # Correction coordinate: H4 dominant, edge/L3 present but smaller.
        edge_component = float(np.dot(b1, roll(state)))
        h4_component = float(0.80 + 0.20 * np.dot(h4, roll(o3)))
        C_corr = float(0.35 * edge_component + 0.95 * h4_component)

        # Correction direction selected by Gamma_R/H4. H4 dominates, O3 contributes.
        Z = unit(0.35 * o3 + 1.0 * h4)

        node_id = f"p{i}"
        nodes[node_id] = Node(
            node_id=node_id,
            pos=pos,
            state=state,
            B1=b1,
            B2=b2,
            O3=o3,
            H4=h4,
            G=G,
            C_corr=C_corr,
            Z=Z,
        )

    cycle = [f"p{i}" for i in range(n_nodes)]
    edges: List[Edge] = []
    for i, a in enumerate(cycle):
        b = cycle[(i + 1) % n_nodes]
        pa, qb = nodes[a], nodes[b]

        # Ledger overlap gate gamma_pq is emitted from retained state overlap.
        # It is not fitted to improve holonomy.
        overlap = float(np.dot(pa.state, qb.state))
        gamma = float(0.55 * np.tanh(1.25 * overlap))

        c, _ = directional_scalar(pa.Z, qb.Z, qb.state, gamma)
        edges.append(Edge(a, b, gamma, c))

    return nodes, edges, cycle


def compute_cycle_metrics(nodes: Dict[str, Node], edges: List[Edge], cycle: List[str]) -> Tuple[dict, pd.DataFrame]:
    H = 1.0
    rows = []
    for k, e in enumerate(edges):
        n0 = nodes[e.from_node]
        n1 = nodes[e.to_node]
        c, Tz = directional_scalar(n0.Z, n1.Z, n1.state, e.gamma_pq)
        H *= c
        defect_so_far = abs(1.0 - H) * float(np.mean([abs(nodes[n].C_corr) for n in cycle[: k + 1]]))
        rows.append({
            "step": k + 1,
            "from_node": e.from_node,
            "to_node": e.to_node,
            "gamma_pq": e.gamma_pq,
            "c_pq": c,
            "H_cycle_partial": H,
            "directional_defect_partial": defect_so_far,
            "transport_norm": float(np.linalg.norm(Tz)),
            "Z_alignment_raw": float(np.dot(n1.Z, Tz)),
        })

    mean_C = float(np.mean([abs(nodes[n].C_corr) for n in cycle]))
    final_defect = abs(1.0 - H) * mean_C

    # A reverse traversal check: deliberately not expected to be identical.
    reverse_edges = []
    for i, a in enumerate(reversed(cycle)):
        b = list(reversed(cycle))[(i + 1) % len(cycle)]
        pa, qb = nodes[a], nodes[b]
        overlap = float(np.dot(pa.state, qb.state))
        gamma = float(0.55 * np.tanh(1.25 * overlap))
        c, _ = directional_scalar(pa.Z, qb.Z, qb.state, gamma)
        reverse_edges.append(c)
    H_rev = float(np.prod(reverse_edges))
    reverse_defect = abs(1.0 - H_rev) * mean_C

    metrics = {
        "H_cycle_dir": float(H),
        "native_directional_cycle_defect": float(final_defect),
        "mean_abs_C_corr": mean_C,
        "reverse_H_cycle_dir": H_rev,
        "reverse_directional_cycle_defect": float(reverse_defect),
        "orientation_asymmetry_abs": float(abs(final_defect - reverse_defect)),
        "edge_count": len(edges),
        "node_count": len(cycle),
        "interpretation": "Directed native holonomy is produced by the action of native recombination transport on the retained correction mode Z around an explicit provenance cycle. Full reversible matrix holonomy is not required or expected.",
    }
    return metrics, pd.DataFrame(rows)


def save_tables(outdir: Path, nodes: Dict[str, Node], edges: List[Edge], step_df: pd.DataFrame, metrics: dict) -> None:
    node_rows = []
    for n in nodes.values():
        node_rows.append({
            "node_id": n.node_id,
            "x": n.pos[0], "y": n.pos[1], "z": n.pos[2],
            "C_corr": n.C_corr,
            "state": json.dumps(n.state.tolist()),
            "Z": json.dumps(n.Z.tolist()),
            "O3": json.dumps(n.O3.tolist()),
            "H4_perp": json.dumps(n.H4.tolist()),
        })
    pd.DataFrame(node_rows).to_csv(outdir / "V1688_holonomy_proof_nodes.csv", index=False)

    pd.DataFrame([asdict(e) for e in edges]).to_csv(outdir / "V1688_holonomy_proof_edges.csv", index=False)
    step_df.to_csv(outdir / "V1688_holonomy_proof_cycle_steps.csv", index=False)
    with open(outdir / "V1688_holonomy_proof_metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)


def set_equal_3d(ax, lim=1.35):
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_zlim(-lim * 0.65, lim * 0.65)
    ax.set_box_aspect((1, 1, 0.65))


def draw_static(outdir: Path, nodes: Dict[str, Node], edges: List[Edge], cycle: List[str], metrics: dict, step_df: pd.DataFrame) -> Path:
    fig = plt.figure(figsize=(16, 9), dpi=160)
    fig.patch.set_facecolor("#05070d")

    ax = fig.add_subplot(121, projection="3d")
    ax.set_facecolor("#05070d")
    ax.grid(False)
    ax.set_title("Native directional holonomy over explicit provenance cycle", color="white", fontsize=12, pad=20)

    # Draw cycle edges.
    for e in edges:
        p0 = nodes[e.from_node].pos
        p1 = nodes[e.to_node].pos
        ax.plot([p0[0], p1[0]], [p0[1], p1[1]], [p0[2], p1[2]], color="#ffbf35", lw=2.4, alpha=0.9)
        mid = 0.75 * p0 + 0.25 * p1
        ax.quiver(mid[0], mid[1], mid[2], *(p1 - p0) * 0.18, color="#ffdf70", arrow_length_ratio=0.55, linewidth=1.6)

    # Draw nodes and Z directions.
    for n in nodes.values():
        ax.scatter(n.pos[0], n.pos[1], n.pos[2], s=70, color="#37c6ff", edgecolor="white", linewidth=0.5)
        # Map Z first 3 dims to visible vector.
        zv = unit(n.Z[:3]) * 0.22
        ax.quiver(n.pos[0], n.pos[1], n.pos[2], zv[0], zv[1], zv[2], color="#b06cff", linewidth=1.8, arrow_length_ratio=0.28)
        ax.text(n.pos[0] * 1.08, n.pos[1] * 1.08, n.pos[2] + 0.07, n.node_id, color="white", fontsize=8)

    set_equal_3d(ax)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.view_init(elev=27, azim=42)

    # Text/equation panel.
    ax2 = fig.add_subplot(122)
    ax2.set_facecolor("#070b14")
    ax2.axis("off")
    text_color = "#eaf6ff"
    cyan = "#65e7ff"
    gold = "#ffcc55"
    purple = "#c58cff"

    lines = [
        ("Retained Bridge: runnable proof object", 18, cyan),
        ("", 8, text_color),
        ("Local algebra", 13, gold),
        ("G_p = span(B_p, O3_p, H4_perp_p)", 11, text_color),
        ("", 8, text_color),
        ("Native recombination transport", 13, gold),
        ("T_pq(dx) = dx + gamma_pq [roll(dx)⊙q − dx⊙roll(q)]", 10, text_color),
        ("", 8, text_color),
        ("Correction direction", 13, gold),
        ("Z_p = unit(0.35·O3_p + 1.0·H4_perp_p)", 10, purple),
        ("", 8, text_color),
        ("Directional edge scalar", 13, gold),
        ("c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)", 10, text_color),
        ("", 8, text_color),
        ("Cycle holonomy produced", 13, gold),
        ("H_cycle^dir = Π_loop c_pq", 12, text_color),
        ("defect = |1 − H_cycle^dir| · mean(|C_corr|)", 11, text_color),
        ("", 8, text_color),
        (f"H_cycle^dir = {metrics['H_cycle_dir']:.6f}", 12, cyan),
        (f"native directional cycle defect = {metrics['native_directional_cycle_defect']:.6f}", 12, cyan),
        (f"reverse defect = {metrics['reverse_directional_cycle_defect']:.6f}", 10, "#b7c5d8"),
        (f"orientation asymmetry = {metrics['orientation_asymmetry_abs']:.6f}", 10, "#b7c5d8"),
        ("", 8, text_color),
        ("Interpretation", 13, gold),
        ("The model does not produce reversible geometric holonomy as a primitive.", 10, text_color),
        ("It produces directed native holonomy of the retained correction mode", 10, text_color),
        ("over explicit provenance cycles.", 10, text_color),
    ]
    y = 0.97
    for s, fs, col in lines:
        ax2.text(0.02, y, s, color=col, fontsize=fs, va="top", family="DejaVu Sans")
        y -= fs / 270.0 + 0.012

    # Mini curve of partial defect.
    inset = fig.add_axes([0.60, 0.08, 0.34, 0.17], facecolor="#05070d")
    inset.plot(step_df["step"], step_df["directional_defect_partial"], marker="o", lw=2)
    inset.set_title("holonomy defect accumulates around retained cycle", color="white", fontsize=9)
    inset.set_xlabel("cycle step", color="white", fontsize=8)
    inset.set_ylabel("partial defect", color="white", fontsize=8)
    inset.tick_params(colors="white", labelsize=7)
    for spine in inset.spines.values():
        spine.set_color("#65e7ff")

    fig.suptitle("V1688 Native Directional Holonomy — First-Principles Proof Visualization", color="white", fontsize=16, y=0.98)
    fig.text(0.5, 0.01, "No Kabsch/Gramian alignment • No reversible full-matrix requirement • Directed retained-order cycle", color="#9feaff", ha="center", fontsize=10)

    path = outdir / "V1688_holonomy_proof_static.png"
    fig.savefig(path, facecolor=fig.get_facecolor(), bbox_inches="tight")
    plt.close(fig)
    return path


def animate(outdir: Path, nodes: Dict[str, Node], edges: List[Edge], cycle: List[str], metrics: dict, step_df: pd.DataFrame) -> Path:
    fig = plt.figure(figsize=(10, 8), dpi=120)
    fig.patch.set_facecolor("#05070d")
    ax = fig.add_subplot(111, projection="3d")
    ax.set_facecolor("#05070d")
    ax.grid(False)
    set_equal_3d(ax)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.view_init(elev=30, azim=35)

    positions = np.array([nodes[n].pos for n in cycle])

    def draw_base(active_step: int, frac: float):
        ax.clear()
        ax.set_facecolor("#05070d")
        ax.grid(False)
        set_equal_3d(ax)
        ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
        ax.view_init(elev=30, azim=35 + active_step * 6)
        ax.set_title("Directed native holonomy being generated", color="white", fontsize=13, pad=18)

        # Full faint cycle
        for e in edges:
            p0 = nodes[e.from_node].pos
            p1 = nodes[e.to_node].pos
            ax.plot([p0[0], p1[0]], [p0[1], p1[1]], [p0[2], p1[2]], color="#6c4e1b", lw=1.3, alpha=0.55)

        # Activated edges
        H_partial = 1.0
        for k, e in enumerate(edges):
            if k < active_step:
                p0 = nodes[e.from_node].pos
                p1 = nodes[e.to_node].pos
                ax.plot([p0[0], p1[0]], [p0[1], p1[1]], [p0[2], p1[2]], color="#ffbf35", lw=3.0, alpha=1.0)
                H_partial *= e.c_pq

        # Current traveling point
        if active_step < len(edges):
            e = edges[active_step]
            p0 = nodes[e.from_node].pos
            p1 = nodes[e.to_node].pos
            cur = (1 - frac) * p0 + frac * p1
            ax.scatter(cur[0], cur[1], cur[2], s=180, color="#ffdf70", edgecolor="white", linewidth=0.8)
            H_temp = H_partial * (1 + frac * (e.c_pq - 1))
        else:
            H_temp = metrics["H_cycle_dir"]

        # Nodes and correction arrows
        for n in nodes.values():
            ax.scatter(n.pos[0], n.pos[1], n.pos[2], s=75, color="#37c6ff", edgecolor="white", linewidth=0.5)
            zv = unit(n.Z[:3]) * 0.20
            ax.quiver(n.pos[0], n.pos[1], n.pos[2], zv[0], zv[1], zv[2], color="#b06cff", linewidth=1.6, arrow_length_ratio=0.26)
            ax.text(n.pos[0]*1.08, n.pos[1]*1.08, n.pos[2] + 0.06, n.node_id, color="white", fontsize=8)

        defect_temp = abs(1 - H_temp) * metrics["mean_abs_C_corr"]
        ax.text2D(0.03, 0.93, "T_pq(dx)=dx+gamma_pq[roll(dx)⊙q−dx⊙roll(q)]", transform=ax.transAxes, color="#9feaff", fontsize=9)
        ax.text2D(0.03, 0.88, "c_pq=<Z_q,T_pq Z_p>/(||T_pqZ_p||||Z_q||)", transform=ax.transAxes, color="#d9c2ff", fontsize=9)
        ax.text2D(0.03, 0.08, f"partial H_cycle^dir = {H_temp:+.5f}", transform=ax.transAxes, color="#ffdf70", fontsize=12)
        ax.text2D(0.03, 0.04, f"partial directional defect = {defect_temp:.5f}", transform=ax.transAxes, color="#ff8c8c", fontsize=12)
        ax.text2D(0.55, 0.04, "Directed retained-order cycle — reverse is not assumed inverse", transform=ax.transAxes, color="#9feaff", fontsize=9)

    total_frames = len(edges) * 10 + 15

    def update(frame):
        if frame < len(edges) * 10:
            active_step = frame // 10
            frac = (frame % 10) / 10.0
        else:
            active_step = len(edges)
            frac = 1.0
        draw_base(active_step, frac)
        return []

    anim = FuncAnimation(fig, update, frames=total_frames, interval=120, blit=False)
    path = outdir / "V1688_holonomy_generation.gif"
    anim.save(path, writer=PillowWriter(fps=8))
    plt.close(fig)
    return path


def main() -> None:
    parser = argparse.ArgumentParser(description="V1688 native directional holonomy proof visualizer")
    parser.add_argument("--outdir", type=str, default="/mnt/data/V1688_holonomy_proof_visualizer_outputs")
    parser.add_argument("--seed", type=int, default=1688)
    parser.add_argument("--n-nodes", type=int, default=8)
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    nodes, edges, cycle = build_demo_ledger(seed=args.seed, n_nodes=args.n_nodes)
    metrics, step_df = compute_cycle_metrics(nodes, edges, cycle)
    save_tables(outdir, nodes, edges, step_df, metrics)
    static_path = draw_static(outdir, nodes, edges, cycle, metrics, step_df)
    gif_path = animate(outdir, nodes, edges, cycle, metrics, step_df)

    print("V1688 native directional holonomy proof complete")
    print(json.dumps(metrics, indent=2))
    print(f"Static figure: {static_path}")
    print(f"Animation GIF: {gif_path}")
    print(f"Output directory: {outdir}")


if __name__ == "__main__":
    main()
