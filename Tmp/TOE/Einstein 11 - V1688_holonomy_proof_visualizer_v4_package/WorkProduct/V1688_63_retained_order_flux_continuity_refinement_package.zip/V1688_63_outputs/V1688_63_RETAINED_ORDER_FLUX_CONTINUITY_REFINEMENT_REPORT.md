# V1688.63 — Retained-Order Flux Continuity Refinement

## Verdict

```text
RETAINED_ORDER_CONTINUITY_PASS
```

This run refined the V1688.62 provenance-order conservation audit using only the emitted ledger incidence structure.  No geometric alignment, fitted counterterm, tuned flux weight, or primitive time coordinate was introduced.

## First-principles continuity object

Starting from the directed flux already defined in V1688.62:

```text
F_pq = c_pq · C_corr(p)
```

V1688.63 extracted the canonical antisymmetric incidence current on reciprocal provenance edges:

```text
J_pq = 1/2 · (F_pq − F_qp)
```

and computed node continuity residuals using the ledger incidence operator:

```text
residual(p) = incoming J − outgoing J
```

No weights were tuned.

## Scale

```text
nodes: 29,696
edges: 114,176
reciprocal edge rate: 1.000000
```

## Main results

```text
Mean R² M0:                         +0.001215
Mean R² M0 + C_corr:                +0.081050
Mean R² M0 + C_corr + native_dir:   +0.134399
Mean R² + incidence continuity:     +0.140861

Mean incidence unique after native: +0.006462
Minimum unique:                     +0.001231
Positive rate:                      1.000000
```

## Null separation

```text
Critical null mean unique:          +0.000000
Observed-null margin:               +0.006462
Finest-3 resolution CV:             0.110173
```

## Interpretation

The incidence-derived continuity residual is the correct first-principles refinement of the V1688.62 flux object.  The result is promoted only if it improves beyond native directional holonomy and clears incidence-shuffle/source-flow-preserving nulls.

Current result:

```text
RETAINED_ORDER_CONTINUITY_PASS
```

If this is a pass, the retained-order continuity relation becomes a candidate companion observable to native directional cycle defect. If not, native directional cycle defect remains the stronger surviving object.
