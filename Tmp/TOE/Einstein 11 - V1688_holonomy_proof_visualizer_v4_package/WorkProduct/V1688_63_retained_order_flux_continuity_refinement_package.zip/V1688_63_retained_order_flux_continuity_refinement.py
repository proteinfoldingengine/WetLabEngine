#!/usr/bin/env python3
"""
V1688.63 — Retained-order flux continuity refinement
First-principles incidence-derived conservation test. No geometry alignment, no fitted
counterterms, no threshold tuning, no primitive time coordinate.
"""
import json, os, zipfile
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

BASE=Path('/mnt/data')
OUT=BASE/'V1688_63_outputs'
OUT.mkdir(exist_ok=True)
NODE_IN=BASE/'V1688_62_outputs'/'V1688_62_node_flux_conservation.csv'
EDGE_IN=BASE/'V1688_62_outputs'/'V1688_62_edge_directed_flux.csv'
node=pd.read_csv(NODE_IN)
edge=pd.read_csv(EDGE_IN)

# ---------- first-principles retained-order incidence refinement ----------
# Directed flux from V1688.62: F_pq = c_pq*C_p.  Refine to the oriented incidence
# current by antisymmetrizing reciprocal ledger edges.  This is not tuned: it is the
# canonical oriented 1-chain component of the emitted reciprocal edge ledger.
edge['key_fwd']=edge['from_node'].astype(str)+'>'+edge['to_node'].astype(str)
edge['key_rev']=edge['to_node'].astype(str)+'>'+edge['from_node'].astype(str)
rev_flux=dict(zip(edge['key_fwd'], edge['directed_flux']))
edge['reverse_flux']=edge['key_rev'].map(rev_flux)
edge['has_reverse']=edge['reverse_flux'].notna()
edge['antisym_flux']=0.5*(edge['directed_flux']-edge['reverse_flux'].fillna(0.0))
edge['symmetric_flux']=0.5*(edge['directed_flux']+edge['reverse_flux'].fillna(0.0))
# Oriented continuity residual from incidence: incoming - outgoing antisym current.
out=edge.groupby('from_node')['antisym_flux'].sum().rename('anti_out_flux')
inp=edge.groupby('to_node')['antisym_flux'].sum().rename('anti_in_flux')
outabs=edge.groupby('from_node')['antisym_flux'].apply(lambda s: np.abs(s).sum()).rename('anti_out_abs')
inabs=edge.groupby('to_node')['antisym_flux'].apply(lambda s: np.abs(s).sum()).rename('anti_in_abs')
sout=edge.groupby('from_node')['symmetric_flux'].sum().rename('sym_out_flux')
sin=edge.groupby('to_node')['symmetric_flux'].sum().rename('sym_in_flux')

div=pd.concat([out,inp,outabs,inabs,sout,sin],axis=1).fillna(0.0)
div['anti_incidence_residual']=div['anti_in_flux']-div['anti_out_flux']
div['anti_incidence_abs_residual']=np.abs(div['anti_incidence_residual'])
div['anti_incidence_norm_residual']=div['anti_incidence_abs_residual']/(1e-12+div['anti_in_abs']+div['anti_out_abs'])
div['sym_incidence_residual']=div['sym_in_flux']-div['sym_out_flux']
div['sym_incidence_abs_residual']=np.abs(div['sym_incidence_residual'])
div['sym_incidence_norm_residual']=div['sym_incidence_abs_residual']/(1e-12+np.abs(div['sym_in_flux'])+np.abs(div['sym_out_flux']))
div['node_id']=div.index
node=node.merge(div.reset_index(drop=True), on='node_id', how='left')
newcols=['anti_out_flux','anti_in_flux','anti_out_abs','anti_in_abs','sym_out_flux','sym_in_flux','anti_incidence_residual','anti_incidence_abs_residual','anti_incidence_norm_residual','sym_incidence_residual','sym_incidence_abs_residual','sym_incidence_norm_residual']
node[newcols]=node[newcols].fillna(0.0)

# Block-wise z scores for conservation observables only, derived from incidence and block ledger.
for c in ['anti_incidence_abs_residual','anti_incidence_norm_residual','sym_incidence_abs_residual','sym_incidence_norm_residual']:
    node[c+'_block_z']=node.groupby('block_id')[c].transform(lambda s: (s-s.mean())/(s.std(ddof=0)+1e-12))

# ---------- modelling ----------
y='weak_target'
M0=['source_abs','access_abs','div_baseline']
C=['C_corr']
NATIVE=['native_directional_cycle_defect']
V62FLUX=['flux_residual_z','abs_flux_residual_z','flux_imbalance_ratio_z','mean_flux_loss_z','abs_mean_flux_loss_z']
INC=['anti_incidence_abs_residual_block_z','anti_incidence_norm_residual_block_z','sym_incidence_abs_residual_block_z','sym_incidence_norm_residual_block_z']
# keep all existing features finite
for c in M0+C+NATIVE+V62FLUX+INC+[y]:
    node[c]=pd.to_numeric(node[c],errors='coerce').replace([np.inf,-np.inf],np.nan).fillna(0.0)

def fit_r2(train,test,features):
    if len(test)<5 or len(train)<10: return np.nan
    model=make_pipeline(StandardScaler(), Ridge(alpha=1.0))
    model.fit(train[features].values, train[y].values)
    pred=model.predict(test[features].values)
    return r2_score(test[y].values, pred)

def holdouts(group_col):
    rows=[]
    for val in sorted(node[group_col].dropna().unique()):
        tr=node[node[group_col]!=val]
        te=node[node[group_col]==val]
        if len(te)<10 or len(tr)<10: continue
        r0=fit_r2(tr,te,M0)
        rc=fit_r2(tr,te,M0+C)
        rn=fit_r2(tr,te,M0+C+NATIVE)
        rv62=fit_r2(tr,te,M0+C+NATIVE+V62FLUX)
        rinc=fit_r2(tr,te,M0+C+NATIVE+INC)
        rall=fit_r2(tr,te,M0+C+NATIVE+V62FLUX+INC)
        rows.append(dict(group=group_col, heldout=str(val), n_test=len(te), r2_M0=r0, r2_C=rc, r2_native=rn, r2_v62_flux=rv62, r2_incidence= rinc, r2_all_flux=rall,
                         unique_native=rn-rc, unique_v62_after_native=rv62-rn, unique_inc_after_native=rinc-rn, unique_inc_after_v62=rall-rv62))
    return rows
hold=[]
for g in ['family','resolution','seed','generator_mode']:
    hold += holdouts(g)
hold_df=pd.DataFrame(hold)

# Nulls: preserve source-flow/M0 and native_dir/C columns, break incidence alignment.
rng=np.random.default_rng(168863)
null_rows=[]
base_feats=M0+C+NATIVE
obs=hold_df['unique_inc_after_native'].mean()
for null_name in ['global_incidence_shuffle','within_block_incidence_shuffle','within_resolution_incidence_shuffle','source_flow_preserving_rank_shuffle','linear_zero_control']:
    tmp=node.copy()
    if null_name=='linear_zero_control':
        for c in INC: tmp[c]=0.0
    elif null_name=='global_incidence_shuffle':
        for c in INC: tmp[c]=rng.permutation(tmp[c].values)
    elif null_name=='within_block_incidence_shuffle':
        for c in INC:
            tmp[c]=tmp.groupby('block_id')[c].transform(lambda s: rng.permutation(s.values))
    elif null_name=='within_resolution_incidence_shuffle':
        for c in INC:
            tmp[c]=tmp.groupby('resolution')[c].transform(lambda s: rng.permutation(s.values))
    elif null_name=='source_flow_preserving_rank_shuffle':
        # bins from M0 source-flow score; shuffle incidence only inside bins.
        score=(tmp['source_abs'].rank(pct=True)+tmp['access_abs'].rank(pct=True)+tmp['div_baseline'].rank(pct=True))/3
        tmp['_bin']=pd.qcut(score, q=20, labels=False, duplicates='drop')
        for c in INC:
            tmp[c]=tmp.groupby('_bin')[c].transform(lambda s: rng.permutation(s.values))
    rows=[]
    old=node; node_tmp=tmp
    # manual for family/resolution/generator/seed
    for g in ['family','resolution','seed','generator_mode']:
        for val in sorted(node_tmp[g].dropna().unique()):
            tr=node_tmp[node_tmp[g]!=val]; te=node_tmp[node_tmp[g]==val]
            if len(te)<10 or len(tr)<10: continue
            rn=fit_r2(tr,te,base_feats)
            ri=fit_r2(tr,te,base_feats+INC)
            rows.append(ri-rn)
    null_rows.append(dict(null=null_name, mean_unique_inc_after_native=float(np.nanmean(rows)), max_unique_inc_after_native=float(np.nanmax(rows)), positive_rate=float(np.nanmean(np.array(rows)>0))))
null_df=pd.DataFrame(null_rows)

# Summary metrics
mean_unique=float(hold_df['unique_inc_after_native'].mean())
min_unique=float(hold_df['unique_inc_after_native'].min())
pos_rate=float((hold_df['unique_inc_after_native']>0).mean())
crit=float(null_df['mean_unique_inc_after_native'].max())
margin=mean_unique-crit
# Correlations
corr_rows=[]
for a in INC:
    for b in ['weak_target','C_corr','native_directional_cycle_defect','h4_perp_norm','source_abs','div_baseline']:
        corr_rows.append(dict(feature=a,target=b,corr=float(np.corrcoef(node[a],node[b])[0,1])))
corr_df=pd.DataFrame(corr_rows)

# resolution diagnostics
res_df=hold_df[hold_df.group=='resolution'].copy()
fin=res_df.sort_values('heldout').tail(3)['unique_inc_after_native'].values
fin_cv=float(np.std(fin)/(abs(np.mean(fin))+1e-12)) if len(fin)>0 else np.nan
verdict='RETAINED_ORDER_CONTINUITY_PASS' if (mean_unique>0 and pos_rate>=0.9 and margin>0) else ('PARTIAL_RETAINED_ORDER_CONTINUITY_SIGNAL_NULL_MARGIN_FAIL' if mean_unique>0 else 'RETAINED_ORDER_CONTINUITY_FAIL')
summary=dict(document_id='V1688_63_RETAINED_ORDER_FLUX_CONTINUITY_REFINEMENT', verdict=verdict,
             n_nodes=int(len(node)), n_edges=int(len(edge)), reciprocal_edge_rate=float(edge['has_reverse'].mean()),
             mean_unique_inc_after_native=mean_unique, min_unique_inc_after_native=min_unique,
             positive_unique_rate=pos_rate, critical_null_mean=crit, observed_null_margin=margin,
             finest3_unique_cv=fin_cv,
             mean_r2_M0=float(hold_df.r2_M0.mean()), mean_r2_C=float(hold_df.r2_C.mean()), mean_r2_native=float(hold_df.r2_native.mean()),
             mean_r2_incidence=float(hold_df.r2_incidence.mean()))

# write outputs
node_out=node[['generator_mode','block_id','family','resolution','seed','i','j','node_id','weak_target','source_abs','access_abs','div_baseline','C_corr','native_directional_cycle_defect']+newcols+[c+'_block_z' for c in ['anti_incidence_abs_residual','anti_incidence_norm_residual','sym_incidence_abs_residual','sym_incidence_norm_residual']]]
edge_out=edge[['from_node','to_node','block_id','generator_mode','directed_flux','reverse_flux','has_reverse','antisym_flux','symmetric_flux']]
node_out.to_csv(OUT/'V1688_63_node_incidence_continuity.csv',index=False)
edge_out.to_csv(OUT/'V1688_63_edge_antisymmetric_flux.csv',index=False)
hold_df.to_csv(OUT/'V1688_63_continuity_holdout_results.csv',index=False)
null_df.to_csv(OUT/'V1688_63_continuity_null_results.csv',index=False)
corr_df.to_csv(OUT/'V1688_63_continuity_correlation_diagnostics.csv',index=False)
res_df.to_csv(OUT/'V1688_63_continuity_resolution_diagnostics.csv',index=False)
with open(OUT/'V1688_63_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)

report=f"""# V1688.63 — Retained-Order Flux Continuity Refinement

## Verdict

```text
{verdict}
```

This run refined the V1688.62 provenance-order conservation audit using only the emitted ledger incidence structure.  No geometric alignment, fitted counterterm, tuned flux weight, or primitive time coordinate was introduced.

## First-principles continuity object

Starting from the directed flux already defined in V1688.62:

```text
F_pq = c_pq · C_corr(p)
```

V1688.63 extracted the canonical antisymmetric incidence current on reciprocal provenance edges:

```text
J_pq = 1/2 · (F_pq − F_qp)
```

and computed node continuity residuals using the ledger incidence operator:

```text
residual(p) = incoming J − outgoing J
```

No weights were tuned.

## Scale

```text
nodes: {len(node):,}
edges: {len(edge):,}
reciprocal edge rate: {edge['has_reverse'].mean():.6f}
```

## Main results

```text
Mean R² M0:                         {summary['mean_r2_M0']:+.6f}
Mean R² M0 + C_corr:                {summary['mean_r2_C']:+.6f}
Mean R² M0 + C_corr + native_dir:   {summary['mean_r2_native']:+.6f}
Mean R² + incidence continuity:     {summary['mean_r2_incidence']:+.6f}

Mean incidence unique after native: {mean_unique:+.6f}
Minimum unique:                     {min_unique:+.6f}
Positive rate:                      {pos_rate:.6f}
```

## Null separation

```text
Critical null mean unique:          {crit:+.6f}
Observed-null margin:               {margin:+.6f}
Finest-3 resolution CV:             {fin_cv:.6f}
```

## Interpretation

The incidence-derived continuity residual is the correct first-principles refinement of the V1688.62 flux object.  The result is promoted only if it improves beyond native directional holonomy and clears incidence-shuffle/source-flow-preserving nulls.

Current result:

```text
{verdict}
```

If this is a pass, the retained-order continuity relation becomes a candidate companion observable to native directional cycle defect. If not, native directional cycle defect remains the stronger surviving object.
"""
with open(OUT/'V1688_63_RETAINED_ORDER_FLUX_CONTINUITY_REFINEMENT_REPORT.md','w') as f: f.write(report)
# package
zip_path=BASE/'V1688_63_retained_order_flux_continuity_refinement_package.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(BASE/'V1688_63_retained_order_flux_continuity_refinement.py',arcname='V1688_63_retained_order_flux_continuity_refinement.py')
    for p in OUT.iterdir(): z.write(p,arcname='V1688_63_outputs/'+p.name)
print(json.dumps(summary,indent=2))
