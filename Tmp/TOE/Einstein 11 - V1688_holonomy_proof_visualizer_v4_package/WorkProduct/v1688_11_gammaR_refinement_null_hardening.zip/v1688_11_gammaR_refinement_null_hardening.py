
from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_11_gammaR_refinement_null_hardening_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-12

def recombine(x, y, gamma=0.35, mode="nonlinear"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if mode=="linear":
        return x+y
    rd=np.r_[x[-1],x[:-1]]
    ru=np.r_[y[1:],y[0]]
    ov=np.minimum(np.abs(x),np.abs(y))/(1+np.minimum(np.abs(x),np.abs(y)))
    return x+y+gamma*ov*(rd*y-x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode=mode),C,mode=mode)-recombine(A,recombine(B,C,mode=mode),mode=mode)

def h4(A,B,C,D,mode="nonlinear"):
    return recombine(recombine(recombine(A,B,mode=mode),C,mode=mode),D,mode=mode)-recombine(A,recombine(B,recombine(C,D,mode=mode),mode=mode),mode=mode)

def mat_rank(cols,tol=1e-9):
    return int(np.linalg.matrix_rank(np.stack(cols,axis=1),tol=tol))

def residual_to_span(v,basis):
    B=np.stack(basis,axis=1)
    c=np.linalg.pinv(B)@v
    pred=B@c
    res=v-pred
    return res,float(np.linalg.norm(res))

def normalize(v):
    n=np.linalg.norm(v)
    return v if n<EPS else v/n

def make_sector(i,j,dim=12,mode="nonlinear",seed_shift=0,operator_variant="baseline"):
    a=np.linspace(0,2*np.pi,dim,endpoint=False)
    branches=[]
    for k in range(4):
        phase=.37*i+.29*j+.63*k+.031*seed_shift
        v=np.sin((k+1)*a+phase)
        v+=.35*np.cos((k+2)*a-.21*i+.17*j+.047*seed_shift)
        center=(2*k+i+2*j+seed_shift)%dim
        bump=np.zeros(dim)
        bump[center]=1.0
        bump[(center+1)%dim]=.55
        bump[(center-1)%dim]=.35
        if operator_variant=="rough_branch":
            bump[(center+2)%dim]=.22
            v += .08*np.sin((k+3)*a + .4*i - .2*j)
        v+=.55*bump
        branches.append(normalize(v))
    B=branches
    O3=[assoc3(B[0],B[1],B[2],mode),assoc3(B[0],B[1],B[3],mode),assoc3(B[0],B[2],B[3],mode),assoc3(B[1],B[2],B[3],mode)]
    H4=h4(B[0],B[1],B[2],B[3],mode)
    H4p,H4pn=residual_to_span(H4,B+O3)
    return {
        "B":B,"O3":O3,"H4":H4,"H4_perp":H4p,"H4_perp_norm":H4pn,
        "branch_norm_mean":float(np.mean([np.linalg.norm(b) for b in B])),
        "O3_norm_mean":float(np.mean([np.linalg.norm(o) for o in O3])),
        "O3_norm_max":float(np.max([np.linalg.norm(o) for o in O3])),
        "rank_B":mat_rank(B),
        "rank_B_O3":mat_rank(B+O3),
        "rank_B_O3_H4":mat_rank(B+O3+[H4]),
    }

def natural_transport(P,Q):
    BP=np.stack(P["B"],axis=1)
    BQ=np.stack(Q["B"],axis=1)
    return BQ@np.linalg.pinv(BP)

def op_faithfulness_defect(T,P,Q,mode="nonlinear"):
    G=P["B"]+P["O3"]
    vals=[]
    for a in range(len(G)):
        for b in range(a+1,len(G)):
            vals.append(np.linalg.norm(T@recombine(G[a],G[b],mode=mode)-recombine(T@G[a],T@G[b],mode=mode)))
    return float(np.mean(vals)),float(np.max(vals))

def loop_transport(Ts):
    T=np.eye(Ts[0].shape[0])
    for A in Ts:
        T=A@T
    return T

def loop_defect(loop,sectors,transports,mode="nonlinear"):
    p0=loop[0]
    Ts=[]; em=[]; ex=[]
    for a,b in zip(loop[:-1],loop[1:]):
        T=transports[(a,b)]
        Ts.append(T)
        mn,mx=op_faithfulness_defect(T,sectors[a],sectors[b],mode)
        em.append(mn); ex.append(mx)
    Tl=loop_transport(Ts)
    S=sectors[p0]
    vecs=S["B"]+S["O3"]+[S["H4_perp"]]
    defects=[np.linalg.norm(Tl@v-v) for v in vecs]
    return {
        "loop_defect_mean":float(np.mean(defects)),
        "loop_defect_max":float(np.max(defects)),
        "edge_faithfulness_defect_mean":float(np.mean(em)),
        "edge_faithfulness_defect_max":float(np.max(ex)),
        "H4_perp_norm":float(S["H4_perp_norm"]),
        "O3_norm_mean":float(S["O3_norm_mean"]),
        "O3_norm_max":float(S["O3_norm_max"]),
        "branch_norm_mean":float(S["branch_norm_mean"]),
        "rank_lift_H4":int(S["rank_B_O3_H4"]-S["rank_B_O3"]),
    }

def build_dataset(mode="nonlinear",ngrid=6,dim=12,seed_shift=0,operator_variant="baseline"):
    sectors={(i,j):make_sector(i,j,dim,mode,seed_shift,operator_variant) for i in range(ngrid) for j in range(ngrid)}
    transports={}
    for i in range(ngrid):
        for j in range(ngrid):
            p=(i,j)
            for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
                if q in sectors:
                    transports[(p,q)]=natural_transport(sectors[p],sectors[q])
    rows=[]
    for i in range(ngrid-1):
        for j in range(ngrid-1):
            loops=[
                [(i,j),(i+1,j),(i+1,j+1),(i,j+1),(i,j)],
                [(i,j),(i,j+1),(i+1,j+1),(i+1,j),(i,j)]
            ]
            for loop in loops:
                row=loop_defect(loop,sectors,transports,mode)
                row.update({"mode":mode,"ngrid":ngrid,"dim":dim,"seed_shift":seed_shift,"operator_variant":operator_variant})
                rows.append(row)
    return pd.DataFrame(rows)

def standardize(X):
    X=np.asarray(X,float)
    mu=X.mean(axis=0)
    sd=X.std(axis=0)
    sd[sd<EPS]=1.0
    return (X-mu)/sd

def fit_r2(y,X):
    y=np.asarray(y,float)
    X=standardize(np.asarray(X,float))
    X=np.c_[np.ones(len(X)),X]
    c=np.linalg.pinv(X)@y
    pred=X@c
    ssr=float(np.sum((y-pred)**2))
    sst=float(np.sum((y-y.mean())**2))
    return 0.0 if sst<EPS else float(1-ssr/sst)

def corr(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

configs=[]
for dim in [10,12,14]:
    for ngrid in [5,6]:
        for seed_shift in range(4):
            configs.append(("nonlinear",ngrid,dim,seed_shift,"baseline"))
for dim in [12,14]:
    for seed_shift in range(3):
        configs.append(("nonlinear",6,dim,seed_shift,"rough_branch"))
configs.append(("linear",6,12,0,"baseline"))

all_dfs=[]
for cfg in configs:
    all_dfs.append(build_dataset(*cfg))
df=pd.concat(all_dfs,ignore_index=True)
df.to_csv(OUT/"v1688_11_gammaR_refinement_rows.csv",index=False)

lower_cols=["branch_norm_mean","O3_norm_mean","O3_norm_max","edge_faithfulness_defect_mean","edge_faithfulness_defect_max"]
full_cols=lower_cols+["H4_perp_norm"]

summary=[]
for keys,sub in df.groupby(["mode","ngrid","dim","seed_shift","operator_variant"]):
    mode,ngrid,dim,seed_shift,variant=keys
    y=sub["loop_defect_mean"].values
    r2_lower=fit_r2(y,sub[lower_cols].values)
    r2_full=fit_r2(y,sub[full_cols].values)
    summary.append({
        "mode":mode,"ngrid":int(ngrid),"dim":int(dim),"seed_shift":int(seed_shift),"operator_variant":variant,
        "loop_count":int(len(sub)),
        "corr_H4perp_loop_defect":corr(sub.H4_perp_norm,y),
        "corr_O3mean_loop_defect":corr(sub.O3_norm_mean,y),
        "r2_lower":r2_lower,
        "r2_full":r2_full,
        "delta_r2_H4perp":r2_full-r2_lower,
        "mean_loop_defect":float(np.mean(y)),
        "rank_lift_rate":float(np.mean(sub.rank_lift_H4>0))
    })
summ=pd.DataFrame(summary)
summ.to_csv(OUT/"v1688_11_summary.csv",index=False)

nonlin=summ[summ["mode"]=="nonlinear"]
linear=summ[summ["mode"]=="linear"]

mean_delta=float(nonlin.delta_r2_H4perp.mean())
median_delta=float(nonlin.delta_r2_H4perp.median())
min_delta=float(nonlin.delta_r2_H4perp.min())
positive_rate=float(np.mean(nonlin.delta_r2_H4perp>0))
mean_h4_corr=float(nonlin.corr_H4perp_loop_defect.mean())
mean_o3_corr=float(nonlin.corr_O3mean_loop_defect.mean())
mean_lower_r2=float(nonlin.r2_lower.mean())
mean_full_r2=float(nonlin.r2_full.mean())

if mean_delta>0.04 and positive_rate>=0.85 and min_delta>-0.02:
    verdict="GAMMAR_REFINEMENT_H4_CORRECTION_HARDENED"
elif mean_delta>0.015 and positive_rate>=0.70:
    verdict="GAMMAR_REFINEMENT_H4_CORRECTION_PARTIAL"
else:
    verdict="GAMMAR_REFINEMENT_H4_CORRECTION_WEAK"

result={
    "document_id":"V1688_11_GAMMAR_REFINEMENT_NULL_HARDENING",
    "status":"completed",
    "verdict":verdict,
    "nonlinear_config_count":int(len(nonlin)),
    "mean_delta_r2_H4perp":mean_delta,
    "median_delta_r2_H4perp":median_delta,
    "min_delta_r2_H4perp":min_delta,
    "positive_delta_rate":positive_rate,
    "mean_corr_H4perp_loop_defect":mean_h4_corr,
    "mean_corr_O3_loop_defect":mean_o3_corr,
    "mean_lower_r2":mean_lower_r2,
    "mean_full_r2":mean_full_r2,
    "linear_control":linear.to_dict(orient="records"),
    "outputs":{
        "rows":str(OUT/"v1688_11_gammaR_refinement_rows.csv"),
        "summary":str(OUT/"v1688_11_summary.csv")
    },
    "claim_boundary":"Gamma_R refinement/null-hardening toy test only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
(OUT/"v1688_11_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_11_GAMMAR_REFINEMENT_NULL_HARDENING_REPORT.md").write_text("# V1688.11 — Gamma_R Refinement and Null-Hardening\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
