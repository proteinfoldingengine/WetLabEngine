# V1688.11 Gamma_R Refinement and Null-Hardening

Tests whether H4_perp delta R2 survives graph/dimension/operator refinement. No GR claim.
