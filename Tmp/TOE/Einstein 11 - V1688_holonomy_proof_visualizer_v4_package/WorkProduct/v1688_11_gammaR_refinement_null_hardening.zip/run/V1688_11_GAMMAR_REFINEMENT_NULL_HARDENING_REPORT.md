# V1688.11 — Gamma_R Refinement and Null-Hardening

```json
{
  "document_id": "V1688_11_GAMMAR_REFINEMENT_NULL_HARDENING",
  "status": "completed",
  "verdict": "GAMMAR_REFINEMENT_H4_CORRECTION_HARDENED",
  "nonlinear_config_count": 30,
  "mean_delta_r2_H4perp": 0.12875457001535479,
  "median_delta_r2_H4perp": 0.10324611569509212,
  "min_delta_r2_H4perp": 0.02024019073806327,
  "positive_delta_rate": 1.0,
  "mean_corr_H4perp_loop_defect": 0.3566329283671869,
  "mean_corr_O3_loop_defect": 0.7486171018756852,
  "mean_lower_r2": 0.6399510560031375,
  "mean_full_r2": 0.7687056260184922,
  "linear_control": [
    {
      "mode": "linear",
      "ngrid": 6,
      "dim": 12,
      "seed_shift": 0,
      "operator_variant": "baseline",
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.0,
      "corr_O3mean_loop_defect": 0.0,
      "r2_lower": 0.0,
      "r2_full": 0.0,
      "delta_r2_H4perp": 0.0,
      "mean_loop_defect": 6.469946154652467e-16,
      "rank_lift_rate": 0.0
    }
  ],
  "outputs": {
    "rows": "/mnt/data/v1688_11_gammaR_refinement_null_hardening_outputs/v1688_11_gammaR_refinement_rows.csv",
    "summary": "/mnt/data/v1688_11_gammaR_refinement_null_hardening_outputs/v1688_11_summary.csv"
  },
  "claim_boundary": "Gamma_R refinement/null-hardening toy test only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
```
