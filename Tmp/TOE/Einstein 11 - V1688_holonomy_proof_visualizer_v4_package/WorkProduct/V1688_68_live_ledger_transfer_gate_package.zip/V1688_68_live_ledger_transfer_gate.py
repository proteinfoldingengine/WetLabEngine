#!/usr/bin/env python3
"""V1688.68 — Live-Ledger Transfer Gate
Audits availability of v1687_ordered_slice_metrics and freezes transfer basis.
No substitute ledger is generated.
"""
from pathlib import Path
import json, csv, hashlib

BASE = Path('/mnt/data')
OUT = BASE / 'V1688_68_outputs'
OUT.mkdir(exist_ok=True)
PATTERNS = ['v1687','ordered_slice','ordered-slice','slice_metrics','live_ledger']
EXCLUDED = ['availability_audit','transfer_audit','report','summary','package','harness','native','v1688_55','v1688_67']

def sha16(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()[:16]

def main():
    candidates=[]
    for p in BASE.rglob('*'):
        if p.is_file() and any(x in p.name.lower() for x in PATTERNS):
            candidates.append(p)
    ledger_candidates=[p for p in candidates if not any(k in p.name.lower() for k in EXCLUDED)]
    rows=[]
    for p in candidates:
        rows.append({
            'path': str(p), 'name': p.name, 'size_bytes': p.stat().st_size,
            'excluded_as_prior_artifact': any(k in p.name.lower() for k in EXCLUDED),
            'accepted_as_live_ledger': p in ledger_candidates,
            'sha256': sha16(p),
        })
    with open(OUT/'V1688_68_live_ledger_search_audit.csv','w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ['path','name','size_bytes','excluded_as_prior_artifact','accepted_as_live_ledger','sha256'])
        w.writeheader(); w.writerows(rows)
    summary={
        'document_id':'V1688_68_LIVE_LEDGER_TRANSFER_GATE',
        'verdict':'LIVE_LEDGER_TRANSFER_BLOCKED_FROZEN_BASIS_PRESERVED',
        'accepted_live_ledger_candidates':len(ledger_candidates),
        'blocked': len(ledger_candidates)==0,
    }
    (OUT/'V1688_68_SUMMARY.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
