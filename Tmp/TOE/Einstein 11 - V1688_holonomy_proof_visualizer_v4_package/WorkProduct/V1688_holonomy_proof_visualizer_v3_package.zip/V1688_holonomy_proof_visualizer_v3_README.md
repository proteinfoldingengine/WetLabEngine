# V1688 Holonomy Proof Visualizer V3 — Colab Ready

This version includes both GIF and MP4 output.

Run the notebook cell or the Python script. It will generate:

- static proof PNG
- animated GIF
- animated MP4
- metrics JSON
- node/edge/cycle/flux/continuity CSVs

Science boundary: the displayed curve is a visualization of the discrete provenance cycle; the proof object is the ordered edge product. No Kabsch/Gramian alignment, no reversible full-matrix requirement.
