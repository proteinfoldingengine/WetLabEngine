
# V1688 Holonomy Proof Visualizer V3 — Colab one-cell runnable
# Outputs BOTH GIF and MP4.
#
# Purpose:
#   Show native directional holonomy being generated edge-by-edge over an explicit
#   provenance cycle, with L3/O3, L4/H4_perp, correction mode Z, native transport,
#   cycle product, and retained-order incidence continuity.
#
# Boundary:
#   This is a finite retained-flow proof visualization. It does not claim GR,
#   Einstein equations, Riemann curvature, physical spacetime, or reversible
#   geometric holonomy.
#
# Core equations:
#   T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
#   c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
#   H_cycle^dir = Π_loop c_pq
#   defect = |1 − H_cycle^dir| · mean(|C_corr|)
#
# No Kabsch/Gramian/Procrustes alignment.
# No reversible full-matrix holonomy requirement.
# No fitted counterterms.
# No primitive time coordinate.

import os, json, ast, math, warnings, shutil
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401

warnings.filterwarnings("ignore")

OUT = Path("V1688_holonomy_proof_visualizer_v3_outputs")
OUT.mkdir(exist_ok=True)

SEED = 168863
N_NODES = 8
DIM = 4

BG = "#05070d"
PANEL = "#0b1020"
GRID = "#1f3554"
TEXT = "#f4f7ff"
MUTED = "#aab5c5"
CYAN = "#4ee7ff"
BLUE = "#3b82f6"
GOLD = "#ffd65a"
ORANGE = "#ffb347"
VIOLET = "#b877ff"
MAGENTA = "#ff6bd6"
RED = "#ff6b6b"
GREEN = "#7ef29a"
WHITE = "#ffffff"

def parse_vec(x):
    if isinstance(x, np.ndarray):
        return x.astype(float)
    if isinstance(x, list):
        return np.array(x, dtype=float)
    if isinstance(x, str):
        return np.array(ast.literal_eval(x), dtype=float)
    raise TypeError(type(x))

def unit(v, eps=1e-12):
    v = np.asarray(v, dtype=float)
    n = np.linalg.norm(v)
    return np.zeros_like(v) if n < eps else v / n

def roll(v):
    return np.roll(np.asarray(v, dtype=float), 1)

def native_transport(dx, q_state, gamma):
    dx = np.asarray(dx, dtype=float)
    q_state = np.asarray(q_state, dtype=float)
    return dx + gamma * (roll(dx) * q_state - dx * roll(q_state))

def directional_scalar(Zp, Zq, q_state, gamma):
    TpZ = native_transport(Zp, q_state, gamma)
    denom = (np.linalg.norm(TpZ) * np.linalg.norm(Zq)) + 1e-12
    c = float(np.dot(Zq, TpZ) / denom)
    return c, TpZ

def maybe_load_existing():
    # Works in Colab if the user uploads the V2/V1688 CSVs, and also in this sandbox.
    candidates = [
        ("V1688_v2_nodes.csv", "V1688_v2_edges.csv"),
        ("/mnt/data/V1688_v2_nodes.csv", "/mnt/data/V1688_v2_edges.csv"),
        ("V1688_holonomy_proof_nodes.csv", "V1688_holonomy_proof_edges.csv"),
        ("/mnt/data/V1688_holonomy_proof_nodes(1).csv", "/mnt/data/V1688_holonomy_proof_edges(1).csv"),
    ]
    for nf, ef in candidates:
        if Path(nf).exists() and Path(ef).exists():
            nodes = pd.read_csv(nf)
            edges = pd.read_csv(ef)
            required_node = {"node_id","x","y","z","C_corr","state","Z","O3","H4_perp"}
            required_edge = {"from_node","to_node","gamma_pq"}
            if required_node.issubset(nodes.columns) and required_edge.issubset(edges.columns):
                return nodes, edges, "loaded_uploaded_or_prior_proof_object"
    return None, None, "generated_deterministic_proof_object"

def generate_deterministic_proof():
    rng = np.random.default_rng(SEED)
    theta = np.linspace(0, 2*np.pi, N_NODES, endpoint=False)

    radius = 2.75 + 0.28*np.sin(3*theta + 0.3)
    x = radius*np.cos(theta)
    y = radius*np.sin(theta)
    z = 0.65*np.sin(2*theta + 0.6)

    states, O3, H4, Z, Ccorr = [], [], [], [], []
    for i in range(N_NODES):
        s = unit(rng.normal(size=DIM))
        o = unit(roll(s) - np.roll(s, -1))  # L3/O3-like retained associator direction.
        h_raw = rng.normal(size=DIM) + 0.20*np.roll(o, 1)
        for b in [s, o]:
            h_raw = h_raw - np.dot(h_raw, b)*b
        h = unit(h_raw)                    # L4/H4_perp-like independent residual.
        zz = unit(0.35*o + 1.0*h)           # Retained correction mode, H4-dominant.
        cc = float(0.55 + 0.20*np.sin(theta[i] + 0.7) + 0.06*rng.normal())

        states.append(s); O3.append(o); H4.append(h); Z.append(zz); Ccorr.append(cc)

    nodes = pd.DataFrame({
        "node_id": [f"p{i}" for i in range(N_NODES)],
        "x": x, "y": y, "z": z,
        "C_corr": Ccorr,
        "state": [v.tolist() for v in states],
        "Z": [v.tolist() for v in Z],
        "O3": [v.tolist() for v in O3],
        "H4_perp": [v.tolist() for v in H4],
    })

    edges = []
    for i in range(N_NODES):
        j = (i + 1) % N_NODES
        gamma = float(0.24*np.tanh(np.dot(states[i], states[j])) + 0.10*np.sin(theta[i]-theta[j]))
        edges.append({"from_node": f"p{i}", "to_node": f"p{j}", "gamma_pq": gamma})
    return nodes, pd.DataFrame(edges)

nodes, edges, source_mode = maybe_load_existing()
if nodes is None:
    nodes, edges = generate_deterministic_proof()

# Parse and compute proof quantities.
pos = {r["node_id"]: np.array([float(r["x"]), float(r["y"]), float(r["z"])]) for _, r in nodes.iterrows()}
states = {r["node_id"]: parse_vec(r["state"]) for _, r in nodes.iterrows()}
Zs = {r["node_id"]: parse_vec(r["Z"]) for _, r in nodes.iterrows()}
O3s = {r["node_id"]: parse_vec(r["O3"]) for _, r in nodes.iterrows()}
H4s = {r["node_id"]: parse_vec(r["H4_perp"]) for _, r in nodes.iterrows()}
Ccorr = {r["node_id"]: float(r["C_corr"]) for _, r in nodes.iterrows()}

edge_rows, step_rows = [], []
partial = 1.0
mean_abs_C = float(np.mean(np.abs(list(Ccorr.values()))))

for k, er in edges.iterrows():
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c, TpZ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    partial *= c
    defect = abs(1 - partial) * mean_abs_C
    edge_rows.append({
        "from_node": p, "to_node": q, "gamma_pq": gamma, "c_pq": c,
        "transport_norm": float(np.linalg.norm(TpZ)),
        "Z_alignment_raw": float(np.dot(Zs[q], TpZ)),
    })
    step_rows.append({
        "step": k+1, "from_node": p, "to_node": q,
        "gamma_pq": gamma, "c_pq": c,
        "H_cycle_partial": partial,
        "directional_defect_partial": defect,
        "transport_norm": float(np.linalg.norm(TpZ)),
        "Z_alignment_raw": float(np.dot(Zs[q], TpZ)),
    })

edges = pd.DataFrame(edge_rows)
steps = pd.DataFrame(step_rows)
H_final = float(steps["H_cycle_partial"].iloc[-1])
defect_final = float(abs(1 - H_final) * mean_abs_C)

# Reverse diagnostic, not assumed inverse.
reverse_product = 1.0
for _, er in edges.iloc[::-1].iterrows():
    p, q = er["to_node"], er["from_node"]
    gamma = float(er["gamma_pq"])
    c_rev, _ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    reverse_product *= c_rev
reverse_defect = float(abs(1 - reverse_product) * mean_abs_C)
orientation_asym = float(abs(defect_final - reverse_defect))

# Incidence continuity.
continuity = {nid: 0.0 for nid in nodes["node_id"]}
flux_rows = []
for _, er in edges.iterrows():
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c_fwd, _ = directional_scalar(Zs[p], Zs[q], states[q], gamma)
    c_rev, _ = directional_scalar(Zs[q], Zs[p], states[p], gamma)
    F_pq = c_fwd * Ccorr[p]
    F_qp = c_rev * Ccorr[q]
    J = 0.5 * (F_pq - F_qp)
    continuity[p] -= J
    continuity[q] += J
    flux_rows.append({"from_node": p, "to_node": q, "c_pq": c_fwd, "c_qp": c_rev, "F_pq": F_pq, "F_qp": F_qp, "J_pq": J})
flux_df = pd.DataFrame(flux_rows)
continuity_df = pd.DataFrame([{"node_id": k, "continuity_residual": v} for k, v in continuity.items()])

metrics = {
    "source_mode": source_mode,
    "H_cycle_dir": H_final,
    "native_directional_cycle_defect": defect_final,
    "mean_abs_C_corr": mean_abs_C,
    "reverse_H_cycle_dir": reverse_product,
    "reverse_directional_cycle_defect": reverse_defect,
    "orientation_asymmetry_abs": orientation_asym,
    "edge_count": int(len(edges)),
    "node_count": int(len(nodes)),
    "max_abs_continuity_residual": float(np.max(np.abs(list(continuity.values())))),
    "interpretation": "Directed native holonomy is generated edge-by-edge by native recombination transport acting on the retained correction mode Z over an explicit provenance cycle."
}

nodes.to_csv(OUT / "V1688_v3_nodes.csv", index=False)
edges.to_csv(OUT / "V1688_v3_edges.csv", index=False)
steps.to_csv(OUT / "V1688_v3_cycle_steps.csv", index=False)
flux_df.to_csv(OUT / "V1688_v3_antisymmetric_flux.csv", index=False)
continuity_df.to_csv(OUT / "V1688_v3_continuity.csv", index=False)
with open(OUT / "V1688_v3_metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)

# -----------------------------
# Drawing helpers
# -----------------------------
def setup_3d(ax, title=None):
    ax.set_facecolor(BG)
    ax.grid(False)
    for pane in [ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane]:
        pane.set_alpha(0.06)
        pane.set_facecolor(GRID)
        pane.set_edgecolor(CYAN)
    ax.tick_params(colors=MUTED, labelsize=7)
    ax.set_xlabel("display x", color=MUTED, labelpad=-2)
    ax.set_ylabel("display y", color=MUTED, labelpad=-2)
    ax.set_zlabel("display z", color=MUTED, labelpad=-2)
    if title:
        ax.set_title(title, color=TEXT, fontsize=14, pad=8)
    ax.view_init(elev=25, azim=-58)

def draw_arrow3d(ax, start, vec, color, lw=2.0, alpha=1.0, label=None):
    start = np.asarray(start)
    vec = np.asarray(vec)
    ax.quiver(start[0], start[1], start[2], vec[0], vec[1], vec[2],
              color=color, linewidth=lw, alpha=alpha, arrow_length_ratio=0.24, normalize=False)
    if label:
        end = start + vec
        ax.text(end[0], end[1], end[2], label, color=color, fontsize=8)

def draw_cycle(ax, active_step=None, trail_steps=None, show_vectors=True, show_display_curve=True):
    ids = list(nodes["node_id"])
    P = np.array([pos[nid] for nid in ids])

    # Display curve: piecewise-dense interpolation only; proof uses discrete edge product.
    if show_display_curve:
        PP = np.vstack([P, P[0]])
        dense = []
        for i in range(len(PP)-1):
            for t in np.linspace(0, 1, 12, endpoint=False):
                dense.append((1-t)*PP[i] + t*PP[i+1])
        dense.append(PP[-1])
        dense = np.array(dense)
        ax.plot(dense[:,0], dense[:,1], dense[:,2], color=GOLD, lw=1.2, alpha=0.28)

    for i, er in edges.iterrows():
        p, q = er["from_node"], er["to_node"]
        a, b = pos[p], pos[q]
        col, lw, alpha = GOLD, 2.0, 0.70
        if active_step is not None and i == active_step:
            col, lw, alpha = WHITE, 5.0, 1.0
        elif trail_steps is not None and i in trail_steps:
            col, lw, alpha = GREEN, 3.0, 0.95

        ax.plot([a[0], b[0]], [a[1], b[1]], [a[2], b[2]], color=col, lw=lw, alpha=alpha)
        mid = 0.55*a + 0.45*b
        draw_arrow3d(ax, mid, unit(b-a)*0.18, col, lw=lw, alpha=alpha)

    ax.scatter(P[:,0], P[:,1], P[:,2], s=75, c=CYAN, edgecolors=WHITE, linewidths=0.7, alpha=0.98)
    for nid in ids:
        p = pos[nid]
        ax.text(p[0]+0.04, p[1]+0.04, p[2]+0.08, nid, color=TEXT, fontsize=8)

    if show_vectors:
        for nid in ids:
            p = pos[nid]
            o = unit(O3s[nid][:3]) * 0.34
            h = unit(H4s[nid][:3]) * 0.37
            z = unit(Zs[nid][:3]) * 0.52
            draw_arrow3d(ax, p, o, ORANGE, lw=1.4, alpha=0.45)   # L3/O3
            draw_arrow3d(ax, p, h, VIOLET, lw=1.6, alpha=0.60)   # L4/H4_perp
            draw_arrow3d(ax, p, z, MAGENTA, lw=2.5, alpha=0.94)  # correction mode

def draw_equation_card(ax, active=None):
    ax.set_facecolor(PANEL); ax.axis("off")
    ax.text(0.03, 0.94, "Native directional holonomy proof", color=CYAN, fontsize=15, family="monospace", va="top")
    if active is None:
        active = len(edges)-1
    er = edges.iloc[active]
    st = steps.iloc[active]
    lines = [
        ("Local algebra", "G_p = span(B_p, O3_p, H4_perp_p)", GOLD),
        ("Native transport", "T_pq(dx) = dx + γ_pq[roll(dx)⊙q − dx⊙roll(q)]", GOLD),
        ("Correction mode", "Z_p = retained Gamma_R/H4 direction", VIOLET),
        ("Active edge", f"{er['from_node']} → {er['to_node']}    γ={er['gamma_pq']:+.5f}", WHITE),
        ("Edge scalar", f"c_pq = {er['c_pq']:+.6f}", CYAN),
        ("Partial product", f"H_cycle^dir = {st['H_cycle_partial']:+.6e}", CYAN),
        ("Partial defect", f"|1 − H|·mean(|C_corr|) = {st['directional_defect_partial']:.6f}", RED),
    ]
    y = 0.78
    for title, body, col in lines:
        ax.text(0.03, y, title, color=col, fontsize=10.5, family="monospace")
        ax.text(0.03, y-0.045, body, color=TEXT, fontsize=9.1, family="monospace")
        y -= 0.115
    ax.text(0.03, 0.045, "No Kabsch/Gramian • No reversible full-matrix requirement • discrete edge product",
            color="#9cecff", fontsize=8.5, family="monospace")

def draw_accumulation(ax, upto=None):
    ax.set_facecolor(PANEL)
    if upto is None:
        upto = len(steps)-1
    ax.plot(steps["step"], steps["directional_defect_partial"], color=GRID, lw=1.2, alpha=0.55)
    d = steps.iloc[:upto+1]
    ax.plot(d["step"], d["directional_defect_partial"], color=CYAN, marker="o", lw=2.1)
    ax.scatter([d["step"].iloc[-1]], [d["directional_defect_partial"].iloc[-1]], color=ORANGE, s=70, zorder=10)
    ax.set_title("Holonomy defect accumulates edge-by-edge", color=TEXT, fontsize=11)
    ax.set_xlabel("cycle step", color=MUTED)
    ax.set_ylabel("partial defect", color=MUTED)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(alpha=0.12, color=GRID)
    for sp in ax.spines.values():
        sp.set_color(CYAN); sp.set_alpha(0.8)

def draw_edge_ledger(ax, upto=None):
    ax.set_facecolor(PANEL)
    if upto is None:
        upto = len(steps)-1
    colors = []
    for i, v in enumerate(steps["c_pq"]):
        if i <= upto:
            colors.append(GREEN if v >= 0 else RED)
        else:
            colors.append(GRID)
    ax.bar(steps["step"], steps["c_pq"], color=colors, alpha=0.88)
    ax.axhline(0, color=WHITE, lw=0.8, alpha=0.55)
    ax.set_title("Edge-product ledger: c_pq values whose product generates H_cycle^dir", color=TEXT, fontsize=11)
    ax.set_xlabel("cycle step", color=MUTED)
    ax.set_ylabel("c_pq", color=MUTED)
    ax.tick_params(colors=MUTED, labelsize=8)
    ax.grid(alpha=0.10, color=GRID)
    for sp in ax.spines.values():
        sp.set_color(CYAN); sp.set_alpha(0.75)

def draw_continuity(ax):
    ax.set_facecolor(PANEL); ax.axis("off")
    ax.text(0.04, 0.92, "Retained-order incidence continuity", color=CYAN, fontsize=12, family="monospace")
    ax.text(0.04, 0.78, "F_pq = c_pq · C_corr(p)", color=TEXT, fontsize=9.2, family="monospace")
    ax.text(0.04, 0.66, "J_pq = 1/2 · (F_pq − F_qp)", color=TEXT, fontsize=9.2, family="monospace")
    ax.text(0.04, 0.54, "continuity(p) = incoming J − outgoing J", color=TEXT, fontsize=9.2, family="monospace")
    vals = continuity_df["continuity_residual"].values
    maxv = max(np.max(np.abs(vals)), 1e-9)
    ax.text(0.04, 0.38, "node residual gauge", color=GOLD, fontsize=9.5, family="monospace")
    for i, row in continuity_df.iterrows():
        x0 = 0.13 + i*0.095
        v = float(row["continuity_residual"]) / maxv
        col = RED if v > 0 else BLUE
        ax.plot([x0, x0], [0.18, 0.18 + 0.15*v], color=col, lw=4, solid_capstyle="round")
        ax.text(x0-0.015, 0.08, row["node_id"], color=MUTED, fontsize=7, rotation=45)

def draw_metrics(ax):
    ax.set_facecolor(PANEL); ax.axis("off")
    ax.text(0.04, 0.92, "Computed metrics", color=GOLD, fontsize=12, family="monospace")
    lines = [
        f"source: {source_mode}",
        f"H_cycle^dir = {H_final:+.6e}",
        f"native defect = {defect_final:.6f}",
        f"reverse diagnostic = {reverse_defect:.6f}",
        f"|forward − reverse| = {orientation_asym:.6e}",
        f"mean(|C_corr|) = {mean_abs_C:.6f}",
    ]
    y = 0.78
    for line in lines:
        ax.text(0.04, y, line, color=TEXT, fontsize=8.8, family="monospace")
        y -= 0.10
    ax.text(0.04, 0.08, "The displayed curve is visualization only;\nproof object is Π_loop c_pq over discrete edges.",
            color="#9cecff", fontsize=8.2, family="monospace")

# -----------------------------
# Static plate: hero topology + mechanism cards
# -----------------------------
fig = plt.figure(figsize=(18, 10), facecolor=BG)
gs = fig.add_gridspec(3, 4, width_ratios=[1.68, 0.95, 0.95, 0.95],
                      height_ratios=[1.05, 0.95, 0.75], wspace=0.22, hspace=0.22)

ax3d = fig.add_subplot(gs[:, 0], projection="3d")
setup_3d(ax3d, "3D L3/L4 provenance cycle topology")
draw_cycle(ax3d, active_step=None, trail_steps=set(range(len(edges))), show_vectors=True)
ax3d.text2D(0.02, 0.035,
            "Gold = explicit provenance cycle | Orange = L3/O3 | Violet = L4/H4_perp | Magenta = correction mode Z\n"
            "Smoothed line is display-only; proof uses ordered edge product Π c_pq.",
            transform=ax3d.transAxes, color="#9cecff", fontsize=8.2)

axEq = fig.add_subplot(gs[0,1:3])
draw_equation_card(axEq, active=len(edges)-1)

axAccum = fig.add_subplot(gs[0,3])
draw_accumulation(axAccum, upto=len(edges)-1)

axCont = fig.add_subplot(gs[1,1])
draw_continuity(axCont)

axMetrics = fig.add_subplot(gs[1,2])
draw_metrics(axMetrics)

axInterp = fig.add_subplot(gs[1,3])
axInterp.set_facecolor(PANEL); axInterp.axis("off")
axInterp.text(0.04, 0.92, "Interpretation", color=GOLD, fontsize=12, family="monospace")
interp = (
    "The model does not produce reversible geometric holonomy as a primitive.\n\n"
    "It produces directed native holonomy of the retained correction mode Z.\n\n"
    "That holonomy is generated edge-by-edge by native recombination transport over an explicit provenance cycle."
)
axInterp.text(0.04, 0.76, interp, color=TEXT, fontsize=9.2, family="monospace", va="top", linespacing=1.55)
axInterp.text(0.04, 0.08, "Boundary: finite retained-flow proof object, not a GR/Einstein derivation.",
              color="#9cecff", fontsize=8.1, family="monospace")

axLedger = fig.add_subplot(gs[2,1:])
draw_edge_ledger(axLedger, upto=len(edges)-1)

fig.suptitle("V1688 Native Directional Holonomy — First-Principles Proof Visualization V3", color=TEXT, fontsize=18, y=0.985)
fig.savefig(OUT / "V1688_v3_static_proof.png", dpi=180, facecolor=BG, bbox_inches="tight")
plt.close(fig)

# -----------------------------
# Animation frames
# -----------------------------
frame_paths = []
for frame_idx in range(len(edges)):
    fig = plt.figure(figsize=(15.5, 8.7), facecolor=BG)
    gs = fig.add_gridspec(2, 3, width_ratios=[1.6, 1.0, 1.0], height_ratios=[1.1, 0.9], wspace=0.24, hspace=0.24)

    ax = fig.add_subplot(gs[:,0], projection="3d")
    setup_3d(ax, "Holonomy generated around explicit provenance cycle")
    draw_cycle(ax, active_step=frame_idx, trail_steps=set(range(frame_idx+1)), show_vectors=True)

    er = edges.iloc[frame_idx]
    p, q = er["from_node"], er["to_node"]
    gamma = float(er["gamma_pq"])
    c = float(er["c_pq"])
    TpZ = native_transport(Zs[p], states[q], gamma)
    draw_arrow3d(ax, pos[q], unit(TpZ[:3])*0.68, WHITE, lw=3.3, alpha=1.0, label="T_pq Z_p")
    ax.text2D(0.02, 0.05, f"active edge: {p} → {q}\nγ={gamma:+.4f}   c_pq={c:+.4f}",
              transform=ax.transAxes, color=GOLD, fontsize=10, family="monospace")

    axEq = fig.add_subplot(gs[0,1])
    draw_equation_card(axEq, active=frame_idx)

    axAccum = fig.add_subplot(gs[0,2])
    draw_accumulation(axAccum, upto=frame_idx)

    axLedger = fig.add_subplot(gs[1,1:])
    draw_edge_ledger(axLedger, upto=frame_idx)

    fig.suptitle("Directed native holonomy being generated — V1688 V3", color=TEXT, fontsize=16)
    fpath = OUT / f"frame_{frame_idx:03d}.png"
    fig.savefig(fpath, dpi=135, facecolor=BG, bbox_inches="tight")
    plt.close(fig)
    frame_paths.append(fpath)

# GIF + MP4 creation.
gif_path = OUT / "V1688_v3_holonomy_animation.gif"
mp4_path = OUT / "V1688_v3_holonomy_animation.mp4"

gif_ok = False
mp4_ok = False
try:
    from PIL import Image
    imgs = [Image.open(p).convert("P", palette=Image.ADAPTIVE) for p in frame_paths]
    imgs[0].save(gif_path, save_all=True, append_images=imgs[1:], duration=950, loop=0)
    gif_ok = gif_path.exists()
except Exception as e:
    print("GIF creation failed:", repr(e))

try:
    import imageio.v2 as imageio
    imgs = [imageio.imread(str(p)) for p in frame_paths]
    imageio.mimsave(str(mp4_path), imgs, fps=1.2, macro_block_size=1)
    mp4_ok = mp4_path.exists()
except Exception as e:
    print("MP4 creation via imageio failed:", repr(e))
    try:
        # Colab fallback: install imageio-ffmpeg if missing.
        import sys, subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "-q", "install", "imageio-ffmpeg"])
        import imageio.v2 as imageio
        imgs = [imageio.imread(str(p)) for p in frame_paths]
        imageio.mimsave(str(mp4_path), imgs, fps=1.2, macro_block_size=1)
        mp4_ok = mp4_path.exists()
    except Exception as e2:
        print("MP4 fallback failed:", repr(e2))

# README output.
readme = f"""# V1688 Holonomy Proof Visualizer V3

Colab one-cell runnable proof visualization. Generates both GIF and MP4.

## Produced files

- V1688_v3_static_proof.png
- V1688_v3_holonomy_animation.gif
- V1688_v3_holonomy_animation.mp4
- V1688_v3_metrics.json
- CSV node/edge/step/flux/continuity tables

## Core equations

```text
T_pq(dx) = dx + gamma_pq [roll(dx) ⊙ q − dx ⊙ roll(q)]
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = Π_loop c_pq
native_directional_cycle_defect = |1 − H_cycle^dir| · mean(|C_corr|)
```

## Metrics

```json
{json.dumps(metrics, indent=2)}
```

## Boundary

The displayed curve is a visualization of the discrete provenance cycle. The proof object is the ordered edge product Π_loop c_pq.

This is a finite retained-flow proof object, not a GR/Einstein derivation.
"""
with open(OUT / "README.md", "w") as f:
    f.write(readme)

metrics["gif_created"] = bool(gif_ok)
metrics["mp4_created"] = bool(mp4_ok)
with open(OUT / "V1688_v3_metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)

print("V1688 V3 complete.")
print(json.dumps(metrics, indent=2))
print("Static:", OUT / "V1688_v3_static_proof.png")
print("GIF:", gif_path, "exists:", gif_ok)
print("MP4:", mp4_path, "exists:", mp4_ok)
