import json, zipfile
from pathlib import Path
import pandas as pd, numpy as np
ROOT=Path('/mnt/data'); OUT=ROOT/'V1688_58_outputs'
edge=pd.read_csv(OUT/'V1688_58_edge_operator_closure_audit.csv')
inv=pd.read_csv(OUT/'V1688_58_inverse_operator_audit.csv')
cyc=pd.read_csv(OUT/'V1688_58_cycle_operator_closure_audit.csv')
nodes=pd.read_csv(OUT/'V1688_58_node_operator_audit.csv')
hold=pd.read_csv(OUT/'V1688_58_operator_audit_holdout_results.csv')
corr=pd.read_csv(OUT/'V1688_58_operator_correlation_diagnostics.csv')
# Null summary: closure leakage is numerical zero because rank(G)=ambient dimension; shuffle nulls are not meaningful as correction tests.
null=pd.DataFrame([
 {'null_mode':'not_run_closure_leakage_numerically_zero','mean_closure_unique_over_Ccorr':0.0,'mean_closure_unique_over_Ccorr_exact':0.0,'reason':'operator closure leakage is ~machine precision; no positive observed gain to harden'}
])
null.to_csv(OUT/'V1688_58_operator_audit_null_results.csv', index=False)
res=[]
for r,g in nodes.groupby('resolution'):
    res.append({'resolution':r,'mean_operator_closure_leakage':float(g.operator_closure_leakage.mean()),'mean_inverse_operator_leakage':float(g.inverse_operator_leakage.mean()),'mean_roundtrip_closure_leakage':float(g.roundtrip_closure_leakage.mean()),'mean_exact_cycle_defect':float(g.exact_cycle_defect.mean()),'mean_C_corr':float(g.C_corr.mean())})
res_df=pd.DataFrame(res).sort_values('resolution')
res_df.to_csv(OUT/'V1688_58_resolution_operator_audit.csv', index=False)
mean_closure=float(edge.operator_closure_leakage.mean()); med=float(edge.operator_closure_leakage.median()); p95=float(edge.operator_closure_leakage.quantile(.95))
mean_cyc=float(cyc.cycle_mean_operator_leakage.mean()); mean_inv=float(inv.roundtrip_inverse_defect.mean()); med_inv=float(inv.roundtrip_inverse_defect.median())
summary={
 'document_id':'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT',
 'verdict':'OPERATOR_CLOSURE_PASS_REPRESENTATION_NOT_THE_FAILURE_NATIVE_OBSERVABLE_MISMATCH_REMAINS',
 'first_principles_constraints':{'no_kabsch_procrustes_gramian_transport':True,'no_fitted_counterterms':True,'no_threshold_patch':True,'no_time_primitive':True},
 'ledger_used':{'node_table':'/mnt/data/V1688_52_outputs/V1688_52_node_table.csv','edge_table':'/mnt/data/V1688_52_outputs/V1688_52_provenance_edge_table.csv','cycle_table':'/mnt/data/V1688_52_outputs/V1688_52_graph_cycle_decomposition.csv'},
 'scale':{'nodes':int(len(nodes)),'edges':int(len(edge)),'cycles':int(len(cyc))},
 'basis':{'mean_rank':float(nodes.G_rank.mean()),'min_rank':float(nodes.G_rank.min()),'mean_condition':float(nodes.G_condition.replace([np.inf,-np.inf],np.nan).mean())},
 'operator_closure':{'mean_edge_leakage':mean_closure,'median_edge_leakage':med,'p95_edge_leakage':p95,'mean_cycle_operator_leakage':mean_cyc},
 'native_inverse':{'mean_roundtrip_inverse_defect':mean_inv,'median_roundtrip_inverse_defect':med_inv},
 'model_results':{
  'mean_R2_M0':float(hold.R2_M0.mean()),
  'mean_R2_M0_Ccorr':float(hold.R2_M0_Ccorr.mean()),
  'mean_R2_M0_Ccorr_exact':float(hold.R2_M0_Ccorr_exact.mean()),
  'mean_closure_unique_over_Ccorr':float(hold.closure_unique_over_Ccorr.mean()),
  'mean_closure_unique_over_Ccorr_exact':float(hold.closure_unique_over_Ccorr_exact.mean()),
  'mean_full_audit_unique_over_Ccorr_exact':float(hold.full_audit_unique_over_Ccorr_exact.mean()),
  'positive_closure_unique_rate':float((hold.closure_unique_over_Ccorr>0).mean())},
 'key_correlation':{r.x+'__'+r.y:float(r.corr) for r in corr.itertuples(index=False) if r.x=='operator_closure_leakage' and r.y in ['weak_target','C_corr','exact_cycle_defect','h4_perp_norm','correction_loss']},
 'interpretation':'G_p is not too small in this emitted ledger; it is effectively full ambient rank, so the native matrix failure is not explained by projection leakage out of G_q. The remaining issue is not operator closure but that native matrix holonomy/invariants are not the same observable as the surviving scalar exact-cycle defect.',
 'claim_boundary':'Finite retained-flow explicit-ledger harness only; not ADM/GR/Riemann/Einstein/physical spacetime closure.',
 'next':'V1688.59 — native observable mismatch audit: compare scalar exact-cycle defect to edgewise signed projection induced by native T_pq acting on the correction direction C/Z, not to full matrix trace/determinant/Frobenius invariants.'
}
with open(OUT/'V1688_58_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)
report=f"""# V1688.58 — Operator-Level Derivation Audit

## Verdict

```text
{summary['verdict']}
```

## Question

V1688.57 failed to derive the surviving scalar exact-cycle defect from native matrix invariants. V1688.58 asked the first-principles diagnostic question:

```text
Is the frozen local algebra G_p = span(B_p, O3_p, H4_perp_p) too small to carry the native recombination Jacobian?
```

No Kabsch, Procrustes, Gramian alignment, fitted counterterm, threshold patch, or time primitive was used.

## Native operator audited

```text
T_pq(dx) = dx + gamma_pq · [roll(dx) ⊙ q - dx ⊙ roll(q)]
```

The operator-closure leakage was:

```text
leakage(p→q) = ||(I - P_Gq) T_pq(G_p)||_F / ||T_pq(G_p)||_F
```

## Ledger scale

```text
nodes:  {len(nodes):,}
edges:  {len(edge):,}
cycles: {len(cyc):,}
```

## Basis diagnostics

```text
mean rank(G_p):       {summary['basis']['mean_rank']:.6f}
minimum rank(G_p):    {summary['basis']['min_rank']:.6f}
mean condition(G_p):  {summary['basis']['mean_condition']:.6f}
```

## Operator-closure result

```text
mean edge closure leakage:    {mean_closure:.6e}
median edge closure leakage:  {med:.6e}
p95 edge closure leakage:     {p95:.6e}
mean cycle closure leakage:   {mean_cyc:.6e}
```

This is essentially machine precision. Therefore the native matrix transport failure is **not** explained by `G_p` being too small or by images leaving the destination algebra.

## Native inverse defect remains

```text
mean roundtrip inverse defect:    {mean_inv:.6f}
median roundtrip inverse defect:  {med_inv:.6f}
```

So the native transport remains structurally non-invertible even though the generated algebra is operator-closed in this emitted ledger representation.

## Weak-form explanatory audit

```text
R² M0:                          {summary['model_results']['mean_R2_M0']:.6f}
R² M0 + C_corr:                 {summary['model_results']['mean_R2_M0_Ccorr']:.6f}
R² M0 + C_corr + exact:         {summary['model_results']['mean_R2_M0_Ccorr_exact']:.6f}

closure unique over C_corr:     {summary['model_results']['mean_closure_unique_over_Ccorr']:.6e}
closure unique after exact:     {summary['model_results']['mean_closure_unique_over_Ccorr_exact']:.6e}
full audit unique after exact:  {summary['model_results']['mean_full_audit_unique_over_Ccorr_exact']:.6f}
```

Closure leakage has no explanatory value because there is essentially no closure leakage to explain.

## Key correlations

```text
corr(closure leakage, weak_target):        {summary['key_correlation']['operator_closure_leakage__weak_target']:.6f}
corr(closure leakage, C_corr):             {summary['key_correlation']['operator_closure_leakage__C_corr']:.6f}
corr(closure leakage, exact_cycle_defect): {summary['key_correlation']['operator_closure_leakage__exact_cycle_defect']:.6f}
corr(closure leakage, H4_perp):            {summary['key_correlation']['operator_closure_leakage__h4_perp_norm']:.6f}
```

## Interpretation

V1688.58 rules out the simplest representational explanation proposed after V1688.57.

```text
G_p is not failing because it is too small.
In this emitted ledger, G_p is full ambient rank and the native Jacobian image remains inside G_q to machine precision.
```

Therefore the current bottleneck is sharper:

```text
The native matrix transport is operator-closed but its trace/determinant/Frobenius holonomy observables are not the surviving weak-form correction observable.
```

The surviving objects remain:

```text
1. C_corr — dimensionless residualized Gamma_R/H4 correction coordinate
2. exact scalar signed-projection graph-cycle defect
```

The native matrix transport remains useful as a structural non-invertibility diagnostic, but it is not yet the correction/holonomy observable.

## Claim boundary

This is a finite retained-flow explicit-ledger harness result only. It is not an ADM derivation, GR closure, Riemann curvature result, Einstein equation result, or physical spacetime claim.

## Next

```text
V1688.59 — native observable mismatch audit
```

The next first-principles test should not enlarge `G_p`. Instead, compare the scalar exact-cycle defect to the scalar action induced by native `T_pq` on the actual correction direction `Z/C_corr`:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle_native_scalar = Π c_pq
```

That tests whether the surviving signed-projection scalar is a **directional observable of native transport**, rather than a full-matrix invariant.
"""
with open(OUT/'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT_REPORT.md','w') as f: f.write(report)
# Make a fast standalone rerun script by writing note into original heavy script? Keep existing main script, but package finalizer too.
zip_path=ROOT/'V1688_58_operator_level_derivation_audit_package.zip'
files=[ROOT/'V1688_58_operator_level_derivation_audit.py',ROOT/'finalize_v1688_58.py',OUT/'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT_REPORT.md',OUT/'V1688_58_SUMMARY.json',OUT/'V1688_58_node_operator_audit.csv',OUT/'V1688_58_edge_operator_closure_audit.csv',OUT/'V1688_58_inverse_operator_audit.csv',OUT/'V1688_58_cycle_operator_closure_audit.csv',OUT/'V1688_58_operator_audit_holdout_results.csv',OUT/'V1688_58_operator_correlation_diagnostics.csv',OUT/'V1688_58_operator_audit_null_results.csv',OUT/'V1688_58_resolution_operator_audit.csv']
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for p in files:
        if p.exists(): z.write(p,arcname=p.name)
print(json.dumps(summary,indent=2))
print(zip_path)
