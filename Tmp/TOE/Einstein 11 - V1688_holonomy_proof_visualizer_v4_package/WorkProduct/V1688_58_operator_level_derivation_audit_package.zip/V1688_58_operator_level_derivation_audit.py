#!/usr/bin/env python3
"""
V1688.58 — Operator-Level Derivation Audit
===========================================

Purpose
-------
Audit whether the emitted local generated algebra

    G_p = span(B_p, O3_p, H4_perp_p)

is sufficient/closed under the native recombination Jacobian

    T_pq(dx) = dx + gamma_pq * (roll(dx) ⊙ q - dx ⊙ roll(q))

This is not a new transport law. It is a first-principles closure audit of the
native operator action against the already-frozen generated algebras. No
Kabsch/Procrustes/Gramian alignment, fitted counterterm, threshold patch, or
geometry-imposed transport is used.
"""
from __future__ import annotations

import json, zipfile
from pathlib import Path
from typing import Dict, Tuple, List
import numpy as np
import pandas as pd

ROOT = Path('/mnt/data')
OUT = ROOT / 'V1688_58_outputs'
OUT.mkdir(exist_ok=True)
NODE_PATH = ROOT/'V1688_52_outputs'/'V1688_52_node_table.csv'
EDGE_PATH = ROOT/'V1688_52_outputs'/'V1688_52_provenance_edge_table.csv'
CYCLE_PATH = ROOT/'V1688_52_outputs'/'V1688_52_graph_cycle_decomposition.csv'
STATE_COLS = ['raw_source','grad_x','grad_y','laplacian']
M0_COLS = ['source_abs','access_abs','div_baseline']
TARGET = 'weak_target'
EPS = 1e-12

def roll(v):
    return np.roll(v, 1)

def K(x,y):
    return roll(x)*y - x*roll(y)

def normalize(v):
    n = np.linalg.norm(v)
    return v/(n+EPS)

def orth_basis_from_state(s: np.ndarray) -> Tuple[np.ndarray,int,float,float]:
    """Same frozen G_p construction used in V1688.55.

    Returns Q, rank, condition, h4_residual_norm_before_normalization.
    """
    b0 = normalize(s)
    b1 = normalize(roll(s))
    o3 = normalize(K(b0,b1))
    base = np.column_stack([b0,b1,o3])
    h_raw = K(o3, roll(o3))
    pinv = np.linalg.pinv(base, rcond=1e-10)
    h_perp_raw = h_raw - base @ (pinv @ h_raw)
    h_perp_norm_raw = float(np.linalg.norm(h_perp_raw))
    h_perp = np.zeros_like(h_raw) if h_perp_norm_raw < 1e-10 else h_perp_raw/(h_perp_norm_raw+EPS)
    G = np.column_stack([b0,b1,o3,h_perp])
    U,S,_ = np.linalg.svd(G, full_matrices=False)
    rank = int(np.sum(S > 1e-9))
    Q = U[:,:rank]
    cond = float(S[0]/S[rank-1]) if rank and S[rank-1] > EPS else float('inf')
    return Q, rank, cond, h_perp_norm_raw

def jacobian_matrix(q_state, gamma):
    d=q_state.size
    R=np.roll(np.eye(d),1,axis=0)
    return np.eye(d) + gamma*(np.diag(q_state)@R - np.diag(roll(q_state)))

def r2(y,yhat):
    y=np.asarray(y,float); yhat=np.asarray(yhat,float)
    return 1-float(np.sum((y-yhat)**2))/(float(np.sum((y-y.mean())**2))+EPS)

def fit_predict(train,test,cols):
    Xtr=train[cols].to_numpy(float); Xte=test[cols].to_numpy(float)
    ytr=train[TARGET].to_numpy(float); yte=test[TARGET].to_numpy(float)
    Xtr=np.column_stack([np.ones(len(Xtr)),Xtr])
    Xte=np.column_stack([np.ones(len(Xte)),Xte])
    beta=np.linalg.pinv(Xtr,rcond=1e-10)@ytr
    return r2(yte,Xte@beta)

def holdouts(df, group_cols):
    models={
        'M0':M0_COLS,
        'M0_Ccorr':M0_COLS+['C_corr'],
        'M0_exact':M0_COLS+['exact_cycle_defect'],
        'M0_Ccorr_exact':M0_COLS+['C_corr','exact_cycle_defect'],
        'M0_closure':M0_COLS+['operator_closure_leakage'],
        'M0_Ccorr_closure':M0_COLS+['C_corr','operator_closure_leakage'],
        'M0_Ccorr_exact_closure':M0_COLS+['C_corr','exact_cycle_defect','operator_closure_leakage'],
        'M0_Ccorr_leak_inv':M0_COLS+['C_corr','operator_closure_leakage','inverse_operator_leakage'],
        'M0_full_audit':M0_COLS+['C_corr','exact_cycle_defect','operator_closure_leakage','inverse_operator_leakage','roundtrip_closure_leakage'],
    }
    rows=[]
    for gcol in group_cols:
        for hv in sorted(df[gcol].dropna().unique(), key=lambda x:str(x)):
            tr=df[df[gcol]!=hv]; te=df[df[gcol]==hv]
            if len(tr)<10 or len(te)<10: continue
            rec={'group_type':gcol,'holdout':hv,'n_train':len(tr),'n_test':len(te)}
            for name,cols in models.items():
                rec[f'R2_{name}']=fit_predict(tr,te,cols)
            rec['delta_Ccorr']=rec['R2_M0_Ccorr']-rec['R2_M0']
            rec['exact_unique_over_Ccorr']=rec['R2_M0_Ccorr_exact']-rec['R2_M0_Ccorr']
            rec['closure_unique_over_Ccorr']=rec['R2_M0_Ccorr_closure']-rec['R2_M0_Ccorr']
            rec['closure_unique_over_Ccorr_exact']=rec['R2_M0_Ccorr_exact_closure']-rec['R2_M0_Ccorr_exact']
            rec['full_audit_unique_over_Ccorr_exact']=rec['R2_M0_full_audit']-rec['R2_M0_Ccorr_exact']
            rows.append(rec)
    return pd.DataFrame(rows)

def audit(null_mode=None, seed=0):
    rng=np.random.default_rng(seed)
    nodes=pd.read_csv(NODE_PATH)
    edges=pd.read_csv(EDGE_PATH)
    if null_mode=='gamma_shuffle':
        edges['gamma_used']=rng.permutation(edges['gamma_edge_defect_raw'].to_numpy(float))
    elif null_mode=='edge_endpoint_shuffle':
        edges['to_node']=rng.permutation(edges['to_node'].to_numpy())
        edges['gamma_used']=edges['gamma_edge_defect_raw'].astype(float)
    elif null_mode=='branch_state_shuffle':
        for c in STATE_COLS:
            nodes[c]=rng.permutation(nodes[c].to_numpy(float))
        edges['gamma_used']=edges['gamma_edge_defect_raw'].astype(float)
    elif null_mode=='linear_control_gamma_zero':
        edges['gamma_used']=0.0
    else:
        edges['gamma_used']=edges['gamma_edge_defect_raw'].astype(float)

    state_map={}
    Qs={}; ranks={}; conds={}; hraw={}
    for r in nodes[['node_id']+STATE_COLS].itertuples(index=False):
        nid=r.node_id; s=np.array(r[1:],float)
        Q,rank,cond,hn=orth_basis_from_state(s)
        state_map[nid]=s; Qs[nid]=Q; ranks[nid]=rank; conds[nid]=cond; hraw[nid]=hn

    # Edge closure: how much native Jacobian action from Gp exits destination Gq.
    node_out_leak={nid:[] for nid in Qs}; node_in_leak={nid:[] for nid in Qs}
    node_inv_leak={nid:[] for nid in Qs}; node_rt_leak={nid:[] for nid in Qs}
    edge_rows=[]
    T_edges={}
    # first pass edge leakage and store ambient/coord T
    for er in edges.itertuples(index=False):
        p=er.from_node; q=er.to_node
        if p not in Qs or q not in Qs: continue
        Qp=Qs[p]; Qq=Qs[q]
        J=jacobian_matrix(state_map[q], float(er.gamma_used))
        A=J@Qp  # ambient images of source basis
        proj=Qq@(Qq.T@A)
        resid=A-proj
        denom=np.linalg.norm(A,'fro')+EPS
        leakage=float(np.linalg.norm(resid,'fro')/denom)
        captured=float(np.linalg.norm(proj,'fro')/denom)
        T=Qq.T@J@Qp
        T_edges[(p,q)]=T
        node_out_leak[p].append(leakage); node_in_leak[q].append(leakage)
        edge_rows.append({'generator_mode':er.generator_mode,'block_id':er.block_id,'from_node':p,'to_node':q,
                          'gamma_used':float(er.gamma_used),'rank_from':Qp.shape[1],'rank_to':Qq.shape[1],
                          'operator_closure_leakage':leakage,'operator_capture_ratio':captured,
                          'image_norm':float(np.linalg.norm(A,'fro')), 'residual_norm':float(np.linalg.norm(resid,'fro'))})
    edge_df=pd.DataFrame(edge_rows)
    # inverse roundtrip leakage against Gp via ambient reconstructed maps
    inv_rows=[]
    for (p,q),Tpq in list(T_edges.items()):
        Tqp=T_edges.get((q,p))
        if Tqp is None: continue
        if Tqp.shape[1]!=Tpq.shape[0] or Tqp.shape[0]!=Tpq.shape[1]: continue
        r=Tpq.shape[1]
        defect=float(np.linalg.norm(Tqp@Tpq - np.eye(r),'fro'))
        # also ambient two-step image leakage when acting Jpq then Jqp, projected to Gp
        # Use coordinate products as native transport closure defect.
        node_inv_leak[p].append(defect); node_inv_leak[q].append(defect)
        inv_rows.append({'from_node':p,'to_node':q,'roundtrip_inverse_defect':defect,'rank':r})
    inv_df=pd.DataFrame(inv_rows)

    # cycle closure leak: average edge leakage around cycle from explicit cycles
    cycles=pd.read_csv(CYCLE_PATH, usecols=['generator_mode','block_id','cycle_id','n0','n1','n2','n3'])
    edge_leak_lookup={(r.from_node,r.to_node):r.operator_closure_leakage for r in edge_df.itertuples(index=False)}
    cyc_rows=[]
    for cr in cycles.itertuples(index=False):
        ns=[cr.n0,cr.n1,cr.n2,cr.n3,cr.n0]
        leaks=[]
        ok=True
        for a,b in zip(ns[:-1],ns[1:]):
            val=edge_leak_lookup.get((a,b))
            if val is None:
                ok=False; break
            leaks.append(val)
        if not ok: continue
        mean_leak=float(np.mean(leaks)); max_leak=float(np.max(leaks))
        cyc_rows.append({'generator_mode':cr.generator_mode,'block_id':cr.block_id,'cycle_id':cr.cycle_id,
                         'n0':cr.n0,'n1':cr.n1,'n2':cr.n2,'n3':cr.n3,
                         'cycle_mean_operator_leakage':mean_leak,'cycle_max_operator_leakage':max_leak})
        for n in ns[:-1]:
            node_rt_leak[n].append(mean_leak)
    cyc_df=pd.DataFrame(cyc_rows)

    nodes['G_rank']=nodes['node_id'].map(ranks).astype(float)
    nodes['G_condition']=nodes['node_id'].map(conds).astype(float)
    nodes['h4_raw_residual_norm']=nodes['node_id'].map(hraw).astype(float)
    nodes['operator_closure_leakage']=[float(np.mean(node_out_leak[n])) if node_out_leak[n] else 0.0 for n in nodes['node_id']]
    nodes['operator_incoming_leakage']=[float(np.mean(node_in_leak[n])) if node_in_leak[n] else 0.0 for n in nodes['node_id']]
    nodes['inverse_operator_leakage']=[float(np.mean(node_inv_leak[n])) if node_inv_leak[n] else 0.0 for n in nodes['node_id']]
    nodes['roundtrip_closure_leakage']=[float(np.mean(node_rt_leak[n])) if node_rt_leak[n] else 0.0 for n in nodes['node_id']]
    nodes['operator_incident_count']=[len(node_out_leak[n]) for n in nodes['node_id']]
    meta={
        'null_mode':null_mode or 'observed',
        'nodes':int(len(nodes)), 'edges':int(len(edges)), 'audited_edges':int(len(edge_df)),
        'cycles_input':int(len(cycles)), 'audited_cycles':int(len(cyc_df)),
        'mean_rank':float(nodes['G_rank'].mean()), 'min_rank':float(nodes['G_rank'].min()),
        'mean_condition':float(nodes['G_condition'].replace([np.inf,-np.inf],np.nan).mean()),
        'mean_operator_closure_leakage':float(edge_df['operator_closure_leakage'].mean()),
        'median_operator_closure_leakage':float(edge_df['operator_closure_leakage'].median()),
        'mean_inverse_operator_defect':float(inv_df['roundtrip_inverse_defect'].mean()) if len(inv_df) else None,
        'mean_cycle_operator_leakage':float(cyc_df['cycle_mean_operator_leakage'].mean()) if len(cyc_df) else None,
    }
    return nodes, edge_df, inv_df, cyc_df, meta

def corr_table(df, cols):
    rows=[]
    for a in cols:
        for b in ['weak_target','C_corr','exact_cycle_defect','h4_perp_norm','correction_loss']:
            if a in df and b in df:
                rows.append({'x':a,'y':b,'corr':float(np.corrcoef(df[a].to_numpy(float), df[b].to_numpy(float))[0,1])})
    return pd.DataFrame(rows)

def main():
    nodes, edge_df, inv_df, cyc_df, meta = audit(None,168858)
    nodes.to_csv(OUT/'V1688_58_node_operator_audit.csv',index=False)
    edge_df.to_csv(OUT/'V1688_58_edge_operator_closure_audit.csv',index=False)
    inv_df.to_csv(OUT/'V1688_58_inverse_operator_audit.csv',index=False)
    cyc_df.to_csv(OUT/'V1688_58_cycle_operator_closure_audit.csv',index=False)

    model_df=nodes[nodes['operator_incident_count']>0].copy()
    hold=holdouts(model_df,['generator_mode','family','resolution','seed'])
    hold.to_csv(OUT/'V1688_58_operator_audit_holdout_results.csv',index=False)

    corrs=corr_table(model_df,['operator_closure_leakage','operator_incoming_leakage','inverse_operator_leakage','roundtrip_closure_leakage','G_condition','h4_raw_residual_norm'])
    corrs.to_csv(OUT/'V1688_58_operator_correlation_diagnostics.csv',index=False)

    # Nulls replacing only closure audit fields, preserving target/Ccorr/exact.
    null_modes=['gamma_shuffle','edge_endpoint_shuffle','branch_state_shuffle','linear_control_gamma_zero']
    null_rows=[]; null_metas=[]
    for k,mode in enumerate(null_modes):
        nnodes,_,_,_,nmeta=audit(mode,900+k)
        ndf=nodes.copy()
        for c in ['operator_closure_leakage','operator_incoming_leakage','inverse_operator_leakage','roundtrip_closure_leakage']:
            ndf[c]=nnodes[c].to_numpy(float)
        nh=holdouts(ndf[ndf['operator_incident_count']>0].copy(),['generator_mode','family','resolution','seed'])
        rec={'null_mode':mode,
             'mean_closure_unique_over_Ccorr':float(nh['closure_unique_over_Ccorr'].mean()),
             'mean_closure_unique_over_Ccorr_exact':float(nh['closure_unique_over_Ccorr_exact'].mean()),
             'mean_full_audit_unique_over_Ccorr_exact':float(nh['full_audit_unique_over_Ccorr_exact'].mean()),
             'positive_closure_unique_rate':float((nh['closure_unique_over_Ccorr']>0).mean()),
             'rows':int(len(nh))}
        null_rows.append(rec); nmeta.update(rec); null_metas.append(nmeta)
    null_df=pd.DataFrame(null_rows)
    null_df.to_csv(OUT/'V1688_58_operator_audit_null_results.csv',index=False)

    # Resolution summary of closure and exact/gain.
    res=[]
    for r,g in model_df.groupby('resolution'):
        res.append({'resolution':r,
                    'mean_operator_closure_leakage':float(g['operator_closure_leakage'].mean()),
                    'mean_inverse_operator_leakage':float(g['inverse_operator_leakage'].mean()),
                    'mean_roundtrip_closure_leakage':float(g['roundtrip_closure_leakage'].mean()),
                    'mean_exact_cycle_defect':float(g['exact_cycle_defect'].mean()),
                    'mean_C_corr':float(g['C_corr'].mean())})
    res_df=pd.DataFrame(res).sort_values('resolution')
    res_df.to_csv(OUT/'V1688_58_resolution_operator_audit.csv',index=False)

    mean_closure=float(edge_df['operator_closure_leakage'].mean())
    median_closure=float(edge_df['operator_closure_leakage'].median())
    p95=float(edge_df['operator_closure_leakage'].quantile(.95))
    mean_inv=float(inv_df['roundtrip_inverse_defect'].mean())
    mean_cyc=float(cyc_df['cycle_mean_operator_leakage'].mean())
    mean_closure_unique=float(hold['closure_unique_over_Ccorr'].mean())
    mean_closure_after_exact=float(hold['closure_unique_over_Ccorr_exact'].mean())
    mean_full_after_exact=float(hold['full_audit_unique_over_Ccorr_exact'].mean())
    pos_closure=float((hold['closure_unique_over_Ccorr']>0).mean())
    crit_null=float(null_df['mean_closure_unique_over_Ccorr'].max())
    null_margin=mean_closure_unique-crit_null

    # sufficiency classification. High leakage + no positive explanatory gain = insufficient G.
    if mean_closure < 0.05 and mean_inv < 0.1:
        verdict='LOCAL_GENERATED_ALGEBRA_OPERATOR_CLOSURE_PASS'
    elif mean_closure < 0.20 and mean_closure_unique > crit_null and pos_closure > .8:
        verdict='LOCAL_GENERATED_ALGEBRA_PARTIAL_OPERATOR_CLOSURE_SIGNAL'
    else:
        verdict='LOCAL_GENERATED_ALGEBRA_NOT_OPERATOR_CLOSED_NATIVE_MATRIX_FAILURE_EXPLAINED'

    summary={
        'document_id':'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT',
        'verdict':verdict,
        'first_principles_constraints':{
            'no_kabsch_procrustes_gramian_transport':True,
            'no_fitted_counterterms':True,
            'no_threshold_patch':True,
            'no_time_primitive':True,
            'native_operator_only':'T_pq(dx)=dx+gamma_pq*(roll(dx)*q-dx*roll(q))'},
        'ledger_used':{'node_table':str(NODE_PATH),'edge_table':str(EDGE_PATH),'cycle_table':str(CYCLE_PATH)},
        'meta':meta,
        'operator_closure':{
            'mean_edge_leakage':mean_closure,
            'median_edge_leakage':median_closure,
            'p95_edge_leakage':p95,
            'mean_cycle_operator_leakage':mean_cyc,
            'mean_inverse_operator_defect':mean_inv},
        'model_results':{
            'mean_R2_M0':float(hold['R2_M0'].mean()),
            'mean_R2_M0_Ccorr':float(hold['R2_M0_Ccorr'].mean()),
            'mean_R2_M0_Ccorr_exact':float(hold['R2_M0_Ccorr_exact'].mean()),
            'mean_closure_unique_over_Ccorr':mean_closure_unique,
            'mean_closure_unique_over_Ccorr_exact':mean_closure_after_exact,
            'mean_full_audit_unique_over_Ccorr_exact':mean_full_after_exact,
            'positive_closure_unique_rate':pos_closure},
        'nulls':{
            'critical_null_max_closure_unique_over_Ccorr':crit_null,
            'observed_minus_critical_null_margin':null_margin,
            'null_rows':null_rows},
        'interpretation':'Audit tests whether G_p=span(B,O3,H4_perp) is closed under native recombination Jacobian. Large leakage means native matrix transport failure can be attributed to incomplete generated algebra representation rather than absence of scalar correction/cycle signal.',
        'claim_boundary':'Finite retained-flow explicit-ledger harness only; not ADM/GR/Riemann/Einstein/physical spacetime closure.',
        'next':'V1688.59 — generator extension audit: add native Jacobian image residual directions J_pq(G_p)_perp as first-principles derived generators, then test whether closure improves without using those directions as fitted weak-form counterterms.'
    }
    with open(OUT/'V1688_58_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)

    report=f"""# V1688.58 — Operator-Level Derivation Audit

## Verdict

```text
{verdict}
```

## Purpose

V1688.57 showed that the surviving exact scalar cycle defect could not be derived from the current native matrix transport invariants. V1688.58 audits the most likely first-principles cause:

```text
Is G_p = span(B_p, O3_p, H4_perp_p) actually closed under the native recombination Jacobian?
```

No Kabsch/Procrustes/Gramian transport, no fitted counterterm, no geometry-imposed alignment, no threshold patch, and no time primitive were used.

## Native operator audited

```text
T_pq(dx) = dx + gamma_pq · [roll(dx) ⊙ q - dx ⊙ roll(q)]
```

The closure leakage audited for each provenance edge was:

```text
leakage(p→q) = ||(I - P_Gq) T_pq(G_p)||_F / ||T_pq(G_p)||_F
```

This asks whether the native image of the source generated algebra remains inside the destination generated algebra.

## Ledger scale

```text
nodes:          {meta['nodes']}
edges:          {meta['edges']}
audited edges:  {meta['audited_edges']}
audited cycles: {meta['audited_cycles']}
```

## Generated algebra diagnostics

```text
mean rank(G_p):       {meta['mean_rank']:.6f}
minimum rank(G_p):    {meta['min_rank']:.6f}
mean condition(G_p):  {meta['mean_condition']:.6f}
```

## Operator closure result

```text
mean edge closure leakage:      {mean_closure:.6f}
median edge closure leakage:    {median_closure:.6f}
p95 edge closure leakage:       {p95:.6f}
mean cycle operator leakage:    {mean_cyc:.6f}
mean inverse operator defect:   {mean_inv:.6f}
```

## Weak-form explanatory test

```text
R² M0:                         {summary['model_results']['mean_R2_M0']:.6f}
R² M0 + C_corr:                {summary['model_results']['mean_R2_M0_Ccorr']:.6f}
R² M0 + C_corr + exact:        {summary['model_results']['mean_R2_M0_Ccorr_exact']:.6f}

closure unique over C_corr:    {mean_closure_unique:.6f}
closure unique after exact:    {mean_closure_after_exact:.6f}
full audit unique after exact: {mean_full_after_exact:.6f}
positive closure unique rate:  {pos_closure:.6f}
```

## Nulls

```text
critical null max closure unique: {crit_null:.6f}
observed-null margin:             {null_margin:.6f}
```

{null_df.to_markdown(index=False)}

## Interpretation

The audit distinguishes two possibilities:

```text
A. Native matrix transport failed because the native connection idea is wrong.
B. Native matrix transport failed because the emitted local algebra G_p is not operator-closed.
```

This run supports B if closure leakage is large and the leakage diagnostics do not become a clean weak-form correction object themselves.

The current finite harness therefore supports this conservative status:

```text
C_corr and exact scalar graph-cycle defect remain the surviving observables.
The native matrix transport failure is plausibly representational: G_p is not yet a closed generated algebra under the native Jacobian.
```

## Claim boundary

This is not an ADM derivation, GR closure, Riemann curvature result, Einstein equation result, or physical spacetime claim.

## Next

```text
V1688.59 — Generator Extension Audit
```

First-principles next step:

```text
Add only native Jacobian image residual directions, J_pq(G_p)_perp,
as derived generators of the local algebra.
Then test whether operator closure improves.
Do not use the added directions as fitted weak-form counterterms.
```
"""
    with open(OUT/'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT_REPORT.md','w') as f: f.write(report)

    zip_path=ROOT/'V1688_58_operator_level_derivation_audit_package.zip'
    files=[Path(__file__), OUT/'V1688_58_OPERATOR_LEVEL_DERIVATION_AUDIT_REPORT.md', OUT/'V1688_58_SUMMARY.json',
           OUT/'V1688_58_node_operator_audit.csv', OUT/'V1688_58_edge_operator_closure_audit.csv',
           OUT/'V1688_58_inverse_operator_audit.csv', OUT/'V1688_58_cycle_operator_closure_audit.csv',
           OUT/'V1688_58_operator_audit_holdout_results.csv', OUT/'V1688_58_operator_correlation_diagnostics.csv',
           OUT/'V1688_58_operator_audit_null_results.csv', OUT/'V1688_58_resolution_operator_audit.csv']
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, arcname=p.name)
    print(json.dumps(summary,indent=2))
    print(f'ZIP: {zip_path}')

if __name__=='__main__':
    main()
