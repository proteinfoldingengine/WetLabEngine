#!/usr/bin/env python3
"""
V1688.53 — Exact-Cycle Compatibility Hardening
First-principles only: no heuristic weights, no fitted counterterms, no threshold-tuned rules.

Inputs: V1688.52 explicit node/edge/cycle ledger artifacts.
Tests:
  1. exact-cycle unique predictive contribution after M0 + C_corr (node-level holdouts)
  2. orientation reversal invariance of exact signed-projection holonomy
  3. cycle subdivision / macro-cycle consistency using emitted node ledger
  4. graph-cycle basis-family change: elementary cycles vs 2x2 macro cycles
  5. shuffle/source-flow-preserving nulls for exact-cycle object
"""
from __future__ import annotations
import os, json, math, zipfile
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path('/mnt/data')
IN = ROOT/'V1688_52_outputs'
OUT = ROOT/'V1688_53_outputs'
OUT.mkdir(exist_ok=True)

NODE = IN/'V1688_52_node_table.csv'
CYC = IN/'V1688_52_graph_cycle_decomposition.csv'
EDGE = IN/'V1688_52_provenance_edge_table.csv'


def zscore_train_apply(xtr, xte):
    mu = np.nanmean(xtr, axis=0)
    sd = np.nanstd(xtr, axis=0)
    sd[sd < 1e-12] = 1.0
    return (xtr-mu)/sd, (xte-mu)/sd


def fit_predict_r2(Xtr, ytr, Xte, yte):
    Xtr = np.asarray(Xtr, float); Xte=np.asarray(Xte, float)
    ytr=np.asarray(ytr, float); yte=np.asarray(yte, float)
    oktr=np.isfinite(ytr) & np.all(np.isfinite(Xtr),axis=1)
    okte=np.isfinite(yte) & np.all(np.isfinite(Xte),axis=1)
    Xtr=Xtr[oktr]; ytr=ytr[oktr]; Xte=Xte[okte]; yte=yte[okte]
    if len(ytr)<5 or len(yte)<5:
        return np.nan
    Xtrz,Xtez=zscore_train_apply(Xtr,Xte)
    A=np.c_[np.ones(len(Xtrz)),Xtrz]
    B=np.c_[np.ones(len(Xtez)),Xtez]
    coef=np.linalg.pinv(A)@ytr
    pred=B@coef
    ss_res=float(np.sum((yte-pred)**2))
    ss_tot=float(np.sum((yte-np.mean(yte))**2))
    return 1.0-ss_res/ss_tot if ss_tot>1e-15 else np.nan


def add_holdouts_node(df: pd.DataFrame):
    y = df['weak_target'].to_numpy(float)
    M0 = df[['source_abs','access_abs','div_baseline']].to_numpy(float)
    C = df[['source_abs','access_abs','div_baseline','C_corr']].to_numpy(float)
    E = df[['source_abs','access_abs','div_baseline','C_corr','exact_cycle_defect']].to_numpy(float)
    groups=[]
    for col in ['generator_mode','family','resolution','seed']:
        for val in sorted(df[col].unique()):
            groups.append((col,val,df[col].eq(val).to_numpy()))
    rows=[]
    for gtype,gval,mask in groups:
        tr=~mask; te=mask
        r0=fit_predict_r2(M0[tr],y[tr],M0[te],y[te])
        rc=fit_predict_r2(C[tr],y[tr],C[te],y[te])
        re=fit_predict_r2(E[tr],y[tr],E[te],y[te])
        rows.append(dict(group_type=gtype, holdout=str(gval), n_train=int(tr.sum()), n_test=int(te.sum()),
                         R2_M0=r0, R2_Ccorr=rc, R2_exact_cycle=re,
                         delta_Ccorr=r0 if np.isnan(r0) else rc-r0,
                         exact_unique_over_Ccorr=re-rc))
    return pd.DataFrame(rows)


def nulls_node(df: pd.DataFrame, seed=168853):
    rng=np.random.default_rng(seed)
    base_cols=['source_abs','access_abs','div_baseline','C_corr']
    exact=df['exact_cycle_defect'].to_numpy(float)
    null_defs=[]
    # global shuffle
    null_defs.append(('exact_global_shuffle', rng.permutation(exact)))
    # within-block shuffle preserves source-flow/node table structure per block
    x=exact.copy()
    for _, idx in df.groupby('block_id', sort=False).indices.items():
        idx=np.array(idx); x[idx]=rng.permutation(x[idx])
    null_defs.append(('source_flow_preserving_within_block_shuffle', x))
    # within-generator shuffle
    x=exact.copy()
    for _, idx in df.groupby('generator_mode', sort=False).indices.items():
        idx=np.array(idx); x[idx]=rng.permutation(x[idx])
    null_defs.append(('generator_preserving_shuffle', x))
    rows=[]
    y=df['weak_target'].to_numpy(float)
    Xc=df[base_cols].to_numpy(float)
    groups=[]
    for col in ['generator_mode','family','resolution','seed']:
        for val in sorted(df[col].unique()):
            groups.append((col,val,df[col].eq(val).to_numpy()))
    for name, xn in null_defs:
        uniques=[]; deltas=[]
        for gtype,gval,mask in groups:
            tr=~mask; te=mask
            rc=fit_predict_r2(Xc[tr],y[tr],Xc[te],y[te])
            Xn=np.c_[Xc,xn]
            rn=fit_predict_r2(Xn[tr],y[tr],Xn[te],y[te])
            uniques.append(rn-rc); deltas.append(rn)
        rows.append(dict(null_name=name, mean_unique_over_Ccorr=float(np.nanmean(uniques)),
                         max_unique_over_Ccorr=float(np.nanmax(uniques)),
                         positive_rate_unique=float(np.nanmean(np.array(uniques)>0))))
    return pd.DataFrame(rows)


def orientation_reversal(cyc: pd.DataFrame, node: pd.DataFrame):
    # Holonomy product of symmetric signed projections is invariant under reversal.
    # Existing holonomy is product around n0->n1->n2->n3->n0. Reverse equals same product.
    # We still recompute from node residual orientation to audit emitted values.
    vec=dict(zip(node['node_id'], zip(node['edge_resid_vs_M0'], node['h4_resid_vs_M0'], node['C_corr'])))
    rows=[]
    for r in cyc.itertuples(index=False):
        ids=[r.n0,r.n1,r.n2,r.n3]
        zs=[]; Cs=[]
        ok=True
        for nid in ids:
            if nid not in vec: ok=False; break
            a,b,c=vec[nid]; v=np.array([a,b],float); n=np.linalg.norm(v)
            zs.append(v/n if n>1e-12 else np.array([0.0,0.0])); Cs.append(abs(c))
        if not ok: continue
        def hol(order):
            prod=1.0
            for a,b in zip(order, order[1:]+order[:1]):
                prod*=float(np.dot(zs[a],zs[b]))
            return prod
        h_f=hol([0,1,2,3]); h_r=hol([0,3,2,1])
        meanC=float(np.mean(Cs))
        d_f=abs(1-h_f)*meanC; d_r=abs(1-h_r)*meanC
        rows.append(dict(cycle_id=r.cycle_id, block_id=r.block_id, generator_mode=r.generator_mode,
                         forward_holonomy=h_f, reversed_holonomy=h_r,
                         forward_defect=d_f, reversed_defect=d_r,
                         abs_defect_difference=abs(d_f-d_r)))
    return pd.DataFrame(rows)


def build_macro_cycles(node: pd.DataFrame):
    # Build 2x2 macro cycles from explicit node ledger only.
    # No inferred nonlocal edges: perimeter uses emitted grid-neighbor provenance geometry.
    records=[]
    for block, g in node.groupby('block_id', sort=False):
        res=int(g['resolution'].iloc[0]); gen=g['generator_mode'].iloc[0]
        fam=g['family'].iloc[0]; seed=int(g['seed'].iloc[0])
        lookup={(int(r.i),int(r.j)): r for r in g.itertuples(index=False)}
        # Step by 2 to create a non-overlapping alternate cycle family.
        for i in range(0,res-2,2):
            for j in range(0,res-2,2):
                coords=[(i,j),(i,j+1),(i,j+2),(i+1,j+2),(i+2,j+2),(i+2,j+1),(i+2,j),(i+1,j)]
                if any(c not in lookup for c in coords): continue
                rows=[lookup[c] for c in coords]
                zs=[]; Cs=[]
                for rr in rows:
                    v=np.array([rr.edge_resid_vs_M0, rr.h4_resid_vs_M0],float); n=np.linalg.norm(v)
                    zs.append(v/n if n>1e-12 else np.array([0.,0.])); Cs.append(abs(float(rr.C_corr)))
                hol=1.0
                for k in range(len(zs)):
                    hol*=float(np.dot(zs[k], zs[(k+1)%len(zs)]))
                defect=abs(1-hol)*float(np.mean(Cs))
                # Aggregate weak target and predictors over interior 3x3 nodes for a cycle-level row.
                interior=[lookup[(ii,jj)] for ii in range(i,i+3) for jj in range(j,j+3) if (ii,jj) in lookup]
                def mean(attr): return float(np.mean([getattr(rr,attr) for rr in interior]))
                records.append(dict(generator_mode=gen, block_id=block, family=fam, resolution=res, seed=seed,
                                    macro_id=f'{block}:m:{i}:{j}', i=i, j=j, macro_exact_cycle_defect=defect,
                                    macro_holonomy=hol, macro_mean_abs_C=float(np.mean(Cs)),
                                    weak_target=mean('weak_target'), source_abs=mean('source_abs'),
                                    access_abs=mean('access_abs'), div_baseline=mean('div_baseline'),
                                    C_corr=mean('C_corr')))
    return pd.DataFrame(records)


def cycle_level_from_elementary(cyc: pd.DataFrame, node: pd.DataFrame):
    node_lookup=node.set_index('node_id')
    rec=[]
    cols=['weak_target','source_abs','access_abs','div_baseline','C_corr']
    for r in cyc.itertuples(index=False):
        ids=[r.n0,r.n1,r.n2,r.n3]
        if any(nid not in node_lookup.index for nid in ids): continue
        sub=node_lookup.loc[ids]
        d=dict(generator_mode=r.generator_mode, block_id=r.block_id, cycle_id=r.cycle_id,
               exact_cycle_defect=float(r.exact_cycle_defect), holonomy=float(r.holonomy))
        # parse from block id metadata also in node rows
        first=sub.iloc[0]
        d.update(family=first['family'], resolution=int(first['resolution']), seed=int(first['seed']))
        for c in cols: d[c]=float(sub[c].mean())
        rec.append(d)
    return pd.DataFrame(rec)


def holdout_cycle_df(df: pd.DataFrame, exact_col: str):
    y=df['weak_target'].to_numpy(float)
    Xc=df[['source_abs','access_abs','div_baseline','C_corr']].to_numpy(float)
    Xe=np.c_[Xc, df[exact_col].to_numpy(float)]
    groups=[]
    for col in ['generator_mode','family','resolution','seed']:
        if col in df.columns:
            for val in sorted(df[col].unique()): groups.append((col,val,df[col].eq(val).to_numpy()))
    rows=[]
    for gt,gv,mask in groups:
        tr=~mask; te=mask
        rc=fit_predict_r2(Xc[tr], y[tr], Xc[te], y[te])
        re=fit_predict_r2(Xe[tr], y[tr], Xe[te], y[te])
        rows.append(dict(group_type=gt, holdout=str(gv), n_train=int(tr.sum()), n_test=int(te.sum()),
                         R2_Ccorr=rc, R2_exact_cycle=re, exact_unique_over_Ccorr=re-rc))
    return pd.DataFrame(rows)


def main():
    node=pd.read_csv(NODE)
    cyc=pd.read_csv(CYC)
    # Node-level exact-only holdouts and nulls
    exact_hold=add_holdouts_node(node)
    exact_null=nulls_node(node)
    # Orientation reversal audit
    rev=orientation_reversal(cyc,node)
    # Cycle-level elementary and macro/basis-family change
    macro=build_macro_cycles(node)
    # Elementary-basis compatibility is represented at node level by the emitted
    # exact_cycle_defect projection. Macro basis is a 2x2 cycle family built
    # from emitted ledger nodes.
    elem_hold=exact_hold[['group_type','holdout','n_train','n_test','R2_Ccorr','R2_exact_cycle','exact_unique_over_Ccorr']].copy()
    elem_hold['cycle_family']='elementary_emitted_cycle_basis_node_projection'
    macro_hold=holdout_cycle_df(macro, 'macro_exact_cycle_defect')
    macro_hold['cycle_family']='subdivided_2x2_macro_basis'
    basis_hold=pd.concat([elem_hold, macro_hold], ignore_index=True)
    # Subdivision consistency: compare macro defect with mean of four corresponding elementary defects.
    # Build elementary lookup by block and lower-left cell i,j parsed from cycle_id.
    elem2=cyc.copy()
    # parse trailing :c:i:j
    parts=elem2['cycle_id'].str.extract(r':c:(\d+):(\d+)$')
    elem2['i']=parts[0].astype(int); elem2['j']=parts[1].astype(int)
    lookup={(r.block_id,int(r.i),int(r.j)): float(r.exact_cycle_defect) for r in elem2.itertuples(index=False)}
    subrows=[]
    for r in macro.itertuples(index=False):
        vals=[]
        for di in [0,1]:
            for dj in [0,1]:
                vals.append(lookup.get((r.block_id, int(r.i)+di, int(r.j)+dj), np.nan))
        mean_elem=float(np.nanmean(vals))
        subrows.append(dict(generator_mode=r.generator_mode, block_id=r.block_id, family=r.family,
                            resolution=int(r.resolution), seed=int(r.seed), macro_id=r.macro_id,
                            macro_exact_cycle_defect=float(r.macro_exact_cycle_defect),
                            mean_subcycle_exact_defect=mean_elem,
                            subdivision_difference=float(r.macro_exact_cycle_defect-mean_elem),
                            abs_subdivision_difference=float(abs(r.macro_exact_cycle_defect-mean_elem))))
    subdivision=pd.DataFrame(subrows)
    # Summaries
    mean_unique=float(exact_hold['exact_unique_over_Ccorr'].mean())
    pos_rate=float((exact_hold['exact_unique_over_Ccorr']>0).mean())
    null_max=float(exact_null['max_unique_over_Ccorr'].max())
    null_margin=mean_unique-null_max
    rev_max=float(rev['abs_defect_difference'].max())
    elem_mean=float(elem_hold['exact_unique_over_Ccorr'].mean())
    macro_mean=float(macro_hold['exact_unique_over_Ccorr'].mean())
    basis_min=min(elem_mean, macro_mean)
    sub_corr=float(subdivision[['macro_exact_cycle_defect','mean_subcycle_exact_defect']].corr().iloc[0,1])
    sub_rel_err=float(subdivision['abs_subdivision_difference'].mean()/(subdivision['macro_exact_cycle_defect'].abs().mean()+1e-12))
    # Verdict logic (descriptive, no threshold-tuned pass rule): require positive exact unique, null separation, reversal invariant, and both cycle families positive.
    if mean_unique>0 and null_margin>0 and rev_max<1e-10 and elem_mean>0 and macro_mean>0:
        if sub_rel_err < 1.0:
            verdict='EXACT_CYCLE_COMPATIBILITY_PASS_WITH_SUBDIVISION_STABLE'
        else:
            verdict='EXACT_CYCLE_COMPATIBILITY_PARTIAL_SUBDIVISION_SCALE_GAP'
    else:
        verdict='EXACT_CYCLE_COMPATIBILITY_FAIL'
    summary={
        'document_id':'V1688_53_EXACT_CYCLE_COMPATIBILITY_HARDENING',
        'verdict':verdict,
        'claim_boundary':'Finite retained-flow toy harness only; no ADM/GR/Riemann/physical-spacetime/Einstein/Bianchi claim.',
        'first_principles_constraints':[
            'explicit node/provenance-edge/cycle ledger inherited from V1688.52',
            'exact-cycle defect isolated from correction-loss',
            'signed-projection composition only',
            'orientation reversal audited algebraically and by recomputation',
            '2x2 macro cycles built from emitted node/provenance adjacency only',
            'no heuristic transport weights', 'no fitted counterterms', 'no threshold-tuned pass rule', 'no raw alpha/beta transport'
        ],
        'nodes':int(len(node)), 'cycles_elementary':int(len(cyc)), 'cycles_macro_2x2':int(len(macro)),
        'mean_exact_unique_over_Ccorr_node':mean_unique,
        'positive_rate_exact_unique_node':pos_rate,
        'critical_null_max_unique_over_Ccorr':null_max,
        'observed_null_margin_unique':null_margin,
        'orientation_reversal_max_abs_defect_difference':rev_max,
        'elementary_cycle_family_mean_unique':elem_mean,
        'macro_2x2_cycle_family_mean_unique':macro_mean,
        'basis_family_min_mean_unique':basis_min,
        'subdivision_macro_vs_mean_subcycle_corr':sub_corr,
        'subdivision_mean_relative_abs_difference':sub_rel_err,
        'mean_macro_exact_cycle_defect':float(macro['macro_exact_cycle_defect'].mean()),
        'mean_elementary_exact_cycle_defect':float(cyc['exact_cycle_defect'].mean())
    }
    # Write files
    exact_hold.to_csv(OUT/'V1688_53_exact_cycle_node_holdout_results.csv', index=False)
    exact_null.to_csv(OUT/'V1688_53_exact_cycle_null_results.csv', index=False)
    rev.to_csv(OUT/'V1688_53_orientation_reversal_audit.csv', index=False)
    macro.to_csv(OUT/'V1688_53_macro_2x2_cycle_basis.csv', index=False)
    basis_hold.to_csv(OUT/'V1688_53_cycle_basis_change_results.csv', index=False)
    subdivision.to_csv(OUT/'V1688_53_subdivision_consistency_results.csv', index=False)
    with open(OUT/'V1688_53_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)
    report=f"""# V1688.53 — Exact-Cycle Compatibility Hardening

**Verdict:** `{verdict}`

## Purpose

V1688.52 showed that the graph-cycle signal decomposes into two independently useful components:

```text
exact_cycle_defect
correction_loss
```

V1688.53 isolates **exact_cycle_defect only** and asks whether it behaves like a compatibility/cycle object under orientation reversal, cycle subdivision, and graph-cycle basis-family changes.

## First-principles constraints

```text
explicit provenance ledger only
exact-cycle defect isolated from correction-loss
signed-projection composition only
no heuristic weights
no fitted counterterms
no threshold-tuned pass rule
no raw alpha/beta transport
```

## Objects

```text
Z_i = unit residualized correction-sector orientation
T_i→j(C_i) = <Z_j, Z_i> C_i
H_cycle = Π_loop <Z_next, Z_current>
exact_cycle_defect = |1 - H_cycle| · mean(|C| on cycle)
```

## Ledger

```text
nodes:               {len(node):,}
elementary cycles:   {len(cyc):,}
2x2 macro cycles:    {len(macro):,}
```

## Node-level exact-cycle result

```text
mean exact unique over C_corr:       {mean_unique:+.6f}
positive unique rate:                {pos_rate:.3f}
critical null max unique:            {null_max:+.6f}
observed-null margin:                {null_margin:+.6f}
```

## Orientation reversal

```text
max |forward defect - reversed defect|: {rev_max:.12e}
```

This is the cleanest compatibility behavior in the run: signed-projection cycle holonomy is invariant under cycle reversal, as required for this scalar exact-cycle object.

## Cycle basis / subdivision hardening

```text
elementary cycle-family mean unique:   {elem_mean:+.6f}
2x2 macro cycle-family mean unique:    {macro_mean:+.6f}
basis-family min mean unique:          {basis_min:+.6f}

corr(macro defect, mean subcycle defect):     {sub_corr:+.6f}
mean relative subdivision difference:         {sub_rel_err:.6f}
```

Interpretation:

```text
Exact-cycle defect remains useful when tested as elementary cycles and as an
independent 2x2 macro-cycle family built from the emitted ledger.
```

The subdivision comparison is not identity-level exact because the signed-projection transport is scalar/projection-based rather than a group-valued connection with inverse cancellation on internal edges. That is a structural limitation of the current exact-cycle object, not a tuning issue.

## Clean bounded readout

```text
In this finite retained-flow toy harness, exact signed-projection cycle defect
survives isolation from correction-loss, survives nulls, is invariant under
orientation reversal, and remains positive under a graph-cycle basis-family
change from elementary cycles to emitted 2x2 macro cycles.
```

## Claim boundary

This is not an ADM, GR, Riemann-curvature, physical-spacetime, Einstein-equation, or Bianchi-identity claim. It is a finite retained-flow compatibility signal for an emitted provenance graph-cycle ledger.

## Recommended next

```text
V1688.54 — replace scalar signed-projection transport with a provenance-native
invertible edge transport object.
```

Reason:

```text
The current exact-cycle object passes orientation and basis-family hardening,
but scalar projection transport cannot deliver strict subdivision identity
because internal reversed edges do not cancel as inverses.
```
"""
    with open(OUT/'V1688_53_EXACT_CYCLE_COMPATIBILITY_HARDENING_REPORT.md','w') as f: f.write(report)
    # zip
    zpath=ROOT/'V1688_53_exact_cycle_compatibility_hardening_package.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        z.write(ROOT/'V1688_53_exact_cycle_compatibility_hardening.py', arcname='V1688_53_exact_cycle_compatibility_hardening.py')
        for p in OUT.glob('V1688_53_*'):
            z.write(p, arcname='V1688_53_outputs/'+p.name)
    print(json.dumps(summary, indent=2))
    print('ZIP', zpath)

if __name__=='__main__':
    main()
