#!/usr/bin/env python3
"""V1688.72 live-ledger transfer execution gate repeat.
Strictly refuses transfer unless actual v1687_ordered_slice_metrics ledger is supplied.
"""
from pathlib import Path
import json

BASE = Path('/mnt/data')
required = ('v1687','ordered','slice','metrics')

def find_candidates():
    out=[]
    for p in BASE.rglob('*'):
        if not p.is_file():
            continue
        name=p.name.lower()
        if all(x in name for x in required) and not any(x in name for x in ['audit','report','summary','contract','readiness','package','validator','skeleton','handoff','gate']):
            out.append(str(p))
    return out

if __name__ == '__main__':
    c=find_candidates()
    print(json.dumps({'accepted_candidates':len(c),'transfer_executed':False,'candidates':c}, indent=2))
