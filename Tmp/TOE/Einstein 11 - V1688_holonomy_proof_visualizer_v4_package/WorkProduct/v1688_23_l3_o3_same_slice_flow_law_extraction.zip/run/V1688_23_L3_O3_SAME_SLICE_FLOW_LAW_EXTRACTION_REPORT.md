# V1688.23 — L3/O3 Same-Slice Flow Law Extraction

```json
{
  "document_id": "V1688_23_L3_O3_SAME_SLICE_FLOW_LAW_EXTRACTION",
  "status": "completed",
  "verdict": "L3_SAME_SLICE_FLOW_LAW_PARTIAL",
  "dominant_candidate": "edge_faithfulness",
  "real_group": {
    "condition": "real",
    "config_count": 36,
    "mean_F0": 0.41636008536898456,
    "mean_F1_O3mag": 0.49421830024099755,
    "mean_F2_edge": 1.0,
    "mean_F3_align": 0.46576740729487237,
    "mean_F6_allL3": 1.0,
    "mean_gain_O3mag": 0.07785821487201294,
    "mean_gain_edge": 0.5836399146310155,
    "mean_gain_align": 0.0494073219258878,
    "mean_gain_allL3": 0.5836399146310155,
    "min_gain_allL3": 0.16529172391394586
  },
  "source_flow_preserving_O3_null": {
    "condition": "source_flow_preserving_O3_null",
    "config_count": 36,
    "mean_F0": 0.41636008536898456,
    "mean_F1_O3mag": 0.45444762155037666,
    "mean_F2_edge": 1.0,
    "mean_F3_align": 0.44150374064904185,
    "mean_F6_allL3": 1.0,
    "mean_gain_O3mag": 0.038087536181392045,
    "mean_gain_edge": 0.5836399146310155,
    "mean_gain_align": 0.025143655280057256,
    "mean_gain_allL3": 0.5836399146310155,
    "min_gain_allL3": 0.16529172391394586
  },
  "edge_shuffle_null": {
    "condition": "edge_shuffle",
    "config_count": 36,
    "mean_F0": 0.41636008536898456,
    "mean_F1_O3mag": 0.49421830024099755,
    "mean_F2_edge": 0.24651256991328316,
    "mean_F3_align": 0.46576740729487237,
    "mean_F6_allL3": 0.6886126209880191,
    "mean_gain_O3mag": 0.07785821487201294,
    "mean_gain_edge": -0.1698475154557014,
    "mean_gain_align": 0.0494073219258878,
    "mean_gain_allL3": 0.27225253561903456,
    "min_gain_allL3": 0.029798746436359047
  },
  "candidate_gains": {
    "O3_magnitude": 0.07785821487201294,
    "edge_faithfulness": 0.5836399146310155,
    "O3_alignment": 0.0494073219258878,
    "all_L3": 0.5836399146310155
  },
  "all_L3_gain_minus_source_flow_preserving_null": 0.0,
  "outputs": {
    "rows": "/mnt/data/v1688_23_l3_o3_same_slice_flow_law_extraction_outputs/v1688_23_l3_flow_law_rows.csv",
    "summary": "/mnt/data/v1688_23_l3_o3_same_slice_flow_law_extraction_outputs/v1688_23_summary.csv",
    "grouped": "/mnt/data/v1688_23_l3_o3_same_slice_flow_law_extraction_outputs/v1688_23_grouped.csv"
  },
  "claim_boundary": "Toy L3/O3 same-slice flow law extraction only; no ADM derivation / GR / physical spacetime claim."
}
```
