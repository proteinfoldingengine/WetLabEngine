
# ============================================================
# V1688.23 — L3/O3 Same-Slice Flow Law Extraction
# ============================================================
# Purpose:
#   Extract which L3/O3 component explains the same-slice flow residual.
#
# Candidate laws:
#   O3 magnitude
#   O3 directional alignment with source divergence
#   Gamma_R edge-faithfulness defect
#   transported source-flow divergence
#   operator-naturality residual
#
# Boundary:
#   Toy same-slice retained-flow law extraction only.
#   No ADM derivation / GR / physical spacetime claim.
# ============================================================

from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_23_l3_o3_same_slice_flow_law_extraction_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-12

def recombine(x,y,gamma=.35,mode="nonlinear"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if mode=="linear": return x+y
    rd=np.r_[x[-1],x[:-1]]
    ru=np.r_[y[1:],y[0]]
    ov=np.minimum(np.abs(x),np.abs(y))/(1+np.minimum(np.abs(x),np.abs(y)))
    return x+y+gamma*ov*(rd*y-x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode=mode),C,mode=mode)-recombine(A,recombine(B,C,mode=mode),mode=mode)

def h4(A,B,C,D,mode="nonlinear"):
    return recombine(recombine(recombine(A,B,mode=mode),C,mode=mode),D,mode=mode)-recombine(A,recombine(B,recombine(C,D,mode=mode),mode=mode),mode=mode)

def normalize(v):
    n=np.linalg.norm(v)
    return v if n<EPS else v/n

def make_sector(i,j,dim=12,seed=0,mode="nonlinear"):
    a=np.linspace(0,2*np.pi,dim,endpoint=False)
    B=[]
    for k in range(4):
        phase=.37*i+.29*j+.63*k+.03*seed
        v=np.sin((k+1)*a+phase)+.35*np.cos((k+2)*a-.21*i+.17*j+.05*seed)
        c=(2*k+i+2*j+seed)%dim
        bump=np.zeros(dim); bump[c]=1.0; bump[(c+1)%dim]=.55; bump[(c-1)%dim]=.35
        v+=.55*bump
        B.append(normalize(v))
    O3=[assoc3(B[0],B[1],B[2],mode),assoc3(B[0],B[1],B[3],mode),assoc3(B[0],B[2],B[3],mode),assoc3(B[1],B[2],B[3],mode)]
    O3_vec=np.mean(np.stack(O3,axis=0),axis=0)
    H=h4(B[0],B[1],B[2],B[3],mode)
    source=np.sum(np.stack(B,axis=0),axis=0)
    return {"B":B,"O3":O3,"O3_vec":O3_vec,"H4":H,"source":source}

def transport(P,Q):
    BP=np.stack(P["B"],axis=1)
    BQ=np.stack(Q["B"],axis=1)
    return BQ@np.linalg.pinv(BP)

def build(ngrid,dim,seed,mode):
    S={(i,j):make_sector(i,j,dim,seed,mode) for i in range(ngrid) for j in range(ngrid)}
    T={}
    for p in S:
        i,j=p
        for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
            if q in S:
                T[(p,q)]=transport(S[p],S[q])
    return S,T

def edge_faithfulness(Tpq,P,Q,mode):
    G=P["B"]+P["O3"]
    vals=[]; vecs=[]
    for a in range(len(G)):
        for b in range(a+1,len(G)):
            lhs=Tpq@recombine(G[a],G[b],mode=mode)
            rhs=recombine(Tpq@G[a],Tpq@G[b],mode=mode)
            d=lhs-rhs
            vals.append(np.linalg.norm(d))
            vecs.append(d)
    return float(np.mean(vals)), np.mean(np.stack(vecs,axis=0),axis=0)

def cos_align(a,b):
    return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)+EPS))

def local_features(i,j,S,T,mode):
    p=(i,j)
    sec=S[p]
    source=sec["source"]
    O3_vec=sec["O3_vec"]

    transported_source_diffs=[]
    edge_vals=[]
    edge_vecs=[]
    for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
        if q in S:
            # neighbor source transported into p
            source_q_to_p=T[(q,p)]@S[q]["source"]
            transported_source_diffs.append(source_q_to_p-source)
            ev,evc=edge_faithfulness(T[(p,q)],S[p],S[q],mode)
            edge_vals.append(ev)
            edge_vecs.append(evc)

    div_vec=np.mean(np.stack(transported_source_diffs,axis=0),axis=0)
    edge_vec=np.mean(np.stack(edge_vecs,axis=0),axis=0)

    div_norm=float(np.linalg.norm(div_vec))
    O3_norm=float(np.linalg.norm(O3_vec))
    edge_norm=float(np.mean(edge_vals))
    align_O3_div=cos_align(O3_vec,div_vec)
    align_O3_edge=cos_align(O3_vec,edge_vec)
    align_edge_div=cos_align(edge_vec,div_vec)

    # Target: same-slice residual from transported source mismatch + small nonlinear edge strain.
    # Candidate laws must explain this without H4.
    target=div_norm + 0.15*edge_norm

    return {
        "i":i,"j":j,
        "target":target,
        "flow_div_norm":div_norm,
        "source_norm":float(np.linalg.norm(source)),
        "O3_norm":O3_norm,
        "edge_faithfulness":edge_norm,
        "O3_div_alignment":align_O3_div,
        "O3_edge_alignment":align_O3_edge,
        "edge_div_alignment":align_edge_div,
        "O3_projected_on_div":O3_norm*align_O3_div,
        "O3_projected_on_edge":O3_norm*align_O3_edge,
        "edge_projected_on_div":edge_norm*align_edge_div,
    }

def dataset(ngrid,dim,seed,mode,condition):
    S,T=build(ngrid,dim,seed,mode)
    rows=[]
    for i in range(1,ngrid-1):
        for j in range(1,ngrid-1):
            rows.append(local_features(i,j,S,T,mode))
    df=pd.DataFrame(rows)
    df["ngrid"]=ngrid; df["dim"]=dim; df["seed"]=seed; df["mode"]=mode; df["condition"]=condition
    rng=np.random.default_rng(23000+ngrid*100+dim*10+seed)
    if condition=="O3_norm_shuffle":
        df["O3_norm"]=rng.permutation(df["O3_norm"].values)
    if condition=="O3_alignment_shuffle":
        df["O3_div_alignment"]=rng.permutation(df["O3_div_alignment"].values)
        df["O3_projected_on_div"]=df["O3_norm"]*df["O3_div_alignment"]
    if condition=="edge_shuffle":
        df["edge_faithfulness"]=rng.permutation(df["edge_faithfulness"].values)
    if condition=="source_flow_preserving_O3_null":
        # preserve flow terms and edge terms, destroy only O3 projections
        df["O3_norm"]=rng.permutation(df["O3_norm"].values)
        df["O3_div_alignment"]=rng.permutation(df["O3_div_alignment"].values)
        df["O3_projected_on_div"]=df["O3_norm"]*df["O3_div_alignment"]
    return df

def standardize(X):
    X=np.asarray(X,float)
    mu=X.mean(axis=0); sd=X.std(axis=0)
    sd[sd<EPS]=1.0
    return (X-mu)/sd

def fit_r2(y,X):
    y=np.asarray(y,float)
    X=standardize(np.asarray(X,float))
    X=np.c_[np.ones(len(X)),X]
    c=np.linalg.pinv(X)@y
    pred=X@c
    ssr=float(np.sum((y-pred)**2))
    sst=float(np.sum((y-y.mean())**2))
    return 0.0 if sst<EPS else float(1-ssr/sst)

def eval_law_models(sub):
    y=sub["target"].values
    models={
        "F0_flow_only":["flow_div_norm","source_norm"],
        "F1_O3_magnitude":["flow_div_norm","source_norm","O3_norm"],
        "F2_edge_faithfulness":["flow_div_norm","source_norm","edge_faithfulness"],
        "F3_O3_alignment":["flow_div_norm","source_norm","O3_projected_on_div"],
        "F4_O3_plus_edge":["flow_div_norm","source_norm","O3_norm","edge_faithfulness"],
        "F5_alignment_plus_edge":["flow_div_norm","source_norm","O3_projected_on_div","edge_faithfulness","O3_edge_alignment"],
        "F6_all_L3":["flow_div_norm","source_norm","O3_norm","edge_faithfulness","O3_projected_on_div","O3_projected_on_edge","edge_projected_on_div"]
    }
    out={}
    for name,cols in models.items():
        out[name]=fit_r2(y,sub[cols].values)
    return out

all_dfs=[]
conditions=["real","O3_norm_shuffle","O3_alignment_shuffle","edge_shuffle","source_flow_preserving_O3_null"]
for condition in conditions:
    for dim in [10,12,14]:
        for ngrid in [5,6,7]:
            for seed in range(4):
                all_dfs.append(dataset(ngrid,dim,seed,"nonlinear",condition))
all_dfs.append(dataset(6,12,0,"linear","linear_control"))
df=pd.concat(all_dfs,ignore_index=True)
df.to_csv(OUT/"v1688_23_l3_flow_law_rows.csv",index=False)

summary=[]
for keys,sub in df.groupby(["condition","mode","ngrid","dim","seed"]):
    condition,mode,ngrid,dim,seed=keys
    rs=eval_law_models(sub)
    row={"condition":condition,"mode":mode,"ngrid":int(ngrid),"dim":int(dim),"seed":int(seed),"n":int(len(sub))}
    row.update(rs)
    row["gain_O3mag_over_flow"]=rs["F1_O3_magnitude"]-rs["F0_flow_only"]
    row["gain_edge_over_flow"]=rs["F2_edge_faithfulness"]-rs["F0_flow_only"]
    row["gain_align_over_flow"]=rs["F3_O3_alignment"]-rs["F0_flow_only"]
    row["gain_allL3_over_flow"]=rs["F6_all_L3"]-rs["F0_flow_only"]
    summary.append(row)
summ=pd.DataFrame(summary)
summ.to_csv(OUT/"v1688_23_summary.csv",index=False)

group=summ.groupby("condition").agg(
    config_count=("condition","count"),
    mean_F0=("F0_flow_only","mean"),
    mean_F1_O3mag=("F1_O3_magnitude","mean"),
    mean_F2_edge=("F2_edge_faithfulness","mean"),
    mean_F3_align=("F3_O3_alignment","mean"),
    mean_F6_allL3=("F6_all_L3","mean"),
    mean_gain_O3mag=("gain_O3mag_over_flow","mean"),
    mean_gain_edge=("gain_edge_over_flow","mean"),
    mean_gain_align=("gain_align_over_flow","mean"),
    mean_gain_allL3=("gain_allL3_over_flow","mean"),
    min_gain_allL3=("gain_allL3_over_flow","min")
).reset_index()
group.to_csv(OUT/"v1688_23_grouped.csv",index=False)

real=group[group.condition=="real"].iloc[0].to_dict()
source_null=group[group.condition=="source_flow_preserving_O3_null"].iloc[0].to_dict()
edge_null=group[group.condition=="edge_shuffle"].iloc[0].to_dict()

# Determine dominant law by gain over flow.
gains={
    "O3_magnitude":float(real["mean_gain_O3mag"]),
    "edge_faithfulness":float(real["mean_gain_edge"]),
    "O3_alignment":float(real["mean_gain_align"]),
    "all_L3":float(real["mean_gain_allL3"])
}
dominant=max(gains,key=gains.get)

# Need all_L3 gain above null, and identify component.
all_gain=float(real["mean_gain_allL3"])
null_gain=float(source_null["mean_gain_allL3"])
margin=all_gain-null_gain

if all_gain>0.20 and margin>0.05:
    verdict="L3_SAME_SLICE_FLOW_LAW_SUPPORTED"
elif all_gain>0.05 and margin>=0:
    verdict="L3_SAME_SLICE_FLOW_LAW_PARTIAL"
else:
    verdict="L3_SAME_SLICE_FLOW_LAW_NOT_SUPPORTED"

result={
    "document_id":"V1688_23_L3_O3_SAME_SLICE_FLOW_LAW_EXTRACTION",
    "status":"completed",
    "verdict":verdict,
    "dominant_candidate":dominant,
    "real_group":real,
    "source_flow_preserving_O3_null":source_null,
    "edge_shuffle_null":edge_null,
    "candidate_gains":gains,
    "all_L3_gain_minus_source_flow_preserving_null":margin,
    "outputs":{
        "rows":str(OUT/"v1688_23_l3_flow_law_rows.csv"),
        "summary":str(OUT/"v1688_23_summary.csv"),
        "grouped":str(OUT/"v1688_23_grouped.csv")
    },
    "claim_boundary":"Toy L3/O3 same-slice flow law extraction only; no ADM derivation / GR / physical spacetime claim."
}
(OUT/"v1688_23_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_23_L3_O3_SAME_SLICE_FLOW_LAW_EXTRACTION_REPORT.md").write_text("# V1688.23 — L3/O3 Same-Slice Flow Law Extraction\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
