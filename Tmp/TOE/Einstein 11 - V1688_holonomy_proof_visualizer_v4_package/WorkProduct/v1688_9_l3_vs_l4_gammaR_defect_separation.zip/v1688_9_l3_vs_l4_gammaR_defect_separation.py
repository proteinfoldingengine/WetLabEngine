
# ============================================================
# V1688.9 — Separate L3-Driven vs L4-Driven Γ_R Loop Defect
# ============================================================
# Purpose:
#   V1688.8 showed Γ_R loop defect is nondegenerate in nonlinear recombination,
#   but O3 predicted it more strongly than H4_perp.
#
# This run tests whether H4_perp adds independent explanatory power beyond:
#   - branch/local magnitude
#   - O3/L3 associator magnitude
#   - edge faithfulness defect
#
# Boundary:
#   Toy finite retained-sector graph.
#   No Riemann curvature / GR / ADM / physical spacetime claim.
# ============================================================

from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_9_l3_vs_l4_gammaR_defect_separation_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-12
SEED = 16889
rng = np.random.default_rng(SEED)

def recombine(x, y, gamma=0.35, mode="nonlinear"):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if mode == "linear":
        return x + y
    rd = np.r_[x[-1], x[:-1]]
    ru = np.r_[y[1:], y[0]]
    overlap = np.minimum(np.abs(x), np.abs(y)) / (1 + np.minimum(np.abs(x), np.abs(y)))
    return x + y + gamma * overlap * (rd*y - x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode=mode),C,mode=mode) - recombine(A,recombine(B,C,mode=mode),mode=mode)

def h4(A,B,C,D,mode="nonlinear"):
    return recombine(recombine(recombine(A,B,mode=mode),C,mode=mode),D,mode=mode) - recombine(A,recombine(B,recombine(C,D,mode=mode),mode=mode),mode=mode)

def mat_rank(cols, tol=1e-9):
    return int(np.linalg.matrix_rank(np.stack(cols, axis=1), tol=tol))

def residual_to_span(v, basis):
    B = np.stack(basis, axis=1)
    coef = np.linalg.pinv(B) @ v
    pred = B @ coef
    res = v - pred
    return res, float(np.linalg.norm(res))

def normalize(v):
    n = np.linalg.norm(v)
    return v if n < EPS else v/n

def make_sector(i, j, dim=12, mode="nonlinear", seed_shift=0):
    base_angles = np.linspace(0, 2*np.pi, dim, endpoint=False)
    branches = []
    for k in range(4):
        phase = 0.37*i + 0.29*j + 0.63*k + 0.03*seed_shift
        v = np.sin((k+1)*base_angles + phase)
        v += 0.35*np.cos((k+2)*base_angles - 0.21*i + 0.17*j + 0.05*seed_shift)
        center = (2*k + i + 2*j + seed_shift) % dim
        bump = np.zeros(dim)
        bump[center] = 1.0
        bump[(center+1)%dim] = 0.55
        bump[(center-1)%dim] = 0.35
        v += 0.55*bump
        branches.append(normalize(v))
    B = branches
    O3 = [
        assoc3(B[0],B[1],B[2],mode),
        assoc3(B[0],B[1],B[3],mode),
        assoc3(B[0],B[2],B[3],mode),
        assoc3(B[1],B[2],B[3],mode)
    ]
    H4 = h4(B[0],B[1],B[2],B[3],mode)
    H4_perp, H4_perp_norm = residual_to_span(H4, B+O3)
    return {
        "ij": (i,j),
        "B": B,
        "O3": O3,
        "H4": H4,
        "H4_perp": H4_perp,
        "H4_perp_norm": H4_perp_norm,
        "branch_norm_mean": float(np.mean([np.linalg.norm(b) for b in B])),
        "O3_norm_mean": float(np.mean([np.linalg.norm(o) for o in O3])),
        "O3_norm_max": float(np.max([np.linalg.norm(o) for o in O3])),
        "rank_B": mat_rank(B),
        "rank_B_O3": mat_rank(B+O3),
        "rank_B_O3_H4": mat_rank(B+O3+[H4]),
    }

def natural_transport(P, Q):
    BP = np.stack(P["B"], axis=1)
    BQ = np.stack(Q["B"], axis=1)
    return BQ @ np.linalg.pinv(BP)

def op_faithfulness_defect(T, P, Q, mode="nonlinear"):
    G = P["B"] + P["O3"]
    vals = []
    for a in range(len(G)):
        for b in range(a+1, len(G)):
            lhs = T @ recombine(G[a], G[b], mode=mode)
            rhs = recombine(T @ G[a], T @ G[b], mode=mode)
            vals.append(np.linalg.norm(lhs-rhs))
    return float(np.mean(vals)), float(np.max(vals))

def loop_transport(Ts):
    T = np.eye(Ts[0].shape[0])
    for A in Ts:
        T = A @ T
    return T

def loop_defect(loop, sectors, transports, mode="nonlinear"):
    p0 = loop[0]
    Ts = []
    edge_mean = []
    edge_max = []
    for a,b in zip(loop[:-1], loop[1:]):
        T = transports[(a,b)]
        Ts.append(T)
        mn,mx = op_faithfulness_defect(T,sectors[a],sectors[b],mode)
        edge_mean.append(mn); edge_max.append(mx)
    Tloop = loop_transport(Ts)
    S0 = sectors[p0]
    test_vecs = S0["B"] + S0["O3"] + [S0["H4_perp"]]
    defects = [np.linalg.norm(Tloop @ v - v) for v in test_vecs]
    return {
        "loop": str(loop),
        "p0": str(p0),
        "loop_defect_mean": float(np.mean(defects)),
        "loop_defect_max": float(np.max(defects)),
        "edge_faithfulness_defect_mean": float(np.mean(edge_mean)),
        "edge_faithfulness_defect_max": float(np.max(edge_max)),
        "H4_perp_norm": float(S0["H4_perp_norm"]),
        "O3_norm_mean": float(S0["O3_norm_mean"]),
        "O3_norm_max": float(S0["O3_norm_max"]),
        "branch_norm_mean": float(S0["branch_norm_mean"]),
        "rank_lift_H4": int(S0["rank_B_O3_H4"] - S0["rank_B_O3"]),
    }

def build_dataset(mode="nonlinear", ngrid=6, dim=12, seed_shift=0):
    sectors = {}
    for i in range(ngrid):
        for j in range(ngrid):
            sectors[(i,j)] = make_sector(i,j,dim=dim,mode=mode,seed_shift=seed_shift)

    transports = {}
    for i in range(ngrid):
        for j in range(ngrid):
            p=(i,j)
            for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
                if q in sectors:
                    transports[(p,q)] = natural_transport(sectors[p], sectors[q])

    rows = []
    for i in range(ngrid-1):
        for j in range(ngrid-1):
            loop = [(i,j),(i+1,j),(i+1,j+1),(i,j+1),(i,j)]
            rows.append(loop_defect(loop,sectors,transports,mode))
            loop_rev = [(i,j),(i,j+1),(i+1,j+1),(i+1,j),(i,j)]
            rows.append(loop_defect(loop_rev,sectors,transports,mode))
    df = pd.DataFrame(rows)
    df["mode"] = mode
    df["seed_shift"] = seed_shift
    return df

def standardize(X):
    X = np.asarray(X, dtype=float)
    mu = X.mean(axis=0)
    sd = X.std(axis=0)
    sd[sd<EPS] = 1.0
    return (X-mu)/sd

def fit_r2(y, X):
    y = np.asarray(y, dtype=float)
    X = np.asarray(X, dtype=float)
    X = standardize(X)
    X = np.c_[np.ones(len(X)), X]
    coef = np.linalg.pinv(X) @ y
    pred = X @ coef
    ss_res = float(np.sum((y-pred)**2))
    ss_tot = float(np.sum((y-y.mean())**2))
    r2 = 0.0 if ss_tot<EPS else 1 - ss_res/ss_tot
    return float(r2), coef.tolist()

def corr(a,b):
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS: return 0.0
    return float(np.corrcoef(a,b)[0,1])

# Build multiple small datasets to test stability.
datasets=[]
for seed_shift in range(5):
    datasets.append(build_dataset("nonlinear", ngrid=6, seed_shift=seed_shift))
datasets.append(build_dataset("linear", ngrid=6, seed_shift=0))
df = pd.concat(datasets, ignore_index=True)
df.to_csv(OUT/"v1688_9_gammaR_loop_rows.csv", index=False)

summary_rows=[]
for (mode, seed_shift), sub in df.groupby(["mode","seed_shift"]):
    y = sub["loop_defect_mean"].values
    lower_cols = ["branch_norm_mean","O3_norm_mean","O3_norm_max","edge_faithfulness_defect_mean","edge_faithfulness_defect_max"]
    full_cols = lower_cols + ["H4_perp_norm"]

    r2_lower,_ = fit_r2(y, sub[lower_cols].values)
    r2_full,_ = fit_r2(y, sub[full_cols].values)
    delta = r2_full - r2_lower

    summary_rows.append({
        "mode": mode,
        "seed_shift": int(seed_shift),
        "loop_count": int(len(sub)),
        "corr_H4perp_loop_defect": corr(sub["H4_perp_norm"], y),
        "corr_O3mean_loop_defect": corr(sub["O3_norm_mean"], y),
        "corr_edge_loop_defect": corr(sub["edge_faithfulness_defect_mean"], y),
        "r2_lower_B_O3_edge": r2_lower,
        "r2_full_plus_H4perp": r2_full,
        "delta_r2_H4perp": delta,
        "mean_loop_defect": float(np.mean(y)),
        "mean_H4perp": float(sub["H4_perp_norm"].mean()),
        "rank_lift_rate": float(np.mean(sub["rank_lift_H4"]>0)),
    })

summary = pd.DataFrame(summary_rows)
summary.to_csv(OUT/"v1688_9_summary.csv", index=False)

nonlin = summary[summary["mode"]=="nonlinear"]
linear = summary[summary["mode"]=="linear"]

mean_delta = float(nonlin["delta_r2_H4perp"].mean())
min_delta = float(nonlin["delta_r2_H4perp"].min())
mean_corr_h4 = float(nonlin["corr_H4perp_loop_defect"].mean())
mean_corr_o3 = float(nonlin["corr_O3mean_loop_defect"].mean())
mean_lower_r2 = float(nonlin["r2_lower_B_O3_edge"].mean())
mean_full_r2 = float(nonlin["r2_full_plus_H4perp"].mean())

if mean_delta > 0.05 and min_delta > 0:
    verdict = "H4_ADDS_INDEPENDENT_GAMMAR_DEFECT_SIGNAL"
elif mean_delta > 0.01 and min_delta > -0.01:
    verdict = "H4_ADDS_WEAK_INDEPENDENT_GAMMAR_DEFECT_SIGNAL"
else:
    verdict = "GAMMAR_DEFECT_PRIMARILY_LOWER_ORDER_DRIVEN"

result = {
    "document_id": "V1688_9_L3_VS_L4_GAMMAR_DEFECT_SEPARATION",
    "status": "completed",
    "verdict": verdict,
    "nonlinear_mean_delta_r2_H4perp": mean_delta,
    "nonlinear_min_delta_r2_H4perp": min_delta,
    "nonlinear_mean_corr_H4perp_loop_defect": mean_corr_h4,
    "nonlinear_mean_corr_O3_loop_defect": mean_corr_o3,
    "nonlinear_mean_lower_r2": mean_lower_r2,
    "nonlinear_mean_full_r2": mean_full_r2,
    "linear_control": linear.to_dict(orient="records"),
    "summary_rows": summary.to_dict(orient="records"),
    "outputs": {
        "loop_rows": str(OUT/"v1688_9_gammaR_loop_rows.csv"),
        "summary": str(OUT/"v1688_9_summary.csv")
    },
    "claim_boundary": "Γ_R toy explanatory separation only; no Riemann curvature / GR / ADM / physical spacetime claim."
}

(OUT/"v1688_9_result.json").write_text(json.dumps(result, indent=2))
(OUT/"V1688_9_L3_VS_L4_GAMMAR_DEFECT_SEPARATION_REPORT.md").write_text(
    "# V1688.9 — L3 vs L4 Γ_R Defect Separation\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n"
)

print(json.dumps(result, indent=2))
