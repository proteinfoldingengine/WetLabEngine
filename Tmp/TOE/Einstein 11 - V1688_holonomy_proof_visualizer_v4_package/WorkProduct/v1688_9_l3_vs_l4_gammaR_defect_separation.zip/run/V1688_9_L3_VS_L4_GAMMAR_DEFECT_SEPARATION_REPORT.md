# V1688.9 — L3 vs L4 Γ_R Defect Separation

```json
{
  "document_id": "V1688_9_L3_VS_L4_GAMMAR_DEFECT_SEPARATION",
  "status": "completed",
  "verdict": "H4_ADDS_INDEPENDENT_GAMMAR_DEFECT_SIGNAL",
  "nonlinear_mean_delta_r2_H4perp": 0.07091265620694172,
  "nonlinear_min_delta_r2_H4perp": 0.0348459665077302,
  "nonlinear_mean_corr_H4perp_loop_defect": 0.24276187293055304,
  "nonlinear_mean_corr_O3_loop_defect": 0.830903978632508,
  "nonlinear_mean_lower_r2": 0.7393238460988567,
  "nonlinear_mean_full_r2": 0.8102365023057985,
  "linear_control": [
    {
      "mode": "linear",
      "seed_shift": 0,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.0,
      "corr_O3mean_loop_defect": 0.0,
      "corr_edge_loop_defect": 0.0,
      "r2_lower_B_O3_edge": 0.0,
      "r2_full_plus_H4perp": 0.0,
      "delta_r2_H4perp": 0.0,
      "mean_loop_defect": 7.266980076972323e-16,
      "mean_H4perp": 1.1319859081045802e-16,
      "rank_lift_rate": 0.0
    }
  ],
  "summary_rows": [
    {
      "mode": "linear",
      "seed_shift": 0,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.0,
      "corr_O3mean_loop_defect": 0.0,
      "corr_edge_loop_defect": 0.0,
      "r2_lower_B_O3_edge": 0.0,
      "r2_full_plus_H4perp": 0.0,
      "delta_r2_H4perp": 0.0,
      "mean_loop_defect": 7.266980076972323e-16,
      "mean_H4perp": 1.1319859081045802e-16,
      "rank_lift_rate": 0.0
    },
    {
      "mode": "nonlinear",
      "seed_shift": 0,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.175621984815372,
      "corr_O3mean_loop_defect": 0.7233484355965941,
      "corr_edge_loop_defect": 0.27507601143966226,
      "r2_lower_B_O3_edge": 0.5934372709957901,
      "r2_full_plus_H4perp": 0.657102092866005,
      "delta_r2_H4perp": 0.06366482187021483,
      "mean_loop_defect": 0.010684359132541921,
      "mean_H4perp": 0.007802114952876078,
      "rank_lift_rate": 1.0
    },
    {
      "mode": "nonlinear",
      "seed_shift": 1,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.3690178127294567,
      "corr_O3mean_loop_defect": 0.794144099111817,
      "corr_edge_loop_defect": -0.10177926625332388,
      "r2_lower_B_O3_edge": 0.6502409625753942,
      "r2_full_plus_H4perp": 0.7554185341157995,
      "delta_r2_H4perp": 0.1051775715404053,
      "mean_loop_defect": 0.01066377577883664,
      "mean_H4perp": 0.008107108324372916,
      "rank_lift_rate": 1.0
    },
    {
      "mode": "nonlinear",
      "seed_shift": 2,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.4550824496479615,
      "corr_O3mean_loop_defect": 0.8569310986798864,
      "corr_edge_loop_defect": -0.12297181252041786,
      "r2_lower_B_O3_edge": 0.805469184012163,
      "r2_full_plus_H4perp": 0.8922408388798682,
      "delta_r2_H4perp": 0.0867716548677051,
      "mean_loop_defect": 0.010861716883783921,
      "mean_H4perp": 0.009687007006758465,
      "rank_lift_rate": 1.0
    },
    {
      "mode": "nonlinear",
      "seed_shift": 3,
      "loop_count": 50,
      "corr_H4perp_loop_defect": 0.2532692004008103,
      "corr_O3mean_loop_defect": 0.8672949060191891,
      "corr_edge_loop_defect": -0.004716564646663934,
      "r2_lower_B_O3_edge": 0.8015085714505344,
      "r2_full_plus_H4perp": 0.8656118376991876,
      "delta_r2_H4perp": 0.06410326624865315,
      "mean_loop_defect": 0.01094880260665085,
      "mean_H4perp": 0.010250698095493798,
      "rank_lift_rate": 1.0
    },
    {
      "mode": "nonlinear",
      "seed_shift": 4,
      "loop_count": 50,
      "corr_H4perp_loop_defect": -0.03918208294083542,
      "corr_O3mean_loop_defect": 0.9128013537550528,
      "corr_edge_loop_defect": -0.026064525020690777,
      "r2_lower_B_O3_edge": 0.8459632414604019,
      "r2_full_plus_H4perp": 0.8808092079681321,
      "delta_r2_H4perp": 0.0348459665077302,
      "mean_loop_defect": 0.01133133645456502,
      "mean_H4perp": 0.010138698697303548,
      "rank_lift_rate": 1.0
    }
  ],
  "outputs": {
    "loop_rows": "/mnt/data/v1688_9_l3_vs_l4_gammaR_defect_separation_outputs/v1688_9_gammaR_loop_rows.csv",
    "summary": "/mnt/data/v1688_9_l3_vs_l4_gammaR_defect_separation_outputs/v1688_9_summary.csv"
  },
  "claim_boundary": "\u0393_R toy explanatory separation only; no Riemann curvature / GR / ADM / physical spacetime claim."
}
```
