# V1688.9 L3 vs L4 Γ_R Defect Separation

Tests ΔR² added by H4⊥ after lower-order controls. No GR claim.
