
# ============================================================
# V1688.13 — Bianchi-like / Conservation Audit for Gamma_R
# ============================================================
# Purpose:
#   Test whether retained connection loop defects R_R satisfy a
#   Bianchi-like compatibility relation over adjacent plaquettes.
#
# Boundary:
#   Toy retained-sector graph only.
#   No Bianchi identity / Riemann / GR / ADM / physical spacetime claim.
# ============================================================

from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_13_bianchi_like_conservation_audit_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-12

def recombine(x, y, gamma=0.35, mode="nonlinear"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if mode=="linear":
        return x+y
    rd=np.r_[x[-1],x[:-1]]
    ru=np.r_[y[1:],y[0]]
    ov=np.minimum(np.abs(x),np.abs(y))/(1+np.minimum(np.abs(x),np.abs(y)))
    return x+y+gamma*ov*(rd*y-x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode=mode),C,mode=mode)-recombine(A,recombine(B,C,mode=mode),mode=mode)

def h4(A,B,C,D,mode="nonlinear"):
    return recombine(recombine(recombine(A,B,mode=mode),C,mode=mode),D,mode=mode)-recombine(A,recombine(B,recombine(C,D,mode=mode),mode=mode),mode=mode)

def normalize(v):
    n=np.linalg.norm(v)
    return v if n<EPS else v/n

def residual_to_span(v,basis):
    B=np.stack(basis,axis=1)
    c=np.linalg.pinv(B)@v
    pred=B@c
    res=v-pred
    return res,float(np.linalg.norm(res))

def make_sector(i,j,dim=12,mode="nonlinear",seed_shift=0):
    a=np.linspace(0,2*np.pi,dim,endpoint=False)
    B=[]
    for k in range(4):
        phase=.37*i+.29*j+.63*k+.031*seed_shift
        v=np.sin((k+1)*a+phase)
        v+=.35*np.cos((k+2)*a-.21*i+.17*j+.047*seed_shift)
        center=(2*k+i+2*j+seed_shift)%dim
        bump=np.zeros(dim)
        bump[center]=1.0
        bump[(center+1)%dim]=.55
        bump[(center-1)%dim]=.35
        v+=.55*bump
        B.append(normalize(v))
    O3=[assoc3(B[0],B[1],B[2],mode),assoc3(B[0],B[1],B[3],mode),assoc3(B[0],B[2],B[3],mode),assoc3(B[1],B[2],B[3],mode)]
    H4=h4(B[0],B[1],B[2],B[3],mode)
    H4p,H4pn=residual_to_span(H4,B+O3)
    return {"B":B,"O3":O3,"H4":H4,"H4_perp":H4p,"H4_perp_norm":H4pn}

def natural_transport(P,Q):
    BP=np.stack(P["B"],axis=1)
    BQ=np.stack(Q["B"],axis=1)
    return BQ @ np.linalg.pinv(BP)

def loop_transport(Ts):
    T=np.eye(Ts[0].shape[0])
    for A in Ts:
        T=A@T
    return T

def build_graph(ngrid=6, dim=12, mode="nonlinear", seed_shift=0):
    sectors={(i,j):make_sector(i,j,dim,mode,seed_shift) for i in range(ngrid) for j in range(ngrid)}
    transports={}
    for i in range(ngrid):
        for j in range(ngrid):
            p=(i,j)
            for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
                if q in sectors:
                    transports[(p,q)]=natural_transport(sectors[p],sectors[q])
    return sectors,transports

def plaquette_loop(i,j,orientation="ccw"):
    if orientation=="ccw":
        return [(i,j),(i+1,j),(i+1,j+1),(i,j+1),(i,j)]
    return [(i,j),(i,j+1),(i+1,j+1),(i+1,j),(i,j)]

def loop_operator(loop, transports):
    Ts=[transports[(a,b)] for a,b in zip(loop[:-1],loop[1:])]
    return loop_transport(Ts)

def loop_defect_vector(loop, sectors, transports):
    p0=loop[0]
    T=loop_operator(loop,transports)
    # Use canonical local test vector = normalized mean of B + O3 + H4perp.
    S=sectors[p0]
    x=np.mean(np.stack(S["B"]+S["O3"]+[S["H4_perp"]],axis=0),axis=0)
    x=normalize(x)
    return T@x-x

def transport_vector_between(vec, start, end, transports):
    if start==end:
        return vec
    # only support local paths in audit: move horizontally then vertically.
    si,sj=start; ei,ej=end
    v=vec.copy()
    cur=(si,sj)
    step=1 if ei>=si else -1
    for ii in range(si,ei,step):
        nxt=(ii+step,sj)
        v=transports[(cur,nxt)]@v
        cur=nxt
    step=1 if ej>=sj else -1
    for jj in range(sj,ej,step):
        nxt=(cur[0],jj+step)
        v=transports[(cur,nxt)]@v
        cur=nxt
    return v

def audit_cell(i,j,sectors,transports):
    # Bianchi-like audit over 2x2 block of plaquettes:
    # signed sum of four plaquette defects, transported to common base (i,j).
    base=(i,j)
    plaquettes=[(i,j),(i+1,j),(i,j+1),(i+1,j+1)]
    vecs=[]
    norms=[]
    for idx,p in enumerate(plaquettes):
        loop=plaquette_loop(p[0],p[1],"ccw")
        dv=loop_defect_vector(loop,sectors,transports)
        # transport defect vector back to common base by using reverse local path
        dv_base=transport_vector_between(dv,p,base,transports)
        vecs.append(dv_base)
        norms.append(np.linalg.norm(dv_base))
    signed_sum=np.sum(np.stack(vecs,axis=0),axis=0)
    b_res=float(np.linalg.norm(signed_sum))
    denom=float(np.sum(norms)+EPS)
    normalized=b_res/denom
    return {
        "cell_i":i,"cell_j":j,
        "B_R_residual":b_res,
        "B_R_normalized":normalized,
        "component_norm_sum":denom,
        "mean_component_norm":float(np.mean(norms)),
        "max_component_norm":float(np.max(norms)),
        "local_H4perp_mean":float(np.mean([sectors[p]["H4_perp_norm"] for p in plaquettes]))
    }

def corr(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

configs=[]
for dim in [10,12,14]:
    for ngrid in [5,6,7]:
        for seed_shift in range(3):
            configs.append(("nonlinear",ngrid,dim,seed_shift))
configs.append(("linear",6,12,0))

rows=[]
for mode,ngrid,dim,seed_shift in configs:
    sectors,transports=build_graph(ngrid,dim,mode,seed_shift)
    for i in range(ngrid-2):
        for j in range(ngrid-2):
            row=audit_cell(i,j,sectors,transports)
            row.update({"mode":mode,"ngrid":ngrid,"dim":dim,"seed_shift":seed_shift})
            rows.append(row)

df=pd.DataFrame(rows)
df.to_csv(OUT/"v1688_13_bianchi_cell_rows.csv",index=False)

summary=[]
for keys,sub in df.groupby(["mode","ngrid","dim","seed_shift"]):
    mode,ngrid,dim,seed_shift=keys
    summary.append({
        "mode":mode,
        "ngrid":int(ngrid),
        "dim":int(dim),
        "seed_shift":int(seed_shift),
        "cell_count":int(len(sub)),
        "mean_B_R_normalized":float(sub.B_R_normalized.mean()),
        "median_B_R_normalized":float(sub.B_R_normalized.median()),
        "min_B_R_normalized":float(sub.B_R_normalized.min()),
        "max_B_R_normalized":float(sub.B_R_normalized.max()),
        "mean_component_norm":float(sub.mean_component_norm.mean()),
        "corr_H4perp_BR_normalized":corr(sub.local_H4perp_mean,sub.B_R_normalized)
    })
summ=pd.DataFrame(summary)
summ.to_csv(OUT/"v1688_13_summary.csv",index=False)

nonlin=summ[summ["mode"]=="nonlinear"]
linear=summ[summ["mode"]=="linear"]

mean_BR=float(nonlin.mean_B_R_normalized.mean())
median_BR=float(nonlin.median_B_R_normalized.mean())
max_BR=float(nonlin.max_B_R_normalized.mean())
mean_corr_H4_BR=float(nonlin.corr_H4perp_BR_normalized.mean())
linear_BR=float(linear.mean_B_R_normalized.mean()) if len(linear)>0 else None

# Bianchi-like compatibility would mean normalized residual substantially below 1
# and stable across configs. Strong <0.35, partial <0.60.
if mean_BR < 0.35 and max_BR < 0.75:
    verdict="GAMMAR_BIANCHI_LIKE_COMPATIBILITY_SUPPORTED"
elif mean_BR < 0.60:
    verdict="GAMMAR_BIANCHI_LIKE_COMPATIBILITY_PARTIAL"
else:
    verdict="GAMMAR_BIANCHI_LIKE_COMPATIBILITY_NOT_SUPPORTED"

result={
    "document_id":"V1688_13_BIANCHI_LIKE_CONSERVATION_AUDIT",
    "status":"completed",
    "verdict":verdict,
    "nonlinear_config_count":int(len(nonlin)),
    "mean_B_R_normalized":mean_BR,
    "median_B_R_normalized_mean":median_BR,
    "mean_max_B_R_normalized":max_BR,
    "mean_corr_H4perp_BR_normalized":mean_corr_H4_BR,
    "linear_control_mean_B_R_normalized":linear_BR,
    "outputs":{
        "cell_rows":str(OUT/"v1688_13_bianchi_cell_rows.csv"),
        "summary":str(OUT/"v1688_13_summary.csv")
    },
    "claim_boundary":"Bianchi-like retained compatibility toy audit only; no Bianchi identity / Riemann curvature / GR / ADM / physical spacetime claim."
}
(OUT/"v1688_13_result.json").write_text(json.dumps(result,indent=2))
(OUT/"V1688_13_BIANCHI_LIKE_CONSERVATION_AUDIT_REPORT.md").write_text("# V1688.13 — Bianchi-like / Conservation Audit\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
