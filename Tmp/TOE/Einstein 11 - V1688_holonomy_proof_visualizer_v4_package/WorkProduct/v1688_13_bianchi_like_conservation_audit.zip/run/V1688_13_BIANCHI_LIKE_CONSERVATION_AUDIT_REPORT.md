# V1688.13 — Bianchi-like / Conservation Audit

```json
{
  "document_id": "V1688_13_BIANCHI_LIKE_CONSERVATION_AUDIT",
  "status": "completed",
  "verdict": "GAMMAR_BIANCHI_LIKE_COMPATIBILITY_NOT_SUPPORTED",
  "nonlinear_config_count": 27,
  "mean_B_R_normalized": 0.9999999999485966,
  "median_B_R_normalized_mean": 0.9999999999534107,
  "mean_max_B_R_normalized": 0.999999999969948,
  "mean_corr_H4perp_BR_normalized": 0.09054837962818661,
  "linear_control_mean_B_R_normalized": 0.0032152028884172776,
  "outputs": {
    "cell_rows": "/mnt/data/v1688_13_bianchi_like_conservation_audit_outputs/v1688_13_bianchi_cell_rows.csv",
    "summary": "/mnt/data/v1688_13_bianchi_like_conservation_audit_outputs/v1688_13_summary.csv"
  },
  "claim_boundary": "Bianchi-like retained compatibility toy audit only; no Bianchi identity / Riemann curvature / GR / ADM / physical spacetime claim."
}
```
