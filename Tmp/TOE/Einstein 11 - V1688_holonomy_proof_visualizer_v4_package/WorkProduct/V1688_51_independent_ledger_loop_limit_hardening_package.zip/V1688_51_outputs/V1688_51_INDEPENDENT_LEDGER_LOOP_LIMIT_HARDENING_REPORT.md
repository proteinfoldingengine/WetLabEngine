# V1688.51 — Independent Ledger Regeneration and Graph-Cycle Loop-Limit Hardening

## Verdict

```text
INDEPENDENT_LEDGER_LOOP_LIMIT_PASS
```

## Purpose

V1688.50 passed after regenerating an explicit node / provenance-edge / graph-cycle ledger. V1688.51 asks whether that pass survives independent regeneration rather than one ledger family.

The harness emits two independently generated retained-operator modes and validates by holding out entire generator modes, families, resolutions, and seeds.

## First-principles constraints

```text
explicit provenance ledger emitted at construction
explicit graph cycle basis emitted at construction
no post-hoc rectangular-loop reconstruction
no kNN / threshold-inferred cycle repair
no fitted counterterms
no threshold-tuned pass rule
no raw alpha/beta transport
```

## Claim boundary

Finite retained-flow toy harness only. No ADM, GR, Riemann curvature, physical spacetime, Einstein equations, or Bianchi identity claim.

## Emitted ledger

```text
nodes:  29696
edges:  114176
cycles: 27440
```

## Model

```text
Y = weak_target
M0 = source_abs + access_abs + div_baseline
C_corr = dimensionless residualized Gamma_R_edge + H4_perp mode
loop_defect = emitted graph-cycle signed-projection holonomy defect
M_loop = M0 + C_corr + loop_defect
```

`conf_proxy` and `closure_surplus` were used only to construct/audit the target and were excluded from all predictive models.

## Main results

```text
Mean M0 R²:                    +0.005693
Mean C_corr R²:                +0.092318
Mean C_corr + loop R²:         +0.132129

Mean ΔR² C_corr over M0:       +0.086625
Mean ΔR² C_corr+loop over M0:  +0.126436
Mean loop unique gain:         +0.039811

C_corr+loop positive rate:     1.000
Generator holdout positive:    1.000
Resolution positive rate:      1.000
```

## Nulls

```text
Critical null max mean ΔR²:    +0.086799
Observed-null margin:          +0.039637
Finest-3 loop Δ CV:            0.077401
```

## Interpretation

The explicit provenance ledger result survives independent regeneration across two operator-generation modes. The loop object is now provenance-valid and not merely a reconstructed rectangular adjacency artifact.

The key readout is that the correction-plus-loop model remains positive under generator-mode, family, resolution, and seed holdout, and it remains separated from the main nulls.

## Valid bounded claim

```text
In this finite retained-flow toy harness, independently regenerated explicit
node/edge/cycle ledgers preserve the Gamma_R/H4 correction signal and support
a graph-cycle loop consistency signal beyond source-flow baseline and nulls.
```

## Recommended next step

```text
V1688.52 — separate loop object into exact-cycle defect and correction-loss components
```
