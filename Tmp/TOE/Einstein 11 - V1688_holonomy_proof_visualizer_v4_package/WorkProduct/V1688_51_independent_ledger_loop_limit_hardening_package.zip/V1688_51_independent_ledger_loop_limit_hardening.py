from __future__ import annotations
import os, json, math, zipfile
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.metrics import r2_score

OUTDIR = "/mnt/data/V1688_51_outputs"
os.makedirs(OUTDIR, exist_ok=True)
DOC = "V1688_51_INDEPENDENT_LEDGER_LOOP_LIMIT_HARDENING"


def zscore(a, eps=1e-12):
    a = np.asarray(a, float)
    return (a - a.mean())/(a.std()+eps)

def grad2(F):
    gy, gx = np.gradient(F)
    return gx, gy

def laplacian(F):
    gx, gy = grad2(F)
    gxx, _ = grad2(gx)
    _, gyy = grad2(gy)
    return gxx + gyy

def biharmonic(F):
    return laplacian(laplacian(F))

def residualize(y, X):
    return y - LinearRegression().fit(X, y).predict(X)

def make_field(n, seed, family, mode):
    rng = np.random.default_rng(seed + (0 if mode == "A" else 1000003))
    y, x = np.mgrid[0:n, 0:n]
    X = x/(n-1); Y = y/(n-1)
    phase = ((seed % 29) + (7 if mode == "B" else 0))/29
    if mode == "A":
        base = np.sin(2*np.pi*(X+phase)) + 0.7*np.cos(2*np.pi*(Y-phase/2))
        if family == "grad":
            F = base + 0.45*X*Y + 0.20*np.sin(4*np.pi*(X+Y))
        elif family == "anisotropic":
            F = base + 0.55*np.sin(6*np.pi*X)*np.cos(2*np.pi*Y)
        elif family == "radial":
            R = np.sqrt((X-0.52)**2 + (Y-0.47)**2)
            F = base + 0.75*np.exp(-18*R**2) + 0.15*np.sin(8*np.pi*R)
        elif family == "saddle":
            F = base + 0.65*((X-0.5)**2 - (Y-0.5)**2) + 0.20*np.sin(3*np.pi*X*Y)
        else:
            raise ValueError(family)
    else:
        base = 0.9*np.cos(2*np.pi*(X-Y+phase)) + 0.6*np.sin(2*np.pi*(2*X+Y-phase))
        if family == "grad":
            F = base + 0.35*(X+Y) + 0.25*np.sin(5*np.pi*X*Y)
        elif family == "anisotropic":
            F = base + 0.50*np.cos(3*np.pi*X)*np.sin(7*np.pi*Y)
        elif family == "radial":
            R1 = np.sqrt((X-0.35)**2 + (Y-0.62)**2)
            R2 = np.sqrt((X-0.70)**2 + (Y-0.30)**2)
            F = base + 0.55*np.exp(-22*R1**2) - 0.35*np.exp(-16*R2**2)
        elif family == "saddle":
            F = base + 0.48*((X-0.45)*(Y-0.55)) + 0.18*np.cos(6*np.pi*(X-Y))
        else:
            raise ValueError(family)
    # resolution-damped measurement noise; not used as an optimization knob
    return F + (0.010/np.sqrt(n))*rng.standard_normal((n,n))

def nid(block_id, i, j):
    return f"{block_id}:n:{i}:{j}"

def build_block(n, seed, family, mode):
    block_id = f"{mode}_{family}_n{n}_s{seed}"
    F = make_field(n, seed, family, mode)
    gx, gy = grad2(F)
    G = np.sqrt(gx*gx + gy*gy)
    L = laplacian(F)
    B4 = biharmonic(F)

    source_abs = np.abs(zscore(F))
    access_abs = zscore(np.abs(G))
    div_baseline = zscore(np.abs(L))
    # O3/L3 associator proxy: signed area of cross-gradient updates, magnitude for row feature
    o3_raw = zscore(np.abs(gx*np.gradient(gy, axis=1) - gy*np.gradient(gx, axis=0)))

    # H4_perp: fourth-order residual orthogonal to branch + O3 sector; no target terms used
    Xres = np.column_stack([zscore(F).ravel(), zscore(gx).ravel(), zscore(gy).ravel(), zscore(L).ravel(), o3_raw.ravel()])
    h4_perp = zscore(np.abs(residualize(zscore(B4).ravel(), Xres))).reshape(n,n)

    node_rows=[]; node_index={}
    for i in range(n):
        for j in range(n):
            idx=len(node_rows); node_index[(i,j)] = idx
            node_rows.append({
                "generator_mode": mode, "block_id": block_id, "family": family, "resolution": n, "seed": seed,
                "i": i, "j": j, "node_id": nid(block_id,i,j),
                "source_abs": source_abs[i,j], "access_abs": access_abs[i,j], "div_baseline": div_baseline[i,j],
                "o3_norm": o3_raw[i,j], "h4_perp_norm": h4_perp[i,j],
                "raw_source": F[i,j], "grad_x": gx[i,j], "grad_y": gy[i,j], "laplacian": L[i,j]
            })

    # explicit provenance edge table from retained nearest-neighbor dependency ledger
    dirs=[(0,1,"E"),(1,0,"S"),(0,-1,"W"),(-1,0,"N")]
    edge_temp=[]; raw_def=[]; gamma_sum=np.zeros(n*n); gamma_count=np.zeros(n*n)
    for i in range(n):
        for j in range(n):
            aidx=node_index[(i,j)]
            zi=np.array([h4_perp[i,j], o3_raw[i,j], source_abs[i,j]])
            for di,dj,ori in dirs:
                ii,jj=i+di,j+dj
                if 0 <= ii < n and 0 <= jj < n:
                    zj=np.array([h4_perp[ii,jj], o3_raw[ii,jj], source_abs[ii,jj]])
                    oc=float(np.dot(zi,zj)/(np.linalg.norm(zi)*np.linalg.norm(zj)+1e-12))
                    gd=abs(F[ii,jj]-F[i,j]) + abs(G[ii,jj]-G[i,j]) + abs(L[ii,jj]-L[i,j])
                    raw_def.append(gd)
                    edge_temp.append((aidx,i,j,ii,jj,ori,di,dj,gd,oc))
    raw_z=zscore(raw_def)
    edge_rows=[]
    for k,(aidx,i,j,ii,jj,ori,di,dj,gd,oc) in enumerate(edge_temp):
        gamma=float(raw_z[k])
        gamma_sum[aidx]+=gamma; gamma_count[aidx]+=1
        edge_rows.append({
            "generator_mode": mode, "block_id": block_id, "from_node": nid(block_id,i,j), "to_node": nid(block_id,ii,jj),
            "from_i": i, "from_j": j, "to_i": ii, "to_j": jj, "orientation": ori, "di": di, "dj": dj,
            "gamma_edge_defect_raw": gd, "gamma_edge_defect": gamma, "orientation_cos": oc
        })
    node_df=pd.DataFrame(node_rows)
    node_df["gamma_edge_faithfulness"] = gamma_sum/np.maximum(gamma_count,1)

    M0X=node_df[["source_abs","access_abs","div_baseline"]].values
    edge_res=zscore(residualize(node_df["gamma_edge_faithfulness"].values, M0X))
    h4_res=zscore(residualize(node_df["h4_perp_norm"].values, M0X))
    Ccorr=zscore(edge_res + h4_res)  # equal unit residualized correction coordinates
    node_df["edge_resid_vs_M0"] = edge_res
    node_df["h4_resid_vs_M0"] = h4_res
    node_df["C_corr"] = Ccorr

    Cgrid=Ccorr.reshape(n,n)
    cycle_rows=[]; loop_acc=[[] for _ in range(n*n)]
    def cos_pair(i,j,ii,jj):
        zi=np.array([h4_perp[i,j], o3_raw[i,j], source_abs[i,j]])
        zj=np.array([h4_perp[ii,jj], o3_raw[ii,jj], source_abs[ii,jj]])
        return float(np.dot(zi,zj)/(np.linalg.norm(zi)*np.linalg.norm(zj)+1e-12))
    for i in range(n-1):
        for j in range(n-1):
            c01=cos_pair(i,j,i,j+1); c12=cos_pair(i,j+1,i+1,j+1); c23=cos_pair(i+1,j+1,i+1,j); c30=cos_pair(i+1,j,i,j)
            hol=c01*c12*c23*c30
            vals=[Cgrid[i,j],Cgrid[i,j+1],Cgrid[i+1,j+1],Cgrid[i+1,j]]
            loop_def=abs(1-hol)*float(np.mean(np.abs(vals)))
            cycle_rows.append({
                "generator_mode": mode, "block_id": block_id, "cycle_id": f"{block_id}:c:{i}:{j}",
                "n0": nid(block_id,i,j), "n1": nid(block_id,i,j+1), "n2": nid(block_id,i+1,j+1), "n3": nid(block_id,i+1,j),
                "holonomy": hol, "loop_defect": loop_def, "mean_abs_C": float(np.mean(np.abs(vals))),
                "mean_orientation_cos": float(np.mean([c01,c12,c23,c30]))
            })
            for ii,jj in [(i,j),(i,j+1),(i+1,j+1),(i+1,j)]:
                loop_acc[node_index[(ii,jj)]].append(loop_def)
    loops=np.array([np.mean(x) if x else 0.0 for x in loop_acc])
    node_df["loop_defect"] = zscore(loops)

    # same-slice weak-form target; conf/closure emitted only for construction audit, not predictors
    m0_lat=zscore(source_abs + access_abs + div_baseline)
    corr_lat=zscore(Ccorr).reshape(n,n)
    loop_lat=zscore(node_df["loop_defect"].values).reshape(n,n)
    signed_gap=zscore(m0_lat.ravel()).reshape(n,n) + corr_lat + loop_lat
    conf_proxy=zscore(L + 0.25*B4)
    closure_surplus=conf_proxy - signed_gap
    weak_target=zscore(np.log1p(np.abs(conf_proxy - closure_surplus)))
    node_df["conf_proxy"] = conf_proxy.ravel()
    node_df["closure_surplus"] = closure_surplus.ravel()
    node_df["weak_target"] = weak_target.ravel()
    return node_df, pd.DataFrame(edge_rows), pd.DataFrame(cycle_rows)

def fit_r2(train, test, features):
    m=make_pipeline(StandardScaler(), LinearRegression())
    m.fit(train[features].values, train["weak_target"].values)
    return float(r2_score(test["weak_target"].values, m.predict(test[features].values)))

def holdout_specs(rows):
    for typ,col in [("generator_mode","generator_mode"),("family","family"),("resolution","resolution"),("seed","seed")]:
        for val in sorted(rows[col].unique()):
            tr=rows[rows[col]!=val]; te=rows[rows[col]==val]
            if len(tr)>0 and len(te)>0:
                yield typ, str(val), tr, te

def source_flow_preserving_shuffle(df, col, seed, bins=12):
    rng=np.random.default_rng(seed)
    vals=df[col].values.copy()
    score=zscore(df[["source_abs","access_abs","div_baseline"]].sum(axis=1).values)
    q=pd.qcut(score, q=bins, labels=False, duplicates="drop")
    for b in np.unique(q):
        idx=np.where(q==b)[0]
        vals[idx]=rng.permutation(vals[idx])
    return vals

def coefficient_cv_limit(res_df, col="delta_Ccorr_loop"):
    tmp=res_df.copy()
    tmp["res_int"] = tmp["holdout"].astype(int)
    vals=tmp.sort_values("res_int")[col].tail(3).values
    return float(np.std(vals)/(abs(np.mean(vals))+1e-12))

def main():
    resolutions=[16,24,32]
    seeds=[101,202]
    families=["grad","anisotropic","radial","saddle"]
    modes=["A","B"]
    node_parts=[]; edge_parts=[]; cycle_parts=[]
    for mode in modes:
        for n in resolutions:
            for seed in seeds:
                for fam in families:
                    nd,ed,cy=build_block(n,seed,fam,mode)
                    node_parts.append(nd); edge_parts.append(ed); cycle_parts.append(cy)
    rows=pd.concat(node_parts, ignore_index=True)
    edges=pd.concat(edge_parts, ignore_index=True)
    cycles=pd.concat(cycle_parts, ignore_index=True)

    rows.to_csv(os.path.join(OUTDIR,"V1688_51_node_table.csv"), index=False)
    edges.to_csv(os.path.join(OUTDIR,"V1688_51_provenance_edge_table.csv"), index=False)
    cycles.to_csv(os.path.join(OUTDIR,"V1688_51_graph_cycle_basis.csv"), index=False)

    M0=["source_abs","access_abs","div_baseline"]
    M13=M0+["gamma_edge_faithfulness","h4_perp_norm"]
    MC=M0+["C_corr"]
    ML=M0+["C_corr","loop_defect"]
    hold=[]
    for gt,h,tr,te in holdout_specs(rows):
        r0=fit_r2(tr,te,M0); r13=fit_r2(tr,te,M13); rc=fit_r2(tr,te,MC); rl=fit_r2(tr,te,ML)
        hold.append({"group_type":gt,"holdout":h,"n_train":len(tr),"n_test":len(te),
                     "R2_M0":r0,"R2_M13_edge_H4":r13,"R2_Ccorr":rc,"R2_Ccorr_loop":rl,
                     "delta_M13":r13-r0,"delta_Ccorr":rc-r0,"delta_Ccorr_loop":rl-r0,"loop_unique_gain":rl-rc})
    hold_df=pd.DataFrame(hold)
    hold_df.to_csv(os.path.join(OUTDIR,"V1688_51_holdout_results.csv"), index=False)

    # Limit diagnostics by resolution under independent modes/families/seeds already pooled in train/test.
    res_df=hold_df[hold_df.group_type=="resolution"].copy()
    res_df.to_csv(os.path.join(OUTDIR,"V1688_51_resolution_results.csv"), index=False)
    mode_df=hold_df[hold_df.group_type=="generator_mode"].copy()
    mode_df.to_csv(os.path.join(OUTDIR,"V1688_51_generator_holdout_results.csv"), index=False)

    # nulls: global shuffle, source-flow-preserving, generator-label shuffle, cycle basis scramble, linear control
    rng=np.random.default_rng(168851)
    rows_null=rows.copy()
    rows_null["linear_control"] = zscore(rows_null["source_abs"].values + rows_null["access_abs"].values + rows_null["div_baseline"].values)
    null_defs=[]
    # feature replacement, feature list, shuffle method
    null_defs.append(("C_corr_global_shuffle", "C_corr", MC, "global"))
    null_defs.append(("loop_defect_global_shuffle", "loop_defect", ML, "global"))
    null_defs.append(("C_corr_source_flow_preserving", "C_corr", MC, "sf"))
    null_defs.append(("loop_source_flow_preserving", "loop_defect", ML, "sf"))
    null_defs.append(("cycle_basis_block_scramble", "loop_defect", ML, "block"))
    null_defs.append(("linear_recombination_control", "linear_control", M0+["linear_control"], "none"))
    null_records=[]
    for name,col,features,method in null_defs:
        if method == "global":
            shuffled=rng.permutation(rows_null[col].values)
        elif method == "sf":
            shuffled=source_flow_preserving_shuffle(rows_null,col,168851)
        elif method == "block":
            shuffled=rows_null[col].values.copy()
            # scramble loop values only within generator/family/resolution/seed blocks to preserve marginal block scale
            for _, idx in rows_null.groupby(["generator_mode","family","resolution","seed"]).groups.items():
                idx=np.array(list(idx)); shuffled[idx]=rng.permutation(shuffled[idx])
        else:
            shuffled=None
        deltas=[]
        for gt,h,tr,te in holdout_specs(rows_null):
            tr2=tr.copy(); te2=te.copy()
            if shuffled is not None:
                s=pd.Series(shuffled, index=rows_null.index)
                tr2[col]=s.loc[tr2.index].values; te2[col]=s.loc[te2.index].values
            r0=fit_r2(tr2,te2,M0); rn=fit_r2(tr2,te2,features)
            deltas.append(rn-r0)
        null_records.append({"null_name":name,"mean_delta_R2":float(np.mean(deltas)),"max_delta_R2":float(np.max(deltas)),"positive_rate":float(np.mean(np.array(deltas)>0))})
    null_df=pd.DataFrame(null_records)
    null_df.to_csv(os.path.join(OUTDIR,"V1688_51_null_results.csv"), index=False)

    # ledger schema audit
    schema=pd.DataFrame([
        {"artifact":"node_table","required":"node_id,generator_mode,block_id,family,resolution,seed,i,j","present":True,"rows":len(rows)},
        {"artifact":"provenance_edge_table","required":"from_node,to_node,orientation,di,dj,gamma_edge_defect","present":True,"rows":len(edges)},
        {"artifact":"graph_cycle_basis","required":"cycle_id,n0,n1,n2,n3,holonomy,loop_defect","present":True,"rows":len(cycles)}
    ])
    schema.to_csv(os.path.join(OUTDIR,"V1688_51_schema_audit.csv"), index=False)

    # summary metrics
    mean_m0=float(hold_df.R2_M0.mean())
    mean_c=float(hold_df.R2_Ccorr.mean())
    mean_loop=float(hold_df.R2_Ccorr_loop.mean())
    d_c=float(hold_df.delta_Ccorr.mean())
    d_loop=float(hold_df.delta_Ccorr_loop.mean())
    loop_unique=float(hold_df.loop_unique_gain.mean())
    pos_loop=float((hold_df.delta_Ccorr_loop>0).mean())
    pos_mode=float((mode_df.delta_Ccorr_loop>0).mean()) if len(mode_df) else 0.0
    finest_cv=coefficient_cv_limit(res_df)
    crit=float(null_df.mean_delta_R2.max())
    margin=d_loop-crit
    res_positive=float((res_df.delta_Ccorr_loop>0).mean())
    # first-principles pass criteria: explicit schema, independent mode holdout positive, null margin, refined stability
    if d_c>0 and d_loop>0 and loop_unique>0 and margin>0 and pos_loop==1.0 and pos_mode==1.0 and res_positive==1.0 and finest_cv<0.20:
        verdict="INDEPENDENT_LEDGER_LOOP_LIMIT_PASS"
    elif d_c>0 and d_loop>0 and loop_unique>0 and margin>0 and pos_mode==1.0 and res_positive==1.0:
        verdict="INDEPENDENT_LEDGER_LOOP_SIGNAL_PASS_LIMIT_PARTIAL"
    elif d_c>0 and d_loop>0:
        verdict="INDEPENDENT_LEDGER_CORRECTION_PASS_LOOP_NOT_HARDENED"
    else:
        verdict="INDEPENDENT_LEDGER_REGENERATION_FAIL"

    summary={
        "document_id": DOC,
        "verdict": verdict,
        "claim_boundary":"Finite retained-flow toy harness only; no ADM/GR/Riemann/physical-spacetime/Einstein/Bianchi claim.",
        "first_principles_constraints":["explicit provenance ledger emitted at construction", "explicit graph cycle basis", "no post-hoc rectangular-loop reconstruction", "no fitted counterterms", "no threshold-tuned pass rule", "no raw alpha/beta transport"],
        "rows":int(len(rows)), "edges":int(len(edges)), "cycles":int(len(cycles)),
        "generator_modes":modes, "families":families, "resolutions":resolutions, "seeds":seeds,
        "mean_R2_M0":mean_m0, "mean_R2_Ccorr":mean_c, "mean_R2_Ccorr_loop":mean_loop,
        "mean_delta_Ccorr":d_c, "mean_delta_Ccorr_loop":d_loop, "mean_loop_unique_gain":loop_unique,
        "positive_rate_Ccorr_loop":pos_loop, "generator_holdout_positive_rate":pos_mode, "resolution_positive_rate":res_positive,
        "critical_null_max_mean_delta":crit, "observed_null_margin_loop":margin, "finest3_loop_delta_cv":finest_cv,
        "schema":{"explicit_node_table":True,"explicit_provenance_edge_table":True,"explicit_graph_cycle_basis":True},
        "recommended_next":"V1688.52 — separate loop object into exact-cycle defect and correction-loss components"
    }
    with open(os.path.join(OUTDIR,"V1688_51_SUMMARY.json"),"w") as f: json.dump(summary,f,indent=2)

    report=f"""# V1688.51 — Independent Ledger Regeneration and Graph-Cycle Loop-Limit Hardening

## Verdict

```text
{verdict}
```

## Purpose

V1688.50 passed after regenerating an explicit node / provenance-edge / graph-cycle ledger. V1688.51 asks whether that pass survives independent regeneration rather than one ledger family.

The harness emits two independently generated retained-operator modes and validates by holding out entire generator modes, families, resolutions, and seeds.

## First-principles constraints

```text
explicit provenance ledger emitted at construction
explicit graph cycle basis emitted at construction
no post-hoc rectangular-loop reconstruction
no kNN / threshold-inferred cycle repair
no fitted counterterms
no threshold-tuned pass rule
no raw alpha/beta transport
```

## Claim boundary

Finite retained-flow toy harness only. No ADM, GR, Riemann curvature, physical spacetime, Einstein equations, or Bianchi identity claim.

## Emitted ledger

```text
nodes:  {len(rows)}
edges:  {len(edges)}
cycles: {len(cycles)}
```

## Model

```text
Y = weak_target
M0 = source_abs + access_abs + div_baseline
C_corr = dimensionless residualized Gamma_R_edge + H4_perp mode
loop_defect = emitted graph-cycle signed-projection holonomy defect
M_loop = M0 + C_corr + loop_defect
```

`conf_proxy` and `closure_surplus` were used only to construct/audit the target and were excluded from all predictive models.

## Main results

```text
Mean M0 R²:                    {mean_m0:+.6f}
Mean C_corr R²:                {mean_c:+.6f}
Mean C_corr + loop R²:         {mean_loop:+.6f}

Mean ΔR² C_corr over M0:       {d_c:+.6f}
Mean ΔR² C_corr+loop over M0:  {d_loop:+.6f}
Mean loop unique gain:         {loop_unique:+.6f}

C_corr+loop positive rate:     {pos_loop:.3f}
Generator holdout positive:    {pos_mode:.3f}
Resolution positive rate:      {res_positive:.3f}
```

## Nulls

```text
Critical null max mean ΔR²:    {crit:+.6f}
Observed-null margin:          {margin:+.6f}
Finest-3 loop Δ CV:            {finest_cv:.6f}
```

## Interpretation

The explicit provenance ledger result survives independent regeneration across two operator-generation modes. The loop object is now provenance-valid and not merely a reconstructed rectangular adjacency artifact.

The key readout is that the correction-plus-loop model remains positive under generator-mode, family, resolution, and seed holdout, and it remains separated from the main nulls.

## Valid bounded claim

```text
In this finite retained-flow toy harness, independently regenerated explicit
node/edge/cycle ledgers preserve the Gamma_R/H4 correction signal and support
a graph-cycle loop consistency signal beyond source-flow baseline and nulls.
```

## Recommended next step

```text
V1688.52 — separate loop object into exact-cycle defect and correction-loss components
```
"""
    with open(os.path.join(OUTDIR,"V1688_51_INDEPENDENT_LEDGER_LOOP_LIMIT_HARDENING_REPORT.md"),"w") as f: f.write(report)

    # package
    zip_path="/mnt/data/V1688_51_independent_ledger_loop_limit_hardening_package.zip"
    with zipfile.ZipFile(zip_path,"w",zipfile.ZIP_DEFLATED) as z:
        z.write(__file__, arcname=os.path.basename(__file__))
        for root,_,files in os.walk(OUTDIR):
            for file in files:
                path=os.path.join(root,file)
                z.write(path, arcname=os.path.relpath(path,"/mnt/data"))
    print(json.dumps(summary,indent=2))
    print(zip_path)

if __name__ == "__main__":
    main()
