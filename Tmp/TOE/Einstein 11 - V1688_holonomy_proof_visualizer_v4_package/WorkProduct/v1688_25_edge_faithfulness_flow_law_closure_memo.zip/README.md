# V1688.25 Edge-Faithfulness Same-Slice Flow Law Closure Memo

Bounded closure of the L3/O3 same-slice flow law.
