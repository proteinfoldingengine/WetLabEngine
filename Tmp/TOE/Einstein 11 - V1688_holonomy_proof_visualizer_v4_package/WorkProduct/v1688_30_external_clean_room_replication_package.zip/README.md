# V1688.30 — External Clean-Room Replication Package

This package is standalone. It reproduces the bounded V1688 edge-faithfulness same-slice retained-flow result.

## Claim boundary

This is a finite retained-flow toy harness.

It does **not** claim:

- ADM derivation
- General Relativity
- Riemann curvature
- physical spacetime
- universal continuum theorem

## Bounded hypothesis

Same-slice retained-flow residual is corrected by generated-algebra operator-faithfulness defect across retained transport edges.

## Run

```bash
python v1688_30_clean_room_replication.py
```

Outputs are written to:

```text
v1688_30_outputs/
```

## Expected result

The real edge-faithfulness correction should improve the flow-only model substantially, while the shuffled edge-faithfulness null should be much weaker.

## Main objects

```text
G_p = generated retained recombination algebra at sector p
T_pq = retained transport from G_p to G_q

D_Gamma^{p->q}(x,y)
=
T_pq(x ⊕_p y) - T_pq(x) ⊕_q T_pq(y)

E_Gamma(p->q)
=
average ||D_Gamma^{p->q}(x,y)|| over generated-algebra elements
```
