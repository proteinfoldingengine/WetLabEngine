# V1688.30 External Clean-Room Replication Notes

## Result to replicate

The bounded law from V1688.29:

> Same-slice retained-flow residual is corrected by generated-algebra operator-faithfulness defect across retained transport edges.

## Why this matters

This identifies a specific mechanism, not a vague geometry claim.

The mechanism is:

```text
retained transport must preserve the generated recombination law;
when it fails, the edge-faithfulness defect corrects same-slice flow residuals.
```

## Layer roles

```text
L1 = retained identity
L2 = pairwise geometry-like closure
L3/O3 = edge-faithfulness law for same-slice flow correction
L4/H4_perp = independent Gamma_R loop-defect correction
```

## What this package does

It builds a small retained-sector grid, defines recombination operators, constructs branch-frame transports, computes generated-algebra edge-faithfulness defects, and tests whether adding that defect improves a same-slice retained-flow residual.

It also runs edge-shuffle nulls.

## What this package does not do

It does not test or claim ADM, GR, Riemann curvature, physical spacetime, or continuum-limit closure.
