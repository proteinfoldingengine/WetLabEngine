
# ============================================================
# V1688.8 — Minimal Γ_R Toy Implementation
# ============================================================
# Purpose:
#   First executable test of the retained-recombination connection Γ_R.
#
# Builds:
#   - small retained-sector lattice
#   - local generated algebra summaries
#   - natural transports T_{p→q} from branch matching
#   - loop defect R_R around plaquettes
#   - local H4⊥ predictor against R_R
#
# Boundary:
#   Toy finite retained-sector graph.
#   No Riemann curvature / GR / ADM / physical spacetime claim.
# ============================================================

from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT = Path("/mnt/data/v1688_8_minimal_gammaR_toy_implementation_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-12
SEED = 16888
rng = np.random.default_rng(SEED)

def recombine(x, y, gamma=0.35, mode="nonlinear"):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    if mode == "linear":
        return x + y
    rd = np.r_[x[-1], x[:-1]]
    ru = np.r_[y[1:], y[0]]
    overlap = np.minimum(np.abs(x), np.abs(y)) / (1 + np.minimum(np.abs(x), np.abs(y)))
    return x + y + gamma * overlap * (rd*y - x*ru)

def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode=mode),C,mode=mode) - recombine(A,recombine(B,C,mode=mode),mode=mode)

def h4(A,B,C,D,mode="nonlinear"):
    left = recombine(recombine(recombine(A,B,mode=mode),C,mode=mode),D,mode=mode)
    right = recombine(A,recombine(B,recombine(C,D,mode=mode),mode=mode),mode=mode)
    return left - right

def mat_rank(cols, tol=1e-9):
    M = np.stack(cols, axis=1)
    return int(np.linalg.matrix_rank(M, tol=tol))

def residual_to_span(v, basis):
    B = np.stack(basis, axis=1)
    coef = np.linalg.pinv(B) @ v
    pred = B @ coef
    res = v - pred
    return res, float(np.linalg.norm(res))

def normalize(v):
    n = np.linalg.norm(v)
    return v if n < EPS else v/n

def make_sector(i, j, dim=12, mode="nonlinear"):
    """
    Local retained sector p=(i,j).
    Branches vary smoothly by sector plus small retained-order perturbation.
    """
    base_angles = np.linspace(0, 2*np.pi, dim, endpoint=False)
    branches = []
    for k in range(4):
        phase = 0.37*i + 0.29*j + 0.63*k
        v = np.sin((k+1)*base_angles + phase)
        v += 0.35*np.cos((k+2)*base_angles - 0.21*i + 0.17*j)
        # retained source localization
        center = (2*k + i + 2*j) % dim
        bump = np.zeros(dim)
        bump[center] = 1.0
        bump[(center+1)%dim] = 0.55
        bump[(center-1)%dim] = 0.35
        v += 0.55*bump
        branches.append(normalize(v))
    B = branches

    O3 = [
        assoc3(B[0],B[1],B[2],mode),
        assoc3(B[0],B[1],B[3],mode),
        assoc3(B[0],B[2],B[3],mode),
        assoc3(B[1],B[2],B[3],mode)
    ]
    H4 = h4(B[0],B[1],B[2],B[3],mode)
    H4_perp, H4_perp_norm = residual_to_span(H4, B+O3)
    return {
        "ij": (i,j),
        "B": B,
        "O3": O3,
        "H4": H4,
        "H4_perp": H4_perp,
        "H4_perp_norm": H4_perp_norm,
        "rank_B": mat_rank(B),
        "rank_B_O3": mat_rank(B+O3),
        "rank_B_O3_H4": mat_rank(B+O3+[H4]),
    }

def natural_transport(P, Q):
    """
    Construct natural transport T_{P→Q} as least-squares branch matching:
      T maps local branch frame of P to branch frame of Q.
    It is derived from B_P and B_Q only, not H4.
    """
    BP = np.stack(P["B"], axis=1) # dim x 4
    BQ = np.stack(Q["B"], axis=1) # dim x 4
    # T BP ≈ BQ, minimal Frobenius solution.
    T = BQ @ np.linalg.pinv(BP)
    return T

def op_faithfulness_defect(T, P, Q, mode="nonlinear"):
    """
    DΓ^{p→q}(x,y)=T(x⊕p y)-T(x)⊕q T(y)
    Tested on generated algebra elements: branches + O3.
    """
    G = P["B"] + P["O3"]
    vals = []
    for a in range(len(G)):
        for b in range(a+1, len(G)):
            lhs = T @ recombine(G[a], G[b], mode=mode)
            rhs = recombine(T @ G[a], T @ G[b], mode=mode)
            vals.append(np.linalg.norm(lhs-rhs))
    return float(np.mean(vals)), float(np.max(vals))

def loop_transport(Ts):
    T = np.eye(Ts[0].shape[0])
    for A in Ts:
        T = A @ T
    return T

def loop_defect(loop, sectors, transports, mode="nonlinear"):
    """
    loop = [p0,p1,p2,p3,p0]
    R_R(loop)x = T_loop(x)-x
    Test on B+O3+H4perp at p0.
    """
    p0 = loop[0]
    Ts = []
    edge_defects = []
    for a,b in zip(loop[:-1], loop[1:]):
        T = transports[(a,b)]
        Ts.append(T)
        meanD,maxD = op_faithfulness_defect(T, sectors[a], sectors[b], mode)
        edge_defects.append(meanD)
    Tloop = loop_transport(Ts)
    S0 = sectors[p0]
    test_vecs = S0["B"] + S0["O3"] + [S0["H4_perp"]]
    defects = [np.linalg.norm(Tloop @ v - v) for v in test_vecs]
    return {
        "loop": loop,
        "loop_defect_mean": float(np.mean(defects)),
        "loop_defect_max": float(np.max(defects)),
        "edge_faithfulness_defect_mean": float(np.mean(edge_defects)),
        "H4_perp_norm_p0": float(S0["H4_perp_norm"]),
        "O3_norm_mean_p0": float(np.mean([np.linalg.norm(o) for o in S0["O3"]])),
        "branch_rank_p0": int(S0["rank_B"]),
        "rank_B_O3_p0": int(S0["rank_B_O3"]),
        "rank_B_O3_H4_p0": int(S0["rank_B_O3_H4"]),
    }

def corr(a,b):
    a=np.asarray(a,dtype=float); b=np.asarray(b,dtype=float)
    if len(a)<3 or np.std(a)<EPS or np.std(b)<EPS:
        return 0.0
    return float(np.corrcoef(a,b)[0,1])

def run(mode="nonlinear", ngrid=5):
    # Build sectors
    sectors = {}
    for i in range(ngrid):
        for j in range(ngrid):
            sectors[(i,j)] = make_sector(i,j,mode=mode)

    # Build directed transports on grid edges
    transports = {}
    for i in range(ngrid):
        for j in range(ngrid):
            p=(i,j)
            for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
                if q in sectors:
                    transports[(p,q)] = natural_transport(sectors[p], sectors[q])

    # Plaquette loops
    rows = []
    for i in range(ngrid-1):
        for j in range(ngrid-1):
            loop = [(i,j),(i+1,j),(i+1,j+1),(i,j+1),(i,j)]
            rows.append(loop_defect(loop,sectors,transports,mode))
            loop_rev = [(i,j),(i,j+1),(i+1,j+1),(i+1,j),(i,j)]
            rows.append(loop_defect(loop_rev,sectors,transports,mode))

    df = pd.DataFrame(rows)
    df["mode"] = mode
    return df, sectors

df_real, sectors_real = run("nonlinear", ngrid=5)
df_lin, sectors_lin = run("linear", ngrid=5)

df = pd.concat([df_real, df_lin], ignore_index=True)
df.to_csv(OUT/"v1688_8_loop_defect_rows.csv", index=False)

summary_rows = []
for mode, sub in df.groupby("mode"):
    summary_rows.append({
        "mode": mode,
        "loop_count": int(len(sub)),
        "corr_H4perp_loop_defect_mean": corr(sub["H4_perp_norm_p0"], sub["loop_defect_mean"]),
        "corr_O3_loop_defect_mean": corr(sub["O3_norm_mean_p0"], sub["loop_defect_mean"]),
        "corr_edge_faithfulness_loop_defect": corr(sub["edge_faithfulness_defect_mean"], sub["loop_defect_mean"]),
        "mean_loop_defect": float(sub["loop_defect_mean"].mean()),
        "mean_H4_perp": float(sub["H4_perp_norm_p0"].mean()),
        "mean_edge_faithfulness_defect": float(sub["edge_faithfulness_defect_mean"].mean()),
        "rank_lift_rate": float(np.mean(sub["rank_B_O3_H4_p0"] > sub["rank_B_O3_p0"])),
    })
summary = pd.DataFrame(summary_rows)
summary.to_csv(OUT/"v1688_8_summary.csv", index=False)

real = summary[summary["mode"]=="nonlinear"].iloc[0].to_dict()
lin = summary[summary["mode"]=="linear"].iloc[0].to_dict()

# Pass criteria: nondegenerate loop defect, H4perp correlation positive and better than O3.
real_corr = float(real["corr_H4perp_loop_defect_mean"])
o3_corr = float(real["corr_O3_loop_defect_mean"])
mean_defect = float(real["mean_loop_defect"])
lin_defect = float(lin["mean_loop_defect"])

if mean_defect > 1e-6 and real_corr > 0.35 and real_corr > o3_corr + 0.05:
    verdict = "GAMMA_R_TOY_H4_PREDICTS_LOOP_DEFECT"
elif mean_defect > 1e-6 and real_corr > 0.15:
    verdict = "GAMMA_R_TOY_PARTIAL_H4_LOOP_DEFECT_SIGNAL"
elif mean_defect <= 1e-9:
    verdict = "GAMMA_R_TOY_DEGENERATE"
else:
    verdict = "GAMMA_R_TOY_H4_NOT_PREDICTIVE"

result = {
    "document_id": "V1688_8_MINIMAL_GAMMAR_TOY_IMPLEMENTATION",
    "status": "completed",
    "verdict": verdict,
    "real_summary": real,
    "linear_control_summary": lin,
    "interpretation": {
        "Gamma_R": "natural transport maps T_{p->q} built from branch-frame matching only, not H4",
        "R_R": "closed-loop retained defect T_loop(x)-x tested on generated algebra elements",
        "main_question": "Does local H4_perp predict Gamma_R loop defect better than lower-order controls?"
    },
    "outputs": {
        "loop_rows": str(OUT/"v1688_8_loop_defect_rows.csv"),
        "summary": str(OUT/"v1688_8_summary.csv")
    },
    "claim_boundary": "Minimal Gamma_R toy implementation only; no Riemann curvature / GR / ADM / physical spacetime claim."
}

(OUT/"v1688_8_result.json").write_text(json.dumps(result, indent=2))
(OUT/"V1688_8_MINIMAL_GAMMAR_TOY_IMPLEMENTATION_REPORT.md").write_text(
    "# V1688.8 — Minimal Γ_R Toy Implementation\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n"
)

print(json.dumps(result, indent=2))
