# V1688.8 Minimal Γ_R Toy Implementation

First executable retained-recombination connection toy model. No GR claim.
