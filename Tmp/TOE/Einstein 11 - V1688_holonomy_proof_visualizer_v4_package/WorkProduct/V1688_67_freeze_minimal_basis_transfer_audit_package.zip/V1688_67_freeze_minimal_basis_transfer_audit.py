#!/usr/bin/env python3
"""
V1688.67 — Freeze Retained Weak-Form Minimal Basis and Transfer/Live-Ledger Availability Audit
First-principles guardrails:
- no new mechanism
- no Kabsch/Procrustes/Gramian transport
- no fitted counterterm or tuned threshold
- no primitive time coordinate; use retained-order/provenance language
"""
from __future__ import annotations
import os, json, glob, zipfile, hashlib
from pathlib import Path
import pandas as pd

ROOT = Path('/mnt/data')
OUT = ROOT / 'V1688_67_outputs'
OUT.mkdir(exist_ok=True)

REQUIRED_V66 = [
    ROOT/'V1688_66_outputs/V1688_66_SUMMARY.json',
    ROOT/'V1688_66_outputs/V1688_66_basis_selection_summary.csv',
    ROOT/'V1688_66_outputs/V1688_66_basis_null_results.csv',
    ROOT/'V1688_66_outputs/V1688_66_incremental_reducibility_results.csv',
    ROOT/'V1688_66_outputs/V1688_66_feature_unique_summary.csv',
]

LIVE_PATTERNS = [
    '*v1687*ordered*slice*metrics*', '*V1687*ordered*slice*metrics*',
    '*v1687*ledger*', '*V1687*ledger*', '*ordered_slice_metrics*',
    '*slice_metrics*ledger*'
]

# Load previous result
missing_v66 = [str(p) for p in REQUIRED_V66 if not p.exists()]
summary66 = json.load(open(REQUIRED_V66[0])) if REQUIRED_V66[0].exists() else {}
sel = pd.read_csv(REQUIRED_V66[1]) if REQUIRED_V66[1].exists() else pd.DataFrame()
nulls = pd.read_csv(REQUIRED_V66[2]) if REQUIRED_V66[2].exists() else pd.DataFrame()
incr = pd.read_csv(REQUIRED_V66[3]) if REQUIRED_V66[3].exists() else pd.DataFrame()
feat = pd.read_csv(REQUIRED_V66[4]) if REQUIRED_V66[4].exists() else pd.DataFrame()

# Search for live ledger candidates
candidates = []
for pat in LIVE_PATTERNS:
    for f in glob.glob(str(ROOT / pat)):
        if Path(f).is_file():
            candidates.append(Path(f))
# Exclude outputs that are reports/scripts, not live ledger
exclude_keywords = ['V1688_', 'REPORT', 'package', '.py', 'outputs']
filtered = []
for f in sorted(set(candidates)):
    s = str(f)
    # Allow if it explicitly contains v1687 or ordered_slice_metrics but not generated V1688 output
    if '/V1688_' in s or '/V1688_' in s:
        continue
    filtered.append(f)

availability_rows = []
for f in sorted(set(candidates)):
    availability_rows.append({
        'path': str(f),
        'basename': f.name,
        'size_bytes': f.stat().st_size if f.exists() else None,
        'used_as_live_ledger': bool(f in filtered),
        'reason': 'candidate accepted' if f in filtered else 'excluded generated V1688 artifact or not live ledger'
    })
if not availability_rows:
    availability_rows.append({
        'path': '', 'basename': '', 'size_bytes': None, 'used_as_live_ledger': False,
        'reason': 'no v1687_ordered_slice_metrics/live ledger file found under /mnt/data'
    })
avail = pd.DataFrame(availability_rows)
avail.to_csv(OUT/'V1688_67_live_ledger_availability_audit.csv', index=False)

# Frozen law spec
frozen_spec = {
    'document_id': 'V1688_67_FROZEN_MINIMAL_RETAINED_WEAK_FORM_BASIS',
    'status': 'frozen_basis_defined_transfer_audit_completed',
    'source_version': 'V1688.66',
    'basis_verdict_inherited': summary66.get('verdict'),
    'target': 'weak_target',
    'baseline_M0': ['source_abs', 'access_abs', 'div_baseline'],
    'frozen_promoted_basis': [
        {'name': 'C_corr', 'definition': 'dimensionless residualized Gamma_R/H4 correction coordinate'},
        {'name': 'native_directional_cycle_defect', 'definition': 'native T_pq action on retained correction direction around provenance cycles'},
        {'name': 'retained_order_incidence_continuity', 'definition': 'antisymmetric reciprocal provenance-edge current residual'},
    ],
    'frozen_law_form': 'weak_target ≈ M0 + C_corr + native_directional_cycle_defect + retained_order_incidence_continuity',
    'demoted_diagnostics': [
        'correction_loss', 'exact_scalar_cycle_defect', 'native_matrix_holonomy',
        'native_inverse_defect_decomposition', 'trace_determinant_frobenius_full_matrix_invariants'
    ],
    'guardrails': [
        'no Kabsch/Procrustes/Gramian transport as law',
        'no fitted counterterms',
        'no threshold-tuned pass rules',
        'no primitive time coordinate; use retained-order/provenance orientation',
        'do not add new mechanisms before live-ledger transfer'
    ],
    'required_live_ledger_columns': [
        'node_id/sector_id', 'ordered_slice_or_retained_order_index', 'source_abs', 'access_abs', 'div_baseline',
        'branch current vectors B_p', 'O3/L3 associator vectors', 'H4_perp/L4 vectors',
        'gamma_pq overlap gates', 'from_node', 'to_node', 'provenance edge direction',
        'graph cycle basis', 'weak_target or weak residual'
    ],
    'v66_core_metrics': {
        'mean_r2_M0': summary66.get('mean_r2_M0'),
        'mean_r2_Ccorr': summary66.get('mean_r2_Ccorr'),
        'mean_r2_selected': summary66.get('mean_r2_selected'),
        'mean_unique_selected_over_Ccorr': summary66.get('mean_unique_selected_over_Ccorr'),
        'min_unique_selected_over_Ccorr': summary66.get('min_unique_selected_over_Ccorr'),
        'positive_rate': summary66.get('positive_rate'),
        'worst_selected_null_margin': summary66.get('worst_selected_null_margin')
    },
    'live_ledger_available': bool(filtered),
    'live_ledger_candidates_used': [str(f) for f in filtered],
}
json.dump(frozen_spec, open(OUT/'V1688_67_FROZEN_MINIMAL_BASIS_SPEC.json','w'), indent=2)

# Freeze summary table
basis_rows = [
    {'role':'baseline', 'symbol':'M0', 'feature':'source_abs + access_abs + div_baseline', 'status':'frozen', 'reason':'source-flow/same-slice baseline'},
    {'role':'promoted', 'symbol':'C_corr', 'feature':'dimensionless residualized Gamma_R/H4 correction coordinate', 'status':'frozen', 'reason':'mandatory retained correction coordinate'},
    {'role':'promoted', 'symbol':'D_native_dir', 'feature':'native_directional_cycle_defect', 'status':'frozen', 'reason':'dominant cycle/holonomy observable after hardening'},
    {'role':'promoted', 'symbol':'J_incidence', 'feature':'retained_order_incidence_continuity', 'status':'frozen', 'reason':'minimal independent addition selected in V1688.66'},
    {'role':'diagnostic', 'symbol':'L_transport', 'feature':'correction_loss', 'status':'demoted', 'reason':'small/non-consistent incremental after selected basis'},
    {'role':'diagnostic', 'symbol':'D_exact_scalar', 'feature':'exact scalar cycle defect', 'status':'demoted', 'reason':'absorbed by native directional cycle in minimal basis'},
]
pd.DataFrame(basis_rows).to_csv(OUT/'V1688_67_frozen_basis_table.csv', index=False)

# Transfer readiness checks
readiness = []
def add_check(name, passed, detail):
    readiness.append({'check': name, 'passed': bool(passed), 'detail': detail})
add_check('V1688.66 summary present', not missing_v66, 'missing: '+str(missing_v66) if missing_v66 else 'all required V1688.66 files present')
add_check('selected basis has positive holdout rate', summary66.get('positive_rate') == 1.0, str(summary66.get('positive_rate')))
add_check('selected basis null margin positive', (summary66.get('worst_selected_null_margin') or -1) > 0, str(summary66.get('worst_selected_null_margin')))
add_check('live v1687 ordered-slice ledger available', bool(filtered), 'found '+str(len(filtered))+' accepted candidate(s)')
add_check('live-ledger transfer executable now', bool(filtered) and not missing_v66, 'requires live ledger with node/edge/cycle/gamma fields')
ready = pd.DataFrame(readiness)
ready.to_csv(OUT/'V1688_67_transfer_readiness_checks.csv', index=False)

# Artifact manifest with hashes for reproducibility
manifest_rows = []
for p in REQUIRED_V66 + [OUT/'V1688_67_FROZEN_MINIMAL_BASIS_SPEC.json', OUT/'V1688_67_frozen_basis_table.csv', OUT/'V1688_67_live_ledger_availability_audit.csv', OUT/'V1688_67_transfer_readiness_checks.csv']:
    if p.exists():
        h = hashlib.sha256(p.read_bytes()).hexdigest()
        manifest_rows.append({'path': str(p), 'sha256': h, 'size_bytes': p.stat().st_size})
pd.DataFrame(manifest_rows).to_csv(OUT/'V1688_67_artifact_manifest.csv', index=False)

verdict = 'FROZEN_MINIMAL_BASIS_READY_LIVE_LEDGER_TRANSFER_BLOCKED' if not filtered else 'FROZEN_MINIMAL_BASIS_READY_LIVE_LEDGER_TRANSFER_AVAILABLE'

summary = {
    'document_id': 'V1688_67_FREEZE_MINIMAL_BASIS_TRANSFER_AUDIT',
    'verdict': verdict,
    'basis_frozen': True,
    'selected_law': frozen_spec['frozen_law_form'],
    'live_ledger_available': bool(filtered),
    'live_ledger_candidates_used': [str(f) for f in filtered],
    'v66_metrics': frozen_spec['v66_core_metrics'],
    'next': 'V1688.68 — live-ledger transfer test once v1687_ordered_slice_metrics ledger is provided' if not filtered else 'V1688.68 — execute live-ledger transfer with frozen basis',
    'claim_boundary': 'Frozen finite-harness minimal basis only; no ADM/GR/Einstein/physical spacetime claim.'
}
json.dump(summary, open(OUT/'V1688_67_SUMMARY.json','w'), indent=2)

report = f"""# V1688.67 — Freeze Minimal Retained Weak-Form Basis and Transfer/Live-Ledger Availability Audit

## Verdict

```text
{verdict}
```

V1688.67 freezes the V1688.66 minimal retained weak-form basis and audits whether a live `v1687_ordered_slice_metrics` ledger is available for transfer.

No new mechanism was added. No Kabsch/Procrustes/Gramian transport, fitted counterterm, tuned flux weight, threshold patching, or primitive time coordinate was used.

## Frozen law form

```text
weak_target ≈ M0
          + C_corr
          + native_directional_cycle_defect
          + retained_order_incidence_continuity
```

where:

```text
M0 = source_abs + access_abs + div_baseline
C_corr = dimensionless residualized Gamma_R/H4 correction coordinate
native_directional_cycle_defect = native T_pq action on retained correction direction around provenance cycles
retained_order_incidence_continuity = antisymmetric reciprocal provenance-edge current residual
```

## Inherited V1688.66 metrics

```json
{json.dumps(frozen_spec['v66_core_metrics'], indent=2)}
```

## Demoted diagnostics

```text
correction_loss
exact_scalar_cycle_defect
native_matrix_holonomy
native_inverse_defect_decomposition
trace/determinant/Frobenius full-matrix invariants
```

These remain diagnostics, not promoted law objects.

## Live-ledger availability

Accepted live-ledger candidates found:

```text
{len(filtered)}
```

The required live ledger was not found if this count is zero. In that case, V1688.67 is a stop/transfer-readiness result, not a live-ledger execution.

Required live ledger fields:

```text
node_id / sector_id
retained-order index or ordered-slice index
source_abs, access_abs, div_baseline
branch current vectors B_p
O3/L3 associator vectors
H4_perp/L4 vectors
gamma_pq overlap gates
from_node, to_node provenance edges
graph cycle basis
weak_target or weak residual
```

## Transfer decision

```text
{'Live-ledger transfer is blocked because the live V1687 ledger is absent.' if not filtered else 'Live-ledger transfer can proceed using the accepted candidate(s).'}
```

## Claim boundary

This freezes a finite retained-flow harness basis. It does not claim ADM, GR, Riemann curvature, Einstein equations, or physical spacetime.

## Next

```text
{summary['next']}
```
"""
(OUT/'V1688_67_FREEZE_MINIMAL_BASIS_TRANSFER_AUDIT_REPORT.md').write_text(report)

# Package
zip_path = ROOT/'V1688_67_freeze_minimal_basis_transfer_audit_package.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    z.write(ROOT/'V1688_67_freeze_minimal_basis_transfer_audit.py', arcname='V1688_67_freeze_minimal_basis_transfer_audit.py')
    for f in OUT.iterdir():
        z.write(f, arcname=f'V1688_67_outputs/{f.name}')
print(json.dumps(summary, indent=2))
print('PACKAGE', zip_path)
