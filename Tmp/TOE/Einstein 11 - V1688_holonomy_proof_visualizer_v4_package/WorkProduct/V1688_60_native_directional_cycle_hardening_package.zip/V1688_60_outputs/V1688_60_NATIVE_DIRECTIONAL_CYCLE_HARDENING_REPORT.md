# V1688.60 — Native Directional Cycle-Basis and Subdivision Hardening

**Verdict:** `PARTIAL_NATIVE_DIRECTIONAL_CYCLE_HARDENING_PASS_ORIENTATION_ASYMMETRY_REMAINS`

## First-principles constraints

No Kabsch, Procrustes, Gramian transport, fitted counterterms, threshold patching, or primitive time coordinate were used.

The observable was held fixed from V1688.59:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = product_loop c_pq
native_directional_cycle_defect = |1 - H_cycle^dir| mean(|C_corr|)
```

## Ledger scale

```text
nodes:             29,696
edges:             114,176
elementary cycles: 27,440
2x2 macro cycles:  25,280
```

## Holdout hardening

```text
mean native-dir unique over C_corr:        +0.053348
mean macro native-dir unique over C_corr:  +0.053622
mean elementary+macro unique over C_corr:  +0.058566
resolution positive rate:                  1.000000
finest-3 native-dir unique CV:             0.152397
```

## Null separation

```text
critical null max unique:                  +0.000075
observed-null margin:                      +0.053273
```

## Orientation reversal

```text
reverse orientation availability:          1.000000
mean |forward defect - reverse defect|:    0.013922
median |forward defect - reverse defect|:  0.004878
forward/reverse defect correlation:        +0.996594
strict reversal invariance pass:           False
```

Interpretation: orientation reversal is not strictly invariant for the native directional scalar. This is expected if the observable is genuinely directed, but it prevents a full reversible-connection compatibility claim.

## Subdivision / cycle-basis change

```text
corr(2x2 macro defect, mean subcycle defect): +0.834059
mean relative subdivision difference:          0.337511
subdivision consistency pass:                  True
```

The 2x2 macro-cycle family preserves a positive native directional signal and tracks the elementary subcycle signal, but not as an exact additive/subdivision identity.

## Interpretation

The native directional observable survives operator-family, generator, resolution, seed, null, and macro-cycle hardening as a predictive weak-form correction object. However, strict orientation-reversal invariance fails because the observable is directional by construction.

This supports the bounded readout:

```text
Native directional holonomy of the retained correction mode remains a valid finite-harness observable, but it is directed rather than a reversible GR-like connection object.
```

## Next

```text
V1688.61 — directed-cycle law audit
```

Test whether the orientation asymmetry itself is structured and source-flow independent:

```text
A_cycle = defect_forward - defect_reverse
```

If the asymmetry survives nulls and couples to ordered provenance / H4 structure, then the correct object is a directed retained-cycle law, not reversible holonomy.
