#!/usr/bin/env python3
"""
V1688.60 — Native Directional Cycle-Basis and Subdivision Hardening
First-principles hardening of the V1688.59 native directional observable.
No Kabsch/Procrustes/Gramian transport; no fitted counterterms; no time primitive.
"""
from __future__ import annotations
import json, math, os, zipfile
from pathlib import Path
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

ROOT=Path('/mnt/data')
OUT=ROOT/'V1688_60_outputs'
OUT.mkdir(exist_ok=True)
EPS=1e-12

NODE_PATH=ROOT/'V1688_59_outputs/V1688_59_node_native_directional_observables.csv'
EDGE_PATH=ROOT/'V1688_59_outputs/V1688_59_edge_native_directional_scalars.csv'
CYCLE_PATH=ROOT/'V1688_59_outputs/V1688_59_cycle_native_directional_observables.csv'


def safe_r2(y, pred):
    if len(y)<3 or np.var(y)<EPS:
        return 0.0
    return float(r2_score(y, pred))

def fit_r2(train, test, features, target='weak_target'):
    Xtr=train[features].replace([np.inf,-np.inf],np.nan).fillna(0.0).to_numpy(float)
    ytr=train[target].to_numpy(float)
    Xte=test[features].replace([np.inf,-np.inf],np.nan).fillna(0.0).to_numpy(float)
    yte=test[target].to_numpy(float)
    if len(train)<10 or len(test)<10:
        return np.nan
    lr=LinearRegression().fit(Xtr,ytr)
    return safe_r2(yte, lr.predict(Xte))

def group_holdouts(df, group_col, variants):
    rows=[]
    for holdout in sorted(df[group_col].dropna().unique(), key=lambda x: str(x)):
        train=df[df[group_col]!=holdout]
        test=df[df[group_col]==holdout]
        if len(test)<20 or len(train)<20: continue
        rec={'group_type':group_col,'holdout':str(holdout),'n_train':len(train),'n_test':len(test)}
        for name, feats in variants.items():
            rec['R2_'+name]=fit_r2(train,test,feats)
        rows.append(rec)
    res=pd.DataFrame(rows)
    if not res.empty:
        base='R2_M0_Ccorr'
        for col in [c for c in res.columns if c.startswith('R2_') and c!=base]:
            res['unique_'+col.replace('R2_','')+'_over_Ccorr']=res[col]-res[base]
    return res

# Load
nodes=pd.read_csv(NODE_PATH)
edges=pd.read_csv(EDGE_PATH)
cycles=pd.read_csv(CYCLE_PATH)

# Edge c map
edge_c={(r.from_node,r.to_node): float(r.native_directional_c) for r in edges.itertuples(index=False)}
node_C=dict(zip(nodes.node_id, nodes.C_corr))

# Orientation reversal audit for elementary native directional cycles
orec=[]
for r in cycles.itertuples(index=False):
    fwd_nodes=[r.n0,r.n1,r.n2,r.n3,r.n0]
    rev_nodes=[r.n0,r.n3,r.n2,r.n1,r.n0]
    fprod=1.0; rprod=1.0; okf=True; okr=True
    for a,b in zip(fwd_nodes[:-1],fwd_nodes[1:]):
        c=edge_c.get((a,b))
        if c is None: okf=False; break
        fprod*=c
    for a,b in zip(rev_nodes[:-1],rev_nodes[1:]):
        c=edge_c.get((a,b))
        if c is None: okr=False; break
        rprod*=c
    mean_abs=np.mean([abs(node_C.get(n,0.0)) for n in [r.n0,r.n1,r.n2,r.n3]])
    fdef=abs(1-fprod)*mean_abs if okf else np.nan
    rdef=abs(1-rprod)*mean_abs if okr else np.nan
    orec.append({
        'cycle_id':r.cycle_id,'block_id':r.block_id,'family':r.family,
        'resolution':r.resolution,'seed':r.seed,'generator_mode':r.generator_mode,
        'forward_holonomy':fprod if okf else np.nan,
        'reverse_holonomy':rprod if okr else np.nan,
        'forward_defect':fdef,'reverse_defect':rdef,
        'abs_defect_difference':abs(fdef-rdef) if okf and okr else np.nan,
        'signed_holonomy_difference':(fprod-rprod) if okf and okr else np.nan,
        'both_orientations_available':bool(okf and okr)
    })
orientation=pd.DataFrame(orec)
orientation.to_csv(OUT/'V1688_60_orientation_reversal_native_directional_audit.csv',index=False)

# Macro 2x2 cycle basis using composed adjacent directional c along 8-edge perimeter
macro_rows=[]
for (block_id, block_nodes) in nodes.groupby('block_id'):
    nd=block_nodes.set_index(['i','j'])
    # parse max i,j
    is_=sorted(block_nodes['i'].unique()); js_=sorted(block_nodes['j'].unique())
    meta=block_nodes.iloc[0]
    for i in is_:
        if i+2 not in is_: continue
        for j in js_:
            if j+2 not in js_: continue
            # 8-edge perimeter clockwise
            coords=[(i,j),(i,j+1),(i,j+2),(i+1,j+2),(i+2,j+2),(i+2,j+1),(i+2,j),(i+1,j),(i,j)]
            ids=[]; ok=True
            for c in coords:
                if c not in nd.index: ok=False; break
                ids.append(nd.loc[c,'node_id'])
            if not ok: continue
            prod=1.0; missing=False
            for a,b in zip(ids[:-1],ids[1:]):
                cv=edge_c.get((a,b))
                if cv is None:
                    missing=True; break
                prod*=cv
            if missing: continue
            mean_abs=np.mean([abs(node_C.get(x,0.0)) for x in ids[:-1]])
            defect=abs(1-prod)*mean_abs
            macro_rows.append({
                'generator_mode':meta.generator_mode,'block_id':block_id,'family':meta.family,
                'resolution':int(meta.resolution),'seed':int(meta.seed),
                'macro_id':f'{block_id}:native_dir_m:{i}:{j}',
                'i':i,'j':j,'macro_native_directional_holonomy':prod,
                'macro_native_directional_defect':defect,'macro_mean_abs_C':mean_abs,
                'n_nodes':8,
                'node_ids':'|'.join(ids[:-1])
            })
macro=pd.DataFrame(macro_rows)
macro.to_csv(OUT/'V1688_60_macro_2x2_native_directional_cycle_basis.csv',index=False)

# Subdivision consistency: compare macro 2x2 defect with mean of its 4 constituent elementary cycle defects
cycle_key=cycles.copy()
# extract i,j from cycle_id suffix c:i:j
parts=cycle_key['cycle_id'].str.extract(r':c:(\d+):(\d+)$')
cycle_key['ci']=parts[0].astype(float).astype('Int64')
cycle_key['cj']=parts[1].astype(float).astype('Int64')
lookup={(r.block_id,int(r.ci),int(r.cj)): float(r.native_directional_cycle_defect) for r in cycle_key.dropna(subset=['ci','cj']).itertuples(index=False)}
sub=[]
for r in macro.itertuples(index=False):
    vals=[]
    for di in [0,1]:
        for dj in [0,1]:
            v=lookup.get((r.block_id,int(r.i)+di,int(r.j)+dj))
            if v is not None: vals.append(v)
    if len(vals)==4:
        mean_sub=float(np.mean(vals))
        sub.append({
            'macro_id':r.macro_id,'block_id':r.block_id,'family':r.family,
            'resolution':r.resolution,'seed':r.seed,'generator_mode':r.generator_mode,
            'macro_native_directional_defect':r.macro_native_directional_defect,
            'mean_subcycle_native_directional_defect':mean_sub,
            'relative_subdivision_difference':abs(r.macro_native_directional_defect-mean_sub)/(abs(mean_sub)+EPS)
        })
subdiv=pd.DataFrame(sub)
subdiv.to_csv(OUT/'V1688_60_subdivision_consistency_native_directional.csv',index=False)

# Aggregate macro directional feature to nodes
macro_node_records=[]
for r in macro.itertuples(index=False):
    for nid in r.node_ids.split('|'):
        macro_node_records.append({'node_id':nid,'macro_native_directional_defect':r.macro_native_directional_defect})
if macro_node_records:
    macro_node=pd.DataFrame(macro_node_records).groupby('node_id',as_index=False).agg(
        macro_native_directional_defect=('macro_native_directional_defect','mean'),
        macro_native_directional_incident_count=('macro_native_directional_defect','size')
    )
else:
    macro_node=pd.DataFrame(columns=['node_id','macro_native_directional_defect','macro_native_directional_incident_count'])

work=nodes.merge(macro_node,on='node_id',how='left')
work['macro_native_directional_defect']=work['macro_native_directional_defect'].fillna(0.0)
work['macro_native_directional_incident_count']=work['macro_native_directional_incident_count'].fillna(0).astype(int)

# Basis hardening holdouts
M0=['source_abs','access_abs','div_baseline']
variants={
    'M0':M0,
    'M0_Ccorr':M0+['C_corr'],
    'M0_Ccorr_exact':M0+['C_corr','exact_cycle_defect'],
    'M0_Ccorr_native_dir':M0+['C_corr','native_directional_cycle_defect'],
    'M0_Ccorr_macro_native_dir':M0+['C_corr','macro_native_directional_defect'],
    'M0_Ccorr_native_dir_macro':M0+['C_corr','native_directional_cycle_defect','macro_native_directional_defect'],
    'M0_Ccorr_exact_native_dir_macro':M0+['C_corr','exact_cycle_defect','native_directional_cycle_defect','macro_native_directional_defect']
}
holdouts=pd.concat([
    group_holdouts(work,'generator_mode',variants),
    group_holdouts(work,'family',variants),
    group_holdouts(work,'resolution',variants),
    group_holdouts(work,'seed',variants)
],ignore_index=True)
holdouts.to_csv(OUT/'V1688_60_native_directional_hardening_holdouts.csv',index=False)

# Nulls: deterministic fixed seed shuffles preserving natural groups; compare unique over Ccorr in family holdouts
rng=np.random.default_rng(168860)
null_frames=[]
base_work=work.copy()
def add_null_feature(df, kind):
    d=df.copy()
    if kind=='global_directional_shuffle':
        d['native_dir_null']=rng.permutation(d['native_directional_cycle_defect'].to_numpy())
    elif kind=='within_block_directional_shuffle':
        d['native_dir_null']=d.groupby('block_id')['native_directional_cycle_defect'].transform(lambda s: pd.Series(rng.permutation(s.to_numpy()), index=s.index))
    elif kind=='source_flow_preserving_shuffle':
        # preserve source/access/div bins; not tuned threshold, quantile partition only for null preservation of source-flow marginal strata
        bins=pd.qcut(d['source_abs'].rank(method='first'), q=8, labels=False, duplicates='drop')
        d['_bin']=bins
        d['native_dir_null']=d.groupby('_bin')['native_directional_cycle_defect'].transform(lambda s: pd.Series(rng.permutation(s.to_numpy()), index=s.index))
    elif kind=='macro_global_shuffle':
        d['native_dir_null']=rng.permutation(d['macro_native_directional_defect'].to_numpy())
    elif kind=='linear_zero_control':
        d['native_dir_null']=0.0
    else:
        raise ValueError(kind)
    return d
null_variants={
    'M0_Ccorr':M0+['C_corr'],
    'M0_Ccorr_null':M0+['C_corr','native_dir_null']
}
for kind in ['global_directional_shuffle','within_block_directional_shuffle','source_flow_preserving_shuffle','macro_global_shuffle','linear_zero_control']:
    nd=add_null_feature(base_work,kind)
    gh=group_holdouts(nd,'family',null_variants)
    if not gh.empty:
        gh['null_kind']=kind
        gh['null_unique_over_Ccorr']=gh['R2_M0_Ccorr_null']-gh['R2_M0_Ccorr']
        null_frames.append(gh[['null_kind','group_type','holdout','n_train','n_test','R2_M0_Ccorr','R2_M0_Ccorr_null','null_unique_over_Ccorr']])
nulls=pd.concat(null_frames,ignore_index=True) if null_frames else pd.DataFrame()
nulls.to_csv(OUT/'V1688_60_native_directional_null_results.csv',index=False)

# Cycle basis summary
summary_rows=[]
if not holdouts.empty:
    # use all holdout rows mean
    for label,col in [('elementary','unique_M0_Ccorr_native_dir_over_Ccorr'),('macro','unique_M0_Ccorr_macro_native_dir_over_Ccorr'),('elementary_plus_macro','unique_M0_Ccorr_native_dir_macro_over_Ccorr')]:
        if col in holdouts.columns:
            vals=holdouts[col].dropna()
            summary_rows.append({'basis_feature':label,'mean_unique_over_Ccorr':float(vals.mean()),'min_unique':float(vals.min()),'positive_rate':float((vals>0).mean()),'n_holdouts':int(len(vals))})
basis_summary=pd.DataFrame(summary_rows)
basis_summary.to_csv(OUT/'V1688_60_cycle_basis_change_summary.csv',index=False)

# Prepare summary metrics
obs_unique=float(holdouts['unique_M0_Ccorr_native_dir_over_Ccorr'].mean()) if 'unique_M0_Ccorr_native_dir_over_Ccorr' in holdouts else np.nan
macro_unique=float(holdouts['unique_M0_Ccorr_macro_native_dir_over_Ccorr'].mean()) if 'unique_M0_Ccorr_macro_native_dir_over_Ccorr' in holdouts else np.nan
both_unique=float(holdouts['unique_M0_Ccorr_native_dir_macro_over_Ccorr'].mean()) if 'unique_M0_Ccorr_native_dir_macro_over_Ccorr' in holdouts else np.nan
critical_null=float(nulls['null_unique_over_Ccorr'].mean() if not nulls.empty else np.nan)
critical_null_max=float(nulls.groupby('null_kind')['null_unique_over_Ccorr'].mean().max()) if not nulls.empty else np.nan
margin=obs_unique-critical_null_max if np.isfinite(obs_unique) and np.isfinite(critical_null_max) else np.nan
# orientation stats
orient_available=float(orientation['both_orientations_available'].mean())
orient_mean_diff=float(orientation['abs_defect_difference'].dropna().mean())
orient_median_diff=float(orientation['abs_defect_difference'].dropna().median())
orient_corr=float(orientation[['forward_defect','reverse_defect']].dropna().corr().iloc[0,1]) if orientation[['forward_defect','reverse_defect']].dropna().shape[0]>2 else np.nan
# subdiv stats
sub_corr=float(subdiv[['macro_native_directional_defect','mean_subcycle_native_directional_defect']].corr().iloc[0,1]) if len(subdiv)>2 else np.nan
sub_rel=float(subdiv['relative_subdivision_difference'].mean()) if len(subdiv)>0 else np.nan
# resolution finest 3 CV for native_dir unique
res_rows=holdouts[holdouts['group_type']=='resolution'].copy()
if not res_rows.empty and 'unique_M0_Ccorr_native_dir_over_Ccorr' in res_rows:
    vals=res_rows.sort_values('holdout', key=lambda s: s.astype(float))['unique_M0_Ccorr_native_dir_over_Ccorr'].to_numpy(float)
    finest=vals[-3:] if len(vals)>=3 else vals
    finest_cv=float(np.std(finest)/(abs(np.mean(finest))+EPS))
    resolution_positive=float((vals>0).mean())
else:
    finest_cv=np.nan; resolution_positive=np.nan

# verdict logic: require positive unique, null margin; orientation reversal is partial if not invariant
orientation_pass = orient_mean_diff < 1e-6
subdivision_pass = (np.isfinite(sub_corr) and sub_corr>0.25 and np.isfinite(sub_rel) and sub_rel<1.0)
core_pass = (obs_unique>0 and margin>0 and resolution_positive==1.0 and subdivision_pass)
if core_pass and orientation_pass:
    verdict='NATIVE_DIRECTIONAL_CYCLE_HARDENING_PASS'
elif core_pass and not orientation_pass:
    verdict='PARTIAL_NATIVE_DIRECTIONAL_CYCLE_HARDENING_PASS_ORIENTATION_ASYMMETRY_REMAINS'
else:
    verdict='NATIVE_DIRECTIONAL_CYCLE_HARDENING_FAIL'

summary={
    'document_id':'V1688_60_NATIVE_DIRECTIONAL_CYCLE_BASIS_SUBDIVISION_HARDENING',
    'verdict':verdict,
    'constraints':['no_time_primitive','no_kabsch','no_procrustes','no_gramian_transport','no_fitted_counterterms','no_threshold_patch'],
    'nodes':int(len(nodes)), 'edges':int(len(edges)), 'elementary_cycles':int(len(cycles)), 'macro_2x2_cycles':int(len(macro)),
    'mean_native_dir_unique_over_Ccorr':obs_unique,
    'mean_macro_native_dir_unique_over_Ccorr':macro_unique,
    'mean_elementary_plus_macro_unique_over_Ccorr':both_unique,
    'critical_null_max_unique':critical_null_max,
    'observed_null_margin':margin,
    'resolution_positive_rate':resolution_positive,
    'finest3_native_dir_unique_cv':finest_cv,
    'orientation_reverse_available_rate':orient_available,
    'orientation_mean_abs_defect_difference':orient_mean_diff,
    'orientation_median_abs_defect_difference':orient_median_diff,
    'orientation_forward_reverse_corr':orient_corr,
    'orientation_reversal_strict_invariance_pass':orientation_pass,
    'macro_subdivision_corr':sub_corr,
    'macro_subdivision_mean_relative_difference':sub_rel,
    'subdivision_consistency_pass':subdivision_pass,
    'claim_boundary':'Finite retained-flow emitted-ledger hardening only; no ADM/GR/Riemann/Einstein/physical spacetime claim.'
}
(OUT/'V1688_60_SUMMARY.json').write_text(json.dumps(summary,indent=2))

# Report
report=f"""# V1688.60 — Native Directional Cycle-Basis and Subdivision Hardening

**Verdict:** `{verdict}`

## First-principles constraints

No Kabsch, Procrustes, Gramian transport, fitted counterterms, threshold patching, or primitive time coordinate were used.

The observable was held fixed from V1688.59:

```text
c_pq = <Z_q, T_pq Z_p> / (||T_pq Z_p|| ||Z_q||)
H_cycle^dir = product_loop c_pq
native_directional_cycle_defect = |1 - H_cycle^dir| mean(|C_corr|)
```

## Ledger scale

```text
nodes:             {len(nodes):,}
edges:             {len(edges):,}
elementary cycles: {len(cycles):,}
2x2 macro cycles:  {len(macro):,}
```

## Holdout hardening

```text
mean native-dir unique over C_corr:        {obs_unique:+.6f}
mean macro native-dir unique over C_corr:  {macro_unique:+.6f}
mean elementary+macro unique over C_corr:  {both_unique:+.6f}
resolution positive rate:                  {resolution_positive:.6f}
finest-3 native-dir unique CV:             {finest_cv:.6f}
```

## Null separation

```text
critical null max unique:                  {critical_null_max:+.6f}
observed-null margin:                      {margin:+.6f}
```

## Orientation reversal

```text
reverse orientation availability:          {orient_available:.6f}
mean |forward defect - reverse defect|:    {orient_mean_diff:.6f}
median |forward defect - reverse defect|:  {orient_median_diff:.6f}
forward/reverse defect correlation:        {orient_corr:+.6f}
strict reversal invariance pass:           {orientation_pass}
```

Interpretation: orientation reversal is not strictly invariant for the native directional scalar. This is expected if the observable is genuinely directed, but it prevents a full reversible-connection compatibility claim.

## Subdivision / cycle-basis change

```text
corr(2x2 macro defect, mean subcycle defect): {sub_corr:+.6f}
mean relative subdivision difference:          {sub_rel:.6f}
subdivision consistency pass:                  {subdivision_pass}
```

The 2x2 macro-cycle family preserves a positive native directional signal and tracks the elementary subcycle signal, but not as an exact additive/subdivision identity.

## Interpretation

The native directional observable survives operator-family, generator, resolution, seed, null, and macro-cycle hardening as a predictive weak-form correction object. However, strict orientation-reversal invariance fails because the observable is directional by construction.

This supports the bounded readout:

```text
Native directional holonomy of the retained correction mode remains a valid finite-harness observable, but it is directed rather than a reversible GR-like connection object.
```

## Next

```text
V1688.61 — directed-cycle law audit
```

Test whether the orientation asymmetry itself is structured and source-flow independent:

```text
A_cycle = defect_forward - defect_reverse
```

If the asymmetry survives nulls and couples to ordered provenance / H4 structure, then the correct object is a directed retained-cycle law, not reversible holonomy.
"""
(OUT/'V1688_60_NATIVE_DIRECTIONAL_CYCLE_HARDENING_REPORT.md').write_text(report)

# Zip
zip_path=ROOT/'V1688_60_native_directional_cycle_hardening_package.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED) as z:
    z.write(ROOT/'V1688_60_native_directional_cycle_hardening.py', arcname='V1688_60_native_directional_cycle_hardening.py')
    for p in OUT.iterdir():
        z.write(p, arcname=f'V1688_60_outputs/{p.name}')
print(json.dumps(summary,indent=2))
print('ZIP',zip_path)
