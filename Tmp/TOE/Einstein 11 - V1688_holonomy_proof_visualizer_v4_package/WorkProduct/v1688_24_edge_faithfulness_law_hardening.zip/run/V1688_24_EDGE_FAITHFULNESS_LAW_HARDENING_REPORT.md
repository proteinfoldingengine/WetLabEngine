# V1688.24 — Edge-Faithfulness Law Hardening

```json
{
  "document_id": "V1688_24_EDGE_FAITHFULNESS_LAW_HARDENING",
  "status": "completed",
  "verdict": "EDGE_FAITHFULNESS_FLOW_LAW_HARDENED",
  "real_group": {
    "condition": "real",
    "config_count": 24,
    "mean_R2_flow": 0.4971272422790826,
    "mean_R2_flow_edge": 1.0,
    "mean_delta_edge": 0.5028727577209174,
    "min_delta_edge": 0.16529172391394586,
    "positive_delta_edge_rate": 1.0,
    "mean_R2_resid_edge": 1.0
  },
  "edge_shuffle_group": {
    "condition": "edge_shuffle",
    "config_count": 24,
    "mean_R2_flow": 0.4971272422790826,
    "mean_R2_flow_edge": 0.5211283452644884,
    "mean_delta_edge": 0.024001102985405778,
    "min_delta_edge": -0.02390615528840323,
    "positive_delta_edge_rate": 0.9583333333333334,
    "mean_R2_resid_edge": 0.07636908489153775
  },
  "edge_block_shuffle_group": {
    "condition": "edge_block_shuffle",
    "config_count": 24,
    "mean_R2_flow": 0.4971272422790826,
    "mean_R2_flow_edge": 0.5880017243745584,
    "mean_delta_edge": 0.09087448209547594,
    "min_delta_edge": 0.0003290397005746293,
    "positive_delta_edge_rate": 1.0,
    "mean_R2_resid_edge": 0.1922395998231389
  },
  "real_gain_minus_shuffle": 0.4788716547355117,
  "real_gain_minus_block_shuffle": 0.4119982756254415,
  "outputs": {
    "rows": "/mnt/data/v1688_24_edge_faithfulness_law_hardening_outputs/v1688_24_edge_law_rows.csv",
    "summary": "/mnt/data/v1688_24_edge_faithfulness_law_hardening_outputs/v1688_24_summary.csv",
    "grouped": "/mnt/data/v1688_24_edge_faithfulness_law_hardening_outputs/v1688_24_grouped.csv"
  },
  "claim_boundary": "Toy edge-faithfulness same-slice flow hardening only; no ADM derivation / GR / physical spacetime claim."
}
```
