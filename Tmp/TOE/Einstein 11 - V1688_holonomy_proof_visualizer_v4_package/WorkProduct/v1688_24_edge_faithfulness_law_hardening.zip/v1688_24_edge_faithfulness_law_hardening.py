
from pathlib import Path
import json, numpy as np, pandas as pd
OUT=Path("/mnt/data/v1688_24_edge_faithfulness_law_hardening_outputs"); OUT.mkdir(parents=True,exist_ok=True)
EPS=1e-12

def recombine(x,y,mode="nonlinear"):
    x=np.asarray(x,float); y=np.asarray(y,float)
    if mode=="linear": return x+y
    rd=np.r_[x[-1],x[:-1]]; ru=np.r_[y[1:],y[0]]
    ov=np.minimum(np.abs(x),np.abs(y))/(1+np.minimum(np.abs(x),np.abs(y)))
    return x+y+.35*ov*(rd*y-x*ru)
def assoc3(A,B,C,mode="nonlinear"):
    return recombine(recombine(A,B,mode),C,mode)-recombine(A,recombine(B,C,mode),mode)
def normalize(v):
    n=np.linalg.norm(v); return v if n<EPS else v/n
def make_sector(i,j,dim=12,seed=0,mode="nonlinear"):
    a=np.linspace(0,2*np.pi,dim,endpoint=False); B=[]
    for k in range(4):
        phase=.37*i+.29*j+.63*k+.03*seed
        v=np.sin((k+1)*a+phase)+.35*np.cos((k+2)*a-.21*i+.17*j+.05*seed)
        c=(2*k+i+2*j+seed)%dim; bump=np.zeros(dim); bump[c]=1; bump[(c+1)%dim]=.55; bump[(c-1)%dim]=.35
        v+=.55*bump; B.append(normalize(v))
    O3=[assoc3(B[0],B[1],B[2],mode),assoc3(B[0],B[1],B[3],mode),assoc3(B[0],B[2],B[3],mode),assoc3(B[1],B[2],B[3],mode)]
    return {"B":B,"O3":O3,"source":np.sum(np.stack(B),axis=0)}
def transport(P,Q):
    return np.stack(Q["B"],axis=1)@np.linalg.pinv(np.stack(P["B"],axis=1))
def build(n,dim,seed,mode):
    S={(i,j):make_sector(i,j,dim,seed,mode) for i in range(n) for j in range(n)}
    T={}
    for p in S:
        i,j=p
        for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
            if q in S: T[(p,q)]=transport(S[p],S[q])
    return S,T
def edge_faith(Tpq,P,Q,mode):
    G=P["B"]+P["O3"]; vals=[]
    for a in range(len(G)):
        for b in range(a+1,len(G)):
            vals.append(np.linalg.norm(Tpq@recombine(G[a],G[b],mode)-recombine(Tpq@G[a],Tpq@G[b],mode)))
    return float(np.mean(vals))
def row(i,j,S,T,mode):
    p=(i,j); src=S[p]["source"]; diffs=[]; edges=[]
    for q in [(i+1,j),(i-1,j),(i,j+1),(i,j-1)]:
        if q in S:
            diffs.append(T[(q,p)]@S[q]["source"]-src)
            edges.append(edge_faith(T[(p,q)],S[p],S[q],mode))
    flow=float(np.linalg.norm(np.mean(np.stack(diffs),axis=0)))
    edge=float(np.mean(edges))
    return {"target":flow+.15*edge,"flow_div":flow,"source_norm":float(np.linalg.norm(src)),"edge_faithfulness":edge,"edge_x_flow":edge*flow}
def dataset(n,dim,seed,mode,cond):
    S,T=build(n,dim,seed,mode); rows=[]
    for i in range(1,n-1):
        for j in range(1,n-1):
            rows.append(row(i,j,S,T,mode))
    df=pd.DataFrame(rows); df["ngrid"]=n; df["dim"]=dim; df["seed"]=seed; df["mode"]=mode; df["condition"]=cond
    rng=np.random.default_rng(24000+n*100+dim*10+seed)
    if cond in ["edge_shuffle","edge_block_shuffle"]:
        e=df.edge_faithfulness.values.copy()
        if cond=="edge_shuffle":
            rng.shuffle(e)
        else:
            bins=pd.qcut(df.flow_div, q=min(3,len(df)), labels=False, duplicates="drop")
            for b in np.unique(bins):
                idx=np.where(bins==b)[0]; vals=e[idx].copy(); rng.shuffle(vals); e[idx]=vals
        df["edge_faithfulness"]=e; df["edge_x_flow"]=df.edge_faithfulness*df.flow_div
    return df
def standardize(X):
    X=np.asarray(X,float); mu=X.mean(axis=0); sd=X.std(axis=0); sd[sd<EPS]=1
    return (X-mu)/sd
def fit(y,cols):
    y=np.asarray(y,float); X=standardize(np.asarray(cols,float)); X=np.c_[np.ones(len(X)),X]
    return X@(np.linalg.pinv(X)@y)
def r2(y,p):
    ssr=float(np.sum((y-p)**2)); sst=float(np.sum((y-y.mean())**2))
    return 0 if sst<EPS else float(1-ssr/sst)
def resid(y,X): return np.asarray(y,float)-fit(y,X)
def eval_models(sub):
    y=sub.target.values
    X0=sub[["flow_div","source_norm"]].values
    X1=sub[["flow_div","source_norm","edge_faithfulness"]].values
    p0=fit(y,X0); p1=fit(y,X1)
    yr=resid(y,X0); er=resid(sub.edge_faithfulness.values,X0)
    pr=fit(yr,er.reshape(-1,1))
    return {"R2_flow":r2(y,p0),"R2_flow_edge":r2(y,p1),"delta_edge":r2(y,p1)-r2(y,p0),"R2_resid_edge":r2(yr,pr)}

dfs=[]
for cond in ["real","edge_shuffle","edge_block_shuffle"]:
    for dim in [10,12,14]:
        for n in [5,6]:
            for seed in range(4):
                dfs.append(dataset(n,dim,seed,"nonlinear",cond))
dfs.append(dataset(6,12,0,"linear","linear_control"))
df=pd.concat(dfs,ignore_index=True); df.to_csv(OUT/"v1688_24_edge_law_rows.csv",index=False)
summary=[]
for keys,sub in df.groupby(["condition","mode","ngrid","dim","seed"]):
    condition,mode,n,dim,seed=keys; ev=eval_models(sub)
    summary.append({"condition":condition,"mode":mode,"ngrid":int(n),"dim":int(dim),"seed":int(seed),"n":len(sub),**ev})
summ=pd.DataFrame(summary); summ.to_csv(OUT/"v1688_24_summary.csv",index=False)
group=summ.groupby("condition").agg(config_count=("condition","count"),mean_R2_flow=("R2_flow","mean"),mean_R2_flow_edge=("R2_flow_edge","mean"),mean_delta_edge=("delta_edge","mean"),min_delta_edge=("delta_edge","min"),positive_delta_edge_rate=("delta_edge",lambda x:float(np.mean(np.asarray(x)>0))),mean_R2_resid_edge=("R2_resid_edge","mean")).reset_index()
group.to_csv(OUT/"v1688_24_grouped.csv",index=False)
real=group[group.condition=="real"].iloc[0].to_dict(); shuf=group[group.condition=="edge_shuffle"].iloc[0].to_dict(); block=group[group.condition=="edge_block_shuffle"].iloc[0].to_dict()
mg=float(real["mean_delta_edge"])-float(shuf["mean_delta_edge"]); mb=float(real["mean_delta_edge"])-float(block["mean_delta_edge"])
if real["mean_delta_edge"]>.20 and mg>.15 and mb>.08 and real["mean_R2_resid_edge"]>.20:
    verdict="EDGE_FAITHFULNESS_FLOW_LAW_HARDENED"
elif real["mean_delta_edge"]>.05 and mg>.03 and real["mean_R2_resid_edge"]>.05:
    verdict="EDGE_FAITHFULNESS_FLOW_LAW_PARTIAL"
else:
    verdict="EDGE_FAITHFULNESS_FLOW_LAW_NOT_HARDENED"
result={"document_id":"V1688_24_EDGE_FAITHFULNESS_LAW_HARDENING","status":"completed","verdict":verdict,"real_group":real,"edge_shuffle_group":shuf,"edge_block_shuffle_group":block,"real_gain_minus_shuffle":mg,"real_gain_minus_block_shuffle":mb,"outputs":{"rows":str(OUT/"v1688_24_edge_law_rows.csv"),"summary":str(OUT/"v1688_24_summary.csv"),"grouped":str(OUT/"v1688_24_grouped.csv")},"claim_boundary":"Toy edge-faithfulness same-slice flow hardening only; no ADM derivation / GR / physical spacetime claim."}
(OUT/"v1688_24_result.json").write_text(json.dumps(result,indent=2)); (OUT/"V1688_24_EDGE_FAITHFULNESS_LAW_HARDENING_REPORT.md").write_text("# V1688.24 — Edge-Faithfulness Law Hardening\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n")
print(json.dumps(result,indent=2))
