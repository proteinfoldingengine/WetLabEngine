# V1688.43 — Coefficient Convergence / Law-Limit Test

**Project:** Retained Bridge / Recoverability Geometry  
**Status:** executed  
**Verdict:** `PARTIAL_COEFFICIENT_CONVERGENCE_SIGNAL_REQUIRES_DEEPER_LADDER`

## Objective

Test whether the V1688.42 minimal two-term correction law approaches stable coefficient limits under a deeper refinement ladder and independently regenerated operator families.

```text
Y = weak_target = z(log1p(abs(conf_proxy - closure_surplus)))
M0 = source_abs + access_abs + div_baseline
M13 = M0 + alpha · Gamma_R_edge + beta · H4_perp
```

`conf_proxy` and `closure_surplus` define the target and are excluded from all predictive models.

## Harness scale

- Resolutions: `[16, 24, 32, 48, 64, 96, 128]`
- Seeds: `7`
- Independent operator families: `5`
- Rows: `57400`

## Group-holdout performance

- Mean M0 R²: `0.580870`
- Mean M13 R²: `0.622673`
- Mean ΔR² M13 − M0: `0.041802`
- Minimum ΔR²: `0.001411`
- Positive-gain rate: `1.000`
- Resolution-holdout positive rate: `1.000`

## Coefficient limit fits

Fitted form:

```text
c(dx) = c_inf + k · dx^p
```

| coefficient   | fit_form           |       c_inf |        k |   p |   r2_fit |         sse |   mean_all |   std_across_resolution_means |   finest3_mean |   finest3_cv_abs |   coarse3_mean |   coarse_to_finest_shift |   sign_rate_resolution_means_positive |
|:--------------|:-------------------|------------:|---------:|----:|---------:|------------:|-----------:|------------------------------:|---------------:|-----------------:|---------------:|-------------------------:|--------------------------------------:|
| edge          | c(dx)=c_inf+k*dx^p | -0.0475599  | 0.839106 | 0.5 | 0.94873  | 0.000767125 |  0.0831834 |                     0.0499374 |      0.0410882 |         0.829817 |       0.126918 |                0.0858298 |                                     1 |
| H4_perp       | c(dx)=c_inf+k*dx^p |  0.00894428 | 1.39056  | 0.5 | 0.966485 | 0.00135187  |  0.225611  |                     0.0819921 |      0.152652  |         0.293144 |       0.302646 |                0.149994  |                                     1 |

## Refinement coefficients by resolution

|   ('resolution', '') |   ('dx', '') |   ('delta_vs_M0', 'mean') |   ('delta_vs_M0', 'std') |   ('coef_edge', 'mean') |   ('coef_edge', 'std') |   ('coef_H4_perp', 'mean') |   ('coef_H4_perp', 'std') |
|---------------------:|-------------:|--------------------------:|-------------------------:|------------------------:|-----------------------:|---------------------------:|--------------------------:|
|                   16 |    0.0625    |                 0.125853  |               0.0176746  |              0.157832   |             0.00340638 |                   0.341023 |                0.00563072 |
|                   24 |    0.0416667 |                 0.093617  |               0.0121047  |              0.119385   |             0.00636317 |                   0.293463 |                0.00499317 |
|                   32 |    0.03125   |                 0.0777242 |               0.00781629 |              0.103537   |             0.00523963 |                   0.273451 |                0.00338568 |
|                   48 |    0.0208333 |                 0.0482113 |               0.00641811 |              0.0782654  |             0.00442575 |                   0.213382 |                0.0027415  |
|                   64 |    0.015625  |                 0.0431119 |               0.00583501 |              0.0761844  |             0.00433943 |                   0.201367 |                0.00222315 |
|                   96 |    0.0104167 |                 0.0209423 |               0.0011317  |              0.03899    |             0.00159887 |                   0.143214 |                0.00114351 |
|                  128 |    0.0078125 |                 0.0127254 |               0.00189712 |              0.00809002 |             0.00306477 |                   0.113374 |                0.00230265 |

## Null / leakage hardening

- Critical null max ΔR²: `0.005738`
- Critical null margin vs max: `0.036064`
- Residualized mean ΔR²: `0.053093`
- Residualized positive rate: `1.000`

| null                                 |   mean_delta_vs_M0 |
|:-------------------------------------|-------------------:|
| edge_H4_joint_shuffle                |        1.37727e-05 |
| linear_recombination_control         |       -2.46471e-05 |
| operator_family_transport_randomized |        0.0019249   |
| source_flow_preserving_block_shuffle |        8.68755e-06 |

## Interpretation

The correction signal remained positive and null-separated, but at least one limit-stability condition was not strong enough for a law-limit pass. Treat this as a convergence candidate requiring a deeper ladder or independent replication.

## Claim boundary

This is a finite retained-flow weak-form toy-harness result only. It is not an ADM derivation, GR derivation, Riemann curvature claim, physical spacetime claim, Einstein-equation claim, or Bianchi identity claim.

## Recommended next step

V1688.44 should diagnose the unstable coefficient component before attempting transfer.
