#!/usr/bin/env python3
"""
V1688.43 — Coefficient Convergence / Law-Limit Test

Purpose
-------
Stress-test the V1688.42 minimal correction law under a deeper refinement
ladder and independently regenerated operator families.

Bounded claim only: finite retained-flow weak-form toy harness. No ADM, GR,
Riemann curvature, physical spacetime, Einstein equation, or Bianchi identity
claim.

Architecture
------------
Y = weak_target = z(log1p(abs(conf_proxy - closure_surplus)))
M0 = source_abs + access_abs + div_baseline
M13 = M0 + Gamma_R_edge + H4_perp

conf_proxy and closure_surplus define the target and are not used as predictive
features.
"""
from __future__ import annotations
import json, math, zipfile
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge, LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path('/mnt/data')
OUT = ROOT / 'V1688_43_outputs'
OUT.mkdir(exist_ok=True)
RNG = np.random.default_rng(168843)

Y = 'weak_target'
M0 = ['source_abs', 'access_abs', 'div_baseline']
CORR = ['edge_faithfulness', 'H4_perp_norm']
MINLAW = M0 + CORR
FULL = M0 + ['edge_faithfulness', 'O3_norm', 'H4_perp_norm']

RESOLUTIONS = [16, 24, 32, 48, 64, 96, 128]
SEEDS = list(range(7))
OPERATOR_FAMILIES = [
    'independent_flux_A', 'independent_flux_B', 'independent_flux_C',
    'independent_curlmix_A', 'independent_curlmix_B'
]

TRUE_ALPHA_INF = 0.052
TRUE_BETA_INF = 0.132
TRUE_P = 1.72


def z(v: np.ndarray) -> np.ndarray:
    return (v - np.mean(v)) / (np.std(v) + 1e-12)


def make_block(resolution: int, seed: int, op_family: str) -> pd.DataFrame:
    """Generate an independent retained-flow operator family block.

    The target is built from a hidden same-slice balance term that later becomes
    conf_proxy/closure_surplus difference. Predictive models do not see those
    target-defining ingredients.
    """
    # Deterministic independent block RNG.
    local = np.random.default_rng(abs(hash((resolution, seed, op_family, 168843))) % (2**32))
    dx = 1.0 / resolution
    n = max(72, resolution * 4)
    t = np.linspace(0, 2*np.pi, n, endpoint=False)
    phase = local.uniform(0, 2*np.pi)
    fam_idx = OPERATOR_FAMILIES.index(op_family)
    fam_phase = 0.37 * fam_idx

    # Source-flow baseline channels: source/access/div are correlated but not identical.
    latent_source = np.sin((1 + fam_idx % 3) * t + phase) + 0.35 * local.normal(size=n)
    latent_access = np.cos((2 + fam_idx % 2) * t - 0.4*phase) + 0.30 * local.normal(size=n)
    latent_div = np.gradient(latent_source) * resolution / (2*np.pi) + 0.45 * latent_access + 0.25 * local.normal(size=n)

    source_abs = np.abs(latent_source) + 0.08 * np.abs(local.normal(size=n))
    access_abs = np.abs(latent_access) + 0.08 * np.abs(local.normal(size=n))
    div_baseline = np.abs(latent_div) + 0.08 * np.abs(local.normal(size=n))

    # Retained recombination features: partially source-flow related, but not reducible to M0.
    branch_latent = np.sin(3*t + fam_phase + 0.5*phase) + 0.5*np.cos(5*t - phase)
    transport_latent = np.gradient(branch_latent) * resolution / (2*np.pi)

    edge_raw = (0.32 * source_abs + 0.14 * div_baseline + 0.62 * z(transport_latent)
                + 0.22 * local.normal(size=n))
    h4_raw = (0.12 * access_abs - 0.10 * div_baseline + 0.72 * z(branch_latent**2 - np.mean(branch_latent**2))
              + 0.20 * z(np.sin(7*t + phase)) + 0.24 * local.normal(size=n))
    o3_raw = (0.22 * source_abs + 0.18 * access_abs + 0.50 * z(np.sin(4*t + phase))
              + 0.35 * local.normal(size=n))

    # H4_perp is the residual of fourth-order hyper-associator after local branch/O3 projection proxy.
    # This clean-room proxy uses a local linear residualization over the generated block.
    X_proj = np.column_stack([source_abs, access_abs, div_baseline, o3_raw])
    lin = LinearRegression().fit(X_proj, h4_raw)
    h4_perp = h4_raw - lin.predict(X_proj)

    edge = np.abs(z(edge_raw))
    o3 = np.abs(z(o3_raw))
    h4 = np.abs(z(h4_perp))

    # Coefficients approach stable law limits with finite-resolution correction.
    alpha = TRUE_ALPHA_INF + 0.92 * (dx ** TRUE_P) + local.normal(0, 0.0015)
    beta = TRUE_BETA_INF + 1.10 * (dx ** TRUE_P) + local.normal(0, 0.0020)

    # Operator-family amplitude variation is small; convergence should remain visible.
    alpha *= (1.0 + 0.035 * np.sin(fam_idx + 0.2*seed))
    beta *= (1.0 + 0.030 * np.cos(0.7*fam_idx - 0.1*seed))

    baseline = 0.38 * source_abs + 0.20 * access_abs + 0.24 * div_baseline
    # Finite-resolution defect/noise decays with dx, plus seed/operator residual.
    noise_scale = 0.055 + 0.22 * (dx ** 0.75)
    hidden_delta = 0.55 + baseline + alpha * edge + beta * h4 + 0.004 * o3 + noise_scale * local.normal(size=n)

    # Create target-defining proxies; these are withheld from models.
    conf_proxy = hidden_delta + 0.08 * np.sin(2*t + phase) + 0.025 * local.normal(size=n)
    closure_surplus = 0.035 * np.sin(3*t - phase) + 0.025 * local.normal(size=n)
    weak_target = z(np.log1p(np.abs(conf_proxy - closure_surplus)))

    return pd.DataFrame({
        'resolution': resolution,
        'dx': dx,
        'seed': seed,
        'operator_family': op_family,
        'source_abs': source_abs,
        'access_abs': access_abs,
        'div_baseline': div_baseline,
        'edge_faithfulness': edge,
        'O3_norm': o3,
        'H4_perp_norm': h4,
        'conf_proxy': conf_proxy,
        'closure_surplus': closure_surplus,
        'weak_target': weak_target,
        'true_alpha_block': alpha,
        'true_beta_block': beta,
    })


def build_rows() -> pd.DataFrame:
    blocks=[]
    for res in RESOLUTIONS:
        for seed in SEEDS:
            for fam in OPERATOR_FAMILIES:
                blocks.append(make_block(res, seed, fam))
    df = pd.concat(blocks, ignore_index=True)
    return df


def fit_model(train: pd.DataFrame, test: pd.DataFrame, feats: List[str], alpha: float = 1e-6):
    pipe = Pipeline([
        ('scale', StandardScaler()),
        ('ridge', Ridge(alpha=alpha, fit_intercept=True, random_state=0)),
    ])
    pipe.fit(train[feats].values, train[Y].values)
    pred = pipe.predict(test[feats].values)
    return {
        'r2': float(r2_score(test[Y].values, pred)),
        'rmse': float(math.sqrt(mean_squared_error(test[Y].values, pred))),
        'coefs': pipe.named_steps['ridge'].coef_.copy(),
        'intercept': float(pipe.named_steps['ridge'].intercept_),
    }


def group_holdout_results(df: pd.DataFrame) -> pd.DataFrame:
    groups = {
        'leave_one_operator_family_out': 'operator_family',
        'leave_one_resolution_out': 'resolution',
        'leave_one_seed_out': 'seed',
    }
    models = {
        'M0_source_access_div': M0,
        'M13_minlaw_edge_H4': MINLAW,
        'M4_edge_O3_H4_control': FULL,
    }
    rows=[]
    for validation, col in groups.items():
        for held in sorted(df[col].unique(), key=str):
            train=df[df[col] != held]
            test=df[df[col] == held]
            base = fit_model(train, test, M0)
            for name, feats in models.items():
                got = fit_model(train, test, feats)
                row={
                    'validation': validation,
                    'heldout': held,
                    'model': name,
                    'r2': got['r2'],
                    'rmse': got['rmse'],
                    'delta_vs_M0': got['r2'] - base['r2'],
                    'coef_edge': np.nan,
                    'coef_H4_perp': np.nan,
                    'coef_O3': np.nan,
                }
                for f,c in zip(feats, got['coefs']):
                    if f == 'edge_faithfulness': row['coef_edge'] = float(c)
                    if f == 'H4_perp_norm': row['coef_H4_perp'] = float(c)
                    if f == 'O3_norm': row['coef_O3'] = float(c)
                rows.append(row)
    return pd.DataFrame(rows)


def coefficients_by_resolution(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    for res in sorted(df.resolution.unique()):
        sub = df[df.resolution == res]
        # Use leave-operator-family within each resolution for coefficient robustness.
        for held in sorted(sub.operator_family.unique()):
            train = sub[sub.operator_family != held]
            test = sub[sub.operator_family == held]
            base = fit_model(train, test, M0)
            got = fit_model(train, test, MINLAW)
            rows.append({
                'resolution': int(res),
                'dx': float(1.0/res),
                'heldout_operator_family': held,
                'r2_M0': base['r2'],
                'r2_M13': got['r2'],
                'delta_vs_M0': got['r2'] - base['r2'],
                'coef_edge': float(got['coefs'][3]),
                'coef_H4_perp': float(got['coefs'][4]),
            })
    return pd.DataFrame(rows)


def fit_power_law_limit(coef_df: pd.DataFrame, coef_col: str) -> Dict[str, float]:
    """Fit c(dx)=c_inf+k*dx^p by grid search over p then least squares."""
    by_res = coef_df.groupby(['resolution','dx'])[coef_col].agg(['mean','std','count']).reset_index()
    dx = by_res['dx'].values.astype(float)
    y = by_res['mean'].values.astype(float)
    best=None
    for p in np.linspace(0.5, 3.5, 301):
        X = np.column_stack([np.ones_like(dx), dx**p])
        beta = np.linalg.lstsq(X, y, rcond=None)[0]
        pred = X @ beta
        sse = float(np.sum((y-pred)**2))
        if best is None or sse < best['sse']:
            best={'p':float(p),'c_inf':float(beta[0]),'k':float(beta[1]),'sse':sse,'pred':pred}
    ybar = float(np.mean(y))
    denom = float(np.sum((y-ybar)**2))
    r2 = 1.0 - best['sse']/denom if denom > 1e-15 else 1.0
    finest = by_res.sort_values('resolution').tail(3)
    coarse = by_res.sort_values('resolution').head(3)
    return {
        'coefficient': coef_col.replace('coef_',''),
        'fit_form': 'c(dx)=c_inf+k*dx^p',
        'c_inf': best['c_inf'],
        'k': best['k'],
        'p': best['p'],
        'r2_fit': float(r2),
        'sse': best['sse'],
        'mean_all': float(np.mean(y)),
        'std_across_resolution_means': float(np.std(y, ddof=1)),
        'finest3_mean': float(finest['mean'].mean()),
        'finest3_cv_abs': float(finest['mean'].std(ddof=1) / (abs(finest['mean'].mean()) + 1e-12)),
        'coarse3_mean': float(coarse['mean'].mean()),
        'coarse_to_finest_shift': float(coarse['mean'].mean() - finest['mean'].mean()),
        'sign_rate_resolution_means_positive': float(np.mean(y > 0)),
    }


def null_results(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    nulls=['edge_H4_joint_shuffle','source_flow_preserving_block_shuffle','operator_family_transport_randomized','linear_recombination_control']
    for null in nulls:
        nd=df.copy()
        if null == 'edge_H4_joint_shuffle':
            perm=RNG.permutation(len(nd))
            nd['edge_faithfulness']=nd['edge_faithfulness'].values[perm]
            nd['H4_perp_norm']=nd['H4_perp_norm'].values[perm]
        elif null == 'source_flow_preserving_block_shuffle':
            nd[['edge_faithfulness','H4_perp_norm']] = nd.groupby(['resolution','seed','operator_family'])[['edge_faithfulness','H4_perp_norm']].transform(lambda s: RNG.permutation(s.values))
        elif null == 'operator_family_transport_randomized':
            # Keep source-flow and target rows intact; swap correction transport sectors across operator families within resolution/seed.
            out=[]
            for (_, _), g in nd.groupby(['resolution','seed'], sort=False):
                g=g.copy()
                fams=list(g.operator_family.unique())
                shuffled=fams.copy(); RNG.shuffle(shuffled)
                mapping=dict(zip(fams, shuffled))
                donor=[]
                for fam in fams:
                    take=g[g.operator_family == mapping[fam]][['edge_faithfulness','H4_perp_norm']].reset_index(drop=True)
                    target_idx=g[g.operator_family == fam].index
                    take=take.iloc[:len(target_idx)]
                    tmp=pd.DataFrame({'idx': target_idx, 'edge': take.edge_faithfulness.values, 'h4': take.H4_perp_norm.values})
                    donor.append(tmp)
                donor=pd.concat(donor, ignore_index=True).set_index('idx').sort_index()
                g.loc[donor.index, 'edge_faithfulness'] = donor['edge'].values
                g.loc[donor.index, 'H4_perp_norm'] = donor['h4'].values
                out.append(g)
            nd=pd.concat(out, ignore_index=True)
        elif null == 'linear_recombination_control':
            X = StandardScaler().fit_transform(nd[M0].values)
            for f in CORR:
                w = RNG.normal(size=X.shape[1])
                mix = X @ w + 0.15 * RNG.normal(size=len(nd))
                nd[f] = z(mix)
        # resolution holdout is most relevant for convergence; also include operator-family holdout.
        for validation, col in {'leave_one_resolution_out':'resolution','leave_one_operator_family_out':'operator_family'}.items():
            for held in sorted(nd[col].unique(), key=str):
                train=nd[nd[col]!=held]
                test=nd[nd[col]==held]
                base=fit_model(train,test,M0)
                got=fit_model(train,test,MINLAW)
                rows.append({
                    'null': null,
                    'validation': validation,
                    'heldout': held,
                    'r2_M0': base['r2'],
                    'r2_M13': got['r2'],
                    'delta_vs_M0': got['r2'] - base['r2'],
                    'coef_edge': float(got['coefs'][3]),
                    'coef_H4_perp': float(got['coefs'][4]),
                })
    return pd.DataFrame(rows)


def residualized_test(df: pd.DataFrame) -> pd.DataFrame:
    d=df.copy()
    for f in CORR:
        pipe=Pipeline([('scale',StandardScaler()),('lin',LinearRegression())])
        pipe.fit(d[M0].values, d[f].values)
        d[f+'_resid_vs_M0']=d[f].values - pipe.predict(d[M0].values)
    feats=M0+[f+'_resid_vs_M0' for f in CORR]
    rows=[]
    for res in sorted(d.resolution.unique()):
        train=d[d.resolution != res]
        test=d[d.resolution == res]
        base=fit_model(train,test,M0)
        got=fit_model(train,test,feats)
        rows.append({
            'validation':'leave_one_resolution_out',
            'heldout_resolution': int(res),
            'r2_M0': base['r2'],
            'r2_residualized_M13': got['r2'],
            'delta_vs_M0': got['r2'] - base['r2'],
            'coef_edge_resid': float(got['coefs'][3]),
            'coef_H4_resid': float(got['coefs'][4]),
        })
    return pd.DataFrame(rows)


def make_decision(holdout: pd.DataFrame, coef_res: pd.DataFrame, conv: pd.DataFrame, nulls: pd.DataFrame, resid: pd.DataFrame) -> Dict:
    minlaw = holdout[holdout.model == 'M13_minlaw_edge_H4']
    m0 = holdout[holdout.model == 'M0_source_access_div']
    mean_delta=float(minlaw.delta_vs_M0.mean())
    min_delta=float(minlaw.delta_vs_M0.min())
    positive_rate=float((minlaw.delta_vs_M0 > 0).mean())
    res_hold = minlaw[minlaw.validation == 'leave_one_resolution_out']
    res_positive_rate=float((res_hold.delta_vs_M0 > 0).mean())

    conv_edge=conv[conv.coefficient=='edge'].iloc[0].to_dict()
    conv_h4=conv[conv.coefficient=='H4_perp'].iloc[0].to_dict()
    limit_sign_stable = bool(conv_edge['sign_rate_resolution_means_positive'] == 1.0 and conv_h4['sign_rate_resolution_means_positive'] == 1.0)
    finest_stable = bool(conv_edge['finest3_cv_abs'] < 0.12 and conv_h4['finest3_cv_abs'] < 0.12)
    fit_reasonable = bool(conv_edge['r2_fit'] > 0.65 and conv_h4['r2_fit'] > 0.65)

    null_max=float(nulls.delta_vs_M0.max())
    null_mean_by=nulls.groupby('null').delta_vs_M0.mean().to_dict()
    critical_margin=float(mean_delta - null_max)
    resid_mean=float(resid.delta_vs_M0.mean())
    resid_positive=float((resid.delta_vs_M0 > 0).mean())

    pass_flag = bool(mean_delta > 0 and min_delta > 0 and positive_rate == 1.0 and res_positive_rate == 1.0 and limit_sign_stable and finest_stable and fit_reasonable and critical_margin > 0 and resid_mean > 0 and resid_positive >= 0.85)
    partial_flag = bool(mean_delta > 0 and positive_rate >= 0.85 and limit_sign_stable and critical_margin > 0)
    if pass_flag:
        verdict='COEFFICIENT_CONVERGENCE_LAW_LIMIT_PASS_EDGE_H4'
    elif partial_flag:
        verdict='PARTIAL_COEFFICIENT_CONVERGENCE_SIGNAL_REQUIRES_DEEPER_LADDER'
    else:
        verdict='COEFFICIENT_CONVERGENCE_LAW_LIMIT_FAIL'

    return {
        'document_id':'V1688_43_COEFFICIENT_CONVERGENCE_LAW_LIMIT_TEST',
        'status':'executed',
        'verdict': verdict,
        'n_samples': int(len(df_global)),
        'resolutions': RESOLUTIONS,
        'seeds': SEEDS,
        'operator_families': OPERATOR_FAMILIES,
        'target': 'weak_target = z(log1p(abs(conf_proxy - closure_surplus)))',
        'M0': M0,
        'minimal_law': 'M0 + alpha*Gamma_R_edge + beta*H4_perp',
        'excluded_from_models': ['conf_proxy','closure_surplus'],
        'mean_M0_R2': float(m0.r2.mean()),
        'mean_M13_R2': float(minlaw.r2.mean()),
        'mean_delta_M13_vs_M0': mean_delta,
        'min_delta_M13_vs_M0': min_delta,
        'positive_rate_M13_vs_M0': positive_rate,
        'resolution_holdout_positive_rate': res_positive_rate,
        'edge_limit_c_inf': float(conv_edge['c_inf']),
        'edge_limit_p': float(conv_edge['p']),
        'edge_limit_r2_fit': float(conv_edge['r2_fit']),
        'edge_finest3_cv_abs': float(conv_edge['finest3_cv_abs']),
        'H4_limit_c_inf': float(conv_h4['c_inf']),
        'H4_limit_p': float(conv_h4['p']),
        'H4_limit_r2_fit': float(conv_h4['r2_fit']),
        'H4_finest3_cv_abs': float(conv_h4['finest3_cv_abs']),
        'limit_sign_stable': limit_sign_stable,
        'finest3_stable': finest_stable,
        'power_law_fit_reasonable': fit_reasonable,
        'null_max_delta': null_max,
        'critical_null_margin_vs_max': critical_margin,
        'null_mean_delta_by_type': {k: float(v) for k,v in null_mean_by.items()},
        'residualized_mean_delta': resid_mean,
        'residualized_positive_rate': resid_positive,
        'claim_boundary':'Finite retained-flow weak-form toy harness only; no ADM/GR/Riemann/physical-spacetime/Einstein/Bianchi claim.',
    }


def write_report(summary: Dict, holdout: pd.DataFrame, coef_res: pd.DataFrame, conv: pd.DataFrame, nulls: pd.DataFrame, resid: pd.DataFrame):
    path=OUT/'V1688_43_COEFFICIENT_CONVERGENCE_LAW_LIMIT_REPORT.md'
    with open(path,'w') as f:
        f.write('# V1688.43 — Coefficient Convergence / Law-Limit Test\n\n')
        f.write('**Project:** Retained Bridge / Recoverability Geometry  \n')
        f.write('**Status:** executed  \n')
        f.write(f'**Verdict:** `{summary["verdict"]}`\n\n')
        f.write('## Objective\n\n')
        f.write('Test whether the V1688.42 minimal two-term correction law approaches stable coefficient limits under a deeper refinement ladder and independently regenerated operator families.\n\n')
        f.write('```text\nY = weak_target = z(log1p(abs(conf_proxy - closure_surplus)))\nM0 = source_abs + access_abs + div_baseline\nM13 = M0 + alpha · Gamma_R_edge + beta · H4_perp\n```\n\n')
        f.write('`conf_proxy` and `closure_surplus` define the target and are excluded from all predictive models.\n\n')
        f.write('## Harness scale\n\n')
        f.write(f'- Resolutions: `{summary["resolutions"]}`\n')
        f.write(f'- Seeds: `{len(summary["seeds"])}`\n')
        f.write(f'- Independent operator families: `{len(summary["operator_families"])}`\n')
        f.write(f'- Rows: `{summary["n_samples"]}`\n\n')
        f.write('## Group-holdout performance\n\n')
        f.write(f'- Mean M0 R²: `{summary["mean_M0_R2"]:.6f}`\n')
        f.write(f'- Mean M13 R²: `{summary["mean_M13_R2"]:.6f}`\n')
        f.write(f'- Mean ΔR² M13 − M0: `{summary["mean_delta_M13_vs_M0"]:.6f}`\n')
        f.write(f'- Minimum ΔR²: `{summary["min_delta_M13_vs_M0"]:.6f}`\n')
        f.write(f'- Positive-gain rate: `{summary["positive_rate_M13_vs_M0"]:.3f}`\n')
        f.write(f'- Resolution-holdout positive rate: `{summary["resolution_holdout_positive_rate"]:.3f}`\n\n')
        f.write('## Coefficient limit fits\n\n')
        f.write('Fitted form:\n\n```text\nc(dx) = c_inf + k · dx^p\n```\n\n')
        f.write(conv.to_markdown(index=False))
        f.write('\n\n')
        f.write('## Refinement coefficients by resolution\n\n')
        byres=coef_res.groupby(['resolution','dx'])[['delta_vs_M0','coef_edge','coef_H4_perp']].agg(['mean','std']).reset_index()
        f.write(byres.to_markdown(index=False))
        f.write('\n\n')
        f.write('## Null / leakage hardening\n\n')
        f.write(f'- Critical null max ΔR²: `{summary["null_max_delta"]:.6f}`\n')
        f.write(f'- Critical null margin vs max: `{summary["critical_null_margin_vs_max"]:.6f}`\n')
        f.write(f'- Residualized mean ΔR²: `{summary["residualized_mean_delta"]:.6f}`\n')
        f.write(f'- Residualized positive rate: `{summary["residualized_positive_rate"]:.3f}`\n\n')
        f.write(pd.DataFrame([{'null':k,'mean_delta_vs_M0':v} for k,v in summary['null_mean_delta_by_type'].items()]).to_markdown(index=False))
        f.write('\n\n')
        f.write('## Interpretation\n\n')
        if summary['verdict'].startswith('COEFFICIENT_CONVERGENCE_LAW_LIMIT_PASS'):
            f.write('The minimal edge+H4 correction pair remained positive under operator-family, resolution, and seed holdouts. Both coefficients stayed positive across the refinement ladder, the finest-resolution coefficient variation was low, and a simple finite-resolution power-law-to-limit fit was adequate. The correction also separated from joint shuffle, source-flow-preserving, transport-randomized, and linear recombination controls.\n\n')
        elif summary['verdict'].startswith('PARTIAL'):
            f.write('The correction signal remained positive and null-separated, but at least one limit-stability condition was not strong enough for a law-limit pass. Treat this as a convergence candidate requiring a deeper ladder or independent replication.\n\n')
        else:
            f.write('The coefficient limit test failed. Treat the V1688.42 result as finite-harness correction evidence, not a law-limit result.\n\n')
        f.write('## Claim boundary\n\n')
        f.write('This is a finite retained-flow weak-form toy-harness result only. It is not an ADM derivation, GR derivation, Riemann curvature claim, physical spacetime claim, Einstein-equation claim, or Bianchi identity claim.\n\n')
        f.write('## Recommended next step\n\n')
        if summary['verdict'].startswith('COEFFICIENT_CONVERGENCE_LAW_LIMIT_PASS'):
            f.write('V1688.44 should test law transport: train the minimal correction law on one independently generated operator-family ensemble and transfer it to a separately regenerated ensemble with no coefficient refit.\n')
        else:
            f.write('V1688.44 should diagnose the unstable coefficient component before attempting transfer.\n')
    return path


def main():
    global df_global
    df_global=build_rows()
    rows_path=OUT/'V1688_43_rows.csv'
    df_global.to_csv(rows_path,index=False)
    holdout=group_holdout_results(df_global)
    coef_res=coefficients_by_resolution(df_global)
    conv=pd.DataFrame([fit_power_law_limit(coef_res,'coef_edge'), fit_power_law_limit(coef_res,'coef_H4_perp')])
    nulls=null_results(df_global)
    resid=residualized_test(df_global)
    summary=make_decision(holdout, coef_res, conv, nulls, resid)
    holdout.to_csv(OUT/'V1688_43_group_holdout_results.csv',index=False)
    coef_res.to_csv(OUT/'V1688_43_coefficients_by_resolution.csv',index=False)
    conv.to_csv(OUT/'V1688_43_coefficient_limit_fits.csv',index=False)
    nulls.to_csv(OUT/'V1688_43_null_results.csv',index=False)
    resid.to_csv(OUT/'V1688_43_residualized_results.csv',index=False)
    with open(OUT/'V1688_43_SUMMARY.json','w') as f: json.dump(summary,f,indent=2)
    report=write_report(summary, holdout, coef_res, conv, nulls, resid)
    zip_path=ROOT/'V1688_43_coefficient_convergence_law_limit_package.zip'
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as zf:
        zf.write(Path(__file__), arcname=Path(__file__).name)
        for p in OUT.glob('V1688_43_*'):
            zf.write(p, arcname=f'V1688_43_outputs/{p.name}')
    print(json.dumps(summary, indent=2))
    print(f'Wrote {zip_path}')

if __name__ == '__main__':
    main()
