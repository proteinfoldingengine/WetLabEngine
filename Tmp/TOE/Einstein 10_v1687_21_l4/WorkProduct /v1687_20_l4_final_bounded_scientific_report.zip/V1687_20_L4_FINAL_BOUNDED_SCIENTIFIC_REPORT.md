# V1687.20 — L4 Final Bounded Scientific Report

**Project:** Retained Bridge / Recoverability Geometry  
**Branch:** L4 hyper-associator after L3 geometry-plus-information  
**Status:** final bounded scientific report for the L4 branch  
**Claim level:** bounded finite-sector / natural-admissibility support; not universal theorem

---

## 1. Executive Summary

The L4 branch asked:

```text
After L3 irreducible third-order associator information,
does four-branch retained recombination merely reduce to branches plus all L3 associators,
or does it create a new irreducible fourth-order information layer?
```

The answer from V1687.1 through V1687.19 is:

```text
L4 appears to be irreducible fourth-order hyper-associator information.
```

The central object is:

\[
H_4
=
(((J_1\oplus J_2)\oplus J_3)\oplus J_4)
-
(J_1\oplus(J_2\oplus(J_3\oplus J_4))).
\]

The lower-order span is:

\[
\operatorname{span}(B_4\cup O_3),
\]

where:

\[
B_4=\{J_1,J_2,J_3,J_4\},
\]

and:

\[
O_3=\{O_{123},O_{124},O_{134},O_{234}\}.
\]

The key L4 result is:

\[
H_4\notin \operatorname{span}(B_4\cup O_3)
\]

in certified finite symbolic sectors.

The current bounded closure status is:

```text
L4 rank-lift: PASS
random-sector robustness: PASS
targeted nonzero-minor certificate: PASS
finite symbolic-sector family sweep: PASS
weak-proxy counterprojection: FOUND
counterprojection audit: INADMISSIBLE POST-HOC
A_op^nd,natural correction: COMPLETE
natural admissible erasure search: PASS
ε4 route under natural admissibility: STRENGTHENED
universal theorem: OPEN
```

The most precise current claim is:

```text
Inside the tested retained recombination operator family,
finite symbolic support/order sectors exist in which H4 contributes
an independent fourth-order retained direction beyond branches plus all L3 associators.

A weak-proxy non-diagonal H4 erasure exists,
but it is post-hoc, obstruction-targeting, and fails generated-algebra faithfulness.

Under the strengthened natural admissibility class A_op^nd,natural(L4),
no natural admissible H4 erasure was found in the finite-sector search.
```

---

## 2. Updated Layer Stack

The working layer stack is now:

```text
L1 = retained identity
L2 = pairwise geometry-like closure
L3 = irreducible third-order associator information / ε_floor
L4 = irreducible fourth-order hyper-associator information / ε4 route
```

This is not simply:

```text
more geometry after geometry.
```

It is a hierarchy of retained recombination irreducibility:

```text
identity
→ pairwise closure
→ third-order associator obstruction
→ fourth-order hyper-associator obstruction
```

The general hypothesis suggested, but not yet proven, is:

```text
Ln = irreducible n-branch retained recombination information.
```

---

## 3. Definitions

### 3.1 Retained Branches

Let:

\[
J_1,J_2,J_3,J_4\in V
\]

be retained branch currents in a finite-dimensional retained-current space \(V\).

### 3.2 Retained Recombination Operator

The tested operator family has form:

\[
x\oplus y=x+y+\gamma_{xy}K(x,y),
\]

with a retained nonlinear overlap kernel such as:

\[
K(x,y)=\operatorname{roll}(x)y-x\operatorname{roll}(y).
\]

This is not claimed as a universal physical law. It is the tested retained recombination class for this branch.

### 3.3 L3 Associators

For any triple:

\[
O_{ijk}
=
(J_i\oplus J_j)\oplus J_k
-
J_i\oplus(J_j\oplus J_k).
\]

For four branches, define:

\[
O_3=\{O_{123},O_{124},O_{134},O_{234}\}.
\]

### 3.4 L4 Hyper-Associator Residual

Define:

\[
H_4
=
(((J_1\oplus J_2)\oplus J_3)\oplus J_4)
-
(J_1\oplus(J_2\oplus(J_3\oplus J_4))).
\]

### 3.5 L4 Rank-Lift

Define:

\[
I_4
=
\operatorname{rank}[B_4,O_3,H_4]
-
\operatorname{rank}[B_4,O_3].
\]

L4 is certified when:

\[
I_4>0.
\]

In the certified finite sectors:

\[
\operatorname{rank}[B_4,O_3]=8,
\]

\[
\operatorname{rank}[B_4,O_3,H_4]=9,
\]

so:

\[
I_4=1.
\]

---

## 4. Discovery Path

### 4.1 V1687.1 — First L4 Discovery Harness

V1687.1 tested:

```text
all triple associators O_ijk
all five four-branch bracketings
rank lift beyond branches
rank lift beyond branches + all L3 associators
operator-family controls
```

The first verdict was:

```text
L4_DISCOVERY_NEW_HYPER_ASSOCIATOR_DIRECTION
```

This indicated:

```text
four-branch bracketing residuals were not reducible to branches + L3 associators.
```

---

### 4.2 V1687.2 — Random-Sector Hardening

V1687.2 hardened the result across random sectors.

Target operator:

```text
full_gated_order_overlap
```

Result:

```json
{
  "sectors": 24,
  "collapsed": 0,
  "l4_new": 24,
  "l4_law": 0,
  "unresolved": 0,
  "mean_l4_joint_lift": 4.0,
  "mean_single_l4_new_count": 4.0,
  "mean_l3_lift": 4.0,
  "mean_triple_NOOCI": 1.0,
  "l4_new_rate": 1.0
}
```

Interpretation:

```text
Across 24 random sectors, four-branch residuals were not reducible
to branches plus all L3 associators.
```

Controls behaved correctly:

```text
linear_associative_control → collapsed
closure_only_control → collapsed
```

This showed that the harness was not automatically inventing L4.

---

### 4.3 V1687.5 — Targeted Nonzero-Minor Certificate

V1687.5 produced a finite symbolic-sector certificate.

Result:

```json
{
  "rank_base_8": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1
}
```

It found an exact rational nonzero determinant:

```text
256480337840586992720981 / 144703125
```

Interpretation:

```text
A nonzero evaluated 9×9 determinant proves the corresponding symbolic minor
is not identically zero.
```

Therefore, in that finite symbolic sector:

\[
H_4\notin \operatorname{span}(B_4\cup O_3).
\]

---

### 4.4 V1687.6 — Finite Symbolic-Sector Family Sweep

V1687.6 extended the certificate from one sector to a finite family.

Result:

```json
{
  "sector_count": 8,
  "certified_count": 8,
  "certified_rate": 1.0,
  "rank_lift_min": 1,
  "rank_lift_mean": 1.0,
  "rank_lift_max": 1
}
```

Verdict:

```text
L4_FAMILY_NONZERO_MINOR_SWEEP_ALL_CERTIFIED
```

Interpretation:

```text
8 / 8 finite symbolic support/order sectors certified L4 rank-lift.
```

---

## 5. The Counterprojection and Why It Matters

### 5.1 V1687.15 — Non-Diagonal H4 Erasure Found

V1687.15 searched broader non-diagonal projections.

It found a projection that erased H4 while passing the earlier weak proxy:

```text
NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND
```

The projection was:

```text
project_away_H4_residual_strength_1.0
```

It produced:

```json
{
  "base_rank_B4_O3": 8,
  "rank_with_H4": 8,
  "rank_lift_H4": 0,
  "operator_faithfulness_gap_max": 6.29e-12,
  "admissible_Aopnd_proxy": true,
  "H4_erased": true
}
```

This was an important adversarial failure.

It showed:

```text
The original A_op^nd proxy was too permissive.
```

---

### 5.2 V1687.16 — Counterprojection Audit

V1687.16 audited the H4-erasing projection.

The projection was:

\[
P=I-uu^T,
\]

where:

\[
u=\frac{\operatorname{residual}(H_4\mid \operatorname{span}(B_4+O_3))}
{\|\operatorname{residual}(H_4\mid \operatorname{span}(B_4+O_3))\|}.
\]

Thus, the projection was explicitly built from the obstruction it erased.

V1687.16 verdict:

```text
H4_ERASURE_PROJECTION_INADMISSIBLE_POSTHOC
```

It passed weak checks but failed stronger ones:

```json
{
  "passes_branch_proxy": true,
  "pair_faithful": true,
  "nested_faithful": true,
  "generated_faithful": false,
  "construction_depends_on_H4": true,
  "construction_natural": false,
  "strict_admissible": false
}
```

Generated-algebra faithfulness failed sharply:

```json
{
  "generated_gap_max": 335274816.82744825,
  "generated_gap_mean": 8332377.074726313
}
```

Conclusion:

```text
The projection erased H4 by post-hoc obstruction targeting,
not by natural admissible projection.
```

---

## 6. Corrected Admissibility

### 6.1 V1687.17 — \(A_{op}^{nd,\natural}(L4)\)

V1687.17 strengthened the admissibility class.

The corrected class is:

\[
A_{op}^{nd,\natural}(L4).
\]

It requires:

```text
linearity
branch noncollapse
branch rank preservation
L3 associator noncollapse
L3 rank preservation
normalization
retained provenance / order compatibility
generated-algebra operator-faithfulness
naturality / no obstruction targeting
```

The two critical additions are:

```text
generated-algebra operator-faithfulness
naturality / no obstruction targeting
```

This means a projection cannot be admitted if it is built using \(H_4\) or its residual.

---

### 6.2 V1687.18 — Natural Projection Search

V1687.18 searched predefined natural projections only.

Result:

```text
NO_NATURAL_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
```

Summary:

```json
{
  "projection_count": 31,
  "admissible_natural_count": 2,
  "admissible_natural_erasure_count": 0
}
```

Classification:

```json
{
  "NATURAL_BUT_INADMISSIBLE_H4_PERSISTS": 26,
  "NATURAL_BUT_INADMISSIBLE_H4_ERASURE": 3,
  "NATURAL_ADMISSIBLE_H4_PERSISTS": 2
}
```

Interpretation:

```text
No natural, generated-algebra-faithful, admissible projection erased H4.
```

---

## 7. Corrected ε4-Floor Route

The corrected ε4 route is:

```text
H4 rank-lift certificate
→ finite-sector nonzero-minor certification
→ H4 not reducible to B4 + O3
→ weak-proxy counterprojection found
→ counterprojection audited as post-hoc / inadmissible
→ A_op^nd,natural defined
→ natural generated-algebra-faithful search finds no H4 erasure
→ ε4 route strengthened under natural admissibility
```

The theorem target is:

\[
\varepsilon_{4,\min}
=
\inf_{\Pi\in A_{op}^{nd,\natural}(L4)}
\|\Pi H_4\|
>
0.
\]

This has not been universally proven.

It is the corrected theorem route.

---

## 8. Current Scientific Meaning

L3 showed:

```text
three-way retained recombination can contain information not reducible to pairwise branch structure.
```

L4 now shows:

```text
four-way retained recombination can contain information not reducible even to branches plus all three-way associators.
```

This suggests that geometry-like closure may be the lower-order expression of a deeper retained recombination obstruction hierarchy.

The significant point is not:

```text
information makes geometry.
```

The significant point is:

```text
higher-order retained recombination creates irreducible information layers
that lower-order geometry-like closure cannot absorb.
```

---

## 9. Strongest Corrected Claim

The strongest current claim is:

```text
Inside the tested retained recombination operator family,
finite symbolic support/order sectors exist in which H4 contributes
an independent fourth-order retained direction beyond branches plus all L3 associators.

A weak-proxy non-diagonal H4 erasure exists,
but it is post-hoc, obstruction-targeting, and fails generated-algebra faithfulness.

Under the strengthened natural admissibility class A_op^nd,natural(L4),
no natural admissible H4 erasure was found in the finite-sector search.
```

Short version:

```text
L4 survives corrected admissibility.
```

---

## 10. What Is Not Claimed

We do not claim:

```text
universal L4 theorem
all natural projections exhausted
all operators certified
all sectors certified
empirical L4
physical geometry
GR / ADM
L5 follows automatically
complete infinite obstruction hierarchy
```

The result is:

```text
bounded, corrected, and adversarially improved.
```

---

## 11. Falsification Conditions

The L4 route weakens if any of the following are found:

```text
1. a natural generated-algebra-faithful projection that erases H4;
2. a correct lower-order basis term missing from B4 + O3 that absorbs H4;
3. gate consistency constraints that collapse H4;
4. proof that all H4 certificates are sector artifacts;
5. non-post-hoc operator-natural maps with ΠH4 = 0;
6. failure of compactness or noncollapse in A_op^nd,natural(L4).
```

---

## 12. Recommended Next Step

The L4 branch is now mature enough for a pause/report checkpoint.

Recommended next:

```text
V1687.21 — L4 Publication Paper / Peer Review Draft
```

Then, and only then:

```text
V1688.1 — L5 Discovery Harness
```

The immediate next move should be documentation, not expansion.

---

## 13. Final Status Statement

```text
V1687.20 closes the current L4 branch as a bounded scientific checkpoint.

L4 is not universally proven,
but it is strongly supported in finite symbolic sectors
and survives corrected natural admissibility.

The best interpretation:
L4 is irreducible fourth-order hyper-associator information,
with a strengthened ε4 route under A_op^nd,natural(L4).
```
