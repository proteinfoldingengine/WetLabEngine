# V1687.5 — Targeted L4 Nonzero Minor Certificate

## Verdict

```text
L4_TARGETED_NONZERO_MINOR_CERTIFICATE_CONFIRMED
```

## Rank result

```json
{
  "rank_base_8": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1
}
```

## Nonzero 9×9 minor

```json
{
  "found": true,
  "rows": [
    0,
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8
  ],
  "determinant": "256480337840586992720981/144703125",
  "determinant_float": 1772458872886034.8,
  "checked": 1
}
```

## Interpretation

A nonzero exact rational determinant for a 9×9 evaluated minor proves
the corresponding symbolic minor is not identically zero.

Therefore, in this finite symbolic sector:

```text
H4 ∉ span{J1,J2,J3,J4,O123,O124,O134,O234}
```

## Boundary

Targeted finite-sector certificate only.
Not universal over all operators/sectors.
No empirical L4 claim.
