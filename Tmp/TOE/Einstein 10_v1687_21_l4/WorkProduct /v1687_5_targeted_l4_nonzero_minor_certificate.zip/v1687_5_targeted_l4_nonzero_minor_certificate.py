# ============================================================
# V1687.5 — Targeted L4 Nonzero Minor Certificate
# ============================================================
# Runtime-safe, self-contained.
#
# Purpose:
#   Upgrade V1687.4-fast from "exact rational numeric witness" to
#   "targeted nonzero minor certificate."
#
# Method:
#   1. Rebuild the symbolic finite-sector construction:
#      [J1,J2,J3,J4,O123,O124,O134,O234,H4]
#
#   2. Substitute the successful exact rational witness.
#
#   3. Search 9-row subsets of the evaluated 12×9 matrix for a nonzero
#      exact rational 9×9 determinant.
#
#   4. A single nonzero evaluated determinant proves the corresponding
#      symbolic 9×9 minor is not identically zero.
#
# This avoids full symbolic expansion while still certifying:
#
#      H4 ∉ span{J1,J2,J3,J4,O123,O124,O134,O234}
#
# on a nonempty algebraic-open sector.
#
# Boundary:
#   Targeted finite-sector nonzero-minor certificate.
#   Not universal over all operators/sectors.
# ============================================================

from __future__ import annotations
import itertools
import json
from pathlib import Path
import sympy as sp
import pandas as pd

OUT = Path("/mnt/data/v1687_5_targeted_l4_nonzero_minor_certificate_outputs")
OUT.mkdir(parents=True, exist_ok=True)

def roll_down(v):
    return sp.Matrix([v[-1], *v[:-1]])

def roll_up(v):
    return sp.Matrix([*v[1:], v[0]])

def phi(x, y, gamma):
    rd = roll_down(x)
    ru = roll_up(y)
    return sp.Matrix([gamma * (rd[i] * y[i] - x[i] * ru[i]) for i in range(len(x))])

def recombine(x, y, gamma):
    return x + y + phi(x, y, gamma)

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return recombine(recombine(A, B, gAB), C, gL) - recombine(A, recombine(B, C, gBC), gR)

def bracket4_left(J1,J2,J3,J4, g12,g123,g1234):
    return recombine(recombine(recombine(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right(J1,J2,J3,J4, g34,g234,g1234r):
    return recombine(J1,recombine(J2,recombine(J3,J4,g34),g234),g1234r)

def make_vector(mask, prefix):
    entries, syms = [], []
    for i, active in enumerate(mask):
        if active:
            s = sp.symbols(f"{prefix}_{i}")
            entries.append(s)
            syms.append(s)
        else:
            entries.append(sp.Integer(0))
    return sp.Matrix(entries), syms

def build_sector():
    masks = {
        "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
        "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
        "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
        "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
    }
    vectors, symbols = {}, []
    for name, mask in masks.items():
        v, sy = make_vector(mask, name.lower())
        vectors[name] = v
        symbols.extend(sy)
    return vectors, symbols, masks

def make_columns():
    vectors, symbols, masks = build_sector()
    J1,J2,J3,J4 = vectors["J1"], vectors["J2"], vectors["J3"], vectors["J4"]

    gates = sp.symbols(
        "g12 g23 g13 g14 g24 g34 "
        "g123_L g123_R g124_L g124_R g134_L g134_R g234_L g234_R "
        "g123 g1234 g234 g1234r"
    )
    (
        g12,g23,g13,g14,g24,g34,
        g123_L,g123_R,g124_L,g124_R,g134_L,g134_R,g234_L,g234_R,
        g123,g1234,g234,g1234r
    ) = gates

    O123 = assoc3(J1,J2,J3,g12,g23,g123_L,g123_R)
    O124 = assoc3(J1,J2,J4,g12,g24,g124_L,g124_R)
    O134 = assoc3(J1,J3,J4,g13,g34,g134_L,g134_R)
    O234 = assoc3(J2,J3,J4,g23,g34,g234_L,g234_R)

    H4 = bracket4_left(J1,J2,J3,J4,g12,g123,g1234) - bracket4_right(J1,J2,J3,J4,g34,g234,g1234r)

    cols = [J1,J2,J3,J4,O123,O124,O134,O234,H4]
    names = ["J1","J2","J3","J4","O123","O124","O134","O234","H4"]
    return cols, names, symbols, list(gates), masks

def witness_values(symbols, gates, seed=1):
    vals = {}
    for idx, s in enumerate(symbols):
        val = ((idx * 7 + seed * 11 + 5) % 23) - 11
        if val == 0:
            val = (idx % 7) + 1
        vals[s] = sp.Integer(val)

    for idx, g in enumerate(gates):
        vals[g] = sp.Rational(((idx + seed) % 7) + 2, ((idx + 2*seed) % 5) + 3)

    return vals

def find_nonzero_9x9_minor(M_eval):
    checked = 0
    for rows in itertools.combinations(range(M_eval.rows), 9):
        sub = M_eval[list(rows), :]
        det = sp.factor(sub.det())
        checked += 1
        if det != 0:
            return {
                "found": True,
                "rows": list(rows),
                "determinant": str(det),
                "determinant_float": float(det),
                "checked": checked,
            }
    return {
        "found": False,
        "rows": None,
        "determinant": "0",
        "determinant_float": 0.0,
        "checked": checked,
    }

def run():
    cols, names, symbols, gates, masks = make_columns()
    M_symbolic = sp.Matrix.hstack(*cols)
    B8_symbolic = sp.Matrix.hstack(*cols[:-1])

    vals = witness_values(symbols, gates, seed=1)

    M_eval = M_symbolic.subs(vals)
    B8_eval = B8_symbolic.subs(vals)

    rank_base = int(B8_eval.rank())
    rank_full = int(M_eval.rank())
    rank_lift = rank_full - rank_base

    minor = find_nonzero_9x9_minor(M_eval)

    if rank_base == 8 and rank_full == 9 and minor["found"]:
        verdict = "L4_TARGETED_NONZERO_MINOR_CERTIFICATE_CONFIRMED"
    elif rank_lift > 0:
        verdict = "L4_RANK_WITNESS_CONFIRMED_MINOR_NOT_FOUND"
    else:
        verdict = "L4_TARGETED_CERTIFICATE_FAILED"

    # Store exact evaluated matrix for reviewer audit.
    mat_rows = []
    for r in range(M_eval.rows):
        row = {"row": r}
        for c, name in enumerate(names):
            row[name] = str(M_eval[r,c])
        mat_rows.append(row)
    pd.DataFrame(mat_rows).to_csv(OUT / "v1687_5_evaluated_12x9_matrix.csv", index=False)

    result = {
        "document_id": "V1687_5_TARGETED_L4_NONZERO_MINOR_CERTIFICATE",
        "status": "completed",
        "verdict": verdict,
        "matrix_shape": [int(M_eval.rows), int(M_eval.cols)],
        "columns": names,
        "rank_base_8": rank_base,
        "rank_with_H4": rank_full,
        "rank_lift_H4": rank_lift,
        "nonzero_minor": minor,
        "sector_masks": {k: "".join(map(str,v)) for k,v in masks.items()},
        "witness_seed": 1,
        "interpretation": {
            "certificate": "A nonzero exact rational determinant of a 9x9 evaluated minor proves the corresponding symbolic minor is not identically zero.",
            "meaning": "H4 contributes an independent direction beyond branches + L3 associators for this finite symbolic sector.",
            "claim": "L4 hyper-associator route has a targeted finite-sector nonzero-minor certificate."
        },
        "outputs": {
            "evaluated_matrix_csv": str(OUT / "v1687_5_evaluated_12x9_matrix.csv")
        },
        "claim_boundary": "Targeted finite-sector certificate only; not universal over all operators/sectors."
    }
    (OUT / "v1687_5_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1687.5 — Targeted L4 Nonzero Minor Certificate

## Verdict

```text
{verdict}
```

## Rank result

```json
{json.dumps({
    "rank_base_8": rank_base,
    "rank_with_H4": rank_full,
    "rank_lift_H4": rank_lift
}, indent=2)}
```

## Nonzero 9×9 minor

```json
{json.dumps(minor, indent=2)}
```

## Interpretation

A nonzero exact rational determinant for a 9×9 evaluated minor proves
the corresponding symbolic minor is not identically zero.

Therefore, in this finite symbolic sector:

```text
H4 ∉ span{{J1,J2,J3,J4,O123,O124,O134,O234}}
```

## Boundary

Targeted finite-sector certificate only.
Not universal over all operators/sectors.
No empirical L4 claim.
"""
    (OUT / "V1687_5_TARGETED_L4_NONZERO_MINOR_CERTIFICATE_REPORT.md").write_text(report)

    print(json.dumps(result, indent=2))

run()
