# V1687.13 — A_op^nd Search for Admissible H4 Erasure

## Verdict

```text
NO_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
```

## Full-space baseline

```json
{
  "rank_base_B4_O3": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1,
  "H4_residual_to_B4_O3": 5573.53442773823
}
```

## Classification counts

```json
{
  "INADMISSIBLE_H4_PERSISTS": 472,
  "INADMISSIBLE_H4_ERASURE": 81,
  "ADMISSIBLE_H4_PERSISTS": 2
}
```

## Best admissible projection

```json
{
  "projection": "mask11_1",
  "nonzero_count": 11,
  "branch_norm_min": 15.329709716755891,
  "O3_norm_min": 98.94294679521903,
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1,
  "H4_norm": 65425.72015621381,
  "H4_residual_to_B4_O3": 5307.274920341428,
  "H4_relative_residual": 0.08111909059112389,
  "operator_faithfulness_gap_max": 0.0,
  "operator_faithfulness_gap_mean": 0.0,
  "operator_faithful": true,
  "admissible_Aopnd_proxy": true,
  "H4_erased": false,
  "classification": "ADMISSIBLE_H4_PERSISTS"
}
```

## Best overall projection

```json
{
  "projection": "zero_top_H4_4",
  "nonzero_count": 8,
  "branch_norm_min": 6.557438524302,
  "O3_norm_min": 23.436197038612153,
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 8,
  "rank_lift_H4": 0,
  "H4_norm": 2167.946261369848,
  "H4_residual_to_B4_O3": 1.879515954433e-11,
  "H4_relative_residual": 8.6695689276237e-15,
  "operator_faithfulness_gap_max": 45.0,
  "operator_faithfulness_gap_mean": 16.4,
  "operator_faithful": false,
  "admissible_Aopnd_proxy": false,
  "H4_erased": true,
  "classification": "INADMISSIBLE_H4_ERASURE"
}
```

## Interpretation

If admissible/operator-faithful projections preserve H4,
while erasure only occurs in inadmissible or operator-violating projections,
then the ε4-floor route is strengthened.

## Boundary

Finite-sector diagonal/coordinate projection search only.
Not a proof over all admissible projections.
