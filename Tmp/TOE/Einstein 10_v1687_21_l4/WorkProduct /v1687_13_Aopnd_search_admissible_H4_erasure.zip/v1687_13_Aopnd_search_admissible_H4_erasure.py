# ============================================================
# V1687.13 — A_op^nd Search for Admissible H4 Erasure
# ============================================================
# Runtime-safe, self-contained.
#
# Purpose:
#   Search for projections Π that satisfy the L4 admissibility conditions
#   while minimizing ||ΠH4||.
#
# Target:
#   Find whether H4 can be erased by an admissible/operator-faithful projection.
#
# A_op^nd(L4) proxy conditions tested:
#   C1 linear projection represented by coordinate/diagonal mask
#   C2 operator-faithfulness gap approximately 0
#   C3 branch noncollapse
#   C4 branch rank preservation = 4
#   C5 L3 associator noncollapse
#   C6 rank([ΠB4,ΠO3]) = 8
#   C7 normalization implicit by nonzero finite projection
#   C8 retained coordinate/provenance compatibility approximated by branch distinctness
#
# Projection families:
#   - coordinate masks of size 8..12
#   - random diagonal weighted projections
#   - structured cyclic masks
#
# Verdicts:
#   ADMISSIBLE_H4_ERASURE_FOUND
#   NO_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
#   SEARCH_UNRESOLVED
#
# Boundary:
#   Finite-sector search only, not proof over all A_op^nd.
# ============================================================

from __future__ import annotations

import itertools
import json
from pathlib import Path
from typing import List, Tuple

import numpy as np
import sympy as sp
import pandas as pd

OUT = Path("/mnt/data/v1687_13_Aopnd_search_admissible_H4_erasure_outputs")
OUT.mkdir(parents=True, exist_ok=True)

EPS = 1e-8
N = 12
SEED = 168713


# ============================================================
# EXACT OPERATOR
# ============================================================

def roll_down_np(v):
    return np.r_[v[-1], v[:-1]]

def roll_up_np(v):
    return np.r_[v[1:], v[0]]

def recombine_np(x, y, gamma):
    return x + y + gamma * (roll_down_np(x) * y - x * roll_up_np(y))

def assoc3_np(A, B, C, gAB, gBC, gL, gR):
    return recombine_np(recombine_np(A, B, gAB), C, gL) - recombine_np(A, recombine_np(B, C, gBC), gR)

def bracket4_left_np(J1,J2,J3,J4,g12,g123,g1234):
    return recombine_np(recombine_np(recombine_np(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right_np(J1,J2,J3,J4,g34,g234,g1234r):
    return recombine_np(J1,recombine_np(J2,recombine_np(J3,J4,g34),g234),g1234r)

def rank_np(cols, tol=1e-8):
    if len(cols) == 0:
        return 0
    M = np.stack(cols, axis=1)
    return int(np.linalg.matrix_rank(M, tol=tol))

def norm(v):
    return float(np.linalg.norm(v))

def residual_to_span(v, basis):
    if not basis:
        return norm(v)
    B = np.stack(basis, axis=1)
    coeff = np.linalg.pinv(B) @ v
    res = v - B @ coeff
    return norm(res)


# ============================================================
# BASE CERTIFIED SECTOR
# ============================================================

MASKS = {
    "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
    "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
    "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
    "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
}

def values_for_mask(mask, prefix, seed=1):
    vals = []
    for i, active in enumerate(mask):
        if active:
            raw = ((seed + 3) * (i + 5) + len(prefix) * 7) % 29 - 14
            if raw == 0:
                raw = i % 7 + 1
            vals.append(float(raw))
        else:
            vals.append(0.0)
    return np.array(vals, dtype=float)

def gate_values(seed=1):
    names = ["g12","g23","g13","g14","g24","g34",
             "g123_L","g123_R","g124_L","g124_R","g134_L","g134_R","g234_L","g234_R",
             "g123","g1234","g234","g1234r"]
    return {name: float(sp.Rational(((idx + seed) % 11) + 2, ((2*idx + seed) % 7) + 3))
            for idx, name in enumerate(names)}

def build_base(seed=1):
    J1 = values_for_mask(MASKS["J1"], "j1", seed)
    J2 = values_for_mask(MASKS["J2"], "j2", seed)
    J3 = values_for_mask(MASKS["J3"], "j3", seed)
    J4 = values_for_mask(MASKS["J4"], "j4", seed)
    g = gate_values(seed)

    O123 = assoc3_np(J1,J2,J3,g["g12"],g["g23"],g["g123_L"],g["g123_R"])
    O124 = assoc3_np(J1,J2,J4,g["g12"],g["g24"],g["g124_L"],g["g124_R"])
    O134 = assoc3_np(J1,J3,J4,g["g13"],g["g34"],g["g134_L"],g["g134_R"])
    O234 = assoc3_np(J2,J3,J4,g["g23"],g["g34"],g["g234_L"],g["g234_R"])
    H4 = bracket4_left_np(J1,J2,J3,J4,g["g12"],g["g123"],g["g1234"]) - bracket4_right_np(J1,J2,J3,J4,g["g34"],g["g234"],g["g1234r"])

    return {
        "branches": [J1,J2,J3,J4],
        "O3": [O123,O124,O134,O234],
        "H4": H4,
        "gates": g
    }


# ============================================================
# PROJECTIONS
# ============================================================

def apply_diag(v, d):
    return d * v

def op_faithfulness_gap(d, base):
    J = base["branches"]
    g = base["gates"]
    pairs = {
        (0,1): g["g12"], (1,2): g["g23"], (0,2): g["g13"],
        (0,3): g["g14"], (1,3): g["g24"], (2,3): g["g34"],
    }
    gaps = []
    for (i,j), gate in pairs.items():
        lhs = apply_diag(recombine_np(J[i], J[j], gate), d)
        rhs = apply_diag(recombine_np(apply_diag(J[i], d), apply_diag(J[j], d), gate), d)
        gaps.append(norm(lhs-rhs))
    return max(gaps), float(np.mean(gaps))

def audit_diag_projection(name, d, base):
    B4 = [apply_diag(v,d) for v in base["branches"]]
    O3 = [apply_diag(v,d) for v in base["O3"]]
    H4 = apply_diag(base["H4"], d)

    branch_norm_min = min(norm(v) for v in B4)
    O3_norm_min = min(norm(v) for v in O3)
    branch_rank = rank_np(B4)
    base_rank = rank_np(B4 + O3)
    with_H4_rank = rank_np(B4 + O3 + [H4])
    rank_lift = with_H4_rank - base_rank
    H4_norm = norm(H4)
    H4_res = residual_to_span(H4, B4+O3)
    rel_res = H4_res / max(EPS, H4_norm)

    gap_max, gap_mean = op_faithfulness_gap(d, base)
    op_faithful = gap_max <= 1e-8

    admissible = bool(
        op_faithful and
        branch_norm_min > 1e-8 and
        O3_norm_min > 1e-8 and
        branch_rank == 4 and
        base_rank == 8
    )

    H4_erased = bool(H4_norm <= 1e-8 or H4_res <= 1e-8 or rank_lift <= 0)

    if admissible and H4_erased:
        classification = "ADMISSIBLE_H4_ERASURE"
    elif admissible and not H4_erased:
        classification = "ADMISSIBLE_H4_PERSISTS"
    elif (not admissible) and H4_erased:
        classification = "INADMISSIBLE_H4_ERASURE"
    else:
        classification = "INADMISSIBLE_H4_PERSISTS"

    return {
        "projection": name,
        "nonzero_count": int(np.sum(np.abs(d) > 1e-12)),
        "branch_norm_min": branch_norm_min,
        "O3_norm_min": O3_norm_min,
        "branch_rank": branch_rank,
        "base_rank_B4_O3": base_rank,
        "rank_with_H4": with_H4_rank,
        "rank_lift_H4": rank_lift,
        "H4_norm": H4_norm,
        "H4_residual_to_B4_O3": H4_res,
        "H4_relative_residual": rel_res,
        "operator_faithfulness_gap_max": gap_max,
        "operator_faithfulness_gap_mean": gap_mean,
        "operator_faithful": bool(op_faithful),
        "admissible_Aopnd_proxy": bool(admissible),
        "H4_erased": bool(H4_erased),
        "classification": classification,
    }

def generate_projection_diagonals():
    diags = []

    # Identity.
    diags.append(("identity", np.ones(N)))

    # Coordinate masks, size 8..12, deterministic subset sample.
    for k in [8,9,10,11]:
        count = 0
        for keep in itertools.combinations(range(N), k):
            if count >= 80:
                break
            d = np.zeros(N)
            d[list(keep)] = 1.0
            diags.append((f"mask{k}_{count}", d))
            count += 1

    # Structured cyclic masks.
    for shift in range(N):
        keep = [(shift+i) % N for i in range(9)]
        d = np.zeros(N)
        d[keep] = 1.0
        diags.append((f"cyclic9_{shift}", d))

    # Random diagonal weights.
    rng = np.random.default_rng(SEED)
    for i in range(300):
        d = rng.uniform(0.05, 1.0, size=N)
        # occasionally near-erasing some coordinates
        if i % 3 == 0:
            zero_idx = rng.choice(np.arange(N), size=rng.integers(1,4), replace=False)
            d[zero_idx] = 0.0
        diags.append((f"random_diag_{i}", d))

    # Direct H4-erasure attempt: zero largest H4 coords (will likely break admissibility).
    base = build_base()
    h = np.abs(base["H4"])
    for m in range(1,5):
        d = np.ones(N)
        idx = np.argsort(-h)[:m]
        d[idx] = 0.0
        diags.append((f"zero_top_H4_{m}", d))

    return diags


# ============================================================
# RUN
# ============================================================

def run():
    base = build_base()

    full_base_rank = rank_np(base["branches"] + base["O3"])
    full_rank_H4 = rank_np(base["branches"] + base["O3"] + [base["H4"]])
    full_H4_res = residual_to_span(base["H4"], base["branches"] + base["O3"])

    rows = []
    for name, d in generate_projection_diagonals():
        rows.append(audit_diag_projection(name, d, base))

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "v1687_13_projection_search_rows.csv", index=False)

    counts = df["classification"].value_counts().to_dict()
    admissible = df[df["admissible_Aopnd_proxy"] == True]
    admissible_erasure = df[df["classification"] == "ADMISSIBLE_H4_ERASURE"]
    inadmissible_erasure = df[df["classification"] == "INADMISSIBLE_H4_ERASURE"]

    best_admissible = None
    if len(admissible) > 0:
        best_admissible = admissible.sort_values("H4_residual_to_B4_O3").iloc[0].to_dict()

    best_overall = df.sort_values("H4_residual_to_B4_O3").iloc[0].to_dict()

    if len(admissible_erasure) > 0:
        verdict = "ADMISSIBLE_H4_ERASURE_FOUND"
    elif len(admissible) > 0 and len(admissible_erasure) == 0:
        verdict = "NO_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED"
    else:
        verdict = "SEARCH_UNRESOLVED_NO_ADMISSIBLE_PROJECTIONS_FOUND"

    result = {
        "document_id": "V1687_13_AOPND_SEARCH_ADMISSIBLE_H4_ERASURE",
        "status": "completed",
        "verdict": verdict,
        "full_space": {
            "rank_base_B4_O3": int(full_base_rank),
            "rank_with_H4": int(full_rank_H4),
            "rank_lift_H4": int(full_rank_H4 - full_base_rank),
            "H4_residual_to_B4_O3": float(full_H4_res),
        },
        "projection_count": int(len(df)),
        "classification_counts": counts,
        "admissible_count": int(len(admissible)),
        "admissible_erasure_count": int(len(admissible_erasure)),
        "inadmissible_erasure_count": int(len(inadmissible_erasure)),
        "best_admissible_min_H4_residual": best_admissible,
        "best_overall_min_H4_residual": best_overall,
        "outputs": {
            "projection_search_rows": str(OUT / "v1687_13_projection_search_rows.csv"),
        },
        "interpretation": {
            "meaning": "No admissible H4-erasing projection found means epsilon4 route is strengthened within the searched projection family.",
            "boundary": "Diagonal/coordinate finite-sector search only; not all possible linear maps."
        },
        "claim_boundary": "Finite-sector A_op^nd proxy search only; not a proof over all admissible projections."
    }

    (OUT / "v1687_13_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1687.13 — A_op^nd Search for Admissible H4 Erasure

## Verdict

```text
{verdict}
```

## Full-space baseline

```json
{json.dumps(result["full_space"], indent=2)}
```

## Classification counts

```json
{json.dumps(counts, indent=2)}
```

## Best admissible projection

```json
{json.dumps(best_admissible, indent=2)}
```

## Best overall projection

```json
{json.dumps(best_overall, indent=2)}
```

## Interpretation

If admissible/operator-faithful projections preserve H4,
while erasure only occurs in inadmissible or operator-violating projections,
then the ε4-floor route is strengthened.

## Boundary

Finite-sector diagonal/coordinate projection search only.
Not a proof over all admissible projections.
"""
    (OUT / "V1687_13_AOPND_SEARCH_ADMISSIBLE_H4_ERASURE_REPORT.md").write_text(report)

    print(json.dumps(result, indent=2))

run()
