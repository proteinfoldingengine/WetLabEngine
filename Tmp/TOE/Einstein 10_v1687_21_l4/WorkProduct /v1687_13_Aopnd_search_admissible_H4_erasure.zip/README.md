# V1687.13 A_op^nd Search for Admissible H4 Erasure

Purpose:

```text
Search projection families for admissible/operator-faithful H4 erasure.
```

Boundary:

```text
Finite-sector diagonal/coordinate projection search only.
```
