# V1687.16 Audit H4-Erasing Projection

Purpose:

```text
Audit whether the V1687.15 H4-erasing non-diagonal projection is genuinely admissible.
```

Boundary:

```text
Finite-sector audit of one projection only.
```
