# ============================================================
# V1687.16 — Audit the H4-Erasing Projection
# ============================================================
# Runtime-safe, self-contained.
#
# Purpose:
#   Audit the V1687.15 non-diagonal projection that erased H4 while
#   passing the finite A_op^nd proxy checks.
#
# Main question:
#   Is the H4-erasing projection genuinely admissible,
#   or did it pass because A_op^nd was too weak?
#
# Suspected issue:
#   The projection is constructed from the H4 residual itself:
#       P = I - uu^T, where u = residual(H4 | span(B4+O3))/||...||
#
# This is post-hoc obstruction-targeting. It may be operator-faithful on
# the tested branch pairs but not natural / functorial / globally faithful
# over the generated recombination algebra.
#
# Tests:
#   1. Reproduce H4 erasure.
#   2. Pairwise operator-faithfulness on branch pairs.
#   3. Nested bracketing faithfulness for all five 4-branch bracketings.
#   4. Algebra-generated faithfulness over random composites.
#   5. Construction-dependence audit: does P explicitly depend on H4?
#   6. Naturalness classification.
#
# Verdicts:
#   H4_ERASURE_PROJECTION_INADMISSIBLE_POSTHOC
#   H4_ERASURE_PROJECTION_TRUE_ADMISSIBLE_COUNTEREXAMPLE
#   H4_ERASURE_PROJECTION_UNRESOLVED
#
# Boundary:
#   Finite-sector audit only.
# ============================================================

from __future__ import annotations

import json
from pathlib import Path
from typing import List, Tuple

import numpy as np
import sympy as sp
import pandas as pd

OUT = Path("/mnt/data/v1687_16_audit_H4_erasing_projection_outputs")
OUT.mkdir(parents=True, exist_ok=True)

N = 12
EPS = 1e-8
SEED = 168716


# ============================================================
# Operator / helpers
# ============================================================

def roll_down(v):
    return np.r_[v[-1], v[:-1]]

def roll_up(v):
    return np.r_[v[1:], v[0]]

def recombine(x, y, gamma):
    return x + y + gamma * (roll_down(x) * y - x * roll_up(y))

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return recombine(recombine(A, B, gAB), C, gL) - recombine(A, recombine(B, C, gBC), gR)

def bracket4_all(J, g):
    J1,J2,J3,J4 = J
    return {
        "B1_(((12)3)4)": recombine(recombine(recombine(J1,J2,g["g12"]),J3,g["g123"]),J4,g["g1234"]),
        "B2_((1(23))4)": recombine(recombine(J1,recombine(J2,J3,g["g23"]),g["g123_R"]),J4,g["g1234"]),
        "B3_(1((23)4))": recombine(J1,recombine(recombine(J2,J3,g["g23"]),J4,g["g234"]),g["g1234r"]),
        "B4_(1(2(34)))": recombine(J1,recombine(J2,recombine(J3,J4,g["g34"]),g["g234"]),g["g1234r"]),
        "B5_((12)(34))": recombine(recombine(J1,J2,g["g12"]),recombine(J3,J4,g["g34"]),g["g1234"]),
    }

def rank(cols, tol=1e-8):
    if not cols:
        return 0
    return int(np.linalg.matrix_rank(np.stack(cols, axis=1), tol=tol))

def norm(v):
    return float(np.linalg.norm(v))

def residual_to_span(v, basis):
    if not basis:
        return v.copy(), norm(v)
    B = np.stack(basis, axis=1)
    coeff = np.linalg.pinv(B) @ v
    res = v - B @ coeff
    return res, norm(res)

def apply(P, v):
    return P @ v


# ============================================================
# Base certified sector
# ============================================================

MASKS = {
    "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
    "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
    "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
    "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
}

def values_for_mask(mask, prefix, seed=1):
    vals = []
    for i, active in enumerate(mask):
        if active:
            raw = ((seed + 3) * (i + 5) + len(prefix) * 7) % 29 - 14
            if raw == 0:
                raw = i % 7 + 1
            vals.append(float(raw))
        else:
            vals.append(0.0)
    return np.array(vals, dtype=float)

def gate_values(seed=1):
    names = ["g12","g23","g13","g14","g24","g34",
             "g123_L","g123_R","g124_L","g124_R","g134_L","g134_R","g234_L","g234_R",
             "g123","g1234","g234","g1234r"]
    return {name: float(sp.Rational(((idx + seed) % 11) + 2, ((2*idx + seed) % 7) + 3))
            for idx, name in enumerate(names)}

def build_base(seed=1):
    J1 = values_for_mask(MASKS["J1"], "j1", seed)
    J2 = values_for_mask(MASKS["J2"], "j2", seed)
    J3 = values_for_mask(MASKS["J3"], "j3", seed)
    J4 = values_for_mask(MASKS["J4"], "j4", seed)
    g = gate_values(seed)
    J = [J1,J2,J3,J4]

    O123 = assoc3(J1,J2,J3,g["g12"],g["g23"],g["g123_L"],g["g123_R"])
    O124 = assoc3(J1,J2,J4,g["g12"],g["g24"],g["g124_L"],g["g124_R"])
    O134 = assoc3(J1,J3,J4,g["g13"],g["g34"],g["g134_L"],g["g134_R"])
    O234 = assoc3(J2,J3,J4,g["g23"],g["g34"],g["g234_L"],g["g234_R"])
    O3 = [O123,O124,O134,O234]

    br = bracket4_all(J,g)
    H4 = br["B1_(((12)3)4)"] - br["B4_(1(2(34)))"]

    return {"branches":J, "O3":O3, "H4":H4, "gates":g, "bracketings":br}

def H4_residual_projection(base):
    # Projection away from the H4 residual to B4+O3 span, the eraser found in V1687.15.
    res, resn = residual_to_span(base["H4"], base["branches"] + base["O3"])
    u = res / max(EPS, resn)
    P = np.eye(N) - np.outer(u,u)
    return P, u, resn


# ============================================================
# Faithfulness audits
# ============================================================

def pair_faithfulness(P, base):
    J = base["branches"]
    g = base["gates"]
    pairs = {
        (0,1): g["g12"], (1,2): g["g23"], (0,2): g["g13"],
        (0,3): g["g14"], (1,3): g["g24"], (2,3): g["g34"],
    }
    rows = []
    for (i,j), gate in pairs.items():
        lhs = apply(P, recombine(J[i], J[j], gate))
        rhs = apply(P, recombine(apply(P, J[i]), apply(P, J[j]), gate))
        rows.append({
            "test": f"pair_J{i+1}J{j+1}",
            "gap": norm(lhs-rhs)
        })
    return rows

def nested_bracketing_faithfulness(P, base):
    # Test P(Bk(original)) vs Bk(PJ)
    J = base["branches"]
    g = base["gates"]
    original = base["bracketings"]

    PJ = [apply(P,v) for v in J]
    projected_brackets = bracket4_all(PJ,g)

    rows = []
    for name, vec in original.items():
        lhs = apply(P, vec)
        rhs = apply(P, projected_brackets[name])
        # note: rhs has final P applied to match codomain representation
        rows.append({
            "test": f"nested_{name}",
            "gap": norm(lhs-rhs)
        })
    return rows

def random_composite_faithfulness(P, base, trials=100):
    # Generate composites from branch linear combos and random gates.
    rng = np.random.default_rng(SEED)
    J = base["branches"]
    gates = list(base["gates"].values())
    rows = []
    max_gap = 0.0
    mean_gaps = []
    for t in range(trials):
        a = sum(rng.normal() * J[i] for i in range(4))
        b = sum(rng.normal() * J[i] for i in range(4))
        gate = float(gates[int(rng.integers(0, len(gates)))])
        lhs = apply(P, recombine(a,b,gate))
        rhs = apply(P, recombine(apply(P,a), apply(P,b), gate))
        gap = norm(lhs-rhs)
        max_gap = max(max_gap, gap)
        mean_gaps.append(gap)
    return {
        "random_composite_trials": trials,
        "random_composite_gap_max": float(max_gap),
        "random_composite_gap_mean": float(np.mean(mean_gaps)),
        "random_composite_gap_median": float(np.median(mean_gaps)),
    }

def algebra_generator_audit(P, base):
    # Generate a small algebra closure set: branches, pairs, triples, bracketings.
    J = base["branches"]
    g = base["gates"]
    vecs = []
    labels = []
    for i,v in enumerate(J):
        labels.append(f"J{i+1}")
        vecs.append(v)
    pair_gates = {(0,1):g["g12"],(1,2):g["g23"],(0,2):g["g13"],(0,3):g["g14"],(1,3):g["g24"],(2,3):g["g34"]}
    for (i,j), gate in pair_gates.items():
        labels.append(f"R_J{i+1}J{j+1}")
        vecs.append(recombine(J[i],J[j],gate))
    for name,v in base["bracketings"].items():
        labels.append(name)
        vecs.append(v)

    # Test all pairs from generated set with a representative gate.
    # If P is truly natural, it should behave beyond branch pairs.
    rows = []
    gates = list(base["gates"].values())
    for idx_a in range(len(vecs)):
        for idx_b in range(idx_a+1, len(vecs)):
            gate = gates[(idx_a + 3*idx_b) % len(gates)]
            lhs = apply(P, recombine(vecs[idx_a], vecs[idx_b], gate))
            rhs = apply(P, recombine(apply(P,vecs[idx_a]), apply(P,vecs[idx_b]), gate))
            rows.append(norm(lhs-rhs))
    return {
        "generated_pair_tests": len(rows),
        "generated_gap_max": float(np.max(rows)) if rows else 0.0,
        "generated_gap_mean": float(np.mean(rows)) if rows else 0.0,
        "generated_gap_median": float(np.median(rows)) if rows else 0.0,
    }


# ============================================================
# Main audit
# ============================================================

def run():
    base = build_base()
    P,u,resn = H4_residual_projection(base)

    PB4 = [apply(P,v) for v in base["branches"]]
    PO3 = [apply(P,v) for v in base["O3"]]
    PH4 = apply(P,base["H4"])
    h4_res_after, h4_res_after_norm = residual_to_span(PH4, PB4+PO3)

    pair_rows = pair_faithfulness(P,base)
    nested_rows = nested_bracketing_faithfulness(P,base)
    random_audit = random_composite_faithfulness(P,base,trials=200)
    algebra_audit = algebra_generator_audit(P,base)

    all_pair_max = max(r["gap"] for r in pair_rows)
    all_nested_max = max(r["gap"] for r in nested_rows)

    # Post-hoc dependence:
    # P was explicitly constructed from residual(H4 | span(B4+O3)).
    construction_depends_on_H4 = True
    construction_natural = False

    passes_branch_proxy = (
        rank(PB4) == 4 and
        rank(PB4+PO3) == 8 and
        min(norm(v) for v in PB4) > EPS and
        min(norm(v) for v in PO3) > EPS
    )
    erases_H4 = (rank(PB4+PO3+[PH4]) == rank(PB4+PO3)) or h4_res_after_norm <= 1e-7

    pair_faithful = all_pair_max <= 1e-7
    nested_faithful = all_nested_max <= 1e-7
    generated_faithful = algebra_audit["generated_gap_max"] <= 1e-7 and random_audit["random_composite_gap_max"] <= 1e-7

    # Stricter admissibility:
    # must be natural / not obstruction-targeting AND faithful on generated algebra.
    strict_admissible = bool(
        passes_branch_proxy and
        pair_faithful and
        nested_faithful and
        generated_faithful and
        construction_natural
    )

    if erases_H4 and not strict_admissible and construction_depends_on_H4:
        verdict = "H4_ERASURE_PROJECTION_INADMISSIBLE_POSTHOC"
    elif erases_H4 and strict_admissible:
        verdict = "H4_ERASURE_PROJECTION_TRUE_ADMISSIBLE_COUNTEREXAMPLE"
    else:
        verdict = "H4_ERASURE_PROJECTION_UNRESOLVED"

    pd.DataFrame(pair_rows).to_csv(OUT / "v1687_16_pair_faithfulness_rows.csv", index=False)
    pd.DataFrame(nested_rows).to_csv(OUT / "v1687_16_nested_faithfulness_rows.csv", index=False)

    result = {
        "document_id": "V1687_16_AUDIT_H4_ERASING_PROJECTION",
        "status": "completed",
        "verdict": verdict,
        "projection": "P = I - uu^T, u = residual(H4 | span(B4+O3))/||residual||",
        "baseline": {
            "rank_B4_O3": rank(base["branches"]+base["O3"]),
            "rank_B4_O3_H4": rank(base["branches"]+base["O3"]+[base["H4"]]),
            "H4_residual_to_B4_O3_before": resn,
        },
        "after_projection": {
            "rank_PB4_PO3": rank(PB4+PO3),
            "rank_PB4_PO3_PH4": rank(PB4+PO3+[PH4]),
            "H4_residual_to_projected_B4_O3": h4_res_after_norm,
            "erases_H4": bool(erases_H4),
        },
        "proxy_conditions": {
            "passes_branch_proxy": bool(passes_branch_proxy),
            "pair_faithful": bool(pair_faithful),
            "nested_faithful": bool(nested_faithful),
            "generated_faithful": bool(generated_faithful),
            "construction_depends_on_H4": bool(construction_depends_on_H4),
            "construction_natural": bool(construction_natural),
            "strict_admissible": bool(strict_admissible),
        },
        "faithfulness_gaps": {
            "pair_gap_max": float(all_pair_max),
            "nested_gap_max": float(all_nested_max),
            **random_audit,
            **algebra_audit,
        },
        "interpretation": {
            "core_issue": "The projection erases H4 because it is constructed from H4 residual itself.",
            "admissibility_update_needed": "A_op^nd(L4) must exclude obstruction-targeting/post-hoc projections and require naturality or generated-algebra operator-faithfulness.",
            "epsilon4_status": "V1687.15 weakens the permissive A_op^nd proxy, but V1687.16 shows the counterprojection is not admissible under stricter naturality/generator-faithfulness conditions."
        },
        "outputs": {
            "pair_faithfulness_rows": str(OUT / "v1687_16_pair_faithfulness_rows.csv"),
            "nested_faithfulness_rows": str(OUT / "v1687_16_nested_faithfulness_rows.csv"),
        },
        "claim_boundary": "Finite-sector audit of one H4-erasing projection; not universal proof."
    }

    (OUT / "v1687_16_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1687.16 — Audit the H4-Erasing Projection

## Verdict

```text
{verdict}
```

## Projection

```text
P = I - uuᵀ
u = residual(H4 | span(B4+O3)) / ||residual||
```

## Baseline

```json
{json.dumps(result["baseline"], indent=2)}
```

## After projection

```json
{json.dumps(result["after_projection"], indent=2)}
```

## Proxy / strict admissibility conditions

```json
{json.dumps(result["proxy_conditions"], indent=2)}
```

## Faithfulness gaps

```json
{json.dumps(result["faithfulness_gaps"], indent=2)}
```

## Interpretation

The projection erases H4 by construction because it is built from the H4 residual.
That is not a natural admissible projection.

A_op^nd(L4) must be revised to exclude post-hoc obstruction-targeting maps
and require naturality or operator-faithfulness on the generated recombination algebra.

## Boundary

Finite-sector audit of one H4-erasing projection.
Not a universal proof.
"""
    (OUT / "V1687_16_AUDIT_H4_ERASING_PROJECTION_REPORT.md").write_text(report)

    print(json.dumps(result, indent=2))

run()
