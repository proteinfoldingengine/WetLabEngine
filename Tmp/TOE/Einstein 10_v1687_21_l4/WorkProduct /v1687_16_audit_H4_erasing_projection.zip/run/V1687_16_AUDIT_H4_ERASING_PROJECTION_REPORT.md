# V1687.16 — Audit the H4-Erasing Projection

## Verdict

```text
H4_ERASURE_PROJECTION_INADMISSIBLE_POSTHOC
```

## Projection

```text
P = I - uuᵀ
u = residual(H4 | span(B4+O3)) / ||residual||
```

## Baseline

```json
{
  "rank_B4_O3": 8,
  "rank_B4_O3_H4": 9,
  "H4_residual_to_B4_O3_before": 5573.53442773823
}
```

## After projection

```json
{
  "rank_PB4_PO3": 8,
  "rank_PB4_PO3_PH4": 8,
  "H4_residual_to_projected_B4_O3": 1.1325160321776731e-09,
  "erases_H4": true
}
```

## Proxy / strict admissibility conditions

```json
{
  "passes_branch_proxy": true,
  "pair_faithful": true,
  "nested_faithful": true,
  "generated_faithful": false,
  "construction_depends_on_H4": true,
  "construction_natural": false,
  "strict_admissible": false
}
```

## Faithfulness gaps

```json
{
  "pair_gap_max": 6.294739023455842e-12,
  "nested_gap_max": 1.7903921828113324e-09,
  "random_composite_trials": 200,
  "random_composite_gap_max": 5.448204569975321e-11,
  "random_composite_gap_mean": 1.071751941945986e-11,
  "random_composite_gap_median": 7.686028535830598e-12,
  "generated_pair_tests": 105,
  "generated_gap_max": 335274816.82744825,
  "generated_gap_mean": 8332377.074726313,
  "generated_gap_median": 14834.559227047996
}
```

## Interpretation

The projection erases H4 by construction because it is built from the H4 residual.
That is not a natural admissible projection.

A_op^nd(L4) must be revised to exclude post-hoc obstruction-targeting maps
and require naturality or operator-faithfulness on the generated recombination algebra.

## Boundary

Finite-sector audit of one H4-erasing projection.
Not a universal proof.
