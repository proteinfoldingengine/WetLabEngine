
from __future__ import annotations
import itertools, json
from pathlib import Path
import sympy as sp
import pandas as pd
import numpy as np

OUT = Path("/mnt/data/v1687_6_l4_family_nonzero_minor_sweep_outputs")
OUT.mkdir(parents=True, exist_ok=True)

SEED = 16876
N = 12
SECTOR_COUNT = 8

def roll_down(v): return sp.Matrix([v[-1], *v[:-1]])
def roll_up(v): return sp.Matrix([*v[1:], v[0]])

def phi(x, y, gamma):
    rd, ru = roll_down(x), roll_up(y)
    return sp.Matrix([gamma * (rd[i] * y[i] - x[i] * ru[i]) for i in range(len(x))])

def recombine(x, y, gamma): return x + y + phi(x, y, gamma)

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return recombine(recombine(A, B, gAB), C, gL) - recombine(A, recombine(B, C, gBC), gR)

def bracket4_left(J1,J2,J3,J4, g12,g123,g1234):
    return recombine(recombine(recombine(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right(J1,J2,J3,J4, g34,g234,g1234r):
    return recombine(J1,recombine(J2,recombine(J3,J4,g34),g234),g1234r)

BASE_MASKS = [
    [1,1,1,0,1,0,0,1,0,0,0,1],
    [1,0,1,1,0,1,0,0,1,0,1,0],
    [0,1,1,1,0,0,1,0,0,1,1,0],
    [1,0,0,1,1,0,1,1,0,1,0,0],
]

def rotate_mask(mask, shift):
    shift %= len(mask)
    return mask[-shift:] + mask[:-shift] if shift else list(mask)

def sector_masks(sector_id):
    rng = np.random.default_rng(SEED + 101 * sector_id)
    masks = []
    for i, base in enumerate(BASE_MASKS):
        m = rotate_mask(base, (sector_id + 2*i) % N)
        for _ in range(2):
            j = int(rng.integers(0, N))
            c = list(m)
            c[j] = 1 - c[j]
            if 5 <= sum(c) <= 8:
                m = c
        masks.append(m)
    return {f"J{i+1}": masks[i] for i in range(4)}

def values_for_mask(mask, prefix, sector_id):
    vals = []
    for i, active in enumerate(mask):
        if active:
            raw = ((sector_id + 3) * (i + 5) + len(prefix) * 7) % 29 - 14
            if raw == 0: raw = i % 7 + 1
            vals.append(sp.Integer(raw))
        else:
            vals.append(sp.Integer(0))
    return sp.Matrix(vals)

def gate_values(sector_id):
    names = ["g12","g23","g13","g14","g24","g34",
             "g123_L","g123_R","g124_L","g124_R","g134_L","g134_R","g234_L","g234_R",
             "g123","g1234","g234","g1234r"]
    return {name: sp.Rational(((idx + sector_id) % 11) + 2, ((2*idx + sector_id) % 7) + 3)
            for idx, name in enumerate(names)}

def build_columns_for_sector(sector_id):
    masks = sector_masks(sector_id)
    J1 = values_for_mask(masks["J1"], "j1", sector_id)
    J2 = values_for_mask(masks["J2"], "j2", sector_id)
    J3 = values_for_mask(masks["J3"], "j3", sector_id)
    J4 = values_for_mask(masks["J4"], "j4", sector_id)
    g = gate_values(sector_id)

    O123 = assoc3(J1,J2,J3,g["g12"],g["g23"],g["g123_L"],g["g123_R"])
    O124 = assoc3(J1,J2,J4,g["g12"],g["g24"],g["g124_L"],g["g124_R"])
    O134 = assoc3(J1,J3,J4,g["g13"],g["g34"],g["g134_L"],g["g134_R"])
    O234 = assoc3(J2,J3,J4,g["g23"],g["g34"],g["g234_L"],g["g234_R"])
    H4 = bracket4_left(J1,J2,J3,J4,g["g12"],g["g123"],g["g1234"]) - bracket4_right(J1,J2,J3,J4,g["g34"],g["g234"],g["g1234r"])
    return [J1,J2,J3,J4,O123,O124,O134,O234,H4], masks

def find_nonzero_9x9_minor(M):
    checked = 0
    for rows in itertools.combinations(range(M.rows), 9):
        det = M[list(rows), :].det()
        checked += 1
        if det != 0:
            return {"found": True, "rows": list(rows), "determinant": str(det), "checked": checked}
    return {"found": False, "rows": None, "determinant": "0", "checked": checked}

def certify_sector(sector_id):
    cols, masks = build_columns_for_sector(sector_id)
    B8, M9 = sp.Matrix.hstack(*cols[:-1]), sp.Matrix.hstack(*cols)
    rank_base, rank_full = int(B8.rank()), int(M9.rank())
    minor = find_nonzero_9x9_minor(M9)
    certified = bool(rank_base >= 8 and rank_full >= 9 and (rank_full-rank_base) > 0 and minor["found"])
    return {
        "sector_id": sector_id,
        "classification": "CERTIFIED_L4_NONZERO_MINOR" if certified else "FAILED_OR_DEGENERATE",
        "certified": certified,
        "rank_base_8": rank_base,
        "rank_with_H4": rank_full,
        "rank_lift_H4": rank_full-rank_base,
        "minor_found": bool(minor["found"]),
        "minor_rows": str(minor["rows"]),
        "minor_checked": int(minor["checked"]),
        "minor_determinant": minor["determinant"],
        "masks": {k: "".join(map(str,v)) for k,v in masks.items()},
    }

def run():
    rows = [certify_sector(sid) for sid in range(SECTOR_COUNT)]
    df = pd.DataFrame(rows)
    df.to_csv(OUT / "v1687_6_l4_family_nonzero_minor_rows.csv", index=False)
    certified_count = int(df["certified"].sum())
    verdict = "L4_FAMILY_NONZERO_MINOR_SWEEP_ALL_CERTIFIED" if certified_count == SECTOR_COUNT else ("L4_FAMILY_NONZERO_MINOR_SWEEP_PARTIAL" if certified_count > 0 else "L4_FAMILY_NONZERO_MINOR_SWEEP_FAILED")
    result = {
        "document_id": "V1687_6_L4_FAMILY_NONZERO_MINOR_SWEEP",
        "status": "completed",
        "verdict": verdict,
        "sector_count": SECTOR_COUNT,
        "certified_count": certified_count,
        "certified_rate": certified_count / SECTOR_COUNT,
        "classification_counts": df["classification"].value_counts().to_dict(),
        "rank_lift_min": int(df["rank_lift_H4"].min()),
        "rank_lift_mean": float(df["rank_lift_H4"].mean()),
        "rank_lift_max": int(df["rank_lift_H4"].max()),
        "outputs": {"sector_rows_csv": str(OUT / "v1687_6_l4_family_nonzero_minor_rows.csv")},
        "claim_boundary": "Finite symbolic-sector family sweep only; not universal over all sectors/operators."
    }
    (OUT / "v1687_6_result.json").write_text(json.dumps(result, indent=2))
    report = f"""# V1687.6 — L4 Family Nonzero-Minor Sweep

## Verdict

```text
{verdict}
```

## Summary

```json
{json.dumps(result, indent=2)}
```

## Interpretation

Each certified sector has H4 rank-lift beyond branches + all L3 associators,
plus a nonzero exact rational 9×9 minor.

## Boundary

Finite symbolic-sector family sweep only.
Not universal over all sectors/operators.
"""
    (OUT / "V1687_6_L4_FAMILY_NONZERO_MINOR_SWEEP_REPORT.md").write_text(report)
    print(json.dumps(result, indent=2))

run()
