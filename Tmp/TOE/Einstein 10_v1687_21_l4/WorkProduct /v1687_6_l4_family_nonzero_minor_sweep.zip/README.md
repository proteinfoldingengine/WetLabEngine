# V1687.6 L4 Family Nonzero-Minor Sweep

Finite symbolic-sector family sweep.
