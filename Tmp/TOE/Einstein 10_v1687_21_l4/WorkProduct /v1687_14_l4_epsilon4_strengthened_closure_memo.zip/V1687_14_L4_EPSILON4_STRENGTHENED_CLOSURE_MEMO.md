# V1687.14 — L4 ε4-Floor Strengthened Closure Memo

**Project:** Retained Bridge / Recoverability Geometry  
**Branch:** L4 hyper-associator / ε4-floor route  
**Status:** strengthened bounded closure after admissible-erasure search  
**Claim level:** finite-sector A_op^nd proxy search; not universal theorem

---

## 1. Executive Verdict

```text
L4_EPSILON4_ROUTE_STRENGTHENED_NO_ADMISSIBLE_ERASURE_FOUND
```

V1687.13 searched for projections that could erase the L4 hyper-associator residual \(H_4\) while satisfying a finite-sector proxy of:

\[
A_{op}^{nd}(L4)
\]

The result:

```text
No admissible/operator-faithful projection erased H4.
```

Across:

```text
555 projection candidates
```

the search found:

```json
{
  "admissible_count": 2,
  "admissible_erasure_count": 0,
  "inadmissible_erasure_count": 81
}
```

Thus, within the searched projection family:

```text
H4 erasure was only achieved by inadmissible/operator-violating projections.
```

This strengthens the L4 ε4-floor route.

---

## 2. The L4 Object

The canonical L4 residual is:

\[
H_4
=
(((J_1\oplus J_2)\oplus J_3)\oplus J_4)
-
(J_1\oplus(J_2\oplus(J_3\oplus J_4))).
\]

The tested lower-order span is:

\[
\operatorname{span}\{J_1,J_2,J_3,J_4,O_{123},O_{124},O_{134},O_{234}\}.
\]

The L4 irreducibility condition is:

\[
H_4\notin \operatorname{span}(B_4\cup O_3).
\]

---

## 3. Full-Space Baseline

V1687.13 preserved the prior certified L4 baseline:

```json
{
  "rank_base_B4_O3": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1,
  "H4_residual_to_B4_O3": 5573.53442773823
}
```

Interpretation:

```text
H4 contributes an independent retained direction beyond branches plus all L3 associators.
```

---

## 4. Projection Search

V1687.13 tested diagonal / coordinate projection families:

```text
identity projection
coordinate masks
structured cyclic masks
random diagonal projections
direct H4-erasure attempts
```

Each projection was audited for:

```text
branch noncollapse
branch rank preservation
L3 associator noncollapse
rank(B4 + O3) preservation
operator-faithfulness gap
H4 residual to projected B4 + O3 span
H4 rank-lift
```

---

## 5. Search Result

Classification counts:

```json
{
  "INADMISSIBLE_H4_PERSISTS": 472,
  "INADMISSIBLE_H4_ERASURE": 81,
  "ADMISSIBLE_H4_PERSISTS": 2
}
```

There were:

```text
0 admissible H4-erasing projections.
```

So:

```text
admissible_erasure_count = 0
```

---

## 6. Best Admissible Projection

The best admissible projection still preserved H4:

```json
{
  "projection": "mask11_1",
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1,
  "operator_faithfulness_gap_max": 0.0,
  "admissible_Aopnd_proxy": true,
  "H4_erased": false,
  "classification": "ADMISSIBLE_H4_PERSISTS"
}
```

Interpretation:

```text
A valid operator-faithful projection preserved the L4 independent direction.
```

---

## 7. Best H4-Erasing Projection

The strongest erasure attempt was:

```json
{
  "projection": "zero_top_H4_4",
  "rank_lift_H4": 0,
  "operator_faithfulness_gap_max": 45.0,
  "operator_faithful": false,
  "admissible_Aopnd_proxy": false,
  "classification": "INADMISSIBLE_H4_ERASURE"
}
```

Interpretation:

```text
H4 can be erased by projection, but only by breaking operator-faithfulness.
```

That is exactly the behavior predicted by the ε4-floor route.

---

## 8. ε4-Floor Route Strengthened

The current route is now:

```text
H4 rank-lift certified
→ H4 not reducible to B4 + O3
→ A_op^nd(L4) defined
→ projection-faithfulness audit passed
→ admissible-erasure search found no ΠH4 = 0
→ ε4_floor route strengthened
```

The key statement is:

```text
Within the tested finite-sector projection family,
H4 cannot be erased without violating admissibility.
```

---

## 9. Updated L4 Closure Status

```text
L4 discovery: PASS
L4 random-sector robustness: PASS
L4 operator controls: PASS
L4 targeted nonzero-minor certificate: PASS
L4 finite-sector family sweep: PASS
L4 projection-faithfulness audit: PASS
L4 A_op^nd definition: PASS
L4 admissible-erasure search: PASS
L4 ε4-floor route: STRENGTHENED
L4 universal theorem: OPEN
L4 empirical closure: OPEN
```

Best status label:

```text
L4 is bounded-closed with strengthened finite-sector ε4-floor support.
```

---

## 10. What Is Still Open

The remaining open items are:

```text
1. prove compactness of A_op^nd(L4);
2. search broader non-diagonal linear projections;
3. prove no admissible Π exists with ΠH4 = 0;
4. identify symbolic sufficient conditions for H4 noncollapse;
5. test operator families beyond the current retained recombination class;
6. define whether the hierarchy continues to L5.
```

---

## 11. Recommended Next Step

The next rigorous step is:

```text
V1687.15 — Non-Diagonal Projection Search
```

Goal:

```text
Search broader linear projections,
not just coordinate/diagonal masks,
for admissible H4 erasure.
```

Possible outcomes:

```text
If no non-diagonal admissible erasure is found:
    ε4 route strengthens further.

If a non-diagonal admissible erasure is found:
    ε4 theorem route must be revised.

If all erasures violate operator-faithfulness:
    operator-faithfulness boundary becomes stronger.
```

---

## 12. Final Status Statement

```text
V1687.14 freezes the strengthened L4 ε4-floor status.

H4 can be erased by inadmissible projections,
but no admissible/operator-faithful erasure was found.

Therefore, inside the tested finite-sector A_op^nd proxy search,
L4 behaves like a genuine fourth-order irreducible retained-information layer.
```
