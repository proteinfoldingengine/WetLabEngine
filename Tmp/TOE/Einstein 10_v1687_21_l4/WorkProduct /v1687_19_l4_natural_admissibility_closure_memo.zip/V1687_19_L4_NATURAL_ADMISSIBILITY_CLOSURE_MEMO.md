# V1687.19 — L4 Natural-Admissibility Closure Memo

**Project:** Retained Bridge / Recoverability Geometry  
**Branch:** L4 hyper-associator / ε4-floor route  
**Status:** corrected bounded closure after natural projection search  
**Claim level:** finite-sector natural-admissibility support; not universal theorem

---

## 1. Executive Verdict

```text
L4_NATURAL_ADMISSIBILITY_EPSILON4_ROUTE_STRENGTHENED
```

V1687.18 searched predefined natural projections under the strengthened admissibility class:

\[
A_{op}^{nd,\natural}(L4)
\]

The result was:

```text
NO_NATURAL_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
```

This means:

```text
No natural, generated-algebra-faithful, admissible projection erased H4.
```

The prior V1687.15 counterprojection was not ignored. It was absorbed correctly:

```text
V1687.15 found a weak-proxy H4 erasure.
V1687.16 showed that erasure was post-hoc and not generated-algebra faithful.
V1687.17 strengthened A_op^nd into A_op^nd,natural.
V1687.18 found no natural admissible H4 erasure under the strengthened class.
```

---

## 2. Current Corrected L4 Status

The current L4 status is:

```text
L4 remains bounded-supported.
The ε4-floor route is restored and strengthened under natural admissibility.
Universal closure remains open.
```

More precisely:

```text
L4 rank-lift: PASS
finite-sector nonzero-minor certificates: PASS
finite-sector family sweep: PASS
random-sector robustness: PASS
weak-proxy counterprojection: FOUND
counterprojection audit: INADMISSIBLE POST-HOC
A_op^nd,natural correction: COMPLETE
natural admissible erasure search: PASS
ε4-floor route under A_op^nd,natural: STRENGTHENED
universal theorem: OPEN
```

---

## 3. L4 Object

The canonical fourth-order residual remains:

\[
H_4
=
(((J_1\oplus J_2)\oplus J_3)\oplus J_4)
-
(J_1\oplus(J_2\oplus(J_3\oplus J_4))).
\]

The lower-order span is:

\[
\operatorname{span}(B_4\cup O_3)
\]

where:

\[
B_4 = \{J_1,J_2,J_3,J_4\}
\]

and:

\[
O_3 = \{O_{123},O_{124},O_{134},O_{234}\}.
\]

The L4 certificate condition is:

\[
H_4\notin \operatorname{span}(B_4\cup O_3).
\]

---

## 4. Evidence Before Projection Closure

The L4 rank-lift evidence remains intact:

### V1687.5

```text
rank_base_8 = 8
rank_with_H4 = 9
rank_lift_H4 = 1
```

with exact rational nonzero determinant:

```text
256480337840586992720981 / 144703125
```

### V1687.6

```text
8 / 8 finite symbolic-sector family certificates
rank_lift_H4 = 1 in every certified sector
```

### V1687.2

```text
24 / 24 random sectors produced L4-new behavior
```

These results certify that H4 can contribute an independent retained direction.

---

## 5. The Weak-Proxy Counterprojection

V1687.15 found a non-diagonal projection that erased H4 while passing weak proxy checks.

That projection was:

\[
P=I-uu^T
\]

where:

\[
u
=
\frac{\operatorname{residual}(H_4\mid \operatorname{span}(B_4+O_3))}
{\|\operatorname{residual}(H_4\mid \operatorname{span}(B_4+O_3))\|}.
\]

This was scientifically important because it showed:

```text
Pairwise faithfulness and branch/L3 rank preservation are not enough.
```

---

## 6. Audit of the Counterprojection

V1687.16 showed the counterprojection was:

```text
post-hoc
obstruction-targeting
constructed from H4 itself
not natural
not generated-algebra faithful
```

Its generated-algebra gaps were large:

```json
{
  "generated_gap_max": 335274816.82744825,
  "generated_gap_mean": 8332377.074726313,
  "generated_gap_median": 14834.559227047996
}
```

Therefore:

```text
The weak-proxy counterprojection is not admissible under the corrected L4 class.
```

---

## 7. Strengthened Admissibility

The corrected class is:

\[
A_{op}^{nd,\natural}(L4).
\]

It requires:

```text
linearity
branch noncollapse
branch rank preservation
L3 associator noncollapse
L3 rank preservation
normalization
retained provenance/order compatibility
generated-algebra operator-faithfulness
naturality / no obstruction targeting
```

The key addition is:

```text
not merely pairwise operator-faithfulness,
but generated-algebra operator-faithfulness.
```

And:

```text
projections cannot be constructed from H4 or its residual.
```

---

## 8. V1687.18 Natural Projection Search

V1687.18 tested predefined natural projections.

Result:

```text
NO_NATURAL_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
```

Search summary:

```json
{
  "projection_count": 31,
  "admissible_natural_count": 2,
  "admissible_natural_erasure_count": 0
}
```

Classification counts:

```json
{
  "NATURAL_BUT_INADMISSIBLE_H4_PERSISTS": 26,
  "NATURAL_BUT_INADMISSIBLE_H4_ERASURE": 3,
  "NATURAL_ADMISSIBLE_H4_PERSISTS": 2
}
```

Thus:

```text
No natural admissible projection erased H4.
```

The best admissible natural projection preserved H4:

```text
rank_with_H4 = 9
rank_lift_H4 = 1
pair_faithful = true
nested_faithful = true
generated_faithful = true
H4_erased = false
```

The best H4-erasing natural projection was inadmissible because it collapsed rank and failed generated-algebra faithfulness.

---

## 9. Corrected ε4-Floor Route

The corrected ε4-floor route is now:

```text
H4 rank-lift certificate
→ finite-sector nonzero-minor certification
→ H4 not reducible to B4 + O3
→ weak-proxy erasure found
→ erasure audited as post-hoc/inadmissible
→ A_op^nd,natural defined
→ natural/generated-algebra-faithful search finds no H4 erasure
→ ε4-floor route strengthened under natural admissibility
```

The formal target remains:

\[
\varepsilon_{4,\min}
=
\inf_{\Pi\in A_{op}^{nd,\natural}(L4)}\|\Pi H_4\|
>
0.
\]

This is not yet universally proven, but the route is now properly constrained.

---

## 10. What We Can Say Now

The strongest corrected statement is:

```text
Inside the tested retained recombination operator family,
H4 is certified as an independent fourth-order retained direction
in finite symbolic sectors.

A weak-proxy non-diagonal erasure exists,
but it is post-hoc and fails generated-algebra faithfulness.

Under the strengthened natural admissibility class,
no natural admissible H4 erasure was found in the finite-sector search.
```

Short version:

```text
L4 survives corrected admissibility.
```

---

## 11. What We Cannot Say Yet

Do not claim:

```text
universal ε4 theorem
all natural projections searched
all linear maps ruled out
all support/order sectors certified
empirical L4
physical geometry / GR / ADM
L5 follows automatically
```

The result is:

```text
bounded, strengthened, and scientifically cleaner after adversarial failure.
```

---

## 12. Recommended Next Step

The next step should be:

```text
V1687.20 — L4 Final Bounded Scientific Report
```

Goal:

```text
Produce a clean paper-style report of the L4 branch:
discovery,
counterexample,
admissibility correction,
bounded closure,
and open theorem conditions.
```

This should be done before moving to L5.

The L4 branch is now mature enough to document.

---

## 13. Final Status Statement

```text
V1687.19 freezes the corrected L4 natural-admissibility status.

L4 remains a bounded-supported fourth-order hyper-associator layer.

The ε4 route survived the weak-proxy counterprojection
after the admissibility class was corrected to require naturality
and generated-algebra operator-faithfulness.

Universal closure remains open.
```
