# ============================================================
# V1687.4 — L4 Symbolic Minimal Certificate
# ============================================================
# Colab-ready, self-contained.
#
# Purpose:
#   Move from V1687.2 numeric/random-sector L4 evidence to symbolic algebra.
#
# Test:
#   Build symbolic four-branch retained currents J1,J2,J3,J4.
#   Compute all L3 triple associators:
#       O123, O124, O134, O234
#
#   Compute canonical L4 four-branch residual:
#       H4 = (((J1⊕J2)⊕J3)⊕J4) - (J1⊕(J2⊕(J3⊕J4)))
#
#   Test whether:
#       H4 ∉ span{J1,J2,J3,J4,O123,O124,O134,O234}
#
#   via symbolic minor / rank-lift witness.
#
# Verdicts:
#   L4_SYMBOLIC_MINIMAL_CERTIFICATE_NONZERO
#   L4_SYMBOLIC_NUMERIC_WITNESS_ONLY
#   L4_SYMBOLIC_CERTIFICATE_FAILED
#
# Boundary:
#   Symbolic finite-sector certificate only.
#   Not universal over all operators/sectors.
#   No empirical L4.
#   No physical geometry / GR / ADM.
# ============================================================

from __future__ import annotations

import itertools
import json
from pathlib import Path

import sympy as sp
import pandas as pd


OUT = Path("/content/v1687_4_l4_symbolic_minimal_certificate")
OUT.mkdir(parents=True, exist_ok=True)


# ============================================================
# SYMBOLIC RETAINED OPERATOR
# ============================================================

def roll_down(v):
    return sp.Matrix([v[-1], *v[:-1]])

def roll_up(v):
    return sp.Matrix([*v[1:], v[0]])

def phi(x, y, gamma):
    # Full-gated symbolic order-overlap kernel.
    rd = roll_down(x)
    ru = roll_up(y)
    return sp.Matrix([gamma * (rd[i] * y[i] - x[i] * ru[i]) for i in range(len(x))])

def recombine(x, y, gamma):
    return x + y + phi(x, y, gamma)

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return sp.simplify(
        recombine(recombine(A, B, gAB), C, gL)
        -
        recombine(A, recombine(B, C, gBC), gR)
    )

def bracket4_left(J1,J2,J3,J4, g12,g123,g1234):
    return recombine(recombine(recombine(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right(J1,J2,J3,J4, g34,g234,g1234r):
    return recombine(J1,recombine(J2,recombine(J3,J4,g34),g234),g1234r)

def make_vector(mask, prefix):
    entries = []
    syms = []
    for i, active in enumerate(mask):
        if active:
            s = sp.symbols(f"{prefix}_{i}", nonzero=True)
            entries.append(s)
            syms.append(s)
        else:
            entries.append(sp.Integer(0))
    return sp.Matrix(entries), syms

def build_sector(n=12):
    """
    Minimal-but-roomy 12D sector.

    Rationale:
      - 4 branch vectors
      - 4 L3 associator vectors
      - 1 H4 vector
      Need enough ambient dimension to allow rank lift beyond 8.
    """
    masks = {
        "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
        "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
        "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
        "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
    }
    vectors = {}
    symbols = []
    for name, mask in masks.items():
        v, sy = make_vector(mask, name.lower())
        vectors[name] = v
        symbols.extend(sy)
    return vectors, symbols, masks

def symbolic_minor_search(M, base_rank_expected=None, max_rows_checked=6000):
    """
    Search 9x9 minors of M = [J1 J2 J3 J4 O123 O124 O134 O234 H4].
    If a nonzero 9x9 minor exists, H4 is not in span of previous 8 columns
    generically, assuming previous 8 are rank 8 somewhere.

    M has 9 columns, n rows.
    """
    n = M.rows
    checked = 0
    for rows in itertools.combinations(range(n), 9):
        sub = M[list(rows), :]
        det = sp.factor(sub.det())
        checked += 1
        if det != 0:
            return {
                "found": True,
                "rows": rows,
                "determinant_sample": str(det)[:6000],
                "checked": checked,
            }
        if checked >= max_rows_checked:
            break
    return {
        "found": False,
        "rows": None,
        "determinant_sample": "",
        "checked": checked,
    }

def numeric_witness_rank(columns, symbols, gates, seed=16874):
    vals = {}
    for idx, s in enumerate(symbols):
        val = ((idx * 7 + seed * 3 + 5) % 19) - 9
        if val == 0:
            val = (idx % 5) + 1
        vals[s] = sp.Integer(val)

    for idx, g in enumerate(gates):
        vals[g] = sp.Rational((idx % 7) + 2, (idx % 5) + 3)

    B8 = sp.Matrix.hstack(*columns[:-1]).subs(vals)
    M9 = sp.Matrix.hstack(*columns).subs(vals)
    return {
        "rank_base_8": int(B8.rank()),
        "rank_with_H4": int(M9.rank()),
        "rank_lift_H4": int(M9.rank() - B8.rank()),
        "values_sample": {str(k): str(v) for k,v in list(vals.items())[:12]},
    }

def run():
    vectors, symbols, masks = build_sector(n=12)
    J1,J2,J3,J4 = vectors["J1"], vectors["J2"], vectors["J3"], vectors["J4"]

    # Gates for triple associators.
    # Use distinct symbolic gates to avoid accidentally imposing hidden identities.
    gates = sp.symbols(
        "g12 g23 g13 g14 g24 g34 "
        "g123_L g123_R g124_L g124_R g134_L g134_R g234_L g234_R "
        "g123 g1234 g234 g1234r"
    )
    (
        g12,g23,g13,g14,g24,g34,
        g123_L,g123_R,g124_L,g124_R,g134_L,g134_R,g234_L,g234_R,
        g123,g1234,g234,g1234r
    ) = gates

    O123 = assoc3(J1,J2,J3,g12,g23,g123_L,g123_R)
    O124 = assoc3(J1,J2,J4,g12,g24,g124_L,g124_R)
    O134 = assoc3(J1,J3,J4,g13,g34,g134_L,g134_R)
    O234 = assoc3(J2,J3,J4,g23,g34,g234_L,g234_R)

    left4 = bracket4_left(J1,J2,J3,J4,g12,g123,g1234)
    right4 = bracket4_right(J1,J2,J3,J4,g34,g234,g1234r)
    H4 = sp.simplify(left4 - right4)

    base_cols = [J1,J2,J3,J4,O123,O124,O134,O234]
    all_cols = base_cols + [H4]

    B8 = sp.Matrix.hstack(*base_cols)
    M9 = sp.Matrix.hstack(*all_cols)

    witness = numeric_witness_rank(all_cols, symbols, list(gates), seed=16874)

    # Symbolic search only if numeric witness says rank-lift possible.
    minor_result = symbolic_minor_search(M9, max_rows_checked=6000)

    if minor_result["found"] and witness["rank_lift_H4"] > 0:
        verdict = "L4_SYMBOLIC_MINIMAL_CERTIFICATE_NONZERO"
    elif witness["rank_lift_H4"] > 0:
        verdict = "L4_SYMBOLIC_NUMERIC_WITNESS_ONLY"
    else:
        verdict = "L4_SYMBOLIC_CERTIFICATE_FAILED"

    # Also test if L3 rank itself is nondegenerate numerically.
    # rank_base_8 >= 8 means all branches + L3 associators independent in witness.
    result = {
        "document_id": "V1687_4_L4_SYMBOLIC_MINIMAL_CERTIFICATE",
        "status": "completed",
        "verdict": verdict,
        "ambient_dimension": int(M9.rows),
        "columns_tested": 9,
        "sector_masks": {"".join(k): "".join(map(str,v)) for k,v in masks.items()},
        "numeric_witness": witness,
        "symbolic_minor": minor_result,
        "interpretation": {
            "test": "H4 not reducible to span{J1,J2,J3,J4,O123,O124,O134,O234}",
            "H4_definition": "(((J1⊕J2)⊕J3)⊕J4) - (J1⊕(J2⊕(J3⊕J4)))",
        },
        "claim_boundary": "Symbolic finite-sector certificate only. Not universal over all operators/sectors. No empirical L4 or physical geometry claim.",
    }

    (OUT / "v1687_4_l4_symbolic_certificate_result.json").write_text(json.dumps(result, indent=2))

    rows = []
    for i, c in enumerate(all_cols):
        rows.append({
            "column_index": i,
            "name": ["J1","J2","J3","J4","O123","O124","O134","O234","H4"][i],
            "nonzero_entries_symbolic": int(sum(1 for x in c if x != 0)),
            "expression_sample": str(c)[:1200],
        })
    pd.DataFrame(rows).to_csv(OUT / "v1687_4_symbolic_column_summary.csv", index=False)

    report = f"""# V1687.4 — L4 Symbolic Minimal Certificate

## Verdict

```text
{verdict}
```

## Test

```text
H4 ∉ span{{J1,J2,J3,J4,O123,O124,O134,O234}}
```

where:

```text
H4 = (((J1⊕J2)⊕J3)⊕J4) - (J1⊕(J2⊕(J3⊕J4)))
```

## Numeric witness

```json
{json.dumps(witness, indent=2)}
```

## Symbolic minor result

```json
{json.dumps(minor_result, indent=2)}
```

## Boundary

Symbolic finite-sector certificate only.
Not universal over all operators/sectors.
No empirical L4 claim.
No physical geometry / GR / ADM claim.
"""
    (OUT / "V1687_4_L4_SYMBOLIC_CERTIFICATE_REPORT.md").write_text(report)

    print("\n==============================")
    print("V1687.4 RESULT")
    print("==============================")
    print(json.dumps(result, indent=2))
    print(f"\nOutputs saved to: {OUT}")

run()
