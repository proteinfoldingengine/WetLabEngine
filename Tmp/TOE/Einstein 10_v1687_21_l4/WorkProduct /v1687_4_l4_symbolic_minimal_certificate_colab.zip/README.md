# V1687.4 L4 Symbolic Minimal Certificate

Run in Colab:

```python
%run v1687_4_l4_symbolic_minimal_certificate_colab.py
```

Purpose:

```text
Move from numeric/random-sector L4 evidence to a finite-dimensional symbolic certificate.
```

Test:

```text
H4 ∉ span{J1,J2,J3,J4,O123,O124,O134,O234}
```

Possible verdicts:

```text
L4_SYMBOLIC_MINIMAL_CERTIFICATE_NONZERO
L4_SYMBOLIC_NUMERIC_WITNESS_ONLY
L4_SYMBOLIC_CERTIFICATE_FAILED
```

Claim boundary:

```text
Symbolic finite-sector certificate only.
No empirical L4.
No physical geometry / GR / ADM.
```
