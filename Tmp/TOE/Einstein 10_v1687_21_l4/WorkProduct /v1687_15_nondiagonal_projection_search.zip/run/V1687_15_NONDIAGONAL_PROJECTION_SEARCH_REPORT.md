# V1687.15 — Non-Diagonal Projection Search

## Verdict

```text
NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND
```

## Full-space baseline

```json
{
  "rank_base_B4_O3": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1,
  "H4_residual_to_B4_O3": 5573.53442773823
}
```

## Classification counts

```json
{
  "INADMISSIBLE_H4_PERSISTS": 463,
  "ADMISSIBLE_H4_PERSISTS": 4,
  "INADMISSIBLE_H4_ERASURE": 1,
  "ADMISSIBLE_H4_ERASURE": 1
}
```

## Best admissible projection

```json
{
  "projection": "project_away_H4_residual_strength_1.0",
  "matrix_rank": 11,
  "is_diagonal": false,
  "branch_norm_min": 15.459624833740307,
  "O3_norm_min": 98.94294679521903,
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 8,
  "rank_lift_H4": 0,
  "H4_norm": 65187.88669639519,
  "H4_residual_to_B4_O3": 1.1325160321776731e-09,
  "H4_relative_residual": 1.7373105488942012e-14,
  "operator_faithfulness_gap_max": 6.294739023455842e-12,
  "operator_faithfulness_gap_mean": 3.2663219774448354e-12,
  "operator_faithful": true,
  "admissible_Aopnd_proxy": true,
  "H4_erased": true,
  "classification": "ADMISSIBLE_H4_ERASURE"
}
```

## Best overall projection

```json
{
  "projection": "project_away_H4_strength_1.0",
  "matrix_rank": 11,
  "is_diagonal": false,
  "branch_norm_min": 12.831119959706085,
  "O3_norm_min": 67.28282606470297,
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 8,
  "rank_lift_H4": 0,
  "H4_norm": 7.72088958700758e-12,
  "H4_residual_to_B4_O3": 6.296829576778809e-12,
  "H4_relative_residual": 0.0006296829576778809,
  "operator_faithfulness_gap_max": 140.0855619607687,
  "operator_faithfulness_gap_mean": 49.65258101249115,
  "operator_faithful": false,
  "admissible_Aopnd_proxy": false,
  "H4_erased": true,
  "classification": "INADMISSIBLE_H4_ERASURE"
}
```

## Best inadmissible erasure

```json
{
  "projection": "project_away_H4_strength_1.0",
  "matrix_rank": 11,
  "is_diagonal": false,
  "branch_norm_min": 12.831119959706085,
  "O3_norm_min": 67.28282606470297,
  "branch_rank": 4,
  "base_rank_B4_O3": 8,
  "rank_with_H4": 8,
  "rank_lift_H4": 0,
  "H4_norm": 7.72088958700758e-12,
  "H4_residual_to_B4_O3": 6.296829576778809e-12,
  "H4_relative_residual": 0.0006296829576778809,
  "operator_faithfulness_gap_max": 140.0855619607687,
  "operator_faithfulness_gap_mean": 49.65258101249115,
  "operator_faithful": false,
  "admissible_Aopnd_proxy": false,
  "H4_erased": true,
  "classification": "INADMISSIBLE_H4_ERASURE"
}
```

## Boundary

Finite-sector non-diagonal projection search only.
Not a proof over all admissible projections.
