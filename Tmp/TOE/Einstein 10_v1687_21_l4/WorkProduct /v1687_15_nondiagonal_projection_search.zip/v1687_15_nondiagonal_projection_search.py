# ============================================================
# V1687.15 — Non-Diagonal Projection Search for H4 Erasure
# ============================================================
# Runtime-safe, self-contained.
#
# Purpose:
#   Extend V1687.13 beyond diagonal/coordinate projections.
#
# Search:
#   non-diagonal linear maps P represented as 12x12 matrices.
#
# Families tested:
#   1. identity
#   2. near-identity random linear maps
#   3. sparse mixing maps
#   4. orthogonal rotations with coordinate thinning
#   5. random low-rank-like maps regularized to preserve B4/O3
#   6. targeted H4-suppressing maps using projection away from H4 direction
#
# A_op^nd proxy conditions:
#   - operator-faithfulness gap approximately 0
#   - branch noncollapse
#   - branch rank = 4
#   - L3 associator noncollapse
#   - rank(PB4 + PO3) = 8
#   - H4 erasure tested by rank_lift <= 0 or residual ≈ 0
#
# Verdicts:
#   NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND
#   NO_NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED
#   SEARCH_UNRESOLVED
#
# Boundary:
#   finite-sector finite-search only;
#   not all possible linear maps.
# ============================================================

from __future__ import annotations

import json
from pathlib import Path
from typing import List

import numpy as np
import sympy as sp
import pandas as pd

OUT = Path("/mnt/data/v1687_15_nondiagonal_projection_search_outputs")
OUT.mkdir(parents=True, exist_ok=True)

N = 12
EPS = 1e-8
SEED = 168715


# ============================================================
# Operator and base sector
# ============================================================

def roll_down(v):
    return np.r_[v[-1], v[:-1]]

def roll_up(v):
    return np.r_[v[1:], v[0]]

def recombine(x, y, gamma):
    return x + y + gamma * (roll_down(x) * y - x * roll_up(y))

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return recombine(recombine(A, B, gAB), C, gL) - recombine(A, recombine(B, C, gBC), gR)

def bracket4_left(J1,J2,J3,J4,g12,g123,g1234):
    return recombine(recombine(recombine(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right(J1,J2,J3,J4,g34,g234,g1234r):
    return recombine(J1,recombine(J2,recombine(J3,J4,g34),g234),g1234r)

def rank(cols, tol=1e-8):
    if not cols:
        return 0
    return int(np.linalg.matrix_rank(np.stack(cols, axis=1), tol=tol))

def norm(v):
    return float(np.linalg.norm(v))

def residual_to_span(v, basis):
    if not basis:
        return norm(v)
    B = np.stack(basis, axis=1)
    coeff = np.linalg.pinv(B) @ v
    res = v - B @ coeff
    return norm(res)

MASKS = {
    "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
    "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
    "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
    "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
}

def values_for_mask(mask, prefix, seed=1):
    vals = []
    for i, active in enumerate(mask):
        if active:
            raw = ((seed + 3) * (i + 5) + len(prefix) * 7) % 29 - 14
            if raw == 0:
                raw = i % 7 + 1
            vals.append(float(raw))
        else:
            vals.append(0.0)
    return np.array(vals, dtype=float)

def gate_values(seed=1):
    names = ["g12","g23","g13","g14","g24","g34",
             "g123_L","g123_R","g124_L","g124_R","g134_L","g134_R","g234_L","g234_R",
             "g123","g1234","g234","g1234r"]
    return {name: float(sp.Rational(((idx + seed) % 11) + 2, ((2*idx + seed) % 7) + 3))
            for idx, name in enumerate(names)}

def build_base(seed=1):
    J1 = values_for_mask(MASKS["J1"], "j1", seed)
    J2 = values_for_mask(MASKS["J2"], "j2", seed)
    J3 = values_for_mask(MASKS["J3"], "j3", seed)
    J4 = values_for_mask(MASKS["J4"], "j4", seed)
    g = gate_values(seed)
    O123 = assoc3(J1,J2,J3,g["g12"],g["g23"],g["g123_L"],g["g123_R"])
    O124 = assoc3(J1,J2,J4,g["g12"],g["g24"],g["g124_L"],g["g124_R"])
    O134 = assoc3(J1,J3,J4,g["g13"],g["g34"],g["g134_L"],g["g134_R"])
    O234 = assoc3(J2,J3,J4,g["g23"],g["g34"],g["g234_L"],g["g234_R"])
    H4 = bracket4_left(J1,J2,J3,J4,g["g12"],g["g123"],g["g1234"]) - bracket4_right(J1,J2,J3,J4,g["g34"],g["g234"],g["g1234r"])
    return {"branches":[J1,J2,J3,J4], "O3":[O123,O124,O134,O234], "H4":H4, "gates":g}


# ============================================================
# Projection audit
# ============================================================

def apply(P, v):
    return P @ v

def op_faithfulness_gap(P, base):
    J = base["branches"]
    g = base["gates"]
    pairs = {
        (0,1): g["g12"], (1,2): g["g23"], (0,2): g["g13"],
        (0,3): g["g14"], (1,3): g["g24"], (2,3): g["g34"],
    }
    gaps = []
    for (i,j), gate in pairs.items():
        lhs = apply(P, recombine(J[i], J[j], gate))
        rhs = apply(P, recombine(apply(P, J[i]), apply(P, J[j]), gate))
        gaps.append(norm(lhs-rhs))
    return float(max(gaps)), float(np.mean(gaps))

def audit_projection(name, P, base):
    PB4 = [apply(P, v) for v in base["branches"]]
    PO3 = [apply(P, v) for v in base["O3"]]
    PH4 = apply(P, base["H4"])

    branch_norm_min = min(norm(v) for v in PB4)
    O3_norm_min = min(norm(v) for v in PO3)
    branch_rank = rank(PB4)
    base_rank = rank(PB4 + PO3)
    with_H4_rank = rank(PB4 + PO3 + [PH4])
    rank_lift = with_H4_rank - base_rank

    H4_norm = norm(PH4)
    H4_res = residual_to_span(PH4, PB4 + PO3)
    rel_res = H4_res / max(EPS, H4_norm)

    gap_max, gap_mean = op_faithfulness_gap(P, base)
    op_faithful = gap_max <= 1e-7

    admissible = bool(
        op_faithful and
        branch_norm_min > 1e-8 and
        O3_norm_min > 1e-8 and
        branch_rank == 4 and
        base_rank == 8
    )

    H4_erased = bool(H4_norm <= 1e-8 or H4_res <= 1e-8 or rank_lift <= 0)

    if admissible and H4_erased:
        classification = "ADMISSIBLE_H4_ERASURE"
    elif admissible and not H4_erased:
        classification = "ADMISSIBLE_H4_PERSISTS"
    elif (not admissible) and H4_erased:
        classification = "INADMISSIBLE_H4_ERASURE"
    else:
        classification = "INADMISSIBLE_H4_PERSISTS"

    return {
        "projection": name,
        "matrix_rank": int(np.linalg.matrix_rank(P)),
        "is_diagonal": bool(np.allclose(P, np.diag(np.diag(P)))),
        "branch_norm_min": branch_norm_min,
        "O3_norm_min": O3_norm_min,
        "branch_rank": branch_rank,
        "base_rank_B4_O3": base_rank,
        "rank_with_H4": with_H4_rank,
        "rank_lift_H4": rank_lift,
        "H4_norm": H4_norm,
        "H4_residual_to_B4_O3": H4_res,
        "H4_relative_residual": rel_res,
        "operator_faithfulness_gap_max": gap_max,
        "operator_faithfulness_gap_mean": gap_mean,
        "operator_faithful": bool(op_faithful),
        "admissible_Aopnd_proxy": bool(admissible),
        "H4_erased": bool(H4_erased),
        "classification": classification,
    }


# ============================================================
# Projection families
# ============================================================

def random_orthogonal(rng):
    A = rng.normal(size=(N,N))
    Q, R = np.linalg.qr(A)
    return Q

def projection_away_from_vector(v, strength=1.0):
    u = v / max(1e-12, np.linalg.norm(v))
    return np.eye(N) - strength * np.outer(u, u)

def generate_projections(base):
    rng = np.random.default_rng(SEED)
    mats = []

    I = np.eye(N)
    mats.append(("identity", I))

    # Near-identity dense maps
    for i in range(150):
        A = rng.normal(size=(N,N))
        P = I + rng.uniform(0.001, 0.08) * A / max(1e-12, np.linalg.norm(A, ord=2))
        mats.append((f"near_identity_dense_{i}", P))

    # Sparse off-diagonal mixing
    for i in range(150):
        P = np.eye(N)
        for _ in range(rng.integers(2, 8)):
            a, b = rng.integers(0, N, size=2)
            if a != b:
                P[a,b] += rng.uniform(-0.2, 0.2)
        mats.append((f"sparse_mixer_{i}", P))

    # Orthogonal rotations, and rotations with mild coordinate thinning
    for i in range(80):
        Q = random_orthogonal(rng)
        theta = rng.uniform(0.02, 0.25)
        P = (1-theta)*I + theta*Q
        mats.append((f"orthomix_{i}", P))

    # Target H4 suppression maps. Likely operator-violating.
    H = base["H4"]
    for strength in [0.25, 0.5, 0.75, 1.0]:
        mats.append((f"project_away_H4_strength_{strength}", projection_away_from_vector(H, strength)))

    # Project away from H4 residual to B4+O3 span
    B = np.stack(base["branches"] + base["O3"], axis=1)
    coeff = np.linalg.pinv(B) @ H
    res = H - B @ coeff
    for strength in [0.25, 0.5, 0.75, 1.0]:
        mats.append((f"project_away_H4_residual_strength_{strength}", projection_away_from_vector(res, strength)))

    # Random low-rank-like, regularized toward identity
    for i in range(80):
        U = rng.normal(size=(N,4))
        V = rng.normal(size=(4,N))
        L = U @ V
        L = L / max(1e-12, np.linalg.norm(L, ord=2))
        alpha = rng.uniform(0.02, 0.35)
        P = (1-alpha)*I + alpha*L
        mats.append((f"lowrank_regularized_{i}", P))

    return mats


def run():
    base = build_base()
    full_base_rank = rank(base["branches"] + base["O3"])
    full_rank_H4 = rank(base["branches"] + base["O3"] + [base["H4"]])
    full_res = residual_to_span(base["H4"], base["branches"] + base["O3"])

    rows = []
    for name, P in generate_projections(base):
        rows.append(audit_projection(name, P, base))

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "v1687_15_nondiagonal_projection_search_rows.csv", index=False)

    counts = df["classification"].value_counts().to_dict()
    admissible = df[df["admissible_Aopnd_proxy"] == True]
    admissible_erasure = df[df["classification"] == "ADMISSIBLE_H4_ERASURE"]
    inadmissible_erasure = df[df["classification"] == "INADMISSIBLE_H4_ERASURE"]

    best_admissible = None
    if len(admissible) > 0:
        best_admissible = admissible.sort_values("H4_residual_to_B4_O3").iloc[0].to_dict()

    best_overall = df.sort_values("H4_residual_to_B4_O3").iloc[0].to_dict()

    best_erasure = None
    if len(inadmissible_erasure) > 0:
        best_erasure = inadmissible_erasure.sort_values("H4_residual_to_B4_O3").iloc[0].to_dict()

    if len(admissible_erasure) > 0:
        verdict = "NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND"
    elif len(admissible) > 0:
        verdict = "NO_NONDIAGONAL_ADMISSIBLE_H4_ERASURE_FOUND_EPS4_STRENGTHENED"
    else:
        verdict = "SEARCH_UNRESOLVED_NO_ADMISSIBLE_PROJECTIONS_FOUND"

    result = {
        "document_id": "V1687_15_NONDIAGONAL_PROJECTION_SEARCH",
        "status": "completed",
        "verdict": verdict,
        "full_space": {
            "rank_base_B4_O3": int(full_base_rank),
            "rank_with_H4": int(full_rank_H4),
            "rank_lift_H4": int(full_rank_H4 - full_base_rank),
            "H4_residual_to_B4_O3": float(full_res),
        },
        "projection_count": int(len(df)),
        "classification_counts": counts,
        "admissible_count": int(len(admissible)),
        "admissible_erasure_count": int(len(admissible_erasure)),
        "inadmissible_erasure_count": int(len(inadmissible_erasure)),
        "best_admissible_min_H4_residual": best_admissible,
        "best_overall_min_H4_residual": best_overall,
        "best_inadmissible_erasure": best_erasure,
        "outputs": {
            "projection_search_rows": str(OUT / "v1687_15_nondiagonal_projection_search_rows.csv"),
        },
        "interpretation": {
            "meaning": "No non-diagonal admissible H4-erasing projection found strengthens epsilon4 route within this finite search.",
            "boundary": "Finite-sector finite non-diagonal search only; not all linear projections."
        },
        "claim_boundary": "Finite-sector non-diagonal projection search only; not a proof over all admissible projections."
    }

    (OUT / "v1687_15_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1687.15 — Non-Diagonal Projection Search

## Verdict

```text
{verdict}
```

## Full-space baseline

```json
{json.dumps(result["full_space"], indent=2)}
```

## Classification counts

```json
{json.dumps(counts, indent=2)}
```

## Best admissible projection

```json
{json.dumps(best_admissible, indent=2)}
```

## Best overall projection

```json
{json.dumps(best_overall, indent=2)}
```

## Best inadmissible erasure

```json
{json.dumps(best_erasure, indent=2)}
```

## Boundary

Finite-sector non-diagonal projection search only.
Not a proof over all admissible projections.
"""
    (OUT / "V1687_15_NONDIAGONAL_PROJECTION_SEARCH_REPORT.md").write_text(report)

    print(json.dumps(result, indent=2))

run()
