# V1687.2 — L4 Hardening / Reducibility Audit

## Verdict

```text
L4_NEW_HYPER_ASSOCIATOR_ROBUST
```

## Target operator

```text
full_gated_order_overlap
```

## Target grouped summary

```json
{
  "operator": "full_gated_order_overlap",
  "sectors": 24,
  "collapsed": 0,
  "l4_new": 24,
  "l4_law": 0,
  "unresolved": 0,
  "mean_l4_joint_lift": 4.0,
  "mean_single_l4_new_count": 4.0,
  "mean_l3_lift": 4.0,
  "mean_triple_NOOCI": 1.0,
  "l4_new_rate": 1.0,
  "collapsed_rate": 0.0
}
```

## Operator grouped summary

```json
[
  {
    "operator": "antisym_no_order_control",
    "sectors": 24,
    "collapsed": 0,
    "l4_new": 24,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 4.0,
    "mean_single_l4_new_count": 4.0,
    "mean_l3_lift": 4.0,
    "mean_triple_NOOCI": 1.0,
    "l4_new_rate": 1.0,
    "collapsed_rate": 0.0
  },
  {
    "operator": "closure_only_control",
    "sectors": 24,
    "collapsed": 24,
    "l4_new": 0,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 0.0,
    "mean_single_l4_new_count": 0.0,
    "mean_l3_lift": 0.0,
    "mean_triple_NOOCI": 0.0,
    "l4_new_rate": 0.0,
    "collapsed_rate": 1.0
  },
  {
    "operator": "full_gated_order_overlap",
    "sectors": 24,
    "collapsed": 0,
    "l4_new": 24,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 4.0,
    "mean_single_l4_new_count": 4.0,
    "mean_l3_lift": 4.0,
    "mean_triple_NOOCI": 1.0,
    "l4_new_rate": 1.0,
    "collapsed_rate": 0.0
  },
  {
    "operator": "linear_associative_control",
    "sectors": 24,
    "collapsed": 24,
    "l4_new": 0,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 0.0,
    "mean_single_l4_new_count": 0.0,
    "mean_l3_lift": 0.0,
    "mean_triple_NOOCI": 0.0,
    "l4_new_rate": 0.0,
    "collapsed_rate": 1.0
  },
  {
    "operator": "nonlinear_symmetric_control",
    "sectors": 24,
    "collapsed": 0,
    "l4_new": 24,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 4.0,
    "mean_single_l4_new_count": 4.0,
    "mean_l3_lift": 4.0,
    "mean_triple_NOOCI": 1.0,
    "l4_new_rate": 1.0,
    "collapsed_rate": 0.0
  },
  {
    "operator": "symmetric_overlap_control",
    "sectors": 24,
    "collapsed": 0,
    "l4_new": 24,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 4.0,
    "mean_single_l4_new_count": 4.0,
    "mean_l3_lift": 4.0,
    "mean_triple_NOOCI": 1.0,
    "l4_new_rate": 1.0,
    "collapsed_rate": 0.0
  }
]
```

## Interpretation rule

```text
If four-branch residuals are reducible to branches + L3 associators:
    L4 = law closure over L3 associators.

If four-branch residuals still add rank beyond branches + L3 associators:
    L4 = fourth-order hyper-associator direction.
```

## Claim boundary

Synthetic L4 hardening audit only.
No empirical L4 claim.
No physical geometry / GR / ADM claim.
