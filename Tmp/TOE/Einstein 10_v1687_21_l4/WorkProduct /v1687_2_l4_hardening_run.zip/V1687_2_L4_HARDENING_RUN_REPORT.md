# V1687.2 — L4 Hardening / Reducibility Audit Run

## Verdict

```text
L4_NEW_HYPER_ASSOCIATOR_ROBUST
```

## Target summary

```json
{
  "operator": "full_gated_order_overlap",
  "sectors": 24,
  "collapsed": 0,
  "l4_new": 24,
  "l4_law": 0,
  "unresolved": 0,
  "mean_l4_joint_lift": 4.0,
  "mean_single_l4_new_count": 4.0,
  "mean_l3_lift": 4.0,
  "mean_triple_NOOCI": 1.0,
  "l4_new_rate": 1.0,
  "collapsed_rate": 0.0
}
```

## Full summary

```json
{
  "document_id": "V1687_2_L4_HARDENING_REDUCIBILITY_AUDIT",
  "status": "completed",
  "verdict": "L4_NEW_HYPER_ASSOCIATOR_ROBUST",
  "sector_count": 24,
  "target_operator": "full_gated_order_overlap",
  "target_grouped_summary": {
    "operator": "full_gated_order_overlap",
    "sectors": 24,
    "collapsed": 0,
    "l4_new": 24,
    "l4_law": 0,
    "unresolved": 0,
    "mean_l4_joint_lift": 4.0,
    "mean_single_l4_new_count": 4.0,
    "mean_l3_lift": 4.0,
    "mean_triple_NOOCI": 1.0,
    "l4_new_rate": 1.0,
    "collapsed_rate": 0.0
  },
  "operator_grouped_summary": [
    {
      "operator": "antisym_no_order_control",
      "sectors": 24,
      "collapsed": 0,
      "l4_new": 24,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 4.0,
      "mean_single_l4_new_count": 4.0,
      "mean_l3_lift": 4.0,
      "mean_triple_NOOCI": 1.0,
      "l4_new_rate": 1.0,
      "collapsed_rate": 0.0
    },
    {
      "operator": "closure_only_control",
      "sectors": 24,
      "collapsed": 24,
      "l4_new": 0,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 0.0,
      "mean_single_l4_new_count": 0.0,
      "mean_l3_lift": 0.0,
      "mean_triple_NOOCI": 0.0,
      "l4_new_rate": 0.0,
      "collapsed_rate": 1.0
    },
    {
      "operator": "full_gated_order_overlap",
      "sectors": 24,
      "collapsed": 0,
      "l4_new": 24,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 4.0,
      "mean_single_l4_new_count": 4.0,
      "mean_l3_lift": 4.0,
      "mean_triple_NOOCI": 1.0,
      "l4_new_rate": 1.0,
      "collapsed_rate": 0.0
    },
    {
      "operator": "linear_associative_control",
      "sectors": 24,
      "collapsed": 24,
      "l4_new": 0,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 0.0,
      "mean_single_l4_new_count": 0.0,
      "mean_l3_lift": 0.0,
      "mean_triple_NOOCI": 0.0,
      "l4_new_rate": 0.0,
      "collapsed_rate": 1.0
    },
    {
      "operator": "nonlinear_symmetric_control",
      "sectors": 24,
      "collapsed": 0,
      "l4_new": 24,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 4.0,
      "mean_single_l4_new_count": 4.0,
      "mean_l3_lift": 4.0,
      "mean_triple_NOOCI": 1.0,
      "l4_new_rate": 1.0,
      "collapsed_rate": 0.0
    },
    {
      "operator": "symmetric_overlap_control",
      "sectors": 24,
      "collapsed": 0,
      "l4_new": 24,
      "l4_law": 0,
      "unresolved": 0,
      "mean_l4_joint_lift": 4.0,
      "mean_single_l4_new_count": 4.0,
      "mean_l3_lift": 4.0,
      "mean_triple_NOOCI": 1.0,
      "l4_new_rate": 1.0,
      "collapsed_rate": 0.0
    }
  ],
  "outputs": {
    "sector_operator_summary_csv": "/mnt/data/v1687_2_l4_hardening_reducibility_audit_outputs/v1687_2_l4_hardening_sector_operator_summary.csv",
    "single_residual_rows_csv": "/mnt/data/v1687_2_l4_hardening_reducibility_audit_outputs/v1687_2_l4_single_residual_rows.csv",
    "operator_grouped_csv": "/mnt/data/v1687_2_l4_hardening_reducibility_audit_outputs/v1687_2_l4_hardening_operator_grouped.csv"
  },
  "claim_boundary": "Synthetic L4 hardening audit only. No empirical L4, no physical geometry/GR/ADM."
}
```

## Boundary

Synthetic L4 hardening audit only.
No empirical L4 claim.
No physical geometry / GR / ADM claim.
