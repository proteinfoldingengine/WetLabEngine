# V1687.4-fast — L4 Symbolic/Numeric Witness

## Verdict

```text
L4_SYMBOLIC_NUMERIC_WITNESS_CONFIRMED
```

## Best witness

```json
{
  "seed": 1,
  "rank_base_8": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1
}
```

## First success

```json
{
  "seed": 1,
  "rank_base_8": 8,
  "rank_with_H4": 9,
  "rank_lift_H4": 1
}
```

## Interpretation

```text
A positive exact rational rank witness means H4 is not reducible to
branches + all L3 associators at that witness point.

This supports the L4 hyper-associator route,
but still needs a symbolic nonzero minor certificate.
```

## Boundary

Exact rational numeric witness over symbolic construction only.
Not yet a full symbolic determinant certificate.
