# ============================================================
# V1687.4-fast — L4 Symbolic/Numeric Witness Split
# ============================================================
# Runtime-safe version.
#
# Purpose:
#   Test whether a canonical L4 residual H4 adds rank beyond:
#       {J1,J2,J3,J4,O123,O124,O134,O234}
#
# This version:
#   1. builds the same symbolic finite sector,
#   2. evaluates many exact rational numeric witnesses,
#   3. reports rank_lift_H4,
#   4. writes a separate optional symbolic-minor TODO.
#
# Verdict:
#   L4_SYMBOLIC_NUMERIC_WITNESS_CONFIRMED
#   L4_NUMERIC_WITNESS_FAILED
#
# Boundary:
#   Numeric witness over symbolic construction only.
#   Not yet full symbolic determinant certificate.
# ============================================================

from __future__ import annotations
import json
from pathlib import Path
import sympy as sp
import pandas as pd

OUT = Path("/mnt/data/v1687_4_fast_l4_symbolic_numeric_witness_outputs")
OUT.mkdir(parents=True, exist_ok=True)

def roll_down(v):
    return sp.Matrix([v[-1], *v[:-1]])

def roll_up(v):
    return sp.Matrix([*v[1:], v[0]])

def phi(x, y, gamma):
    rd = roll_down(x)
    ru = roll_up(y)
    return sp.Matrix([gamma * (rd[i] * y[i] - x[i] * ru[i]) for i in range(len(x))])

def recombine(x, y, gamma):
    return x + y + phi(x, y, gamma)

def assoc3(A, B, C, gAB, gBC, gL, gR):
    return recombine(recombine(A, B, gAB), C, gL) - recombine(A, recombine(B, C, gBC), gR)

def bracket4_left(J1,J2,J3,J4, g12,g123,g1234):
    return recombine(recombine(recombine(J1,J2,g12),J3,g123),J4,g1234)

def bracket4_right(J1,J2,J3,J4, g34,g234,g1234r):
    return recombine(J1,recombine(J2,recombine(J3,J4,g34),g234),g1234r)

def make_vector(mask, prefix):
    entries, syms = [], []
    for i, active in enumerate(mask):
        if active:
            s = sp.symbols(f"{prefix}_{i}")
            entries.append(s)
            syms.append(s)
        else:
            entries.append(sp.Integer(0))
    return sp.Matrix(entries), syms

def build_sector():
    # 12D sector with enough ambient room for rank up to 9.
    masks = {
        "J1": [1,1,1,0,1,0,0,1,0,0,0,1],
        "J2": [1,0,1,1,0,1,0,0,1,0,1,0],
        "J3": [0,1,1,1,0,0,1,0,0,1,1,0],
        "J4": [1,0,0,1,1,0,1,1,0,1,0,0],
    }
    vectors, symbols = {}, []
    for name, mask in masks.items():
        v, sy = make_vector(mask, name.lower())
        vectors[name] = v
        symbols.extend(sy)
    return vectors, symbols, masks

def make_columns():
    vectors, symbols, masks = build_sector()
    J1,J2,J3,J4 = vectors["J1"], vectors["J2"], vectors["J3"], vectors["J4"]

    gates = sp.symbols(
        "g12 g23 g13 g14 g24 g34 "
        "g123_L g123_R g124_L g124_R g134_L g134_R g234_L g234_R "
        "g123 g1234 g234 g1234r"
    )
    (
        g12,g23,g13,g14,g24,g34,
        g123_L,g123_R,g124_L,g124_R,g134_L,g134_R,g234_L,g234_R,
        g123,g1234,g234,g1234r
    ) = gates

    O123 = assoc3(J1,J2,J3,g12,g23,g123_L,g123_R)
    O124 = assoc3(J1,J2,J4,g12,g24,g124_L,g124_R)
    O134 = assoc3(J1,J3,J4,g13,g34,g134_L,g134_R)
    O234 = assoc3(J2,J3,J4,g23,g34,g234_L,g234_R)

    H4 = bracket4_left(J1,J2,J3,J4,g12,g123,g1234) - bracket4_right(J1,J2,J3,J4,g34,g234,g1234r)

    cols = [J1,J2,J3,J4,O123,O124,O134,O234,H4]
    names = ["J1","J2","J3","J4","O123","O124","O134","O234","H4"]
    return cols, names, symbols, list(gates), masks

def exact_numeric_witness(cols, symbols, gates, seed):
    vals = {}
    for idx, s in enumerate(symbols):
        val = ((idx * 7 + seed * 11 + 5) % 23) - 11
        if val == 0:
            val = (idx % 7) + 1
        vals[s] = sp.Integer(val)

    for idx, g in enumerate(gates):
        vals[g] = sp.Rational(((idx + seed) % 7) + 2, ((idx + 2*seed) % 5) + 3)

    base = sp.Matrix.hstack(*cols[:-1]).subs(vals)
    full = sp.Matrix.hstack(*cols).subs(vals)
    rank_base = int(base.rank())
    rank_full = int(full.rank())
    return {
        "seed": seed,
        "rank_base_8": rank_base,
        "rank_with_H4": rank_full,
        "rank_lift_H4": rank_full - rank_base,
    }

def run():
    cols, names, symbols, gates, masks = make_columns()

    rows = []
    success = False
    best = None
    for seed in range(1, 41):
        w = exact_numeric_witness(cols, symbols, gates, seed)
        rows.append(w)
        if best is None or w["rank_lift_H4"] > best["rank_lift_H4"]:
            best = w
        if w["rank_lift_H4"] > 0 and w["rank_base_8"] >= 8:
            success = True
            # keep scanning lightly for statistics

    df = pd.DataFrame(rows)
    df.to_csv(OUT / "v1687_4_fast_numeric_witness_rows.csv", index=False)

    col_summary = []
    for name, c in zip(names, cols):
        col_summary.append({
            "name": name,
            "nonzero_entries": int(sum(1 for x in c if x != 0)),
            "sample": str(c)[:900],
        })
    pd.DataFrame(col_summary).to_csv(OUT / "v1687_4_fast_column_summary.csv", index=False)

    success_rows = df[(df["rank_lift_H4"] > 0) & (df["rank_base_8"] >= 8)]
    verdict = "L4_SYMBOLIC_NUMERIC_WITNESS_CONFIRMED" if len(success_rows) > 0 else "L4_NUMERIC_WITNESS_FAILED"

    result = {
        "document_id": "V1687_4_FAST_L4_SYMBOLIC_NUMERIC_WITNESS",
        "status": "completed",
        "verdict": verdict,
        "ambient_dimension": 12,
        "columns_tested": names,
        "witness_count": int(len(df)),
        "success_count": int(len(success_rows)),
        "success_rate": float(len(success_rows) / len(df)),
        "best_witness": best,
        "first_success": success_rows.iloc[0].to_dict() if len(success_rows) else None,
        "sector_masks": {k: "".join(map(str,v)) for k,v in masks.items()},
        "interpretation": {
            "test": "H4 not reducible to span{J1,J2,J3,J4,O123,O124,O134,O234}",
            "meaning_of_positive_rank_lift": "A finite exact rational witness shows H4 contributes an independent direction beyond branches + L3 associators for this symbolic sector.",
            "next_needed": "Full symbolic nonzero minor certificate to upgrade from numeric witness to symbolic theorem route."
        },
        "outputs": {
            "numeric_witness_rows": str(OUT / "v1687_4_fast_numeric_witness_rows.csv"),
            "column_summary": str(OUT / "v1687_4_fast_column_summary.csv"),
        },
        "claim_boundary": "Exact rational numeric witness over symbolic construction only; not yet full symbolic determinant certificate."
    }
    (OUT / "v1687_4_fast_result.json").write_text(json.dumps(result, indent=2))

    report = f"""# V1687.4-fast — L4 Symbolic/Numeric Witness

## Verdict

```text
{verdict}
```

## Best witness

```json
{json.dumps(best, indent=2)}
```

## First success

```json
{json.dumps(result["first_success"], indent=2)}
```

## Interpretation

```text
A positive exact rational rank witness means H4 is not reducible to
branches + all L3 associators at that witness point.

This supports the L4 hyper-associator route,
but still needs a symbolic nonzero minor certificate.
```

## Boundary

Exact rational numeric witness over symbolic construction only.
Not yet a full symbolic determinant certificate.
"""
    (OUT / "V1687_4_FAST_REPORT.md").write_text(report)

    print(json.dumps(result, indent=2))

run()
