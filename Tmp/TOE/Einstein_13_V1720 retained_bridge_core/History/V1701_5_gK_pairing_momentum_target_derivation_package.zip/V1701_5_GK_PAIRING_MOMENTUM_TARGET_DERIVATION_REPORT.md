# V1701.5 — Momentum Target Derivation from the (g_R, K_R) Retained Pairing

**Verdict:** `GK_PAIRING_DERIVED_MOMENTUM_TARGET_PASS`

## Purpose

V1701.4 likely failed because the momentum target was still guessed.

V1701.5 derives the retained momentum target from the `(g_R,K_R)` pairing itself.

## Pairing

```text
Ω((δg,δK),(ηg,ηK)) =
<δg,ηK>_W - <δK,ηg>_W

W = rho / g_R^-1
```

## Derived target

```text
A_g(c) = diag(c)D + diag(Dc)

A_K(c) = -W^-1 A_g(c)^T W

X_M(c) =
[ A_g(c)   0      ]
[ 0        A_K(c) ]
```

## Metrics

```json
{
  "version": "V1701.5",
  "valid_case_count": 12,
  "null_case_count": 24,
  "valid_pass_rate": 1.0,
  "null_fail_rate": 1.0,
  "max_valid_pairing_preservation_residual": 2.05179616061726e-17,
  "min_valid_old_target_preservation_residual": 0.0023219209402613973,
  "min_valid_derived_vs_old_difference": 0.057399203150200646,
  "diagnosis": "The retained (g_R,K_R) symplectic pairing derives a momentum target that preserves the pairing and differs from the old guessed target.",
  "verdict": "GK_PAIRING_DERIVED_MOMENTUM_TARGET_PASS",
  "pillar_status": {
    "Pillar 1 - Global Atlas Closure": "COMPLETE",
    "Pillar 2 - Retained Curvature / Source-Current Compatibility": "NONTRIVIAL FINITE-SECTOR ACTION PASS",
    "Pillar 3 - GR / ADM Correspondence and Continuum Identification": "GK-DERIVED MOMENTUM TARGET IDENTIFIED"
  }
}
```

## Diagnosis

The retained (g_R,K_R) symplectic pairing derives a momentum target that preserves the pairing and differs from the old guessed target.

## Boundary

This derives the target only. It does not yet close H-H.
