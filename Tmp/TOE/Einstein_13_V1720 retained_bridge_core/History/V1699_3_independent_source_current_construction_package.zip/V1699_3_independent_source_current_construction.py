# Generated direct-execution branch. See JSON/CSV outputs for full audit state.
