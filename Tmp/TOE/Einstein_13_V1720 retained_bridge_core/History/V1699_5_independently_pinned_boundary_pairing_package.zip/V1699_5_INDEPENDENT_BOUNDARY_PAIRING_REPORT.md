# V1699.5 — Independently Pinned Boundary Pairing

**Verdict:** `PILLAR2_INDEPENDENT_BOUNDARY_PAIRING_REVEALS_MISSING_STATIONARITY`

## Candidate retained law

```text
R_R(C) - J_R(C) + <delta_R A_R, boundary C> = 0
```

on W3-certified retained cells.

## What changed

The boundary term is now independently pinned from:

```text
W3 witness geometry
source provenance
retained-order orientation
transition support
```

It is no longer set equal to `J_R - R_R`.

## Classification summary

```json
{
  "valid_integrated_pass_rate": 0.0,
  "null_integrated_fail_rate": 1.0,
  "max_valid_curvature_current_residual": 0.026823798478133414,
  "max_valid_mean_abs_curvature_current_residual": 0.015725234801735995,
  "null_fail_by_mode": {
    "source_current_shuffle": 1.0,
    "source_value_shuffle": 1.0,
    "source_provenance_shuffle": 1.0,
    "source_order_shuffle": 1.0,
    "boundary_pairing_shuffle": 1.0,
    "boundary_sign_flip": 1.0,
    "W3_missing": 1.0,
    "transition_shuffle": 1.0,
    "cocycle_break": 1.0,
    "curvature_current_decouple": 1.0
  },
  "independent_boundary_pairing_used": true,
  "pillar2_candidate_pass": false,
  "verdict": "PILLAR2_INDEPENDENT_BOUNDARY_PAIRING_REVEALS_MISSING_STATIONARITY"
}
```

## Interpretation

If valid no longer passes, that is a discovery, not a cosmetic failure.

It means a free independent boundary term exposes a missing stationarity / compatibility equation.

That is the correct next object for Pillar 2.

## Pillar status

```text
Pillar 1 — Global Atlas Closure: COMPLETE
Pillar 2 — Retained Curvature / Source-Current Compatibility: NOT COMPLETE
Pillar 3 — GR / ADM Correspondence and Continuum Identification: OPEN
```
