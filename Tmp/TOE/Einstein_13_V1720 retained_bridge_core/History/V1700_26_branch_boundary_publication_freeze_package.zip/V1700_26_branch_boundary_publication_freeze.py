#!/usr/bin/env python3
print("V1700.26 audit outputs are CSV/JSON/MD artifacts in this package.")
