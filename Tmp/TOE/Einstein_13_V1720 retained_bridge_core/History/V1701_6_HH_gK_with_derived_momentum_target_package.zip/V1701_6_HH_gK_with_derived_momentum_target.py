#!/usr/bin/env python3
print("V1701.6 audit outputs are CSV/JSON/MD artifacts in this package.")
