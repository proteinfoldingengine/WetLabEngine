# V1701.6 — H-H on (g_R,K_R) with Derived Momentum Target

**Verdict:** `HH_GK_DERIVED_TARGET_CLOSURE_FAIL`

## Purpose

V1701.5 showed that the old H-H momentum target was wrong. V1701.6 retests H-H using the target derived from the retained `(g_R,K_R)` pairing.

## Target used

```text
A_g(c) = diag(c)D + diag(Dc)

A_K(c) = -W^-1 A_g(c)^T W

X_M(c) =
[ A_g(c)   0      ]
[ 0        A_K(c) ]
```

## Scalar generator tested

```text
X_H(N) =
[ 0      2N ]
[ -B_N   0 ]

B_N = rho^-1 D^T G D diag(rho N)
```

## Metrics

```json
{
  "version": "V1701.6",
  "valid_case_count": 16,
  "null_case_count": 48,
  "valid_pass_rate": 0.0,
  "null_fail_rate": 1.0,
  "max_valid_HH_operator_residual": 1.6888333574366896,
  "mean_valid_HH_operator_residual": 1.594396598906664,
  "max_valid_probe_residual": 2.404481871649188,
  "max_valid_target_pairing_residual": 2.05179616061726e-17,
  "min_HH_residual_scaling_p": -0.08271086028454258,
  "diagnosis": "The pairing-derived momentum target is correct and symplectic, but H-H still does not close with the tested scalar generator. The remaining error is now on the scalar-generator side, not the momentum-target side.",
  "verdict": "HH_GK_DERIVED_TARGET_CLOSURE_FAIL",
  "pillar_status": {
    "Pillar 1 - Global Atlas Closure": "COMPLETE",
    "Pillar 2 - Retained Curvature / Source-Current Compatibility": "NONTRIVIAL FINITE-SECTOR ACTION PASS",
    "Pillar 3 - GR / ADM Correspondence and Continuum Identification": "OPEN"
  }
}
```

## Diagnosis

The pairing-derived momentum target is correct and symplectic, but H-H still does not close with the tested scalar generator. The remaining error is now on the scalar-generator side, not the momentum-target side.

## Boundary

This does not claim ADM/Dirac algebra closure unless the H-H hard gate passes.
