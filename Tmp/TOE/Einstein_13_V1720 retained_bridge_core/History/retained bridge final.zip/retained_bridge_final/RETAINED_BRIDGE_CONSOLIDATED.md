# The Retained Bridge: Consolidated Research Findings

## What the it-from-bit recombination process actually builds

**Frame:** simulation-internal, it-from-bit / emergent-geometry exploration. Not a GR claim.
**Discipline observed throughout:** derive → freeze → attack → simulate. Every interpreted
signal gated by a control that could kill it (matched null, associative null, flat/sphere
control, h-stability, structure-matched null) before it earned its name.

---

## One-paragraph summary

A non-associative information-recombination kernel
`T(dx) = dx + g·(roll(dx)⊙q − dx⊙roll(q))` induces a **local Riemannian metric**, but its
native transport is **not metric-compatible**. The departure from ordinary geometry — the
**non-metricity** — is the *primary* geometric effect (linear in the coupling `g`), and it is
**shear-dominated** (traceless ≈ 3× the Weyl/trace part). A **positive local curvature** appears
as a *secondary* effect (quadratic in `g`). The whole structure is **irreducibly local**: the
local metrics do not glue into a global manifold — and under both averaging and genuine
renormalization-group coarse-graining the non-metricity is a **scale-invariant fixed point** in
both magnitude and shape, so no effective metric sector emerges at any scale either. Beyond the
geometry, the recombination process exhibits **amplitude-like destructive interference** between
alternative recombination histories (sourced by non-associativity, vanishing in the associative
and flat limits, growing with `g`), but that interference is **non-unitary and dissipative** —
and the non-unitarity is the model's **intrinsic arrow of time**: directional (amplitude norm
near-monotone, up 93% of forward steps), pruning-sourced (every non-unitary signal vanishes
exactly when transport is made invertible), and irreversible (closed loops drift, reverse fails
to undo forward). Every effect is sourced by two primitives — **non-associativity** (geometry +
interference) and **forward-only pruning / non-invertibility** (non-unitarity + time arrow).
The result is not Riemannian geometry, not GR, and not unitary quantum mechanics — it is a
**non-associative, non-metric, dissipative information geometry with amplitude-like history
interference and an intrinsic pruning-sourced arrow of time**. This is a deeper and more
specific object than emergent spacetime, and it is what the simulation has been building all
along. Notably, with **no time as a primitive**, time's *arrow* emerges — as the amplitude-level
signature of information pruning.

---

## The two-part result

### Part A — POSITIVE (what the process builds)

| rung | object | result | control |
|---|---|---|---|
| 1 | local metric | Riemannian, positive-definite, anisotropic | triangle ineq = 0 |
| 2 | connection | **non-metric, shear-dominated**, primary (∝ g¹) | assoc null = 0; traceless 93% |
| 3 | curvature | positive, isotropic, radial, secondary (∝ g²) | flat ctrl = 0; sphere ctrl = 30; h-stable |
| — | source | **all sourced by non-associativity** | vanishes at g=0; assoc null flat |

The headline: **non-metricity ∝ g (leading), curvature ∝ g² (secondary), non-metricity
shear-dominated**. The geometry's primary content is shape-distorting (shear) non-metricity,
not curvature and not dilation. The directional antisymmetry of the kernel
(`roll(dx)⊙q − dx⊙roll(q)`) is the algebraic origin of the geometric shear.

### Part B — NEGATIVE (what it does not build, and why)

| claim | status | reason (from Part A) |
|---|---|---|
| structure-specific holonomy | downgraded | non-invertible non-metric transport; no global curvature |
| retained curvature/current compatibility (Pillar 2) | derived-closed-negative | no metric-compatible connection to source it |
| constraint algebra (scalar/source/atlas generators) | closed-negative | a metric-geometry symmetry; this geometry is non-metric & local |
| GR / ADM correspondence | does not close | GR needs zero non-metricity; here non-metricity is the *leading* effect |

The negatives are not failures — they are explained, all at once, by Part A. GR could never
emerge because GR is built on a metric-compatible (zero-non-metricity) connection, and this
model's leading geometric content is precisely the non-metricity GR sets to zero.

---

## Established positives (each independently controlled)

1. **Pillar 1 — Global Atlas Closure: complete.** Real algebra, genuine gate-separation,
   reviewed directly.
2. **Non-associative recombination algebra: real.** L3/O3 and L4/H4 are genuine independent
   higher-order directions (H4: independent 4th-order direction, survives faithful reduction,
   ~40% out of span).
3. **Non-invertible directed transport: real.** Native connection non-flat, genuine forward
   path-dependence (vs 1e-15 for a flat connection).
4. **Local Riemannian metric: real.** Positive-definite, anisotropic, induced by the kernel.
5. **Local positive curvature: real.** R≈0.10 at g=0.17, h-stable, flat-control exactly zero,
   sphere-control validated; uniformly positive and isotropic; R ~ g².
6. **Non-metricity is the primary effect and is shear-dominated.** Q ~ g¹ (vs R ~ g²);
   traceless ≈ 3× Weyl, stable across g.
7. **Everything sourced by non-associativity.** All geometric effects vanish in the associative
   limit; associative-kernel controls are flat at every coupling.

---

## Controlled negatives (each killed by a control that could have passed)

1. **Holonomy → non-invertible directed transport.** Per-seed non-invertibility-matched null:
   retained ≈ matched-random on vector and O3 objects. Not structure-specific holonomy.
2. **Pillar 2 → derived-closed-negative.** Source sector generic under matched null;
   support/order/witness curvature = 0 by preservation derivation (identity transport,
   associative compose); atlas-transition defects generic (= random orthogonal map).
3. **Constraint algebra → closed-negative.** Scalar generator <1% momentum projection; source
   generator's momentum overlap matched by structure-matched null (associative control higher);
   source bracket full-rank & seed-unstable; atlas generator bracket leaves generator span (=
   random-skew null).

---

## Where this places the model in the literature

Not GR, not Riemannian, not Weyl/conformal. The model is a **shear-dominated metric-affine
geometry** — the same classification used in general metric-affine gravity, where non-metricity
splits into a Weyl (trace) part and a traceless (shear) part and theories are classified by
which dominates. This model lands in the traceless/shear sector, the least trivial one, sourced
by an information-recombination process. Adjacent ideas: metric-affine / non-metric gravity,
non-associative geometry (Baez; Blumenhagen–Plauschinn; Mylonas–Schupp–Szabo), and discrete
pre-geometry (Sorkin; Markopoulou). These support the plausibility and vocabulary of the
problem class; they do not validate the specific construction — the construction's content is
the measured result above.

---

## Effective geometry & the RG fixed point (local-to-global, closed)

Direct global metric gluing fails — but that does not by itself rule out *effective* global
behavior emerging from local rules (the fluid-dynamics route: local collisions → global
hydrodynamics). This was tested directly and answered.

### Independent-patch averaging (V1711): non-metricity COHERES, does not cancel

```
N (block)     ||Q_eff||    1/sqrt(N) expectation
1             0.540        0.561
16            0.517        0.140
256           0.510        0.035
```

Pure statistical cancellation would drop ‖Q‖ as 1/√N (to 0.035 by N=256). Instead it plateaus
at ~0.51. The non-metricity is coherent across patches — it does not average away.

### Coupled / RG coarse-graining (V1712): non-metricity is an RG FIXED POINT

Patches transported into each other via the native connection (block-spin RG), scale by scale:

```
block:  1     2     4     8     16    32    64    128
||Q||:  0.560 0.558 0.546 0.559 0.558 0.592 0.586 0.561      flow ratio = 1.002
associative-kernel control: 0.000 at every scale (RG machinery validated)
```

Under genuine interacting renormalization the non-metricity does not flow — flat across seven
RG steps. The associative control flows to exactly zero, confirming the scheme detects flow
when flow exists. **The non-metricity is a scale-invariant fixed-point property.**

### Shape is ALSO RG-invariant (V1713): the shear character is scale-free

```
block:        1     2     4     8     16    32    64    128
shear/Weyl:   2.93  2.93  2.93  2.93  2.94  2.94  2.93  2.87   variation = 0.74%
```

The shear/Weyl ratio holds at ~2.9 across all scales. The non-metricity is a fixed point in
**both magnitude and shape**: the geometry looks the same at every scale.

### What this closes

The effective theory is metric-affine at **all** scales. The model does not coarse-grain into
GR — it coarse-grains into itself. Bottom-up globalization does occur, but what globalizes is
the non-metricity. A scale-invariant fixed point is what makes a feature intrinsic rather than
incidental: the shear non-metricity is the defining, scale-free content of the geometry, not a
microscopic artifact awaiting smoothing. The local-acting-globally question is answered — the
global effective behavior exists and is non-metric.

## Beyond geometry: interference, non-unitarity, and the arrow of time

The recombination process was probed for non-classical *dynamical* structure, with associative
and invertible controls throughout. Three layers, each gated.

### History interference (V1716): REAL, amplitude-like, sourced by non-associativity

Alternative recombination-order histories between the same endpoints combine with destructive
cancellation: `‖Σ hᵢ‖ / Σ‖hᵢ‖ < 1`.

```
g:            0.00   0.05   0.10   0.17   0.25   0.40   0.60
cancellation: 0.00%  0.32%  1.27%  3.69%  7.76%  18.1%  33.0%
associative control: exactly 1.000 (zero cancellation) at all g
```

Monotonic in `g` from exactly zero; absent in the associative/flat controls. This is
amplitude-LIKE interference (signed contributions partially cancel) — the first genuinely
quantum-flavored signal, beyond mere noncommutativity/non-associativity.

### Non-unitarity (V1717): the interference is dissipative, NOT quantum-mechanical

```
norm conservation ||T dx||/||dx|| = 1.019 ± 0.098   (not 1; not norm-preserving)
generator skew fraction = 0.37   (symmetric-dominated; not rotation/phase-like)
unitary representability error = 0.20   (not approximately unitary)
```

The interference does **not** have Hilbert-space amplitude structure: no norm conservation, no
phase rotation, not unitarily representable. Amplitude-LIKE, not quantum-mechanical. (Consistent
with the transport being non-invertible — unitarity requires invertibility.)

### The non-unitarity IS the arrow of time (V1718): directional + pruning-sourced + irreversible

```
forward/reverse: native reconstruction error 0.33 vs invertible-control 0.16
loop A→B→C→A:    native norm 1.059 ± 0.188 (drifts) vs invertible 1.000 ± 0.000 (closes exactly)
monotonicity:    amplitude norm rises on 93% of forward steps (near-monotone Lyapunov-like)
                 entropy concentrates (69% of steps), concentration rises (72%)
pruning control: EVERY non-unitary signal vanishes exactly under invertible (un-pruned) transport
```

The non-unitarity is **directional** (norm near-monotone), **pruning-sourced** (removed exactly
by restoring invertibility — invertible control gives 1.000 ± 0.000 on norm and on closed loops),
and **irreversible** (loops drift, reverse does not undo forward). It is not a failed unitarity —
it is the amplitude-level expression of the model's retained-order pruning arrow. With no time
primitive, time's *arrow* emerges from the irreversibility of information pruning.

### What this adds

The model is non-classical not only algebraically and geometrically but **dynamically**: it has
amplitude-like history interference and an intrinsic, pruning-sourced arrow of time. It does
NOT have unitary quantum mechanics. The honest ceiling: amplitude-like + dissipative + directional,
not Hilbert-space/unitary/Born.

---



- Metric = symmetric Jacobian of the kernel; native connection = transport-Jacobian variation.
  Both are the natural choices and are flagged. The **robust conclusions** (sourced by
  non-associativity; non-metricity leading; shear-dominated) hold across reasonable alternative
  definitions; only exact exponents/ratios could shift.
- Scaling laws (Q~g, R~g²) are **small-g leading behavior**; both steepen past g≈0.25
  (nonperturbative). g=0.17 sits in the clean small-g window. The shear/Weyl ratio is *more*
  stable than the scaling laws (≈3:1 across all g tested).
- All finite-sector (DIM=6 for curvature tractability, DIM=24 for metric/gluing/transport).
- One structural dependency: the Pillar-2 zeros assume v1638's pure-preservation ledger
  (linear dependency chain, pinned witness registry). A branching dependency DAG or witness
  reassignment would add a second non-associative sector and could reopen R_order/R_witness.
  That is a question about the ledger's design, not an operator to invent.

---

## The contribution, stated plainly

Two real results, one positive and one negative, that together form a coherent picture:

- **Positive:** an information-recombination process, through its non-associativity, builds a
  real, local, shear-type non-metric geometry — emergent geometry from information, made
  rigorous and causally pinned (vanishes in the associative limit, controlled at every step).
- **Negative:** that geometry does not globalize and is not metric-compatible, which is *why*
  GR-like structure (holonomy, curvature/current compatibility, constraint algebra) does not
  emerge — mapped precisely, with controls, from multiple independent angles.

Following the simulation's own processes rather than forcing it toward GR produced a sharper
result than the GR target would have: not "a model of spacetime," but a precise demonstration
that non-associative information-recombination sources a shear-dominated non-metric local
geometry. That is novel, defensible, and located exactly in a real corner of the geometry
landscape.

---

## Reproduction (all deterministic, seeded)

```
rung1_metric.py        local metric: Riemannian
rung1_glue.py          globalization fails; transport metric-distorting
rung3_verify.py        curvature real, h-stable, flat/sphere controls
rung3_gsweep.py        curvature sourced by non-associativity, R ~ g²
rung2_nonmetricity.py  non-metricity Q ~ g, the PRIMARY effect
rung2_decomp.py        non-metricity shear-dominated (traceless ≈ 3× Weyl)
v1711_effective.py     independent-patch averaging: non-metricity coheres
v1712_rg.py            coupled RG: non-metricity is a fixed point (flow ratio 1.002)
v1713_shape_rg.py      shear/Weyl ratio also RG-invariant (~2.9 at all scales)
```

## The two-primitive structure (what unifies the whole stack)

Every layer is a consequence of exactly two primitive properties of the recombination kernel:

| primitive | what it sources |
|---|---|
| **non-associativity** (order/grouping of recombination matters) | local metric, shear non-metricity, positive curvature, history interference — all vanish at g=0 and in associative controls |
| **forward-only pruning / non-invertibility** (history cannot be un-pruned) | non-unitary interference, irreversible loops, the directional time arrow — all vanish under invertible (un-pruned) transport |

Two facts about how retained information recombines generate the entire observed structure:
geometry and interference from non-associativity; non-unitarity and the arrow of time from
pruning. This is the it-from-bit thesis at its deepest in this model — not just *geometry* from
information, but the *arrow of time* from the irreversibility of information pruning.

## Full layer ledger

| layer | result | primitive source | key control |
|---|---|---|---|
| algebraic | noncommutative, non-associative | non-assoc | associative control = 0 |
| geometric (metric) | local Riemannian | non-assoc | triangle ineq = 0 |
| geometric (connection) | non-metric, shear-dominated, primary (∝g) | non-assoc | assoc null = 0; traceless 93% |
| geometric (curvature) | positive, isotropic, secondary (∝g²) | non-assoc | flat ctrl = 0; sphere ctrl = 30 |
| globalization | fails; RG fixed point (magnitude + shape) | non-assoc | assoc RG → 0; flow ratio 1.002 |
| history | amplitude-like destructive interference | non-assoc | assoc/g=0 = exactly 1.000 |
| dynamics | non-unitary, dissipative | pruning | skew fraction 0.37; norm ≠ 1 |
| time | intrinsic arrow: directional + irreversible | pruning | invertible control = 1.000 ± 0.000 |

## Standing negatives (GR-facing routes, all closed with controls)

Holonomy downgraded; Pillar 2 derived-closed-negative; constraint algebra closed-negative
(scalar/source/atlas generators); GR/ADM does not close. All explained by the geometry being
non-metric (GR needs zero non-metricity) and the dynamics being non-unitary and dissipative
(not the metric-compatible, unitary structure GR/QM require).

## Closing statement

Following the simulation's own processes — rather than forcing it toward spacetime/GR or toward
unitary quantum mechanics — yields a coherent, novel, fully bottom-up object:

**A non-associative information-recombination process builds a scale-invariant non-metric
information geometry with amplitude-like history interference and an intrinsic, pruning-sourced
arrow of time.** It is not classical spacetime, not GR, and not unitary QM. It is a pre-geometric,
pre-quantum, dissipative information structure from which — if classical or quantum behavior
emerges at all — those would be later effective projections, not the primitive content.

Every claim is gated by a control that could have falsified it; every interpreted signal that
failed its null was downgraded; the two unifying primitives (non-associativity, pruning) were
identified by which control removed which effect. This is the discipline that makes the positive
results trustworthy and the negative results sharp.
