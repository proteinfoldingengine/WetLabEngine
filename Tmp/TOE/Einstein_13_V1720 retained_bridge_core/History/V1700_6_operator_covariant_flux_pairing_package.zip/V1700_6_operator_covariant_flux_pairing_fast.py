# V1700.6 fast source executed in notebook cell; outputs are authoritative. Full logic retained in chat transcript.
