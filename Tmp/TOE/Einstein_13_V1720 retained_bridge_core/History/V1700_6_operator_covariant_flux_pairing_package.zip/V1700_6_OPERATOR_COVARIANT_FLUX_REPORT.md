# V1700.6 — Operator-Covariant Momentum Flux Pairing

**Verdict:** `PILLAR3_OPERATOR_COVARIANT_M_FLUX_PAIRING_PASS`

## Pairings tested

```text
raw:  corr(M, F)
K:    <M, K F> / sqrt(<M,K M><F,K F>)
Kinv: <M, K⁻¹ F> / sqrt(<M,K⁻¹ M><F,K⁻¹ F>)
```

where:

```text
M = Dq - (DJ_R - DB_R)
F = DJ_R - DB_R
```

## Metrics

```json
{
  "pairing_summary": [
    {
      "pairing": "raw",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "min_valid_corr": 0.41397121051581304,
      "mean_valid_corr": 0.7928918020581864,
      "max_H_norm": 1.2230587162763817e-17,
      "max_M_norm": 7.001331583654863e-16
    },
    {
      "pairing": "K",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "min_valid_corr": 0.4516306745143351,
      "mean_valid_corr": 0.8231544946001074,
      "max_H_norm": 1.2230587162763817e-17,
      "max_M_norm": 7.001331583654863e-16
    },
    {
      "pairing": "Kinv",
      "valid_pass_rate": 0.6171875,
      "null_fail_rate": 1.0,
      "min_valid_corr": 0.0,
      "mean_valid_corr": 0.4563928561364632,
      "max_H_norm": 1.2230587162763817e-17,
      "max_M_norm": 7.001331583654863e-16
    }
  ],
  "best_pairing": {
    "pairing": "K",
    "valid_pass_rate": 1.0,
    "null_fail_rate": 1.0,
    "min_valid_corr": 0.4516306745143351,
    "mean_valid_corr": 0.8231544946001074,
    "max_H_norm": 1.2230587162763817e-17,
    "max_M_norm": 7.001331583654863e-16
  },
  "raw_min_corr": 0.41397121051581304,
  "best_min_corr": 0.4516306745143351,
  "valid_case_count": 128,
  "null_case_count": 1024
}
```

## Boundary

Finite retained-sector Pillar 3 candidate only. No continuum ADM/GR claim.
