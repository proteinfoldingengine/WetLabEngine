#!/usr/bin/env python3
"""
V1700.1 — Momentum Constraint Recovery Attempt
==============================================

Purpose
-------
V1700.0 showed stable H-like scalar compatibility but failed the naive M-like flux proxy.

This script searches first-principles retained momentum-like candidates from:
    - retained incidence/divergence
    - KKT multiplier flux
    - source-current divergence
    - boundary divergence
    - connection correction divergence
    - coupled Noether-like balance from constrained action

No fitting to the final residual is allowed.

Boundary:
    Pillar 3 attempt only. No ADM/GR claim unless a candidate survives
    resolution ladder + nulls + nontriviality.
"""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Tuple
import argparse, csv, hashlib, json, math, shutil
import numpy as np

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_PLOT=True
except Exception:
    HAS_PLOT=False

EPS=1e-8
SIZES=[9,13,17,25,33,49,65,97]
MODES=["valid","source_shuffle","order_shuffle","support_shuffle","transition_shuffle","W3_shuffle","constraint_operator_break"]
CANDIDATES=[
    "dq_minus_dJ_scaled",
    "dq_plus_dlambda",
    "d_lambda_plus_dJ",
    "d_q_plus_d_boundary",
    "Noether_balance",
    "incidence_Kq_plus_LTlambda",
    "projected_multiplier_flux",
]

def clean(x):
    if isinstance(x,np.bool_): return bool(x)
    if isinstance(x,np.integer): return int(x)
    if isinstance(x,np.floating): return float(x)
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,dict): return {k:clean(v) for k,v in x.items()}
    if isinstance(x,list): return [clean(v) for v in x]
    return x
def digest(*items,n=16): return hashlib.sha256("|".join(map(str,items)).encode()).hexdigest()[:n]
def phase(sig):
    v=int(hashlib.sha256(sig.encode()).hexdigest()[:8],16)
    return (v%1000003)/1000003*2*math.pi
def save_csv(path, rows, cols):
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for r in rows: w.writerow({c:clean(r.get(c,"")) for c in cols})
def save_json(path,data): path.write_text(json.dumps(clean(data),indent=2))

def root(n): return digest("V1700.1","MOMENTUM_RECOVERY",n)
def source_profile(n):
    x=np.arange(n)/n
    s=np.exp(-((x-.15)/.055)**2)-.70*np.exp(-((x-.52)/.075)**2)-.30*np.exp(-((x-.78)/.06)**2)
    s=s-np.mean(s); return s
def weight(src,order,i): return 1.+.05*math.sin(phase(src+"::"+order)+.31*i)
def charts(n):
    r=root(n); prior=r; out=[]
    for i,val in enumerate(source_profile(n)):
        src=digest("SRC",r,i,float(val)); order=digest("ORDER",r,i); support=digest("SUPPORT",r,i)
        ev=digest("EVENT",r,prior,i,src,order,support)
        out.append(dict(chart=f"U{i}",idx=i,theta=float(2*math.pi*i/n),source=float(val),root=r,prior=prior,event=ev,
                        source_witness=src,order_witness=order,support_witness=support))
        prior=ev
    return r,out
def current_node(C): return np.array([c["source"]*weight(c["source_witness"],c["order_witness"],c["idx"]) for c in C])
def frame(i,n,J):
    th=2*math.pi*i/n
    a=.12*math.sin(th)+.07*math.cos(2*th)+.025*J[i]
    c,s=math.cos(a),math.sin(a)
    R=np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]])
    S=np.diag([1+.025*math.sin(th),1+.022*math.cos(th),1+.015*math.sin(2*th)])
    Sh=np.eye(3); Sh[0,1]=.012*math.cos(th)
    return R@S@Sh
def transport(C):
    n=len(C); J=current_node(C); F={i:frame(i,n,J) for i in range(n)}; T={}
    for i in range(n):
        for st in [1,2]:
            j=(i+st)%n
            T[(f"U{i}",f"U{j}")]=np.linalg.inv(F[j])@F[i]
            T[(f"U{j}",f"U{i}")]=np.linalg.inv(F[i])@F[j]
    return T
def cells(n,r):
    out=[]
    for i in range(n):
        nodes=[f"U{i}",f"U{(i+1)%n}",f"U{(i+2)%n}"]
        prov=digest("W3P",r,i,*nodes); adj=digest("W3A",r,i,f"C{(i-1)%n}",f"C{(i+1)%n}")
        sub=digest("W3S",r,i,digest("L",r,i),digest("R",r,i)); cf=digest("W3CF",r,i//2)
        out.append(dict(cell=f"C{i}",i=i,nodes=nodes,ori=1 if i%2==0 else -1,W1=True,W2=True,W3=True,
                        w3_prov=prov,w3_adj=adj,w3_sub=sub,w3_cf=cf,w3_basis=digest("W3B",prov,adj,sub,cf)))
    return out
def expected_basis(c): return digest("W3B",c["w3_prov"],c["w3_adj"],c["w3_sub"],c["w3_cf"])
def integrity(C,ref,r,K,refK):
    g=sum(c["root"]!=r for c in C)
    R={c["chart"]:c for c in ref}; cb=0
    for c in C:
        rc=R[c["chart"]]
        for f in ["source","source_witness","order_witness","support_witness"]:
            cb+=int(str(c[f])!=str(rc[f]))
    RK={c["cell"]:c for c in refK}; wb=0
    for c in K:
        rc=RK[c["cell"]]
        checks=[c["W3"]==rc["W3"],c["w3_prov"]==rc["w3_prov"],c["w3_adj"]==rc["w3_adj"],
                c["w3_sub"]==rc["w3_sub"],c["w3_cf"]==rc["w3_cf"],c["w3_basis"]==rc["w3_basis"],
                c["w3_basis"]==expected_basis(c)]
        wb+=sum(not v for v in checks)
    return int(g),int(cb),int(wb)
def closure(T,K):
    inv=[float(np.linalg.norm(T[(b,a)]@X-np.eye(3))) if (b,a) in T else float("inf") for (a,b),X in T.items()]
    co=[]
    for c in K:
        a,b,d=c["nodes"]
        if (a,b) in T and (b,d) in T and (d,a) in T:
            H=T[(d,a)]@T[(b,d)]@T[(a,b)]
            co.append(float(np.linalg.norm(H-np.eye(3))))
        else: co.append(float("inf"))
    return max(inv),max(co),max(co)
def curv(T,c):
    a,b,d=c["nodes"]; H=T[(d,a)]@T[(b,d)]@T[(a,b)]
    return c["ori"]*float(np.linalg.norm(H-np.eye(3)))
def J(M,c):
    vals=[]
    for u in c["nodes"]:
        ch=M[u]; vals.append(ch["source"]*weight(ch["source_witness"],ch["order_witness"],ch["idx"]))
    return c["ori"]*float(np.mean(vals))
def B(M,c,T):
    if not c["W3"]: return float("nan")
    vals=[]; phs=[]
    for u in c["nodes"]:
        ch=M[u]
        vals.append(ch["source"]*weight(ch["source_witness"],ch["order_witness"],ch["idx"]))
        phs.append(math.sin(phase(ch["source_witness"]+"::"+ch["order_witness"])))
    sb=c["ori"]*float(np.mean(vals))
    pb=.008*c["ori"]*float(np.mean(phs))
    wb=.003*c["ori"]*(math.sin(phase(c["w3_prov"]))+math.sin(phase(c["w3_adj"]))+math.sin(phase(c["w3_sub"]))+
                       math.sin(phase(c["w3_cf"]))+math.cos(phase(c["w3_basis"])))
    a,b,d=c["nodes"]
    tb=.0008*c["ori"]*float(np.trace(T[(a,b)])+np.trace(T[(b,d)])+np.trace(T[(d,a)]))
    return float(sb+pb+wb+tb)
def action(C,T,K):
    M={c["chart"]:c for c in C}
    Rv=[]; Jv=[]; Bv=[]; meta=[]
    for c in K:
        R=curv(T,c); j=J(M,c); b=B(M,c,T)
        Rv.append(R); Jv.append(j); Bv.append(b)
        meta.append(dict(cell=c["cell"],i=c["i"],R=R,J=j,B=b,raw=R-j+b))
    r0=np.array(Rv)-np.array(Jv)+np.array(Bv)
    n=len(K); L=np.eye(n)
    D=np.zeros((n,n))
    for i in range(n):
        D[i,i]=-1.; D[i,(i+1)%n]=1.
    Kmat=np.eye(n)+D.T@D
    return np.array(Rv),np.array(Jv),np.array(Bv),r0,L,Kmat,D,meta
def solve(r0,L,Kmat,enabled=True):
    if not enabled or not np.all(np.isfinite(r0)):
        n=len(r0); return np.full(n,np.nan),np.full(n,np.nan),float("inf"),float("inf")
    n=L.shape[1]; m=L.shape[0]
    A=np.block([[Kmat,L.T],[L,np.zeros((m,m))]])
    rhs=np.concatenate([np.zeros(n),-r0])
    sol=np.linalg.solve(A,rhs); q=sol[:n]; lam=sol[n:]
    grad=Kmat@q+L.T@lam; cons=L@q+r0
    return q,lam,float(np.linalg.norm(grad)),float(np.linalg.norm(cons))
def cand_norms(q,lam,R,Jv,Bv,Kmat,D):
    if not np.all(np.isfinite(q)): return {c:float("inf") for c in CANDIDATES}
    dq=D@q; dJ=D@Jv; dB=D@Bv; dl=D@lam
    scale=np.mean(np.abs(dq))/(np.mean(np.abs(dJ))+1e-12)
    cands={
        "dq_minus_dJ_scaled": dq-scale*dJ,
        "dq_plus_dlambda": dq+dl,
        "d_lambda_plus_dJ": dl+dJ,
        "d_q_plus_d_boundary": dq+dB,
        # Noether-like retained balance: divergence of energy gradient + source/boundary flux.
        "Noether_balance": D@(Kmat@q)+dJ-dB,
        # KKT first equation projected by incidence: D(Kq + lambda) should close when L=I.
        "incidence_Kq_plus_LTlambda": D@(Kmat@q+lam),
        # multiplier as flux after removing mean mode
        "projected_multiplier_flux": D@(lam-np.mean(lam)),
    }
    return {k:float(np.linalg.norm(v)/np.sqrt(len(v))) for k,v in cands.items()}
def mutate(mode,n,r,C,T,K):
    import copy
    C2=copy.deepcopy(C); T2={k:v.copy() for k,v in T.items()}; K2=copy.deepcopy(K); enabled=True
    if mode=="source_shuffle":
        vals=[c["source"] for c in C2][2:]+[c["source"] for c in C2][:2]
        for c,v in zip(C2,vals): c["source"]=v
    elif mode=="order_shuffle":
        vals=[c["order_witness"] for c in C2][1:]+[C2[0]["order_witness"]]
        for c,v in zip(C2,vals): c["order_witness"]=v
    elif mode=="support_shuffle":
        vals=[c["support_witness"] for c in C2][3:]+[c["support_witness"] for c in C2][:3]
        for c,v in zip(C2,vals): c["support_witness"]=v
    elif mode=="transition_shuffle":
        keys=list(T2.keys()); vals=[T2[k] for k in keys][5:]+[T2[k] for k in keys][:5]; T2={k:v for k,v in zip(keys,vals)}
    elif mode=="W3_shuffle":
        vals=[c["w3_basis"] for c in K2][3:]+[c["w3_basis"] for c in K2][:3]
        for c,v in zip(K2,vals): c["w3_basis"]=v
    elif mode=="constraint_operator_break":
        enabled=False
    return C2,T2,K2,enabled
def eval_case(n,mode):
    r,C=charts(n); T=transport(C); K=cells(n,r)
    C2,T2,K2,enabled=mutate(mode,n,r,C,T,K)
    g,cb,wb=integrity(C2,C,r,K2,K)
    inv,coc,hol=closure(T2,K2)
    R,Jv,Bv,r0,L,Kmat,D,meta=action(C2,T2,K2)
    q,lam,grad,cons=solve(r0,L,Kmat,enabled)
    Hnorm=float(np.linalg.norm(r0+q)/np.sqrt(n)) if np.all(np.isfinite(q)) else float("inf")
    norms=cand_norms(q,lam,R,Jv,Bv,Kmat,D)
    opbad=0 if enabled else len(K2)
    valid_gate=(inv<=EPS and coc<=EPS and hol<=EPS and g==0 and cb==0 and wb==0 and opbad==0 and grad<=EPS and cons<=EPS and Hnorm<=EPS)
    row=dict(n=n,mode=mode,genesis_mismatches=g,chart_mismatches=cb,W3_mismatches=wb,operator_mismatches=opbad,
             atlas_inverse_residual=inv,atlas_cocycle_residual=coc,atlas_holonomy_residual=hol,
             KKT_grad_norm=grad,KKT_constraint_norm=cons,H_like_constraint_norm=Hnorm,full_stack_gate=valid_gate)
    row.update({f"{k}_norm":v for k,v in norms.items()})
    details=[]
    for i,m in enumerate(meta):
        details.append(dict(n=n,mode=mode,cell=m["cell"],i=m["i"],R=m["R"],J=m["J"],B=m["B"],raw=m["raw"],
                            q=float(q[i]) if np.isfinite(q[i]) else float("nan"),
                            lambda_kkt=float(lam[i]) if np.isfinite(lam[i]) else float("nan")))
    return row,details
def fit_power(ns,ys):
    xs=np.array(ns,float); yy=np.array(ys,float); mask=np.isfinite(yy)&(yy>0)
    if mask.sum()<3: return dict(power=float("nan"),ok=False)
    p=np.polyfit(np.log(xs[mask]),np.log(yy[mask]),1)
    return dict(power=float(p[0]),intercept=float(p[1]),ok=True)
def run(outdir):
    if outdir.exists(): shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    rows=[]; details=[]
    for n in SIZES:
        for m in MODES:
            r,d=eval_case(n,m); rows.append(r); details.extend(d)
    cols=["n","mode","genesis_mismatches","chart_mismatches","W3_mismatches","operator_mismatches",
          "atlas_inverse_residual","atlas_cocycle_residual","atlas_holonomy_residual","KKT_grad_norm","KKT_constraint_norm",
          "H_like_constraint_norm","full_stack_gate"]+[f"{c}_norm" for c in CANDIDATES]
    save_csv(outdir/"V1700_1_momentum_candidate_rows.csv",rows,cols)
    save_csv(outdir/"V1700_1_cell_details.csv",details,["n","mode","cell","i","R","J","B","raw","q","lambda_kkt"])
    valid=[r for r in rows if r["mode"]=="valid"]; nulls=[r for r in rows if r["mode"]!="valid"]
    cand_summary=[]
    for c in CANDIDATES:
        vals=[r[f"{c}_norm"] for r in valid]
        maxv=max(vals); fit=fit_power([r["n"] for r in valid],[max(v,1e-18) for v in vals])
        cand_summary.append(dict(candidate=c,max_valid_norm=maxv,scaling_power=fit["power"],scaling_ok=fit["ok"],
                                 closes=maxv<=EPS))
    save_csv(outdir/"V1700_1_candidate_summary.csv",cand_summary,["candidate","max_valid_norm","scaling_power","scaling_ok","closes"])
    closing=[c for c in cand_summary if c["closes"]]
    metrics={
        "valid_full_stack_gate_rate":sum(r["full_stack_gate"] for r in valid)/len(valid),
        "null_full_stack_fail_rate":sum(not r["full_stack_gate"] for r in nulls)/len(nulls),
        "closing_momentum_candidates":[c["candidate"] for c in closing],
        "candidate_summary":cand_summary,
        "null_fail_by_mode":{}
    }
    for m in MODES:
        if m=="valid": continue
        sub=[r for r in rows if r["mode"]==m]
        metrics["null_fail_by_mode"][m]=sum(not r["full_stack_gate"] for r in sub)/len(sub)
    pass_any=metrics["valid_full_stack_gate_rate"]==1.0 and metrics["null_full_stack_fail_rate"]==1.0 and len(closing)>0
    verdict="PILLAR3_MOMENTUM_OBJECT_CANDIDATE_FOUND" if pass_any else "PILLAR3_MOMENTUM_OBJECT_NOT_FOUND"
    result={"version":"V1700.1","title":"Momentum Constraint Recovery Attempt","verdict":verdict,
            "metrics":metrics,
            "interpretation":"A zero-closing candidate based only on KKT first equation is expected/tautological unless it also carries independent source/boundary flux content. Treat as diagnostic, not ADM recovery.",
            "pillar_status":{"Pillar 1 - Global Atlas Closure":"COMPLETE",
                             "Pillar 2 - Retained Curvature / Source-Current Compatibility":"NONTRIVIAL FINITE-SECTOR ACTION PASS",
                             "Pillar 3 - GR / ADM Correspondence and Continuum Identification":"OPEN"},
            "boundary":"No ADM momentum recovery unless candidate is non-tautological and survives independent source/boundary flux tests."}
    save_json(outdir/"V1700_1_SUMMARY.json",result)
    report=f"""# V1700.1 — Momentum Constraint Recovery Attempt

**Verdict:** `{verdict}`

## Candidate families

```text
{chr(10).join(CANDIDATES)}
```

## Metrics

```json
{json.dumps(clean(metrics), indent=2)}
```

## Interpretation

A candidate that closes only because it is exactly the KKT first equation is not yet ADM momentum recovery. It must carry independent source/boundary flux content.

## Pillar status

```text
Pillar 1 — Global Atlas Closure: COMPLETE
Pillar 2 — Retained Curvature / Source-Current Compatibility: NONTRIVIAL FINITE-SECTOR ACTION PASS
Pillar 3 — GR / ADM Correspondence and Continuum Identification: OPEN
```
"""
    (outdir/"V1700_1_MOMENTUM_RECOVERY_REPORT.md").write_text(report)
    if HAS_PLOT:
        xs=[r["n"] for r in valid]
        fig,ax=plt.subplots(figsize=(9,5))
        for c in CANDIDATES:
            ax.plot(xs,[max(r[f"{c}_norm"],1e-18) for r in valid],marker="o",label=c)
        ax.set_yscale("log"); ax.set_xlabel("retained resolution"); ax.set_ylabel("candidate norm")
        ax.set_title("V1700.1 momentum-like candidate norms"); ax.grid(True,alpha=.25); ax.legend(fontsize=7)
        fig.tight_layout(); fig.savefig(outdir/"V1700_1_candidate_scaling.png",dpi=160); plt.close(fig)
    return result
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--outdir",default="V1700_1_outputs")
    args=ap.parse_args(); print(json.dumps(clean(run(Path(args.outdir))),indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
