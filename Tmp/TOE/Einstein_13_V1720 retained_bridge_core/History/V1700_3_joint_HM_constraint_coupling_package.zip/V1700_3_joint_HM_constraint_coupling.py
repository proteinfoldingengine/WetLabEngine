#!/usr/bin/env python3
"""
V1700.3 — Joint H/M Constraint Coupling Audit
============================================

Purpose
-------
V1700.2 found a non-tautological M-like candidate:

    M_R = Dq - (D J_R - D B_R)

This script tests whether H-like and M-like constraints close together
under the same retained action and whether the M-like object is not merely a
copy of the H-like residual.

H-like:
    H_R = R_R + q - J_R + B_R

M-like:
    M_R = Dq - (D J_R - D B_R)

Boundary:
    Pillar 3 audit only.
    No continuum GR/ADM recovery claim.
"""

from __future__ import annotations
from pathlib import Path
import argparse, csv, hashlib, json, math, shutil
from typing import Any, List, Dict, Tuple
import numpy as np

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_PLOT=True
except Exception:
    HAS_PLOT=False

EPS=1e-8
SIZES=[9,13,17,25,33,49,65,97,129]
MODES=["valid","source_shuffle","order_shuffle","support_shuffle","transition_shuffle","W3_shuffle","constraint_operator_break","M_operator_break","H_operator_break"]

def clean(x):
    if isinstance(x,np.bool_): return bool(x)
    if isinstance(x,np.integer): return int(x)
    if isinstance(x,np.floating): return float(x)
    if isinstance(x,np.ndarray): return x.tolist()
    if isinstance(x,dict): return {k:clean(v) for k,v in x.items()}
    if isinstance(x,list): return [clean(v) for v in x]
    return x
def digest(*items,n=16): return hashlib.sha256("|".join(map(str,items)).encode()).hexdigest()[:n]
def phase(sig):
    v=int(hashlib.sha256(sig.encode()).hexdigest()[:8],16)
    return (v%1000003)/1000003*2*math.pi
def save_csv(path,rows,cols):
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for r in rows: w.writerow({c:clean(r.get(c,"")) for c in cols})
def save_json(path,data): path.write_text(json.dumps(clean(data),indent=2))

def root(n): return digest("V1700.3","JOINT_HM",n)
def src_profile(n):
    x=np.arange(n)/n
    s=np.exp(-((x-.15)/.055)**2)-.70*np.exp(-((x-.52)/.075)**2)-.30*np.exp(-((x-.78)/.06)**2)
    return s-np.mean(s)
def weight(src,order,i): return 1.+.05*math.sin(phase(src+"::"+order)+.31*i)
def charts(n):
    r=root(n); prior=r; C=[]
    for i,val in enumerate(src_profile(n)):
        src=digest("SRC",r,i,float(val)); order=digest("ORDER",r,i); support=digest("SUPPORT",r,i)
        ev=digest("EVENT",r,prior,i,src,order,support)
        C.append(dict(chart=f"U{i}",idx=i,theta=float(2*math.pi*i/n),source=float(val),root=r,prior=prior,event=ev,
                      source_witness=src,order_witness=order,support_witness=support))
        prior=ev
    return r,C
def node_current(C): return np.array([c["source"]*weight(c["source_witness"],c["order_witness"],c["idx"]) for c in C])
def frame(i,n,J):
    th=2*math.pi*i/n
    a=.12*math.sin(th)+.07*math.cos(2*th)+.025*J[i]
    c,s=math.cos(a),math.sin(a)
    R=np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]])
    S=np.diag([1+.025*math.sin(th),1+.022*math.cos(th),1+.015*math.sin(2*th)])
    Sh=np.eye(3); Sh[0,1]=.012*math.cos(th)
    return R@S@Sh
def transport(C):
    n=len(C); J=node_current(C); F={i:frame(i,n,J) for i in range(n)}; T={}
    for i in range(n):
        for st in [1,2]:
            j=(i+st)%n
            T[(f"U{i}",f"U{j}")]=np.linalg.inv(F[j])@F[i]
            T[(f"U{j}",f"U{i}")]=np.linalg.inv(F[i])@F[j]
    return T
def cells(n,r):
    K=[]
    for i in range(n):
        nodes=[f"U{i}",f"U{(i+1)%n}",f"U{(i+2)%n}"]
        prov=digest("W3P",r,i,*nodes); adj=digest("W3A",r,i,f"C{(i-1)%n}",f"C{(i+1)%n}")
        sub=digest("W3S",r,i,digest("L",r,i),digest("R",r,i)); cf=digest("W3CF",r,i//2)
        K.append(dict(cell=f"C{i}",i=i,nodes=nodes,ori=1 if i%2==0 else -1,W3=True,
                      w3_prov=prov,w3_adj=adj,w3_sub=sub,w3_cf=cf,w3_basis=digest("W3B",prov,adj,sub,cf)))
    return K
def expected_basis(c): return digest("W3B",c["w3_prov"],c["w3_adj"],c["w3_sub"],c["w3_cf"])
def integrity(C,ref,r,K,refK):
    g=sum(c["root"]!=r for c in C)
    R={c["chart"]:c for c in ref}; cb=0
    for c in C:
        rc=R[c["chart"]]
        for f in ["source","source_witness","order_witness","support_witness"]:
            cb+=int(str(c[f])!=str(rc[f]))
    RK={c["cell"]:c for c in refK}; wb=0
    for c in K:
        rc=RK[c["cell"]]
        checks=[c["W3"]==rc["W3"],c["w3_prov"]==rc["w3_prov"],c["w3_adj"]==rc["w3_adj"],
                c["w3_sub"]==rc["w3_sub"],c["w3_cf"]==rc["w3_cf"],c["w3_basis"]==rc["w3_basis"],
                c["w3_basis"]==expected_basis(c)]
        wb+=sum(not v for v in checks)
    return int(g),int(cb),int(wb)
def closure(T,K):
    inv=[float(np.linalg.norm(T[(b,a)]@X-np.eye(3))) if (b,a) in T else float("inf") for (a,b),X in T.items()]
    co=[]
    for c in K:
        a,b,d=c["nodes"]
        if (a,b) in T and (b,d) in T and (d,a) in T:
            H=T[(d,a)]@T[(b,d)]@T[(a,b)]
            co.append(float(np.linalg.norm(H-np.eye(3))))
        else: co.append(float("inf"))
    return max(inv),max(co),max(co)
def curv(T,c):
    a,b,d=c["nodes"]; H=T[(d,a)]@T[(b,d)]@T[(a,b)]
    return c["ori"]*float(np.linalg.norm(H-np.eye(3)))
def J(M,c):
    return c["ori"]*float(np.mean([M[u]["source"]*weight(M[u]["source_witness"],M[u]["order_witness"],M[u]["idx"]) for u in c["nodes"]]))
def B(M,c,T):
    if not c["W3"]: return float("nan")
    vals=[]; phs=[]
    for u in c["nodes"]:
        ch=M[u]
        vals.append(ch["source"]*weight(ch["source_witness"],ch["order_witness"],ch["idx"]))
        phs.append(math.sin(phase(ch["source_witness"]+"::"+ch["order_witness"])))
    sb=c["ori"]*float(np.mean(vals))
    pb=.008*c["ori"]*float(np.mean(phs))
    wb=.003*c["ori"]*(math.sin(phase(c["w3_prov"]))+math.sin(phase(c["w3_adj"]))+math.sin(phase(c["w3_sub"]))+
                       math.sin(phase(c["w3_cf"]))+math.cos(phase(c["w3_basis"])))
    a,b,d=c["nodes"]
    tb=.0008*c["ori"]*float(np.trace(T[(a,b)])+np.trace(T[(b,d)])+np.trace(T[(d,a)]))
    return float(sb+pb+wb+tb)
def incidence(n):
    D=np.zeros((n,n))
    for i in range(n):
        D[i,i]=-1.; D[i,(i+1)%n]=1.
    return D
def action(C,T,K):
    M={c["chart"]:c for c in C}
    Rv=[]; Jv=[]; Bv=[]; meta=[]
    for c in K:
        rr=curv(T,c); jj=J(M,c); bb=B(M,c,T)
        Rv.append(rr); Jv.append(jj); Bv.append(bb); meta.append(dict(cell=c["cell"],i=c["i"],R=rr,J=jj,B=bb))
    Rv=np.array(Rv); Jv=np.array(Jv); Bv=np.array(Bv)
    r0=Rv-Jv+Bv
    n=len(K); L=np.eye(n); D=incidence(n); Kmat=np.eye(n)+D.T@D
    return Rv,Jv,Bv,r0,L,Kmat,D,meta
def solve(r0,L,Kmat,enabled=True):
    if not enabled or not np.all(np.isfinite(r0)):
        n=len(r0); return np.full(n,np.nan),np.full(n,np.nan),float("inf"),float("inf")
    n=L.shape[1]; m=L.shape[0]
    A=np.block([[Kmat,L.T],[L,np.zeros((m,m))]])
    rhs=np.concatenate([np.zeros(n),-r0])
    sol=np.linalg.solve(A,rhs); q=sol[:n]; lam=sol[n:]
    grad=Kmat@q+L.T@lam; cons=L@q+r0
    return q,lam,float(np.linalg.norm(grad)),float(np.linalg.norm(cons))
def corr(a,b):
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)): return float("nan")
    aa=a-np.mean(a); bb=b-np.mean(b); den=np.linalg.norm(aa)*np.linalg.norm(bb)
    if den<1e-30: return 0.0
    return float(np.dot(aa,bb)/den)
def norms(R,Jv,Bv,r0,q,lam,Kmat,D,H_ok=True,M_ok=True):
    if not np.all(np.isfinite(q)): 
        return dict(H=float("inf"),M=float("inf"),HM_corr=float("nan"),M_flux_corr=float("nan"),M_from_H_projection_fraction=float("nan"),joint=False)
    H = r0 + q if H_ok else np.full_like(q,np.inf)
    M = D@q - (D@Jv - D@Bv) if M_ok else np.full_like(q,np.inf)
    # independence: project M onto D(H) and measure fraction
    DH=D@H if np.all(np.isfinite(H)) else np.full_like(M,np.nan)
    den=float(np.dot(DH,DH)) if np.all(np.isfinite(DH)) else 0.0
    if den>1e-30:
        coef=float(np.dot(M,DH)/den)
        frac=float(abs(coef)*np.linalg.norm(DH)/(np.linalg.norm(M)+1e-30))
    else:
        frac=0.0
    flux=(D@Jv-D@Bv)
    hn=float(np.linalg.norm(H)/np.sqrt(len(H))) if np.all(np.isfinite(H)) else float("inf")
    mn=float(np.linalg.norm(M)/np.sqrt(len(M))) if np.all(np.isfinite(M)) else float("inf")
    return dict(H=hn,M=mn,HM_corr=abs(corr(H,M)),M_flux_corr=abs(corr(M,flux)),M_from_H_projection_fraction=frac,
                joint=(hn<=EPS and mn<=EPS and frac<0.25))
def mutate(mode,n,r,C,T,K):
    import copy
    C2=copy.deepcopy(C); T2={k:v.copy() for k,v in T.items()}; K2=copy.deepcopy(K)
    solve_ok=True; H_ok=True; M_ok=True
    if mode=="source_shuffle":
        vals=[c["source"] for c in C2][2:]+[c["source"] for c in C2][:2]
        for c,v in zip(C2,vals): c["source"]=v
    elif mode=="order_shuffle":
        vals=[c["order_witness"] for c in C2][1:]+[C2[0]["order_witness"]]
        for c,v in zip(C2,vals): c["order_witness"]=v
    elif mode=="support_shuffle":
        vals=[c["support_witness"] for c in C2][3:]+[c["support_witness"] for c in C2][:3]
        for c,v in zip(C2,vals): c["support_witness"]=v
    elif mode=="transition_shuffle":
        keys=list(T2.keys()); vals=[T2[k] for k in keys][5:]+[T2[k] for k in keys][:5]; T2={k:v for k,v in zip(keys,vals)}
    elif mode=="W3_shuffle":
        vals=[c["w3_basis"] for c in K2][3:]+[c["w3_basis"] for c in K2][:3]
        for c,v in zip(K2,vals): c["w3_basis"]=v
    elif mode=="constraint_operator_break":
        solve_ok=False
    elif mode=="M_operator_break":
        M_ok=False
    elif mode=="H_operator_break":
        H_ok=False
    return C2,T2,K2,solve_ok,H_ok,M_ok
def eval_case(n,mode):
    r,C=charts(n); T=transport(C); K=cells(n,r)
    C2,T2,K2,solve_ok,H_ok,M_ok=mutate(mode,n,r,C,T,K)
    g,cb,wb=integrity(C2,C,r,K2,K)
    inv,coc,hol=closure(T2,K2)
    R,Jv,Bv,r0,L,Kmat,D,meta=action(C2,T2,K2)
    q,lam,grad,cons=solve(r0,L,Kmat,solve_ok)
    no=norms(R,Jv,Bv,r0,q,lam,Kmat,D,H_ok,M_ok)
    operator_bad=0 if solve_ok and H_ok and M_ok else len(K2)
    gate=inv<=EPS and coc<=EPS and hol<=EPS and g==0 and cb==0 and wb==0 and operator_bad==0 and grad<=EPS and cons<=EPS and no["joint"]
    row=dict(n=n,mode=mode,genesis_mismatches=g,chart_mismatches=cb,W3_mismatches=wb,operator_mismatches=operator_bad,
             atlas_inverse_residual=inv,atlas_cocycle_residual=coc,atlas_holonomy_residual=hol,
             KKT_grad_norm=grad,KKT_constraint_norm=cons,H_norm=no["H"],M_norm=no["M"],
             H_M_abs_corr=no["HM_corr"],M_flux_abs_corr=no["M_flux_corr"],M_from_H_projection_fraction=no["M_from_H_projection_fraction"],
             joint_HM_pass=no["joint"],full_stack_gate=gate)
    details=[]
    Hvec=r0+q if np.all(np.isfinite(q)) else np.full(len(r0),np.nan)
    Mvec=D@q-(D@Jv-D@Bv) if np.all(np.isfinite(q)) else np.full(len(r0),np.nan)
    for i,m in enumerate(meta):
        details.append(dict(n=n,mode=mode,cell=m["cell"],i=m["i"],R=m["R"],J=m["J"],B=m["B"],
                            q=float(q[i]) if np.isfinite(q[i]) else float("nan"),
                            lambda_kkt=float(lam[i]) if np.isfinite(lam[i]) else float("nan"),
                            H=float(Hvec[i]) if np.isfinite(Hvec[i]) else float("nan"),
                            M=float(Mvec[i]) if np.isfinite(Mvec[i]) else float("nan")))
    return row,details
def fit_power(ns,ys):
    xs=np.array(ns,float); yy=np.array(ys,float); mask=np.isfinite(yy)&(yy>0)
    if mask.sum()<3: return dict(power=float("nan"),ok=False)
    p=np.polyfit(np.log(xs[mask]),np.log(yy[mask]),1)
    return dict(power=float(p[0]),intercept=float(p[1]),ok=True)
def run(outdir):
    if outdir.exists(): shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    rows=[]; details=[]
    for n in SIZES:
        for m in MODES:
            r,d=eval_case(n,m); rows.append(r); details.extend(d)
    cols=["n","mode","genesis_mismatches","chart_mismatches","W3_mismatches","operator_mismatches",
          "atlas_inverse_residual","atlas_cocycle_residual","atlas_holonomy_residual","KKT_grad_norm","KKT_constraint_norm",
          "H_norm","M_norm","H_M_abs_corr","M_flux_abs_corr","M_from_H_projection_fraction","joint_HM_pass","full_stack_gate"]
    save_csv(outdir/"V1700_3_joint_HM_rows.csv",rows,cols)
    save_csv(outdir/"V1700_3_cell_details.csv",details,["n","mode","cell","i","R","J","B","q","lambda_kkt","H","M"])
    valid=[r for r in rows if r["mode"]=="valid"]; nulls=[r for r in rows if r["mode"]!="valid"]
    metrics={
        "valid_joint_HM_pass_rate":sum(r["joint_HM_pass"] for r in valid)/len(valid),
        "valid_full_stack_gate_rate":sum(r["full_stack_gate"] for r in valid)/len(valid),
        "null_full_stack_fail_rate":sum(not r["full_stack_gate"] for r in nulls)/len(nulls),
        "max_valid_H_norm":max(r["H_norm"] for r in valid),
        "max_valid_M_norm":max(r["M_norm"] for r in valid),
        "max_valid_H_M_abs_corr":max(r["H_M_abs_corr"] for r in valid if np.isfinite(r["H_M_abs_corr"])),
        "max_valid_M_from_H_projection_fraction":max(r["M_from_H_projection_fraction"] for r in valid if np.isfinite(r["M_from_H_projection_fraction"])),
        "min_valid_M_flux_abs_corr":min(r["M_flux_abs_corr"] for r in valid if np.isfinite(r["M_flux_abs_corr"])),
        "H_scaling_fit":fit_power([r["n"] for r in valid],[max(r["H_norm"],1e-18) for r in valid]),
        "M_scaling_fit":fit_power([r["n"] for r in valid],[max(r["M_norm"],1e-18) for r in valid]),
        "null_fail_by_mode":{}
    }
    for m in MODES:
        if m=="valid": continue
        sub=[r for r in rows if r["mode"]==m]
        metrics["null_fail_by_mode"][m]=sum(not r["full_stack_gate"] for r in sub)/len(sub)
    passed=(metrics["valid_joint_HM_pass_rate"]==1.0 and metrics["valid_full_stack_gate_rate"]==1.0 and
            metrics["null_full_stack_fail_rate"]==1.0 and metrics["max_valid_H_norm"]<=EPS and metrics["max_valid_M_norm"]<=EPS and
            metrics["max_valid_M_from_H_projection_fraction"]<0.25)
    verdict="PILLAR3_JOINT_HM_CONSTRAINT_CANDIDATE_PASS" if passed else "PILLAR3_JOINT_HM_CONSTRAINT_NOT_CLOSED"
    result={"version":"V1700.3","title":"Joint H/M Constraint Coupling Audit","verdict":verdict,
            "metrics":metrics,
            "H_like":"H_R = R_R + q - J_R + B_R",
            "M_like":"M_R = Dq - (D J_R - D B_R)",
            "pillar_status":{"Pillar 1 - Global Atlas Closure":"COMPLETE",
                             "Pillar 2 - Retained Curvature / Source-Current Compatibility":"NONTRIVIAL FINITE-SECTOR ACTION PASS",
                             "Pillar 3 - GR / ADM Correspondence and Continuum Identification":"JOINT H/M CANDIDATE PASS" if passed else "OPEN"},
            "boundary":"Joint H/M retained candidate only. No continuum ADM/GR claim."}
    save_json(outdir/"V1700_3_SUMMARY.json",result)
    report=f"""# V1700.3 — Joint H/M Constraint Coupling Audit

**Verdict:** `{verdict}`

## Constraints tested

```text
H_R = R_R + q - J_R + B_R
M_R = Dq - (D J_R - D B_R)
```

## Metrics

```json
{json.dumps(clean(metrics), indent=2)}
```

## Interpretation

This tests whether scalar compatibility and non-tautological retained flux balance close together under the same retained action.

It remains a finite retained-sector Pillar 3 candidate, not continuum ADM recovery.

## Pillar status

```text
Pillar 1 — Global Atlas Closure: COMPLETE
Pillar 2 — Retained Curvature / Source-Current Compatibility: NONTRIVIAL FINITE-SECTOR ACTION PASS
Pillar 3 — GR / ADM Correspondence and Continuum Identification: {"JOINT H/M CANDIDATE PASS" if passed else "OPEN"}
```
"""
    (outdir/"V1700_3_JOINT_HM_REPORT.md").write_text(report)
    if HAS_PLOT:
        xs=[r["n"] for r in valid]
        fig,ax=plt.subplots(figsize=(8,5))
        ax.plot(xs,[max(r["H_norm"],1e-18) for r in valid],marker="o",label="H-like")
        ax.plot(xs,[max(r["M_norm"],1e-18) for r in valid],marker="s",label="M-like")
        ax.plot(xs,[max(r["KKT_constraint_norm"],1e-18) for r in valid],marker="^",label="KKT constraint")
        ax.set_yscale("log"); ax.set_xlabel("retained resolution"); ax.set_ylabel("norm")
        ax.set_title("V1700.3 joint H/M scaling"); ax.grid(True,alpha=.25); ax.legend()
        fig.tight_layout(); fig.savefig(outdir/"V1700_3_joint_HM_scaling.png",dpi=160); plt.close(fig)
        modes=[m for m in MODES if m!="valid"]
        fig,ax=plt.subplots(figsize=(11,5))
        ax.bar(modes,[metrics["null_fail_by_mode"][m] for m in modes])
        ax.set_ylim(0,1.05); ax.set_ylabel("gate fail rate"); ax.set_title("V1700.3 null rejection"); ax.tick_params(axis="x",rotation=30)
        fig.tight_layout(); fig.savefig(outdir/"V1700_3_null_rejection.png",dpi=160); plt.close(fig)
    return result
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--outdir",default="V1700_3_outputs")
    args=ap.parse_args(); print(json.dumps(clean(run(Path(args.outdir))),indent=2)); return 0
if __name__=="__main__": raise SystemExit(main())
