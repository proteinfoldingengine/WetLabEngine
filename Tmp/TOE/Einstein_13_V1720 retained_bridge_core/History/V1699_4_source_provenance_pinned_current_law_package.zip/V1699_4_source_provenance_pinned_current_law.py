# Direct branch output. See CSV/JSON outputs for reproducible audit state.
