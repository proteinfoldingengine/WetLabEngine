#!/usr/bin/env python3
"""
V1700.7 — ADM-Lineage Recovery Audit

Standalone audit script reading:
V1700_6_covariant_flux_rows.csv

It audits whether V1700.6 recovers ADM-like constraint slots:
H-like scalar slot, M-like flux slot, and K-covariant pairing.
"""

from pathlib import Path
import pandas as pd, json, numpy as np

EPS = 1e-8

def run(input_csv: str, outdir: str):
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(input_csv)
    valid = df[df["mode"]=="valid"].copy()
    nulls = df[df["mode"]!="valid"].copy()
    family = valid.groupby(["source_family","operator_family"]).agg(
        cases=("n","count"),
        max_H_norm=("H_norm","max"),
        max_M_norm=("M_norm","max"),
        min_K_flux_corr=("K_flux_corr","min"),
        joint_K_pass_rate=("joint_K_pass","mean"),
    ).reset_index()
    family["slot_status"] = np.where(
        (family["max_H_norm"] <= EPS) &
        (family["max_M_norm"] <= EPS) &
        (family["min_K_flux_corr"] > 0.25) &
        (family["joint_K_pass_rate"] == 1.0),
        "PASS", "FAIL"
    )
    metrics = {
        "H_like_slot_pass": bool((valid["H_norm"] <= EPS).all()),
        "M_like_slot_pass": bool((valid["M_norm"] <= EPS).all()),
        "K_covariant_flux_slot_pass": bool((valid["K_flux_corr"] > 0.25).all()),
        "null_rejection_pass": bool((~nulls["joint_K_pass"].astype(bool)).all()),
        "all_source_operator_families_pass": bool((family["slot_status"] == "PASS").all()),
        "ADM_equivalence_claim": False,
    }
    metrics["ADM_lineage_recovered_as_constraint_slots"] = all([
        metrics["H_like_slot_pass"],
        metrics["M_like_slot_pass"],
        metrics["K_covariant_flux_slot_pass"],
        metrics["null_rejection_pass"],
        metrics["all_source_operator_families_pass"],
    ])
    (out/"V1700_7_reaudit_summary.json").write_text(json.dumps(metrics, indent=2))
    family.to_csv(out/"V1700_7_reaudit_family_summary.csv", index=False)
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--input_csv", required=True)
    ap.add_argument("--outdir", default="V1700_7_reaudit")
    args = ap.parse_args()
    run(args.input_csv, args.outdir)
