# V1701.13 Python Proof

**Verdict:** `PROOF_PASS_OMEGA_W_SCALAR_FRAME_REPAIR`

## Claim proved

The proof verifies the V1701.13 scalar-frame result:

```text
X_H_old is not Hamiltonian under Ω_W.
X_M is Hamiltonian under Ω_W.
X_H_new = Ω_W-derived scalar generator is Hamiltonian under Ω_W.
```

## Key equations

For:

```text
Ω_W = [[0, W],[-W, 0]]
X_H = [[0, A],[-B, 0]]
```

`X_H` is Hamiltonian iff:

```text
W A symmetric
W B symmetric
```

The Ω_W-derived scalar generator is:

```text
A_new = W^-1 sym(W A_old)
B_new = W^-1 sym(W B_old)
```

## Metrics

```json
{
  "version": "V1701.13_python_proof",
  "dynamic_mean_RA_old": 0.10758464484354213,
  "dynamic_mean_RA_new": 8.345682710401725e-18,
  "dynamic_mean_RB_momentum": 3.5504833761861796e-17,
  "dynamic_mean_old_A_failure": 0.0,
  "dynamic_mean_old_B_failure": 0.3811930704427001,
  "dynamic_B_block_failure_dominance_rate": 1.0,
  "dynamic_mean_correction_A": 4.3587068394845534e-17,
  "dynamic_mean_correction_B": 0.19508930674116273,
  "verdict": "PROOF_PASS_OMEGA_W_SCALAR_FRAME_REPAIR",
  "diagnosis": "The old scalar generator is not Hamiltonian under \u03a9_W; the momentum generator is Hamiltonian; the \u03a9_W-rederived scalar generator is Hamiltonian to machine scale. The prior H-H tests were not valid algebra tests until this frame repair.",
  "boundary": "This proves scalar-generator Hamiltonian-frame consistency under \u03a9_W. It does not prove H-H closure."
}
```

## Diagnosis

The old scalar generator is not Hamiltonian under Ω_W; the momentum generator is Hamiltonian; the Ω_W-rederived scalar generator is Hamiltonian to machine scale. The prior H-H tests were not valid algebra tests until this frame repair.

## Boundary

This is not an H-H closure proof.

It proves that the scalar generator has been brought into the same W-weighted Hamiltonian frame as the momentum generator, so the H-H bracket can be tested meaningfully next.
