# V1701.13 Python Proof Package

This package contains a standalone Python proof of the V1701.13 result.

## Run

```bash
python V1701_13_python_proof.py
```

## Proves

- The old scalar generator is not Hamiltonian under Ω_W.
- The derived momentum generator is Hamiltonian under Ω_W.
- The Ω_W-rederived scalar generator is Hamiltonian under Ω_W.
- The old failure is localized in the B_N / δK block.

## Does not prove

- H-H closure.
- ADM/Dirac algebra recovery.
- Physical spacetime or Einstein equations.

The next meaningful test is V1701.14: H-H retest with the Ω_W-derived scalar generator.
