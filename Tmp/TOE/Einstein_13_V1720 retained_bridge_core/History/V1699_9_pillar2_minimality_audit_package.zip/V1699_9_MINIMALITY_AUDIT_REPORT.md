# V1699.9 — Pillar 2 Hardening: Leave-One-Basis-Out / Minimality Audit

**Verdict:** `PILLAR2_MINIMALITY_HARDENING_CANDIDATE_PASS`

## Purpose

V1699.8 produced the first candidate pass for the retained curvature/current compatibility law using an expanded admissible `δΓ_R` basis.

V1699.9 tests whether that basis is overbuilt or minimally justified.

## Result

```json
{
  "full_variant_candidate_pass": true,
  "number_of_passing_variants": 8,
  "minimal_passing_variant": "drop_W3_local",
  "minimal_passing_rank": 49,
  "full_variant_rank": 49,
  "summary_by_variant": [
    {
      "basis_variant": "full",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 6.591949208711867e-17,
      "max_valid_solver_norm": 1.7988848379013047e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_node_second",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 8.326672684688674e-17,
      "max_valid_solver_norm": 2.2945429883464155e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_edge_grad",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 1.1709383462843448e-16,
      "max_valid_solver_norm": 2.632835801776363e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_global_modes",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 4.510281037539698e-16,
      "max_valid_solver_norm": 8.184549635216721e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_W3_local",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 6.938893903907228e-17,
      "max_valid_solver_norm": 1.8626508126777088e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_orientation",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 2.5240226575462543e-16,
      "max_valid_solver_norm": 6.553709418454995e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "drop_order_modes",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 8.673617379884035e-17,
      "max_valid_solver_norm": 2.723984760254633e-16,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "minimal_W3_only",
      "valid_pass_rate": 1.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 0.0,
      "max_valid_solver_norm": 0.0,
      "max_valid_basis_rank": 49,
      "candidate_pass": true
    },
    {
      "basis_variant": "minimal_node_edge_only",
      "valid_pass_rate": 0.0,
      "null_fail_rate": 1.0,
      "max_valid_stationary_residual": 0.008129536675948824,
      "max_valid_solver_norm": 0.021508732318739163,
      "max_valid_basis_rank": 48,
      "candidate_pass": false
    }
  ],
  "pillar2_candidate_pass": true,
  "verdict": "PILLAR2_MINIMALITY_HARDENING_CANDIDATE_PASS"
}
```

## Interpretation

A basis family is necessary if dropping it prevents the valid branch from reaching stationarity while the full basis still rejects all nulls.

The minimal passing variant is:

```text
drop_W3_local
```

## Pillar status

```text
Pillar 1 — Global Atlas Closure: COMPLETE
Pillar 2 — Retained Curvature / Source-Current Compatibility: HARDENED CANDIDATE PASS
Pillar 3 — GR / ADM Correspondence and Continuum Identification: OPEN
```

## Boundary

This hardens Pillar 2. It does not complete Pillar 3 or identify the law with continuum GR/ADM.
