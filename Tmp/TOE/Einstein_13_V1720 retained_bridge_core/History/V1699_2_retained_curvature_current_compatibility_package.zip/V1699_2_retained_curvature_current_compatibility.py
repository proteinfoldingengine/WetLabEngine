# Direct branch output generated in this notebook. See CSV/JSON outputs for reproducible audit state.
