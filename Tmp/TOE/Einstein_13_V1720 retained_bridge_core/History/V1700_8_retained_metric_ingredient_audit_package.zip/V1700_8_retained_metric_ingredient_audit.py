#!/usr/bin/env python3
"""
V1700.8 retained metric ingredient audit artifact.

This package was generated from the notebook execution.
Use V1700_8_metric_ingredient_rows.csv and V1700_8_SUMMARY.json to inspect results.
"""
print("V1700.8 audit outputs are CSV/JSON artifacts in this package.")
