#!/usr/bin/env python3
print("V1701.13 audit outputs are CSV/JSON/MD artifacts in this package.")
