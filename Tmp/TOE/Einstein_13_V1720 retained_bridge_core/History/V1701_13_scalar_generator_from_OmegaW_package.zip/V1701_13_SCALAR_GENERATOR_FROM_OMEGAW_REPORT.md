# V1701.13 — Scalar Generator Re-Derivation from Ω_W Hamiltonian Integrability

**Verdict:** `OMEGA_W_DERIVED_SCALAR_GENERATOR_FRAME_PASS`

## Purpose

V1701.12 showed that the tested scalar generator was not Hamiltonian under the retained W-weighted pairing, while the momentum generator was Hamiltonian.

V1701.13 does not test H-H closure. It only repairs scalar-generator frame consistency.

## Hamiltonian integrability condition

For:

```text
X_H(N) =
[ 0    A_N ]
[ -B_N 0   ]
```

and

```text
Ω_W =
[ 0  W ]
[ -W 0 ]
```

the condition `Ω_W X_H = (Ω_W X_H)^T` becomes:

```text
W A_N symmetric
W B_N symmetric
```

## Re-derived scalar blocks

```text
A_N^new = W^-1 sym(W A_N^old)

B_N^new = W^-1 sym(W B_N^old)
```

This is the minimal Ω_W-derived Hamiltonian-frame correction.

## Metrics

```json
{
  "version": "V1701.13",
  "dynamic_mean_RA_old": 0.10758464484352559,
  "dynamic_mean_RA_new": 8.345682710400678e-18,
  "dynamic_mean_RB_momentum": 3.484717654105877e-17,
  "dynamic_B_block_failure_dominance_rate": 1.0,
  "dynamic_mean_old_A_failure": 0.0,
  "dynamic_mean_old_B_failure": 0.3811930704427001,
  "dynamic_mean_correction_A": 4.3587068394845534e-17,
  "dynamic_mean_correction_B": 0.19508930674116273,
  "dynamic_mean_old_B_local_fraction": 0.8146590608074219,
  "dynamic_mean_new_B_local_fraction": 0.8401610908568719,
  "diagnosis": "The \u03a9_W re-derived scalar generator collapses R_A to machine scale while X_M remains Hamiltonian. The prior H-H residual was not a valid algebra test until this repair.",
  "verdict": "OMEGA_W_DERIVED_SCALAR_GENERATOR_FRAME_PASS",
  "pillar_status": {
    "Pillar 1 - Global Atlas Closure": "COMPLETE",
    "Pillar 2 - Retained Curvature / Source-Current Compatibility": "NONTRIVIAL FINITE-SECTOR ACTION PASS",
    "Pillar 3 - GR / ADM Correspondence and Continuum Identification": "SCALAR GENERATOR \u03a9_W FRAME CONSISTENT; H-H NOW TESTABLE"
  }
}
```

## Diagnosis

The Ω_W re-derived scalar generator collapses R_A to machine scale while X_M remains Hamiltonian. The prior H-H residual was not a valid algebra test until this repair.

## Boundary

This does not establish H-H closure.

It establishes whether the scalar generator has been made Hamiltonian under Ω_W, so that a later H-H bracket test becomes meaningful.
