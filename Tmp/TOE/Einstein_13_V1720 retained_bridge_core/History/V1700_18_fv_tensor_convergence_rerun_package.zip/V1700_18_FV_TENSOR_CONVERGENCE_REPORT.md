# V1700.18 — Finite-Volume Tensor Convergence Rerun

**Verdict:** `FV_CONTINUUM_TENSOR_CONVERGENCE_CANDIDATE_PASS`

## Purpose

V1700.15 failed because raw/pointwise J_R and B_R were used as continuum tensor targets.

V1700.18 reruns the tensor convergence audit using the V1700.17 finite-volume objects:

```text
J_cell_integral = dx · retained cell source density
B_fv_flux       = dx · oriented retained boundary-face flux
```

Witness/provenance remains a discrete ledger and is not treated as a continuum tensor.

## Metrics

```json
{
  "version": "V1700.18",
  "case_count": 96,
  "pair_count": 80,
  "min_g_p": 1.9967563468864264,
  "min_K_p": 0.9719089862449772,
  "min_J_fv_p": 0.9174334660085176,
  "min_B_fv_p": 1.8617257317131235,
  "max_R_finest_diff": 3.551320577183596e-16,
  "max_finest_g_diff": 1.778796418297785e-06,
  "max_finest_K_diff": 0.0001311627959246783,
  "max_finest_J_fv_diff": 0.0018021008241346048,
  "max_finest_B_fv_diff": 0.00016859531211841058,
  "max_finest_H_diff": 2.7435033392717895e-18,
  "max_finest_M_diff": 6.773614700324083e-16,
  "all_fv_tensor_targets_converge": true,
  "fv_continuum_tensor_convergence_pass": true,
  "verdict": "FV_CONTINUUM_TENSOR_CONVERGENCE_CANDIDATE_PASS",
  "pillar_status": {
    "Pillar 1 - Global Atlas Closure": "COMPLETE",
    "Pillar 2 - Retained Curvature / Source-Current Compatibility": "NONTRIVIAL FINITE-SECTOR ACTION PASS",
    "Pillar 3 - GR / ADM Correspondence and Continuum Identification": "FINITE-VOLUME TENSOR CONVERGENCE CANDIDATE PASS"
  }
}
```

## Interpretation

If this passes, the retained ADM-like continuum-candidate object set is:

```text
g_R
K_R
J_cell_integral
B_fv_flux
constraint closure H_R/M_R
discrete witness ledger as admissibility layer
```

This is still not ADM/GR equivalence.
