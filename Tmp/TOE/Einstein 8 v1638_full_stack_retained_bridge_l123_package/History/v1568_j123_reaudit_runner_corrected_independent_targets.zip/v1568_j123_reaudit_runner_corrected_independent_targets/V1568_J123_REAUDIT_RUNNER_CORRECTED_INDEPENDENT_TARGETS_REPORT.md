# V1568 J123 Re-Audit Runner with Corrected Independent Targets

## Verdict

```text
J123_SUPPORTED_AGAINST_INDEPENDENT_TARGET_NOT_CLOSURE
```

## Interpretation

J123 tracks the corrected independent target under the locked protocol. This supports J123 as a candidate only; L3 remains unresolved.

## Metrics

```json
{
  "n_runs": 6,
  "corr_J123_absO_independent": 0.9143487576293577,
  "corr_J123_O_independent_signed": 0.9143487576293577,
  "rank_same_as_absO_independent": true,
  "rank_same_as_O_independent": true,
  "permutation_p_abs": 0.001,
  "permutation_mean_abs_corr": 0.3771832684353253,
  "base_abs_corr": 0.9143487576293577,
  "null_invalidation_pass_rate": 1.0,
  "O_123_independent_std": 0.08803740948213722,
  "leave_one_out": [
    {
      "omit": "B_123",
      "corr_loo_absO_independent": 0.9143487576293577,
      "corr_loo_O_independent": 0.9143487576293577,
      "rank_same_absO": true
    },
    {
      "omit": "Phi_123",
      "corr_loo_absO_independent": 0.9143487576293576,
      "corr_loo_O_independent": 0.9143487576293576,
      "rank_same_absO": true
    },
    {
      "omit": "H_123",
      "corr_loo_absO_independent": 0.9143487576293577,
      "corr_loo_O_independent": 0.9143487576293577,
      "rank_same_absO": true
    },
    {
      "omit": "E_123",
      "corr_loo_absO_independent": 0.9143487576293573,
      "corr_loo_O_independent": 0.9143487576293573,
      "rank_same_absO": true
    },
    {
      "omit": "I_irr123",
      "corr_loo_absO_independent": 0.0,
      "corr_loo_O_independent": 0.0,
      "rank_same_absO": true
    }
  ]
}
```

## Checks

```json
{
  "protocol_lock": {
    "ok": true
  },
  "v1566_validation": {
    "ok": true,
    "verdict": "CORRECTED_INDEPENDENT_TARGETS_VALIDATED_AUDIT_STILL_DISABLED",
    "validated": true
  },
  "input_leakage": {
    "ok": true,
    "target_cols_in_candidate": [],
    "missing_inputs": [],
    "candidate_cols_in_targets": []
  },
  "normalization_guard": {
    "ok": true
  },
  "null_guard": {
    "ok": true
  },
  "anti_circularity": {
    "ok": true
  },
  "target_variation": {
    "ok": true,
    "O_std": 0.08803740948213722
  }
}
```

## Boundary

No fitting.  
No threshold tuning.  
No counterterm.  
No ε-floor update.  
No L3 closure claim.
