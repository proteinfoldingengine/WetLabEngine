# V1501 Reproducibility Checklist

## Required upstream packages

The formal closure depends on these prior packages:

```text
V1472 empirical admissibility / UCI+BPI chain
V1492 hybrid global/branch source recombination
V1494 valid stress-regime constraint retest
V1497 Richardson-style residual scaling audit
V1498 minimal residual law extraction
V1499 branch-interference counterterm audit
V1500 integrated law closure audit
```

## Key files from V1500

```text
v1500_summary.json
v1500_minimal_law_table.csv
v1500_integrated_audit_table.csv
V1500_INTEGRATED_LAW_CLOSURE_AUDIT_REPORT.md
```

## Reproduction logic

1. Confirm empirical admissibility:
   - UCI = near-miss / partial holdout.
   - BPI2014 = repaired null-suite pass.

2. Confirm geometry/source weak-form:
   - V1492 pass.

3. Confirm constraint-like propagation:
   - V1494 pass.

4. Confirm residual scaling:
   - V1497 pass as diagnostic, not continuum certification.

5. Confirm minimal law:
   - V1498: L1/L2/L3.

6. Confirm counterterm failure:
   - V1499: amplitude reduced, L3 scaling not removed.

7. Confirm integrated closure:
   - V1500: partial law closure, L3 unresolved.

## Stop condition

Do not add another heuristic patch after V1500/V1501 unless it is derived from an observable conservation principle.
