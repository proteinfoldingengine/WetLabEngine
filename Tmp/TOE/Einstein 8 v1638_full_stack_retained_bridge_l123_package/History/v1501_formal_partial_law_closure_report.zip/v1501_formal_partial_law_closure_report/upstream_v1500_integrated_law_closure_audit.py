# === V1500 INTEGRATED LAW CLOSURE AUDIT ===
# Purpose:
#   Integrate V1472 -> V1499 into one law-closure audit.
#
# Honest closure state:
#   - Empirical admissibility evidence:
#       UCI 498: strong near-miss / partial holdout, not full certification
#       BPI2014: passed after restoring entropy + phase-order admissibility
#   - Geometry stack:
#       V1492 passed hybrid weak-form source/geometry relation
#       V1494 passed valid stress + Bianchi-like constraint retest
#       V1497 passed residual scaling diagnostic
#       V1498 extracted minimal residual law
#       V1499 counterterm reduced L3 amplitude but did not remove L3 divergence
#
# Boundary:
#   Model-native retained-history geometry/source law audit only.
#   Not physical GR, not Einstein equations, not ADM proof,
#   not physical stress-energy, not physical spacetime, not physical curvature.

from __future__ import annotations

from pathlib import Path
import json
import pandas as pd
import numpy as np

OUT = Path("v1500_outputs")
OUT.mkdir(exist_ok=True)

INPUTS = {
    "v1498_summary": [
        Path("v1498_outputs/v1498_summary.json"),
        Path("/mnt/data/v1498_minimal_residual_law_extraction/v1498_summary.json"),
    ],
    "v1499_summary": [
        Path("v1499_outputs/v1499_summary.json"),
        Path("/mnt/data/v1499_three_source_branch_interference_counterterm/v1499_summary.json"),
    ],
    "v1499_fits": [
        Path("v1499_outputs/v1499_scaling_fits.csv"),
        Path("/mnt/data/v1499_three_source_branch_interference_counterterm/v1499_scaling_fits.csv"),
    ],
}

def find_file(candidates, required=True):
    for p in candidates:
        if p.exists():
            return p
    if required:
        raise FileNotFoundError("Missing required input: " + " OR ".join(str(x) for x in candidates))
    return None

def read_json(p):
    return json.loads(Path(p).read_text())

def main():
    v1498_path = find_file(INPUTS["v1498_summary"])
    v1499_path = find_file(INPUTS["v1499_summary"])
    fits_path = find_file(INPUTS["v1499_fits"])

    v1498 = read_json(v1498_path)
    v1499 = read_json(v1499_path)
    fits = pd.read_csv(fits_path)

    # Extract core law fractions.
    law_fractions = v1498.get("law_fractions", {})
    l1 = float(law_fractions.get("L1_dissipative_convergence", 0.0))
    l2 = float(law_fractions.get("L2_irreducible_plateau", 0.0))
    l3 = float(law_fractions.get("L3_branch_interference_growth", 0.0))
    l12 = l1 + l2

    # V1499 counterterm result.
    target_baseline = v1499.get("target_baseline", {})
    target_counterterm = v1499.get("target_counterterm", {})
    counterterm_status = {
        "best_beta": v1499.get("best_beta"),
        "final_verdict": v1499.get("final_verdict"),
        "target_fixed": v1499.get("target_fixed"),
        "baseline_trend": target_baseline.get("trend"),
        "counterterm_trend": target_counterterm.get("trend"),
        "baseline_p": target_baseline.get("p"),
        "counterterm_p": target_counterterm.get("p"),
        "baseline_mean_value": target_baseline.get("mean_value"),
        "counterterm_mean_value": target_counterterm.get("mean_value"),
        "baseline_max_value": target_baseline.get("max_value"),
        "counterterm_max_value": target_counterterm.get("max_value"),
        "null_geometry_count": v1499.get("null_geometry_count"),
        "null_pass_count": v1499.get("null_pass_count"),
    }

    amplitude_reduction = None
    max_reduction = None
    if counterterm_status["baseline_mean_value"] and counterterm_status["counterterm_mean_value"]:
        amplitude_reduction = 1.0 - float(counterterm_status["counterterm_mean_value"]) / float(counterterm_status["baseline_mean_value"])
    if counterterm_status["baseline_max_value"] and counterterm_status["counterterm_max_value"]:
        max_reduction = 1.0 - float(counterterm_status["counterterm_max_value"]) / float(counterterm_status["baseline_max_value"])

    # Law-closure decision.
    closure_status = "PARTIAL_LAW_CLOSURE"
    final_verdict = "V1500_PARTIAL_LAW_CLOSURE_L3_UNRESOLVED"

    claims_allowed = [
        "Admissibility is required before geometry is meaningful.",
        "Geometry-only closure can be spoofed by invalid histories.",
        "For BPI2014, after entropy-arrow and phase-order repairs, the full null suite failed while the real trace passed.",
        "The model-native weak-form geometry/source relation passed multi-source, branching, overlap, three-source, and valid stress regimes at the tested base scale.",
        "Bianchi-like constraint-conservation diagnostics passed on admissible tested regimes at the base scale.",
        "Residual scaling mostly converges or plateaus: L1 + L2 = {:.1f}%.".format(100*l12),
        "One residual family remains unresolved: L3 branch-interference growth = {:.1f}%.".format(100*l3),
        "The V1499 counterterm reduced L3 amplitude but did not remove the L3 scaling divergence.",
    ]

    claims_not_allowed = [
        "Do not claim physical GR recovery.",
        "Do not claim Einstein equations have been derived or proven.",
        "Do not claim ADM closure as physical ADM.",
        "Do not claim physical stress-energy tensor recovery.",
        "Do not claim physical spacetime or physical curvature.",
        "Do not claim full continuum limit.",
        "Do not call UCI 498 a full certification; it remains a strong near-miss / partial holdout result.",
        "Do not keep the V1499 counterterm as a law-closing fix.",
    ]

    law_table = pd.DataFrame([
        {
            "law": "L1",
            "name": "dissipative convergence",
            "form": "R(N) = R_inf + a/N^p, p > 0",
            "fraction": l1,
            "status": "closed_as_model_native_scaling_family",
        },
        {
            "law": "L2",
            "name": "irreducible plateau",
            "form": "R(N) ≈ R_plateau + bounded variation",
            "fraction": l2,
            "status": "closed_as_model_native_residual_floor",
        },
        {
            "law": "L3",
            "name": "branch-interference growth",
            "form": "multi-source active constraint-amplitude mode",
            "fraction": l3,
            "status": "unresolved; amplitude reducible but scaling not removed",
        },
    ])
    law_table.to_csv(OUT/"v1500_minimal_law_table.csv", index=False)

    audit_rows = [
        {
            "component": "Empirical admissibility / UCI 498",
            "result": "strong near-miss / partial holdout, not full certification",
            "claim_status": "evidence_supporting_but_not_closed",
        },
        {
            "component": "Empirical admissibility / BPI2014",
            "result": "passed repaired full null suite after entropy + phase-order restoration",
            "claim_status": "evidence_candidate_pass",
        },
        {
            "component": "Weak-form geometry/source relation",
            "result": "passed hybrid global/branch recombination in tested regimes",
            "claim_status": "model_native_pass",
        },
        {
            "component": "Bianchi-like constraint conservation",
            "result": "passed valid stress retest at base scale",
            "claim_status": "model_native_pass",
        },
        {
            "component": "Resolution scaling",
            "result": "mostly converging/plateau with one L3 divergence",
            "claim_status": "partial_scaling_closure",
        },
        {
            "component": "Counterterm repair",
            "result": "reduced amplitude but failed to remove L3 divergence",
            "claim_status": "failed_as_law_closure_fix",
        },
    ]
    audit_df = pd.DataFrame(audit_rows)
    audit_df.to_csv(OUT/"v1500_integrated_audit_table.csv", index=False)

    summary = {
        "document_id": "V1500_INTEGRATED_LAW_CLOSURE_AUDIT",
        "status": "completed",
        "core_axiom": "No pruning-order trace, no empirical geometry claim.",
        "claim_boundary": "Model-native retained-history geometry/source law audit only; not physical GR, EFE, ADM, stress-energy, spacetime, or curvature.",
        "final_verdict": final_verdict,
        "closure_status": closure_status,
        "law_fractions": {
            "L1_dissipative_convergence": l1,
            "L2_irreducible_plateau": l2,
            "L1_plus_L2_closed_fraction": l12,
            "L3_branch_interference_growth_unresolved": l3,
        },
        "counterterm_status": {
            **counterterm_status,
            "mean_amplitude_reduction_fraction": amplitude_reduction,
            "max_amplitude_reduction_fraction": max_reduction,
        },
        "claims_allowed": claims_allowed,
        "claims_not_allowed": claims_not_allowed,
        "next_scientific_options": [
            "Stop and write a formal partial-law-closure report.",
            "Try to derive L3 analytically as an irreducible multi-source constraint-amplitude term.",
            "Test whether L3 appears in empirical multi-source traces, without claiming physical GR.",
            "Do not add another heuristic counterterm unless it is derived from an observable conservation law.",
        ],
    }
    (OUT/"v1500_summary.json").write_text(json.dumps(summary, indent=2))

    md = f"""# V1500 Integrated Law Closure Audit

## Final verdict

`{final_verdict}`

## Core axiom

> No pruning-order trace, no empirical geometry claim.

## What is closed

The current stack supports a **model-native retained-history geometry/source law structure**.

The strongest honest result is:

```text
L1 + L2 explain {100*l12:.1f}% of residual families.
L3 remains unresolved at {100*l3:.1f}%.
```

## Minimal law table

| Law | Name | Form | Status |
|---|---|---|---|
| L1 | Dissipative convergence | `R(N) = R_inf + a/N^p, p > 0` | Closed as model-native scaling family |
| L2 | Irreducible plateau | `R(N) ≈ R_plateau + bounded variation` | Closed as model-native residual floor |
| L3 | Branch-interference growth | multi-source active constraint-amplitude mode | Unresolved |

## Counterterm audit

V1499 tested an orthogonal branch-current counterterm.

It helped amplitude:

```text
mean amplitude reduction ≈ {None if amplitude_reduction is None else round(100*amplitude_reduction, 2)}%
max amplitude reduction ≈ {None if max_reduction is None else round(100*max_reduction, 2)}%
```

But it did **not** remove the L3 scaling divergence:

```text
baseline trend:    {counterterm_status["baseline_trend"]}
counterterm trend: {counterterm_status["counterterm_trend"]}
```

So the counterterm is **not** accepted as law closure.

## What can be claimed

{chr(10).join("- " + x for x in claims_allowed)}

## What cannot be claimed

{chr(10).join("- " + x for x in claims_not_allowed)}

## Scientific meaning

The work supports this narrower statement:

> Admissible retained histories can generate stable model-native geometry/source relations and constraint-like residual structure. Geometry alone is not sufficient; history/provenance/entropy order are necessary. Most residual behavior closes into convergence or plateau families, while one multi-source branch-interference mode remains unresolved.

## Next options

1. Stop and produce a formal partial-law-closure paper.
2. Derive L3 analytically rather than patching it.
3. Test L3 on empirical multi-source traces.
4. Avoid further heuristic counterterms unless derived from an observable conservation law.
"""
    (OUT/"V1500_INTEGRATED_LAW_CLOSURE_AUDIT_REPORT.md").write_text(md)

    print("=== V1500 INTEGRATED LAW CLOSURE AUDIT ===")
    print("Final verdict:", final_verdict)
    print("Closed fraction L1+L2:", round(l12, 4))
    print("Unresolved L3 fraction:", round(l3, 4))
    print("Counterterm mean amplitude reduction:", amplitude_reduction)
    print("Counterterm max amplitude reduction:", max_reduction)
    print("\nAllowed headline:")
    print("Admissible retained histories generate stable model-native geometry/source residual structure; 96% closes into convergence/plateau, while L3 remains unresolved.")
    print("\nWrote:")
    print(OUT/"v1500_summary.json")
    print(OUT/"v1500_minimal_law_table.csv")
    print(OUT/"v1500_integrated_audit_table.csv")
    print(OUT/"V1500_INTEGRATED_LAW_CLOSURE_AUDIT_REPORT.md")

if __name__ == "__main__":
    main()
