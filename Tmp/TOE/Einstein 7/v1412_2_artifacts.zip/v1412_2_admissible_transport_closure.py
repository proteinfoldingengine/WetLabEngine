# V1412.2 admissible transport closure
