# Cautious Report-Out Draft

The current synthetic-harness result is:

Transport appears necessary, but not sufficient.

When identity/source-order/continuity were preserved while transport was destroyed, validity did not survive.

When transport was preserved but integrity constraints were degraded, validity still did not survive.

So the best current candidate is not transport alone, identity alone, or continuity alone.

It is admissible transport:

transport + integrity constraints

This is not a GR claim, not an Einstein-equation claim, and not a physical spacetime claim. It is a synthetic graph recoverability result.
