# V1413 Work Order — Admissible Transport Invariance

## Goal
Test whether admissible transport is invariant under:
- graph relabeling
- graph family changes
- source-order transformations
- equivalent representation changes

## Why
V1412 supports admissible transport as necessary + integrity-constrained.
The next question is whether this condition is representation-invariant.

## Pass Condition
Admissible transport remains predictive under relabeled/isomorphic graph histories and held-out graph families.

## Fail Condition
Admissible transport depends on representation-specific labels or construction details.
