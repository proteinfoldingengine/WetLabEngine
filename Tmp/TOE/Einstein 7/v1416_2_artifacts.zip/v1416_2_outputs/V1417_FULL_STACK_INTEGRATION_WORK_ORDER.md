# V1417 Work Order — Full Stack Integration Test

## Candidate Stack

admissible transport
→ lineage retention
→ continuity / scalar-continuity diagnostics
→ H-like summaries
→ geometry-like summaries

## Goal

Test whether this ordered stack predicts held-out validity better than shuffled stacks.

## Required Tests

1. Integrated validity target combining:
   - transport/source-order validity
   - hidden lineage reconstruction
   - continuity stability

2. Shuffled alternatives:
   - lineage → transport → continuity
   - continuity → transport → lineage
   - H/geometry-first stack
   - identity-first-only stack

3. Held-out graph families.
4. Relabeling.
5. Leakage audits.

## Pass Condition

Candidate stack beats shuffled stacks across held-out families and leakage controls.

## Fail Condition

Any shuffled stack matches or beats candidate stack.
