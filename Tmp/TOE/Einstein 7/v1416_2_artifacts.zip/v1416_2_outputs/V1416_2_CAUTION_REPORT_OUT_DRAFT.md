# Cautious Report-Out Draft

The current synthetic graph result has sharpened.

Earlier work showed admissible transport is necessary but not sufficient for transport/source-order validity.

Then hidden-lineage tests revealed a separate lineage-retention layer.

The latest coupling tests suggest the direction is:

admissible transport → lineage retention

Cross-lag tests showed early admissible/transport signals predict later lineage retention better than early lineage predicts later admissible transport. Ablation tests strengthened this: destroying transport damaged later lineage retention, while destroying lineage did not damage admissible transport.

This is not a GR claim, not an Einstein-equation claim, and not a physical spacetime claim.

It is a synthetic graph result suggesting that retained source memory emerges downstream of admissible transport in this harness.
