# V1467 Work Order — Empirical Graph Pilot

## Goal
Test whether the direct geometry result survives outside designed synthetic graph fields.

## Required
- Choose one empirical or semi-empirical graph class.
- Define source-origin/recoverability labels without using geometry outputs.
- Compute topology-native geometry behavior.
- Run source-destroyed matched-amplitude null.
- No tuning after first run.

## Candidate datasets
- dependency graph / repair graph
- citation/provenance graph
- communication graph
- biological pathway graph
- transport network

## Pass
Recoverability/source-correspondent field beats matched source-destroyed null under topology-native direct geometry.

## Fail
Matched null reproduces the geometry behavior.
