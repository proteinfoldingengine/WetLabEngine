# Cautious Report-Out Draft

The current synthetic graph work supports a coupled first-layer structure.

Transport/admissibility and lineage retention both matter. However, the current evidence does not cleanly order them as transport→lineage or lineage→transport.

The safest stack is:

transport/admissibility + lineage retention
→ continuity
→ H-like summaries
→ geometry-like summaries

This is not a GR claim, not an Einstein-equation claim, and not a physical spacetime claim.

It is a synthetic graph result suggesting that the primitive layer may be a coupled admissibility block rather than a single scalar, geometry, or transport term.
