# V1418 Work Order — Minimal Coupled Admissibility Operator

## Goal

Formalize the first-layer block as a minimal two-component admissibility operator:

A_coupled = f(admissible_transport, lineage_retention)

## Hypothesis

Integrated validity requires both:
1. admissible transport
2. lineage retention

## Tests

1. Full coupled operator.
2. Remove transport component.
3. Remove lineage component.
4. Remove both.
5. Shuffled/null controls.

## Target

Integrated validity across:
- transport/source-order tasks
- hidden lineage reconstruction tasks
- continuity stability tasks

## Pass Condition

The full coupled operator beats either single-component ablation across held-out graph families and relabeling.

## Fail Condition

A single component matches full coupled performance.
