# V1417.2 full stack closure
