# V1433.0 theoretical source-coupled field derivation
