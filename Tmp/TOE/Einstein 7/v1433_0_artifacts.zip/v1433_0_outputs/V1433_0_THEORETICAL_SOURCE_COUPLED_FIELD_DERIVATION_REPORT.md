# V1433.0 — Theoretical Source-Coupled Field Derivation

## Status
Completed.

## Purpose

V1432 closed the prior source-coupled field branch as failed:

```text
Ω_s = exp(-0.35S + 0.12F + 0.30z(I_node))
```

V1433 does not tune that field.

Instead, it defines a new field mathematically before testing.

## Claim Boundary

Theoretical field derivation only.

No simulation result, physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

---

# Root Theorem

```text
Recoverability under pruning requires retained source-origin information.
```

Formal root:

```text
E_R ≤ ε ⇒ I_source > I_min
```

with:

```text
ε = 0.20
```

---

# Core Correction

The failed Ω_s construction added source information directly into Ω.

That was too ad hoc:

```text
Ω_s = exp(-0.35S + 0.12F + 0.30z(I_node))
```

The new approach is:

```text
derive a recoverability potential first,
then define Ω and flow from that potential.
```

---

# Proposed Field

Define:

```text
ρ_A(x) = accessibility density
i_s(x) = retained source-origin information density
ψ_A(x) = log(ρ_A(x) + δ)
```

Then define the recoverability potential:

```text
Φ_R(x) = -log(i_s(x) + δ) + λ_A ψ_A(x)
```

and:

```text
Ω_R(x) = exp(-Φ_R(x))
J_R(x) = -∇Φ_R(x)
```

---

# Interpretation

```text
low retained source-origin information raises Φ_R
accessibility density modulates Φ_R
J_R flows down recoverability potential gradients
Ω_R is a recoverability-response factor, not physical geometry
```

---

# Variational Motivation

Candidate action:

```text
S_R[Φ] = ∫ [ 1/2 |∇Φ|²
           + α Φ (I_min - i_s)_+
           + β Φ C_prune ] dx
```

where:

```text
(I_min - i_s)_+
```

penalizes local source-information deficit.

This is not yet a proved physical action. It is a model-native variational construction.

---

# Frozen Parameters for First Test

```text
δ = 1e-6
λ_A = 0.25
α = 1.0
β = 0.25
```

These must not be tuned after test results.

---

# Falsifiers

The field fails if:

```text
source-origin information is destroyed
but Φ_R / Ω_R / J_R diagnostics remain strong
```

or:

```text
shuffled i_s performs as well as true i_s
```

or:

```text
ordinary source-blind Ω outperforms Ω_R under retained vs destroyed source controls
```

or:

```text
recoverability succeeds while i_s ≤ I_min and Φ_R still appears valid
```

---

# What Is Not Claimed

```text
GR
Einstein equations
physical spacetime
full ADM
physical curvature
geometry as primitive
```

---

# Safe Statement

```text
V1433 defines a new model-native recoverability potential from retained source-origin information and accessibility density.
It is ready for a frozen falsification protocol, but it has not been tested yet.
```

---

# Next Step

```text
V1433.1 — freeze the test protocol for Φ_R / Ω_R / J_R.
```
