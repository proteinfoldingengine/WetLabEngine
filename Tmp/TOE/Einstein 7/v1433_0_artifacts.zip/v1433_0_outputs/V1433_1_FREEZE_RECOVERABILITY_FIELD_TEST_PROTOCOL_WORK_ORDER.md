# V1433.1 Work Order — Freeze Recoverability Field Test Protocol

## Goal
Freeze a test protocol for the new field:

Phi_R(x) = -log(i_s(x)+delta) + lambda_A log(rho_A(x)+delta)
Omega_R(x) = exp(-Phi_R(x))
J_R(x) = -grad(Phi_R(x))

## Fixed parameters
delta = 1e-6
lambda_A = 0.25
alpha = 1.0
beta = 0.25

## Must test
1. true i_s
2. shuffled i_s
3. source-destroyed controls
4. source-retained controls
5. ordinary source-blind Omega baseline

## Pass
Phi_R/Omega_R/J_R degrade under source-origin destruction and beat shuffled i_s and ordinary Omega baselines.

## Fail
Source-destroyed or shuffled controls perform as well as true source-retained field.

## No simulation until protocol is frozen.
