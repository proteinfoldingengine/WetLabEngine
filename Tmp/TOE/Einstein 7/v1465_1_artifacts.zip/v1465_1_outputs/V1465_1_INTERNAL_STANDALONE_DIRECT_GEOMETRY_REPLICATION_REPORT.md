# V1465.1 — Internal Standalone Direct Geometry Replication

## Status
Completed.

## Decision

```text
internal_standalone_replication_passed
```

## Replication Summary

```json
{
  "document_id": "V1465_0_DIRECT_GEOMETRY_REPLICATION",
  "seed": 146500,
  "resolution_harness": {
    "passed": true,
    "true_mean": 0.0738661669126155,
    "max_control": 0.0015566622180951295,
    "control_to_true_ratio": 0.02107408957494172,
    "resolution_cv": 0.027234267249846775,
    "by_family": {
      "recoverability_direct": {
        "mean_G_direct_resnorm": 0.0738661669126155,
        "max_G_direct_resnorm": 0.10666934663280243
      },
      "matched_random_field": {
        "mean_G_direct_resnorm": 0.00041409804022339027,
        "max_G_direct_resnorm": 0.01383679460416228
      },
      "smooth_spoof": {
        "mean_G_direct_resnorm": 0.0004929967984165607,
        "max_G_direct_resnorm": 0.007875599965824636
      },
      "shuffled_source": {
        "mean_G_direct_resnorm": 0.00036130812730752847,
        "max_G_direct_resnorm": 0.007850230248444974
      },
      "closure_disrupted": {
        "mean_G_direct_resnorm": 0.0015566622180951295,
        "max_G_direct_resnorm": 0.016657077729148442
      },
      "random_null": {
        "mean_G_direct_resnorm": 0.00010278770879935819,
        "max_G_direct_resnorm": 0.005202338316187993
      }
    },
    "by_resolution": {
      "10": {
        "mean_G_direct_resnorm": 0.07637413148892432
      },
      "14": {
        "mean_G_direct_resnorm": 0.07377534233623123
      },
      "18": {
        "mean_G_direct_resnorm": 0.07144902691269095
      }
    }
  },
  "topology_native_harness": {
    "passed": true,
    "aggregate_normalized_effect": 1.0,
    "topology_cv": 0.0,
    "all_pass": true,
    "topology_results": {
      "regular_grid": {
        "recoverability_mean": 0.43773664873548185,
        "best_control_family": "closure_disrupted",
        "best_control_mean": 0.02602187162391553,
        "effect_ratio": 16.82187411594007,
        "source_destroyed_ratio": 0.005951613992109874,
        "normalized_effect": 1.0,
        "pass": true
      },
      "ring_cycle": {
        "recoverability_mean": 0.4287345554947211,
        "best_control_family": "closure_disrupted",
        "best_control_mean": 0.029981415295572997,
        "effect_ratio": 14.30001056500249,
        "source_destroyed_ratio": 0.005721313747627888,
        "normalized_effect": 1.0,
        "pass": true
      },
      "tree": {
        "recoverability_mean": 0.4298100496900742,
        "best_control_family": "closure_disrupted",
        "best_control_mean": 0.03274061916067269,
        "effect_ratio": 13.127731261515812,
        "source_destroyed_ratio": 0.00536898513356,
        "normalized_effect": 1.0,
        "pass": true
      },
      "smallworld_modular": {
        "recoverability_mean": 0.436834587389686,
        "best_control_family": "closure_disrupted",
        "best_control_mean": 0.026718516066483237,
        "effect_ratio": 16.34950782020859,
        "source_destroyed_ratio": 0.005759185785138741,
        "normalized_effect": 1.0,
        "pass": true
      }
    }
  },
  "replication_passed": true
}
```

## Interpretation

The standalone script was copied into a clean output folder and executed as packaged.
