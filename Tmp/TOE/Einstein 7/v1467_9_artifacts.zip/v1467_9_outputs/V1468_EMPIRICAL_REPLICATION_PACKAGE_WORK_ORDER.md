# V1468 Work Order — Empirical Dependency Graph Replication Package

## Goal
Create standalone script to reproduce V1467.8.

## Include
- directed import graph extraction
- directed flow source residual
- degree/reach residualization
- closure coupling score
- degree_matched_source_destroyed null
- direction_destroyed null
- closure_source_decoupled null
- summary JSON and CSV outputs

## Pass
A clean run reproduces the V1467.8 empirical pilot pass.
