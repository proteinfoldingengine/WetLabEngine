# V1467.9 — Empirical Graph Pilot Closure

## Status
Completed.

## Decision

```text
empirical_dependency_graph_pilot_closed_under_directed_residual_closure_coupled_protocol
```

## Milestone Chain

| version   | test                                     | decision                                         | result                                                                | lesson                                                                                                      |
|:----------|:-----------------------------------------|:-------------------------------------------------|:----------------------------------------------------------------------|:------------------------------------------------------------------------------------------------------------|
| V1467.0   | first empirical dependency graph pilot   | empirical_dependency_graph_pilot_not_closed      | control/true=0.984334; source_destroyed/true=0.014032                 | source-destroyed null stayed low, but degree_only nearly matched recoverability.                            |
| V1467.1   | degree-centrality confound forensics     | degree_centrality_confound_confirmed             | source_quality degree R² = 1.000000                                   | old empirical source definition was effectively inverse degree.                                             |
| V1467.3   | degree-residual empirical pilot          | degree_residual_empirical_graph_pilot_not_closed | source_residual_collapsed=True; true=0.102939                         | degree residual score separated controls, but the source residual collapsed.                                |
| V1467.5   | directed flow source empirical pilot     | directed_flow_source_empirical_pilot_not_closed  | source_residual_std=0.187050; control/true=0.300843                   | directed source survived residualization, but closure_disrupted remained too high.                          |
| V1467.6   | closure-disruption forensics             | closure_disruption_failure_explained             | closure_to_true=0.300843                                              | closure null preserved geodesic and curvature; closure needed explicit coupling.                            |
| V1467.8   | closure-source decoupled empirical pilot | closure_source_decoupled_empirical_pilot_passed  | true=0.083961; control/true=0.011611; closure_decoupled/true=0.011278 | empirical directed dependency-flow pilot passed under degree residualization and closure-coupling controls. |

## Final Passing Result: V1467.8

```text
true mean native score: 0.08396145
max control mean: 0.00097490
control / true ratio: 0.01161126
degree_matched / true ratio: 0.00008642
direction_destroyed / true ratio: 0.00000000
closure_decoupled / true ratio: 0.01127782
closure coupling true: 0.98937379
```

## What Was Repaired

```text
degree/centrality confound
inverse-degree source definition
collapsed source residual
weak closure-disruption null
missing closure-coupling term
```

## What Is Now Supported

```text
On the local Python stdlib directed import/dependency graph,
a directed dependency-flow source residual produced an empirical geometry signal
that survived degree/reach residualization, direction-destroyed nulls,
degree-matched source-destroyed nulls, and closure-source decoupled nulls.
```

## Claim Boundary

```text
This is one empirical/semi-empirical graph pilot.
It is not universal validation.
It requires replication on unrelated graph classes.
```

## Next

```text
V1468 — external-style replication package for empirical dependency graph pilot
```
