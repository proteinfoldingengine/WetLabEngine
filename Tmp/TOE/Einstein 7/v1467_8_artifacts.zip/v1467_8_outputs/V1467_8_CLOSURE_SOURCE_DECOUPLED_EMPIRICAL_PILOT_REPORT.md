# V1467.8 — Closure-Source Decoupled Empirical Pilot

## Status
Completed.

## Dataset

```text
local Python stdlib directed import/dependency graph
nodes: 508
directed edges: 1774
```

## Updated Score

```text
G_empirical =
geodesic
× curvature
× continuity
× correspondence
× closure_coupling
× degree_independence
```

## Results

```text
source residual std: 0.18705024
closure coupling true: 0.98937379
true mean native score: 0.08396145
max control mean: 0.00097490
control / true ratio: 0.01161126
degree_matched / true ratio: 0.00008642
direction_destroyed / true ratio: 0.00000000
closure_decoupled / true ratio: 0.01127782
```

## Decision

```text
closure_source_decoupled_empirical_pilot_passed
```

## By Family

```json
{
  "residual_recoverability": {
    "mean_native_score": 0.08396145464848132,
    "max_native_score": 0.08396145464848132,
    "mean_geodesic": 0.8076923073816568,
    "mean_curvature": 0.1635144620131163,
    "mean_continuity": 0.7579251914572677,
    "mean_correspondence": 0.8477954736495962,
    "mean_closure_coupling": 0.9893737924231918,
    "mean_degree_independence": 0.9999999999999993
  },
  "degree_matched_source_destroyed": {
    "mean_native_score": 7.255645922725766e-06,
    "max_native_score": 0.00016529397197629562,
    "mean_geodesic": 0.1991644356999781,
    "mean_curvature": 0.036982431622031776,
    "mean_continuity": 0.7625782104862764,
    "mean_correspondence": 0.03436180591584938,
    "mean_closure_coupling": 0.033855279097971105,
    "mean_degree_independence": 0.9759647431062688
  },
  "direction_destroyed_null": {
    "mean_native_score": 0.0,
    "max_native_score": 0.0,
    "mean_geodesic": 0.9999999995,
    "mean_curvature": 0.0,
    "mean_continuity": 0.7332109289213973,
    "mean_correspondence": 0.3333333333333333,
    "mean_closure_coupling": 1.0,
    "mean_degree_independence": 0.999999999999999
  },
  "closure_source_decoupled_null": {
    "mean_native_score": 0.000946902270901927,
    "max_native_score": 0.004437423997194331,
    "mean_geodesic": 0.8076923073816568,
    "mean_curvature": 0.1635144620131163,
    "mean_continuity": 0.7640817062937454,
    "mean_correspondence": 0.25829882206602495,
    "mean_closure_coupling": 0.03527855997655395,
    "mean_degree_independence": 0.9887745628520013
  },
  "closure_disrupted_legacy": {
    "mean_native_score": 0.0009748979746557952,
    "max_native_score": 0.005652584267083598,
    "mean_geodesic": 0.8076923073816568,
    "mean_curvature": 0.1635144620131163,
    "mean_continuity": 0.7565466994749629,
    "mean_correspondence": 0.2596600415200116,
    "mean_closure_coupling": 0.036373359265383313,
    "mean_degree_independence": 0.9875936882728744
  },
  "degree_only": {
    "mean_native_score": 1.1841396436644168e-16,
    "max_native_score": 1.1841396436644168e-16,
    "mean_geodesic": 0.9999999997868853,
    "mean_curvature": 0.15264702378984332,
    "mean_continuity": 0.7138086179340122,
    "mean_correspondence": 1.0,
    "mean_closure_coupling": 0.889876787016882,
    "mean_degree_independence": 1.2212453270876722e-15
  },
  "random_null": {
    "mean_native_score": 4.5522635687432295e-06,
    "max_native_score": 0.00015911981231205504,
    "mean_geodesic": 0.1116684659341295,
    "mean_curvature": 0.03509707679248749,
    "mean_continuity": 0.7229747008672225,
    "mean_correspondence": 0.034765376621106056,
    "mean_closure_coupling": 0.0359582761968077,
    "mean_degree_independence": 0.9641567971048075
  }
}
```
