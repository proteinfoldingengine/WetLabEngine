# V1468.1 — Internal Standalone Empirical Replication

## Status
Completed.

## Decision

```text
internal_standalone_empirical_replication_passed
```

## Replication Summary

```json
{
  "document_id": "V1468_0_EMPIRICAL_DEPENDENCY_GRAPH_REPLICATION",
  "seed": 146800,
  "nodes": 508,
  "directed_edges": 1774,
  "source_residual_std": 0.18705023865429202,
  "degree_residual_r2": {
    "source_raw": 0.041344237668861084,
    "recover_raw": 0.26234980033744626,
    "closure_raw": 0.18755869463118968
  },
  "true_mean_native_score": 0.08396145464848132,
  "max_control_mean_native_score": 0.0009382810290683484,
  "control_to_true_ratio": 0.011175140223397079,
  "degree_matched_to_true_ratio": 0.00010837073645785005,
  "direction_destroyed_to_true_ratio": 0.0,
  "closure_decoupled_to_true_ratio": 0.011175140223397079,
  "closure_coupling_true": 0.9893737924231918,
  "by_family": {
    "residual_recoverability": {
      "mean_native_score": 0.08396145464848132,
      "max_native_score": 0.08396145464848132,
      "mean_geodesic": 0.8076923073816568,
      "mean_curvature": 0.1635144620131163,
      "mean_continuity": 0.7579251914572677,
      "mean_correspondence": 0.8477954736495962,
      "mean_closure_coupling": 0.9893737924231918,
      "mean_degree_independence": 0.9999999999999993
    },
    "degree_matched_source_destroyed": {
      "mean_native_score": 9.09896467443667e-06,
      "max_native_score": 0.00023031916727410658,
      "mean_geodesic": 0.21539392081159783,
      "mean_curvature": 0.03473896825291812,
      "mean_continuity": 0.7626262509574853,
      "mean_correspondence": 0.035236521595671894,
      "mean_closure_coupling": 0.03428262541827321,
      "mean_degree_independence": 0.9762033013910294
    },
    "direction_destroyed_null": {
      "mean_native_score": 0.0,
      "max_native_score": 0.0,
      "mean_geodesic": 0.9999999995,
      "mean_curvature": 0.0,
      "mean_continuity": 0.7332109289213973,
      "mean_correspondence": 0.3333333333333333,
      "mean_closure_coupling": 1.0,
      "mean_degree_independence": 0.999999999999999
    },
    "closure_source_decoupled_null": {
      "mean_native_score": 0.0009382810290683484,
      "max_native_score": 0.0039768290436784206,
      "mean_geodesic": 0.8076923073816568,
      "mean_curvature": 0.1635144620131163,
      "mean_continuity": 0.7641945103040629,
      "mean_correspondence": 0.2582667187756468,
      "mean_closure_coupling": 0.034859524529081184,
      "mean_degree_independence": 0.9884953104933952
    },
    "degree_only": {
      "mean_native_score": 1.1841396436644168e-16,
      "max_native_score": 1.1841396436644168e-16,
      "mean_geodesic": 0.9999999997868853,
      "mean_curvature": 0.15264702378984332,
      "mean_continuity": 0.7138086179340122,
      "mean_correspondence": 1.0,
      "mean_closure_coupling": 0.889876787016882,
      "mean_degree_independence": 1.2212453270876722e-15
    },
    "random_null": {
      "mean_native_score": 4.426303343602229e-06,
      "max_native_score": 0.00013621853426500356,
      "mean_geodesic": 0.12140454466731651,
      "mean_curvature": 0.03647371050514733,
      "mean_continuity": 0.7235028147770894,
      "mean_correspondence": 0.03675918866841036,
      "mean_closure_coupling": 0.03599056975243144,
      "mean_degree_independence": 0.9639236368279629
    }
  },
  "replication_passed": true
}
```

## Interpretation

The standalone empirical dependency-graph replication script was copied into a clean output folder and executed as packaged.
