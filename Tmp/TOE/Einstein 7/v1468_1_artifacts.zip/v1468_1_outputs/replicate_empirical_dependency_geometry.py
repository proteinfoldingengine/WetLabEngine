
"""
V1468.0 — Empirical Dependency Graph Replication Package

Reproduces V1467.8:
- directed import graph extraction from local Python stdlib
- directed flow source residual
- degree/reach residualization
- closure coupling score
- degree_matched_source_destroyed null
- direction_destroyed null
- closure_source_decoupled null

Run:
    python replicate_empirical_dependency_geometry.py

Outputs:
    v1468_empirical_replication_summary.json
    v1468_empirical_trials.csv
"""

from __future__ import annotations
from pathlib import Path
import ast, json, random, statistics, csv
from collections import deque
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

SEED = 146800
random.seed(SEED)
np.random.seed(SEED)

ROOT = Path("/usr/lib/python3.13")
MAX_FILES = 650

def clamp(x: float) -> float:
    return max(0.0, min(1.0, float(x)))

def rescale01(x):
    x = np.asarray(x, dtype=float)
    mn, mx = float(np.min(x)), float(np.max(x))
    if mx - mn < 1e-12:
        return np.ones_like(x) * 0.5
    return (x - mn) / (mx - mn)

def bfs(edges, src):
    dist = [-1] * len(edges)
    dist[src] = 0
    q = deque([src])
    while q:
        u = q.popleft()
        for v in edges[u]:
            if dist[v] < 0:
                dist[v] = dist[u] + 1
                q.append(v)
    return dist

def safe_corr(a, b) -> float:
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    if np.std(a) < 1e-12 or np.std(b) < 1e-12:
        return 0.0
    return float(abs(np.corrcoef(a, b)[0, 1]))

def extract_directed_import_graph():
    py_files = []
    for p in ROOT.rglob("*.py"):
        parts = set(p.parts)
        if "__pycache__" in parts or "site-packages" in parts or "dist-packages" in parts or "test" in parts or "tests" in parts:
            continue
        py_files.append(p)
        if len(py_files) >= MAX_FILES:
            break

    module_names = {}
    for p in py_files:
        rel = p.relative_to(ROOT)
        name = ".".join(rel.with_suffix("").parts)
        if name.endswith(".__init__"):
            name = name[:-9]
        module_names[p] = name

    all_names = sorted(set(module_names.values()))
    name_to_idx = {name: i for i, name in enumerate(all_names)}
    idx_to_name = {i: name for name, i in name_to_idx.items()}

    n0 = len(all_names)
    out_edges = [set() for _ in range(n0)]
    in_edges = [set() for _ in range(n0)]

    for p, mod in module_names.items():
        u = name_to_idx[mod]
        try:
            tree = ast.parse(p.read_text(errors="ignore"))
        except Exception:
            continue
        for node in ast.walk(tree):
            targets = []
            if isinstance(node, ast.Import):
                targets.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                targets.append(node.module)
            for t in targets:
                candidates = [t]
                if "." in t:
                    candidates.append(t.split(".")[0])
                for c in candidates:
                    if c in name_to_idx:
                        v = name_to_idx[c]
                        if v != u:
                            out_edges[u].add(v)
                            in_edges[v].add(u)
                        break

    undirected = [set() for _ in range(n0)]
    for u in range(n0):
        for v in out_edges[u] | in_edges[u]:
            undirected[u].add(v)
            undirected[v].add(u)

    seen = set()
    components = []
    for s in range(n0):
        if s in seen or not undirected[s]:
            continue
        q = deque([s])
        seen.add(s)
        comp = []
        while q:
            u = q.popleft()
            comp.append(u)
            for v in undirected[u]:
                if v not in seen:
                    seen.add(v)
                    q.append(v)
        components.append(comp)

    largest = max(components, key=len)
    old_to_new = {old: i for i, old in enumerate(largest)}
    names = {old_to_new[o]: idx_to_name[o] for o in largest}
    n = len(largest)

    out = [set() for _ in range(n)]
    inn = [set() for _ in range(n)]
    undir = [set() for _ in range(n)]
    for old in largest:
        u = old_to_new[old]
        for v_old in out_edges[old]:
            if v_old in old_to_new:
                v = old_to_new[v_old]
                out[u].add(v)
                inn[v].add(u)
                undir[u].add(v)
                undir[v].add(u)
        for v_old in in_edges[old]:
            if v_old in old_to_new:
                v = old_to_new[v_old]
                inn[u].add(v)
                out[v].add(u)
                undir[u].add(v)
                undir[v].add(u)

    return names, [list(e) for e in out], [list(e) for e in inn], [list(e) for e in undir]

def build_residual_fields(out, inn, undir):
    n = len(out)
    out_reach, in_reach = [], []
    for u in range(n):
        d_out = bfs(out, u)
        d_in = bfs(inn, u)
        out_reach.append(sum(1 for d in d_out if d >= 0) / n)
        in_reach.append(sum(1 for d in d_in if d >= 0) / n)

    out_deg = np.array([len(out[u]) for u in range(n)], dtype=float)
    in_deg = np.array([len(inn[u]) for u in range(n)], dtype=float)
    total_deg = out_deg + in_deg
    undirected_reach = np.array([sum(1 for d in bfs(undir, u) if d >= 0) / n for u in range(n)])

    source_raw = rescale01(np.array(in_reach) - 0.65 * rescale01(out_deg) - 0.35 * rescale01(out_reach))
    recover_raw = rescale01(0.55 * np.array(in_reach) + 0.25 * np.array(out_reach) + 0.20 * rescale01(total_deg))
    closure_raw = rescale01(0.55 * recover_raw + 0.45 * source_raw)

    x = np.column_stack([rescale01(total_deg), undirected_reach])

    def residualize(y):
        model = LinearRegression().fit(x, y)
        pred = model.predict(x)
        return y - pred, float(r2_score(y, pred))

    source_res, source_r2 = residualize(source_raw)
    recover_res, recover_r2 = residualize(recover_raw)
    closure_res, closure_r2 = residualize(closure_raw)

    fields = {
        "source_ch": rescale01(source_res),
        "recover_ch": rescale01(recover_res),
        "closure_ch": rescale01(closure_res),
        "source_residual_std": float(np.std(source_res)),
        "total_deg": total_deg,
        "undirected_reach": undirected_reach,
        "degree_residual_r2": {
            "source_raw": source_r2,
            "recover_raw": recover_r2,
            "closure_raw": closure_r2,
        },
    }
    return fields

def empirical_score(src, rec, clo, out, inn, total_deg):
    n = len(out)
    high_src = list(np.argsort(src)[-max(5, n // 10):])
    high_rec = set(np.argsort(rec)[-max(5, n // 10):])
    low_rec = set(np.argsort(rec)[:max(5, n // 10)])

    def avg_min(B):
        vals = []
        for a in high_src[:30]:
            d = bfs(inn, a)
            ds = [d[b] for b in B if d[b] >= 0]
            if ds:
                vals.append(min(ds))
        return statistics.mean(vals) if vals else n

    d_good = avg_min(high_rec)
    d_bad = avg_min(low_rec)
    geodesic = clamp((d_bad - d_good) / (d_bad + 1e-9))

    contrasts, srcs = [], []
    for i in range(n):
        nbrs = list(set(out[i]) | set(inn[i]))
        if nbrs:
            vals = [rec[j] for j in nbrs] + [rec[i]]
            contrasts.append(max(vals) - min(vals))
            srcs.append(src[i])
    curvature = clamp(safe_corr(contrasts, srcs))

    residuals = []
    for i in range(n):
        denom = max(1, len(out[i]) + len(inn[i]))
        div = (sum(rec[j] - rec[i] for j in out[i]) - sum(rec[j] - rec[i] for j in inn[i])) / denom
        pressure = 0.45 * clo[i] + 0.35 * src[i] - 0.30 * rec[i]
        residuals.append(abs(div - pressure))
    continuity = clamp(1 - statistics.mean(residuals) / 1.2)

    correspondence = (safe_corr(src, rec) + safe_corr(src, clo) + safe_corr(rec, clo)) / 3
    closure_coupling = safe_corr(clo, src * rec)
    degree_correlation = (safe_corr(src, total_deg) + safe_corr(rec, total_deg) + safe_corr(clo, total_deg)) / 3
    degree_independence = clamp(1 - degree_correlation)

    native_score = geodesic * curvature * continuity * correspondence * closure_coupling * degree_independence
    return {
        "geodesic": geodesic,
        "curvature": curvature,
        "continuity": continuity,
        "correspondence": correspondence,
        "closure_coupling": closure_coupling,
        "degree_correlation": degree_correlation,
        "degree_independence": degree_independence,
        "native_score": native_score,
    }

def make_fields(family, base, total_deg, undirected_reach):
    src = base["source_ch"].copy()
    rec = base["recover_ch"].copy()
    clo = base["closure_ch"].copy()
    if family == "residual_recoverability":
        pass
    elif family == "degree_matched_source_destroyed":
        np.random.shuffle(src)
        np.random.shuffle(clo)
    elif family == "direction_destroyed_null":
        undirected = rescale01(undirected_reach)
        src = undirected.copy()
        rec = base["recover_ch"].copy()
        clo = rescale01(0.5 * undirected + 0.5 * rec)
        np.random.shuffle(src)
    elif family == "closure_source_decoupled_null":
        np.random.shuffle(clo)
    elif family == "degree_only":
        degree = rescale01(total_deg)
        src = degree.copy()
        rec = degree.copy()
        clo = degree.copy()
    elif family == "random_null":
        n = len(src)
        src = np.random.random(n)
        rec = np.random.random(n)
        clo = np.random.random(n)
    else:
        raise ValueError(f"Unknown family: {family}")
    return src, rec, clo

def run():
    names, out, inn, undir = extract_directed_import_graph()
    base = build_residual_fields(out, inn, undir)
    total_deg = base["total_deg"]
    families = [
        "residual_recoverability",
        "degree_matched_source_destroyed",
        "direction_destroyed_null",
        "closure_source_decoupled_null",
        "degree_only",
        "random_null",
    ]
    rows = []
    for _ in range(350):
        for fam in families:
            src, rec, clo = make_fields(fam, base, total_deg, base["undirected_reach"])
            rows.append({"family": fam, **empirical_score(src, rec, clo, out, inn, total_deg)})

    by_family = {}
    for fam in families:
        vals = [r for r in rows if r["family"] == fam]
        by_family[fam] = {
            "mean_native_score": statistics.mean(v["native_score"] for v in vals),
            "max_native_score": max(v["native_score"] for v in vals),
            "mean_geodesic": statistics.mean(v["geodesic"] for v in vals),
            "mean_curvature": statistics.mean(v["curvature"] for v in vals),
            "mean_continuity": statistics.mean(v["continuity"] for v in vals),
            "mean_correspondence": statistics.mean(v["correspondence"] for v in vals),
            "mean_closure_coupling": statistics.mean(v["closure_coupling"] for v in vals),
            "mean_degree_independence": statistics.mean(v["degree_independence"] for v in vals),
        }

    true_mean = by_family["residual_recoverability"]["mean_native_score"]
    max_control = max(v["mean_native_score"] for k, v in by_family.items() if k != "residual_recoverability")
    ratio = max_control / (true_mean + 1e-12)
    degree_matched_ratio = by_family["degree_matched_source_destroyed"]["mean_native_score"] / (true_mean + 1e-12)
    direction_ratio = by_family["direction_destroyed_null"]["mean_native_score"] / (true_mean + 1e-12)
    closure_decoupled_ratio = by_family["closure_source_decoupled_null"]["mean_native_score"] / (true_mean + 1e-12)
    closure_coupling_true = by_family["residual_recoverability"]["mean_closure_coupling"]

    passed = (
        base["source_residual_std"] > 1e-3
        and closure_coupling_true > 0.05
        and true_mean > 0
        and ratio < 0.20
        and degree_matched_ratio < 0.20
        and direction_ratio < 0.20
        and closure_decoupled_ratio < 0.20
    )

    with open("v1468_empirical_trials.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    with open("v1468_graph_nodes.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["idx", "module"])
        writer.writeheader()
        for i, name in names.items():
            writer.writerow({"idx": i, "module": name})

    summary = {
        "document_id": "V1468_0_EMPIRICAL_DEPENDENCY_GRAPH_REPLICATION",
        "seed": SEED,
        "nodes": len(out),
        "directed_edges": sum(len(e) for e in out),
        "source_residual_std": base["source_residual_std"],
        "degree_residual_r2": base["degree_residual_r2"],
        "true_mean_native_score": true_mean,
        "max_control_mean_native_score": max_control,
        "control_to_true_ratio": ratio,
        "degree_matched_to_true_ratio": degree_matched_ratio,
        "direction_destroyed_to_true_ratio": direction_ratio,
        "closure_decoupled_to_true_ratio": closure_decoupled_ratio,
        "closure_coupling_true": closure_coupling_true,
        "by_family": by_family,
        "replication_passed": bool(passed),
    }
    with open("v1468_empirical_replication_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))

if __name__ == "__main__":
    run()
