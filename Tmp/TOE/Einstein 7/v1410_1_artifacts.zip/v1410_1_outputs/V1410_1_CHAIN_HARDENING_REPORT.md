# V1410.1 — Chain Hardening

## Status
Completed.

## Purpose
Test proposed chain across multiple recoverability/residual targets.

## Claim Boundary
Synthetic graph recoverability diagnostics only. No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

## Mean by Chain

| chain                          |   mean_auc |   min_auc |   max_auc |
|:-------------------------------|-----------:|----------:|----------:|
| admissible_identity_continuity |   0.757256 |  0.546836 |  0.928114 |
| continuity_transport_identity  |   0.756731 |  0.57932  |  0.899178 |
| identity_admissible_continuity |   0.75573  |  0.545455 |  0.929233 |
| continuity_identity_transport  |   0.755443 |  0.576838 |  0.901284 |
| transport_identity_continuity  |   0.755028 |  0.539813 |  0.931442 |
| identity_transport_continuity  |   0.752266 |  0.549127 |  0.918241 |

## Winners by Target

| target                    | chain                          | order                                |   auc_best |
|:--------------------------|:-------------------------------|:-------------------------------------|-----------:|
| valid_rec_resid_identity  | identity_transport_continuity  | identity -> transport -> continuity  |   0.797775 |
| valid_rec_resid_joint     | continuity_transport_identity  | continuity -> transport -> identity  |   0.57932  |
| valid_rec_resid_transport | admissible_identity_continuity | admissible -> identity -> continuity |   0.790698 |
| valid_recoverable         | transport_identity_continuity  | transport -> identity -> continuity  |   0.931442 |

## Decision

```text
chain_ordering_supported
```

## Interpretation
If the proposed chain is within tolerance of the best mean chain across residual targets, the ordering remains provisionally supported.
