# V1405.3 Work Order — Scalar-Continuity Compression

## Question

Can H and continuity be compressed into one scalar-continuity diagnostic?

Candidate:

S_CH = f(H, continuity)

## Test

Compare:

1. Helmholtz only
2. Helmholtz + H
3. Helmholtz + continuity
4. Helmholtz + H + continuity
5. Helmholtz + S_CH

## Goal

If Helmholtz + S_CH matches Helmholtz + H + continuity, then H and continuity become one semi-primitive diagnostic layer.
