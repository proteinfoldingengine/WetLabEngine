# V1405.2 — Semi-Primitive Layer Decision

## Status
Completed.

## Purpose

V1405.0–V1405.1 tested whether the stack can compress to Helmholtz current alignment alone.

It cannot fully compress.

V1405.2 decides which downstream diagnostic layers must be retained as semi-primitive working layers.

## Claim Boundary

Synthetic recoverability diagnostics only.

No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

## Stack Comparison

| candidate_stack            |   mean_auc |   lift_vs_base |   gap_to_full |
|:---------------------------|-----------:|---------------:|--------------:|
| Helmholtz only             |   0.91608  |      0         |   0.0838117   |
| Helmholtz + continuity     |   0.941003 |      0.0249228 |   0.0588889   |
| Helmholtz + H              |   0.998164 |      0.0820833 |   0.0017284   |
| Helmholtz + continuity + H |   0.999799 |      0.0837191 |   9.25926e-05 |
| Full stack                 |   0.999892 |      0.0838117 |   0           |

## Decision

```text
minimal_working_stack_helmholtz_plus_H
```

Minimal working stack:

```text
['Helmholtz current alignment', 'H diagnostic']
```

## Interpretation

Helmholtz current alignment is the core propagation law candidate.

But:

```text
Helmholtz only AUC ≈ 0.9161
```

is materially below:

```text
full stack AUC ≈ 0.9999
```

The key lift comes from H:

```text
Helmholtz + H AUC ≈ 0.9982
```

Continuity + H reaches essentially full-stack performance:

```text
Helmholtz + continuity + H AUC ≈ 0.9998
```

Therefore the current minimal working stack is:

```text
identity preservation
+
ordered propagation
+
Helmholtz-constrained current alignment
+
H diagnostic
```

with continuity retained as a supporting diagnostic because it closes the remaining gap.

Geometry proxies are not needed as primitive/semi-primitive layers.

## Updated Stack

```text
identity preservation
+
ordered propagation
+
Helmholtz-constrained current alignment
+
H diagnostic
+
continuity diagnostic

→ geometry-like summaries downstream
```

## Next Step

V1405.3 should test whether H and continuity can be replaced by one combined scalar-continuity diagnostic:

```text
S_CH = f(H, continuity)
```

If yes, the stack compresses to:

```text
Helmholtz current alignment + scalar-continuity diagnostic
```
