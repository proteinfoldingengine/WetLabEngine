# V1405.2 semi-primitive layer decision
print("Artifacts in /mnt/data/v1405_2_outputs")
