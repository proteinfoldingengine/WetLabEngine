# V1447.2 — Source-Conditioned Geometry Replication Closure

## Status
Completed.

## Claim Boundary
Replication closure only.

No physical GR, Einstein equations, full ADM derivation, actual Bianchi identity, physical spacetime, or physical curvature is claimed.

## Decision

```text
source_conditioned_geometry_replication_package_internally_validated
```

## Evidence

| version   | test                                            | result                                                                    | meaning                                                       | numbers                                                                                                    |
|:----------|:------------------------------------------------|:--------------------------------------------------------------------------|:--------------------------------------------------------------|:-----------------------------------------------------------------------------------------------------------|
| V1447.0   | Source-conditioned geometry replication package | Created standalone replication script, README, and expected summary JSON. | Patched G_legit can be rerun outside the prior notebook flow. | nan                                                                                                        |
| V1447.1   | Internal replication check                      | Standalone script reproduced patched source-conditioned geometry result.  | Replication package is internally valid.                      | trials=49500; true_mean=0.110977; spoof_mean=0.000207; max_spoof=0.044629; spoof_rate=0.000000; pass=True. |

## What Is Supported

```text
A standalone patched G_legit replication package was created.
The standalone script reran successfully.
The internal rerun reproduced the source-conditioned anti-spoof geometry result.
The result remains bounded to synthetic diagnostics.
```

## What Is Not Supported

```text
external independent replication
physical geometry
GR / Einstein equations / physical spacetime / physical curvature / full ADM
actual Bianchi identity
universal proof of geometry emergence
```

## Safe Scientific Statement

```text
The patched source-conditioned geometry legitimacy metric has a standalone replication package
and passed internal rerun,
but still awaits external independent replication.
```

## Current Hierarchy

```text
source-origin information
→ source admissibility
→ basic recoverability
→ B-like closure admissibility
→ coordinated source-flow recoverability
→ source-conditioned geometry legitimacy
```

## Next Step

```text
V1448 — manuscript/report update integrating source-conditioned geometry legitimacy
with the two-level admissibility hierarchy.
```
