# V1405.0 irreducible stack compression baseline
print("Artifacts in /mnt/data/v1405_0_outputs")
