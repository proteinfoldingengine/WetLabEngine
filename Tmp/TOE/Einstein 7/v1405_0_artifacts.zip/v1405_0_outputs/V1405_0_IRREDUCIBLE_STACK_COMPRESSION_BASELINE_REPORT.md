# V1405.0 — Irreducible Stack Compression Baseline

## Status
Completed.

## Purpose

Test whether the working stack can be compressed to:

```text
identity
+
ordered propagation
+
Helmholtz-constrained current alignment
```

with:

```text
continuity
H
geometry-like summaries
```

treated as downstream diagnostics, not primitive layers.

## Claim Boundary

Synthetic recoverability diagnostics only.

No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

## Aggregate Leave-Family-Out Scores

| feature_set                  |   mean_test_auc |   min_test_auc |   max_test_auc |   std_test_auc |   mean_train_auc |   n_features |
|:-----------------------------|----------------:|---------------:|---------------:|---------------:|-----------------:|-------------:|
| full_stack                   |        0.999892 |       0.99946  |       1        |    0.000241551 |         0.99994  |           12 |
| compressed_plus_continuity_H |        0.999799 |       0.998997 |       1        |    0.000448594 |         0.999868 |            7 |
| compressed_plus_H            |        0.998164 |       0.99159  |       1        |    0.0036817   |         0.996428 |            6 |
| continuity_H_only            |        0.967052 |       0.946219 |       0.998611 |    0.0227219   |         0.968943 |            2 |
| compressed_plus_continuity   |        0.941003 |       0.866821 |       0.981713 |    0.0496676   |         0.942751 |            6 |
| compressed_helmholtz_only    |        0.91608  |       0.809645 |       0.972917 |    0.0715516   |         0.916577 |            5 |
| geometry_only                |        0.868765 |       0.761034 |       0.936574 |    0.0707049   |         0.868144 |            5 |

## Compression Decision

```text
compressed mean AUC:      0.9161
full stack mean AUC:      0.9999
full - compressed delta:  0.0838

decision: compressed_stack_partially_sufficient
```

## Interpretation

If compressed Helmholtz-only performance is close to full stack, then the irreducible stack is likely:

```text
identity + ordered propagation + Helmholtz current alignment
```

and continuity/H/geometry should remain downstream diagnostics.

If adding continuity/H/geometry materially improves prediction, one of those layers may need semi-primitive status.

## Next Step

V1405.1 should test downstream reconstruction from the compressed stack:
- predict continuity
- predict H
- predict raw geometry proxies
- test residual validity signals
