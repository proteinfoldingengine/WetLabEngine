# V1465.2 — Direct Geometry Replication Closure

## Status
Completed.

## Decision

```text
direct_geometry_replication_internally_validated
```

## Evidence

| version   | test                                    | decision                                    | key_result                                                              | meaning                                                      |
|:----------|:----------------------------------------|:--------------------------------------------|:------------------------------------------------------------------------|:-------------------------------------------------------------|
| V1465.0   | Standalone replication package creation | direct_geometry_replication_package_created | Created replicate_direct_geometry.py, README.md, expected_summary.json. | Direct geometry work is no longer notebook-dependent.        |
| V1465.1   | Internal standalone replication run     | internal_standalone_replication_passed      | resolution_pass=True; topology_pass=True; replication_passed=True       | Standalone package reproduced both direct geometry closures. |

## Standalone Replication Results

### Resolution Harness

```text
passed: True
true mean: 0.07386617
max control: 0.00155666
control / true ratio: 0.02107409
resolution CV: 0.02723427
```

### Topology-Native Harness

```text
passed: True
all topologies pass: True
aggregate normalized effect: 1.00000000
topology CV: 0.00000000
```

## What Is Supported

```text
A standalone replication package was created.
The package reproduced the resolution-normalized corrected direct graph result.
The package reproduced the topology-native direct geometry result.
The topology-native result survived source_destroyed_matched_amplitude null controls.
The direct geometry branch is now internally reproducible from a clean script.
```

## What Is Still Needed

```text
external independent rerun outside this runtime
full integrated theorem/report
concise falsifiable claim
additional non-synthetic or empirical graph tests
```

## Current Status

```text
internal_replication_closed_not_external_report_ready
```

## Next

```text
V1466 — integrated theorem/report draft for emergent direct geometry from recoverability
```
