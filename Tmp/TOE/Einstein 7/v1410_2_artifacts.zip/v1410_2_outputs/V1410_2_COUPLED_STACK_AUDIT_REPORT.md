# V1410.2 — Coupled Stack Audit

## Status
Completed.

## Purpose
V1410.1 showed no single causal chain dominates strongly. V1410.2 tests whether the better interpretation is a coupled stack:

```text
identity + admissible/transport + continuity
```

rather than a strict one-way chain.

## Claim Boundary
Synthetic graph recoverability diagnostics only. No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

## Mean Scores

| score                       |   mean_auc |   min_auc |   max_auc |
|:----------------------------|-----------:|----------:|----------:|
| continuity                  |   0.755399 |  0.668674 |  0.805546 |
| identity                    |   0.740834 |  0.644056 |  0.873943 |
| identity_transport_couple   |   0.73095  |  0.518451 |  0.902632 |
| coupled_residual_stack      |   0.730846 |  0.512781 |  0.89947  |
| coupled_product             |   0.708131 |  0.523193 |  0.825001 |
| admissible                  |   0.704191 |  0.522874 |  0.823956 |
| transport                   |   0.671829 |  0.540449 |  0.79121  |
| coupled_sum                 |   0.656722 |  0.505887 |  0.792419 |
| transport_continuity_couple |   0.557607 |  0.50854  |  0.654928 |

## Winners by Target

| target                    | score                     |   auc_high |   auc_low |   auc_best |
|:--------------------------|:--------------------------|-----------:|----------:|-----------:|
| valid_rec_resid_identity  | coupled_product           |  0.174999  |  0.825001 |   0.825001 |
| valid_rec_resid_joint     | continuity                |  0.668674  |  0.331326 |   0.668674 |
| valid_rec_resid_transport | identity                  |  0.207117  |  0.792883 |   0.792883 |
| valid_recoverable         | identity_transport_couple |  0.0973685 |  0.902632 |   0.902632 |

## Decision

```text
single_feature_frontier_remains
```

## Interpretation
If coupled scores match or beat the best single feature across residual targets, the result is better described as a coupled recoverability stack than a strict causal ordering.
