# V1161 — Frozen Clean-Room Replication Harness

Run:

```bash
python v1161_frozen_clean_room_replication_harness.py
```

Outputs:

- v1161_clean_room_results.csv
- v1161_clean_room_calibration.csv
- v1161_clean_room_by_world_summary.csv
- v1161_clean_room_summary.json

Do not modify thresholds after seeing results.
