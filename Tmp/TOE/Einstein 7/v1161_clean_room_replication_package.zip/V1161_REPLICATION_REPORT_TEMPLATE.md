# V1161 — Clean-Room Replication Report Template

## Protocol

Frozen law:

```text
BufferedNormalizedOmegaCompatibility
AND GenesisPin
AND SourceFlowClosureEnvelope
AND CausalTransportSignatureEnvelope
```

Rules:

1. Use valid-only calibration.
2. Apply Ω stability buffer.
3. Do not tune after adversary generation.
4. Report failures directly.

## Required Results

```json
{
  "valid_rate": null,
  "invalid_rate": null,
  "invalid_certified_count": null,
  "false_negative_valid_count": null
}
```

## Failure Autopsy

If any error occurs, identify failed term:

```text
Ω
Genesis
Closure
CausalTransport
```
