#!/usr/bin/env python3
"""
V1161 — Frozen Clean-Room Replication Harness

Purpose:
    Replicate the V1160 admissible-geometry law without tuning.

Frozen law:
    AdmissibleGeometry :=
        BufferedNormalizedOmegaCompatibility
        AND GenesisPin
        AND SourceFlowClosureEnvelope
        AND CausalTransportSignatureEnvelope

Protocol:
    1. Generate valid calibration histories.
    2. Freeze thresholds using valid-only calibration.
    3. Generate valid + invalid test histories.
    4. Apply frozen law.
    5. Report valid_rate, invalid_rate, invalid_certified_count, false_negative_valid_count.
    6. Do not patch after seeing failures.

This script is intentionally compact and readable for clean-room replication.
"""

from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd

OUT = Path("v1161_clean_room_replication_outputs")
OUT.mkdir(exist_ok=True)

EPS = 1e-12
SEED = 1161
N = 192
T = 7
N_CAL = 48
N_OMEGA = 32
N_CASES = 12
BUFFER_FRACTION = 0.25

WORLDS = ["replica_diffusion", "replica_branching", "replica_wavepacket"]
MODES = ["valid", "bad_path", "bad_ledger", "bad_closure", "bad_omega"]


def z(x):
    x = np.asarray(x, float)
    return (x - x.mean()) / (x.std() + EPS)


def cosine(a, b):
    a = np.ravel(a)
    b = np.ravel(b)
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + EPS))


def corr(a, b):
    if np.std(a) < EPS or np.std(b) < EPS:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def closure_metrics(final, x):
    y = z(final["response"])
    X = np.c_[np.ones(len(y)), z(final["source"]), z(final["flow"])]
    beta = np.linalg.lstsq(X, y, rcond=None)[0]
    residual = float(np.sqrt(np.mean((y - X @ beta) ** 2)))
    source_alignment = corr(final["source"], y)
    flow_alignment = corr(final["flow"], np.gradient(final["response"], x))
    return residual, source_alignment, flow_alignment


def causal_signature(hist, x):
    sig = []
    for t in range(1, len(hist)):
        a = hist[t - 1]
        b = hist[t]
        ds = z(b["source"] - a["source"])
        df = z(b["flow"] - a["flow"])
        dr = z(b["response"] - a["response"])
        sig += [
            cosine(ds, df),
            cosine(ds, dr),
            cosine(df, dr),
            float(np.linalg.norm(b["source"] - a["source"]) / np.sqrt(len(ds))),
            float(np.linalg.norm(b["flow"] - a["flow"]) / np.sqrt(len(df))),
            float(np.linalg.norm(b["response"] - a["response"]) / np.sqrt(len(dr))),
        ]
    return np.array(sig, float)


def finalize(src, flow, response):
    omega = np.exp(-(-0.25 * src + 0.12 * flow))
    return omega


def world_replica_diffusion(seed, mode):
    r = np.random.default_rng(seed)
    x = np.linspace(0, 1, N)
    src0 = z(r.normal(size=N))
    ledger = True
    hist = []
    for t in range(T):
        tau = t / (T - 1)
        src = z(src0 + 0.16 * np.roll(src0, int(5 * tau)) + 0.025 * r.normal(size=N))
        flow = z(np.roll(src, 1) - 0.7 * src + 0.10 * np.convolve(src, np.ones(7) / 7, mode="same"))
        response = z(0.50 * src + 0.28 * flow + 0.22 * np.sin(2 * np.pi * x + tau))

        if mode == "bad_path":
            if 2 <= t <= 4:
                flow = z(np.roll(flow, N // 4))
            if t == T - 1:
                flow = z(np.roll(src, 1) - 0.7 * src + 0.10 * np.convolve(src, np.ones(7) / 7, mode="same"))
                response = z(0.50 * src + 0.28 * flow + 0.22 * np.sin(2 * np.pi * x + tau))
        elif mode == "bad_ledger":
            ledger = False
        elif mode == "bad_closure":
            response = z(response + 0.65 * r.normal(size=N))
        elif mode == "bad_omega":
            src = z(r.permutation(src))
            flow = z(r.permutation(flow))

        omega = finalize(src, flow, response)
        hist.append(dict(source=src, flow=flow, response=response, omega=omega))
    return hist, ledger, x


def world_replica_branching(seed, mode):
    r = np.random.default_rng(seed)
    x = np.linspace(-1, 1, N)
    centers = [-0.7, -0.25, 0.15, 0.55]
    src0 = z(sum(r.normal() * np.exp(-18 * (x - c) ** 2) for c in centers))
    ledger = True
    hist = []
    for t in range(T):
        tau = t / (T - 1)
        pulses = sum(np.exp(-30 * (x - (c + 0.08 * tau * np.sign(c + 0.01))) ** 2) for c in centers)
        src = z(0.55 * src0 + 0.45 * pulses + 0.025 * r.normal(size=N))
        flow = z(np.gradient(src, x) + 0.12 * pulses)
        response = z(0.44 * src + 0.30 * flow + 0.26 * pulses)

        if mode == "bad_path":
            if 1 <= t <= 5:
                src = z(np.roll(src, N // 7))
                flow = z(np.gradient(src, x) - 0.12 * pulses)
            if t == T - 1:
                src = z(0.55 * src0 + 0.45 * pulses)
                flow = z(np.gradient(src, x) + 0.12 * pulses)
                response = z(0.44 * src + 0.30 * flow + 0.26 * pulses)
        elif mode == "bad_ledger":
            ledger = False
        elif mode == "bad_closure":
            response = z(np.roll(response, N // 5))
        elif mode == "bad_omega":
            src = z(-src)
            flow = z(np.roll(flow, N // 4))

        omega = finalize(src, flow, response)
        hist.append(dict(source=src, flow=flow, response=response, omega=omega))
    return hist, ledger, x


def world_replica_wavepacket(seed, mode):
    r = np.random.default_rng(seed)
    x = np.linspace(0, 2 * np.pi, N, endpoint=False)
    phase = r.uniform(0, 2 * np.pi)
    ledger = True
    hist = []
    for t in range(T):
        tau = t / (T - 1)
        src = z(np.sin(2 * x + phase + 0.35 * tau) + 0.45 * np.sin(5 * x - phase + 0.15 * tau))
        flow = z(np.cos(2 * x + phase + 0.35 * tau) - 0.25 * np.cos(5 * x - phase + 0.15 * tau))
        response = z(0.52 * src + 0.25 * flow + 0.23 * np.sin(x + tau))

        if mode == "bad_path":
            if 2 <= t <= 4:
                flow = z(-flow)
            if t == T - 1:
                flow = z(np.cos(2 * x + phase + 0.35 * tau) - 0.25 * np.cos(5 * x - phase + 0.15 * tau))
                response = z(0.52 * src + 0.25 * flow + 0.23 * np.sin(x + tau))
        elif mode == "bad_ledger":
            ledger = False
        elif mode == "bad_closure":
            response = z(response + 0.55 * np.sin(11 * x))
        elif mode == "bad_omega":
            src = z(np.roll(src, N // 5))
            flow = z(np.roll(flow, N // 6))

        omega = finalize(src, flow, response)
        hist.append(dict(source=src, flow=flow, response=response, omega=omega))
    return hist, ledger, x


GENS = {
    "replica_diffusion": world_replica_diffusion,
    "replica_branching": world_replica_branching,
    "replica_wavepacket": world_replica_wavepacket,
}


def calibrate_world(gen, world_name):
    closures = []
    signatures = []

    for i in range(N_CAL):
        hist, _, x = gen(10000 + i, "valid")
        closures.append(closure_metrics(hist[-1], x))
        signatures.append(causal_signature(hist, x))

    closures = np.array(closures)
    signatures = np.array(signatures)
    center = signatures.mean(axis=0)
    dists = np.linalg.norm(signatures - center, axis=1)

    omega_pairs = []
    for i in range(N_OMEGA):
        ref, _, _ = gen(20000 + i, "valid")
        cand, _, _ = gen(21000 + i, "valid")
        omega_pairs.append(cosine(cand[-1]["omega"], ref[-1]["omega"]))
    omega_pairs = np.array(omega_pairs)

    omega_min = float(omega_pairs.min())
    omega_std = float(omega_pairs.std() + EPS)
    omega_thr = omega_min - BUFFER_FRACTION * omega_std

    return {
        "world": world_name,
        "B_like_threshold": float(closures[:, 0].max()),
        "source_alignment_min": float(closures[:, 1].min()),
        "flow_alignment_min": float(closures[:, 2].min()),
        "causal_signature_threshold": float(dists.max()),
        "omega_min_valid": omega_min,
        "omega_std_valid": omega_std,
        "omega_buffer_threshold": omega_thr,
        "signature_center": center,
    }


def certify(hist, ledger, x, ref_hist, calibration):
    final = hist[-1]
    ref_final = ref_hist[-1]
    residual, src_align, flow_align = closure_metrics(final, x)
    sig_distance = float(np.linalg.norm(causal_signature(hist, x) - calibration["signature_center"]))

    omega_similarity = cosine(final["omega"], ref_final["omega"])
    omega_margin = (omega_similarity - calibration["omega_buffer_threshold"]) / (calibration["omega_std_valid"] + EPS)

    omega_ok = omega_margin >= 0
    genesis_ok = bool(ledger)
    closure_ok = (
        residual <= calibration["B_like_threshold"]
        and src_align >= calibration["source_alignment_min"]
        and flow_align >= calibration["flow_alignment_min"]
    )
    causal_ok = sig_distance <= calibration["causal_signature_threshold"]

    return {
        "omega_similarity": omega_similarity,
        "omega_buffer_margin": omega_margin,
        "omega_certified": omega_ok,
        "genesis_pin_pass": genesis_ok,
        "B_like_rms": residual,
        "source_alignment": src_align,
        "flow_alignment": flow_align,
        "closure_certified": closure_ok,
        "causal_signature_distance": sig_distance,
        "causal_transport_certified": causal_ok,
        "law_certified": omega_ok and genesis_ok and closure_ok and causal_ok,
    }


def main():
    rows = []
    cal_rows = []

    for world, gen in GENS.items():
        cal = calibrate_world(gen, world)
        cal_public = {k: v for k, v in cal.items() if k != "signature_center"}
        cal_rows.append(cal_public)

        for case in range(N_CASES):
            ref_hist, _, _ = gen(30000 + case, "valid")
            for mode in MODES:
                hist, ledger, x = gen(40000 + case, mode)
                cert = certify(hist, ledger, x, ref_hist, cal)
                rows.append({
                    "world": world,
                    "case": case,
                    "mode": mode,
                    "expected_valid": mode == "valid",
                    **cert,
                })

    df = pd.DataFrame(rows)
    caldf = pd.DataFrame(cal_rows)

    overall = {
        "valid_rate": float(df[df.expected_valid].law_certified.mean()),
        "invalid_rate": float(df[~df.expected_valid].law_certified.mean()),
        "invalid_certified_count": int(df[(~df.expected_valid) & df.law_certified].shape[0]),
        "false_negative_valid_count": int(df[(df.expected_valid) & (~df.law_certified)].shape[0]),
    }

    by_world = df.groupby("world").apply(
        lambda g: pd.Series({
            "valid_rate": float(g[g.expected_valid].law_certified.mean()),
            "invalid_rate": float(g[~g.expected_valid].law_certified.mean()),
            "invalid_certified_count": int(g[(~g.expected_valid) & g.law_certified].shape[0]),
            "false_negative_valid_count": int(g[(g.expected_valid) & (~g.law_certified)].shape[0]),
        }),
        include_groups=False,
    ).reset_index()

    df.to_csv(OUT / "v1161_clean_room_results.csv", index=False)
    caldf.to_csv(OUT / "v1161_clean_room_calibration.csv", index=False)
    by_world.to_csv(OUT / "v1161_clean_room_by_world_summary.csv", index=False)

    summary = {
        "document_id": "V1161_FROZEN_CLEAN_ROOM_REPLICATION_HARNESS",
        "status": "completed",
        "protocol": "Frozen law, valid-only calibration, Ω stability buffer, no post-adversary retuning.",
        "law": "BufferedNormalizedOmegaCompatibility AND GenesisPin AND SourceFlowClosureEnvelope AND CausalTransportSignatureEnvelope",
        "overall_result": overall,
        "by_world": by_world.to_dict(orient="records"),
    }
    (OUT / "v1161_clean_room_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
