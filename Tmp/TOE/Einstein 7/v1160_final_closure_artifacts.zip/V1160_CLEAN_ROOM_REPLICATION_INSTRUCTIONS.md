# V1160 Clean-Room Replication Instructions

## Do not tune the law.

Use:

AdmissibleGeometry := BufferedNormalizedOmegaCompatibility AND GenesisPin AND SourceFlowClosureEnvelope AND CausalTransportSignatureEnvelope

## Required outputs

- valid_rate
- invalid_rate
- invalid_certified_count
- false_negative_valid_count
- failure term autopsy if nonzero errors

## Rules

1. Use valid-only calibration.
2. Do not inspect adversaries before freezing thresholds.
3. Apply Ω buffer: min(valid Ω margin) - 0.25 * std(valid Ω margin).
4. Report failures without patching.
5. Separate law failures from calibration failures.
