# V1413.4 — Corrected Invariance Closure

## Status
Completed.

## Purpose

Close V1413 after the leakage audit.

## Claim Boundary

Synthetic graph source-order/recoverability diagnostics only.

No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

---

# Decision

```text
corrected_invariance_not_independent_but_explanatory
```

## Milestone Evidence

| version   | test                            | result                                                                                    | numbers                                                            | meaning                                                                                   |
|:----------|:--------------------------------|:------------------------------------------------------------------------------------------|:-------------------------------------------------------------------|:------------------------------------------------------------------------------------------|
| V1413.0   | Relabel invariance              | Admissible transport survived graph relabeling.                                           | admissible AUC all≈0.9999; original≈0.9997; relabeled=1.0000.      | Strong apparent representation invariance.                                                |
| V1413.1   | Family + relabel subgroup audit | Admissible transport survived graph-family/relabel subgroup testing.                      | mean AUC≈0.9998; min AUC≈0.9994.                                   | Still strong under subgroup splitting.                                                    |
| V1413.2   | Leakage / tautology audit       | Near-perfect result was partly label-coupled.                                             | admissible AUC after source residualized against admissible≈0.578. | Cannot claim clean independent invariance.                                                |
| V1413.3   | Clean source residual test      | No candidate strongly predicted source-order residual after removing measured components. | best candidate identity AUC≈0.587.                                 | Admissible transport explains measured source-order components, not independent residual. |

---

# What Is Supported

```text
Admissible transport is invariant under graph relabeling for the constructed validity target.
Admissible transport explains a large portion of source-order preservation in this harness.
```

# What Is Not Supported

```text
A fully independent source-order residual law.
A non-leaky proof of admissible transport invariance.
```

---

# Corrected Scientific Statement

```text
Admissible transport robustly explains the constructed source-order signal,
but once source-order is residualized against measured candidate components,
no strong independent residual predictor remains.
```

This is still useful, but it is not the same as proving an independent primitive law.

---

# Current Best Stack

```text
admissible transport
→ source-order / recoverability components
→ continuity / scalar-continuity diagnostics
→ H-like and geometry-like summaries
```

with this caution:

```text
the source-order target partly contains the same structure measured by admissible transport
```

---

# Next Step

```text
V1414 — Hidden Source-Lineage Compression Test
```

Define validity using a target not algebraically built from:
- source_order
- transport
- identity
- continuity

Candidate:

```text
Can the original hidden source lineage be reconstructed after compression/pruning?
```

If admissible transport predicts that, it becomes much stronger.
