# Corrected Report-Out Draft

The latest audit corrected the source-order result.

Admissible transport remained extremely strong under relabeling and graph-family splits, but a leakage audit showed that the near-perfect result was partly label-coupled.

Correct statement:

Admissible transport robustly explains the constructed source-order signal in the synthetic graph harness. But when source-order is residualized against the measured candidate components, no strong independent residual predictor remains.

So the result is still meaningful, but it is not yet a clean independent law.

Next test: hidden source-lineage reconstruction after compression/pruning, using a target not built from source_order, transport, identity, or continuity.
