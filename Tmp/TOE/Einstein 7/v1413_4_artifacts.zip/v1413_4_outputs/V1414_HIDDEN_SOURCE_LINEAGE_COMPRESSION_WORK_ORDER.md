# V1414 Work Order — Hidden Source-Lineage Compression Test

## Goal

Define a new independent target that is not built from source_order, transport, identity, or continuity.

## Proposed Target

Hidden source-lineage reconstruction after compression/pruning.

## Design

1. Assign hidden source labels to nodes.
2. Generate graph histories under multiple update rules.
3. Compress/prune the final state.
4. Attempt to reconstruct hidden source lineage from retained state only.
5. Define validity by reconstruction accuracy.
6. Test whether admissible transport, identity, transport, or continuity predicts this target.

## Critical Rule

Do not use source_order, access current, transport score, identity score, or continuity score to define the target.

## Pass Condition

Admissible transport predicts hidden lineage reconstruction across graph families and relabeling.

## Fail Condition

No candidate predicts hidden lineage reconstruction, or performance collapses under relabeling.
