# V1406 Work Order — External Stress Test

## Frozen Stack

identity preservation
+ ordered propagation
+ Helmholtz-constrained current alignment
+ S_CH

where:

S_CH = z(H) + z(continuity)

## Goal

Stress-test the frozen stack under harsher and less constructed conditions.

## Tests

1. New field families:
   - vortices
   - filaments
   - multi-scale blobs
   - anisotropic ridges
   - sharp discontinuities
   - noisy sparse fields

2. New update rules:
   - advective
   - diffusive
   - rotational
   - mixed curl/divergence
   - stochastic jumps

3. Boundary conditions:
   - periodic
   - reflective
   - absorbing
   - clipped domain

4. Adversarial controls:
   - same H, wrong current alignment
   - same S_CH, wrong Helmholtz alignment
   - same geometry, wrong ordered propagation

## Decision Outcomes

A. Frozen stack survives.
B. S_CH must split back into H + continuity.
C. Geometry becomes semi-primitive.
D. New law candidate required.
