# V1405.4 — Irreducible Working Stack Freeze

## Status
Completed.

## Purpose

V1405 tested whether the stack could be compressed.

The answer is:

```text
Not to Helmholtz-only.
Yes to Helmholtz + scalar-continuity diagnostic.
```

## Claim Boundary

Synthetic recoverability diagnostics only.

No physical GR, Einstein equations, full ADM derivation, physical spacetime, or physical curvature is claimed.

---

# Frozen Minimal Working Stack

```text
identity preservation
+
ordered propagation
+
Helmholtz-constrained current alignment
+
scalar-continuity diagnostic S_CH
```

where:

```text
S_CH = z(H) + z(continuity)
```

---

# Milestone Summary

| version   | test                          | result                                                                                  | numbers                                                           | meaning                                                                     |
|:----------|:------------------------------|:----------------------------------------------------------------------------------------|:------------------------------------------------------------------|:----------------------------------------------------------------------------|
| V1405.0   | Compression baseline          | Helmholtz-only was strong but materially below full stack.                              | Helmholtz-only AUC≈0.916; full stack AUC≈0.9999.                  | Cannot compress to Helmholtz-only.                                          |
| V1405.1   | Downstream reconstruction     | Continuity and H were partially reconstructed from Helmholtz core; raw geometry weaker. | Continuity R²≈0.553; H R²≈0.347; geometry R²≈0.07–0.17.           | Continuity/H need retained diagnostic status.                               |
| V1405.2   | Semi-primitive layer decision | H gave most diagnostic lift over Helmholtz-only.                                        | Helmholtz+H AUC≈0.9982; Helmholtz+continuity+H AUC≈0.9998.        | H is essential; continuity helps close final gap.                           |
| V1405.3   | Scalar-continuity compression | H and continuity compressed into a single diagnostic S_CH.                              | Helmholtz+S_CH AUC≈0.999892; Helmholtz+H+continuity AUC≈0.999799. | One scalar-continuity diagnostic replaces separate H and continuity layers. |

---

# What Was Rejected

```text
Helmholtz-only stack
H as primitive scalar law
continuity as separate primitive law
geometry as primitive law
```

---

# What Was Preserved

```text
Helmholtz current alignment is the core propagation law candidate.
S_CH is the minimal semi-primitive diagnostic layer.
Geometry-like summaries remain downstream/diagnostic.
```

---

# Current Master Stack

```text
identity
+
ordered propagation
+
Helmholtz current alignment
+
S_CH

→ geometry-like summaries
```

This is the cleanest stack so far.

---

# Scientific Meaning

The model no longer supports:

```text
identity → H → transport
```

It now supports:

```text
identity + ordered propagation
→ Helmholtz current alignment
→ scalar-continuity diagnostic
→ geometry-like summaries
```

The scalar component survives, but compressed into:

```text
S_CH
```

not as an independent H-first law.

---

# Next Work

```text
V1406 — External Stress Test
```

Question:

```text
Does the frozen stack survive harsher unseen conditions?
```

Required tests:

```text
1. new density families
2. adversarial gauges
3. unseen update rules
4. higher noise
5. non-periodic boundary conditions
6. leave-family-out and leave-update-rule-out generalization
```

Pass condition:

```text
Helmholtz + S_CH remains near full-stack performance.
```

Fail condition:

```text
A new independent layer is required.
```
