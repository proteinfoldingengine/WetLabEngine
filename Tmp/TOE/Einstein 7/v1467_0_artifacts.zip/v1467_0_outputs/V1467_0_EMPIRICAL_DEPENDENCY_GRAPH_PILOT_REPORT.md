# V1467.0 — Empirical Dependency Graph Pilot

## Status
Completed.

## Dataset

```text
local Python stdlib import/dependency graph
largest connected component
nodes: 508
undirected edges: 1752
```

## Purpose
Test whether the direct geometry result survives on a non-designed local dependency/import graph.

## Results

```text
true mean native score: 0.03669175
max control mean native score: 0.03611693
control / true ratio: 0.98433386
source_destroyed / true ratio: 0.01403150
```

## Decision

```text
empirical_dependency_graph_pilot_not_closed
```

## By Family

```json
{
  "recoverability_direct": {
    "mean_native_score": 0.036691751995038,
    "max_native_score": 0.036691751995038,
    "mean_geodesic": 0.5849056601566394,
    "mean_curvature": 0.22128741754626755,
    "mean_continuity": 0.5924727965048797,
    "mean_source_correspondence": 0.47847306011398927
  },
  "source_destroyed_matched_amplitude": {
    "mean_native_score": 0.0005148403866389079,
    "max_native_score": 0.004798937781943869,
    "mean_geodesic": 0.677753014068306,
    "mean_curvature": 0.03554161814796311,
    "mean_continuity": 0.5924727965048797,
    "mean_source_correspondence": 0.03482120773653794
  },
  "closure_disrupted": {
    "mean_native_score": 0.01760952989587064,
    "max_native_score": 0.02243890394828708,
    "mean_geodesic": 0.5849056601566394,
    "mean_curvature": 0.22128741754626755,
    "mean_continuity": 0.7077754927413537,
    "mean_source_correspondence": 0.19222972394186488
  },
  "degree_only": {
    "mean_native_score": 0.036116934035526314,
    "max_native_score": 0.036116934035526314,
    "mean_geodesic": 0.9999999990476189,
    "mean_curvature": 0.1489820845726359,
    "mean_continuity": 0.24242467927833944,
    "mean_source_correspondence": 0.9999999999773984
  },
  "random_null": {
    "mean_native_score": 5.715580199240391e-05,
    "max_native_score": 0.0009672459131219447,
    "mean_geodesic": 0.060529324087897,
    "mean_curvature": 0.036804565458116334,
    "mean_continuity": 0.6951548597798928,
    "mean_source_correspondence": 0.03583249555388
  }
}
```

## Interpretation
This is a first empirical/semi-empirical pilot. It uses local dependency/import structure rather than a designed synthetic graph.
