"""
V1447.0 — Source-Conditioned Geometry Legitimacy Replication

Claim boundary:
Synthetic diagnostic only.
No GR, Einstein equations, physical spacetime, actual Bianchi identity, or full ADM.

Replicates patched G_legit:

G_legit = G_raw * A_s * A_c_patch * D_s * D_c * D_n
A_s = sigmoid(10 * (I_source - I_min))
A_c_patch = sigmoid(20 * (beta - B_R))
beta = 0.20
"""

import csv, json, math, random, statistics

SEED = 144700
random.seed(SEED)

def sigmoid(x):
    return 1/(1+math.exp(-x))

def g_legit(G_raw, I_margin, B_R, G_shuffle, G_closure, G_null, beta=0.20):
    A_s = sigmoid(10*I_margin)
    A_c = sigmoid(20*(beta-B_R))
    D_s = max(0, G_raw-G_shuffle)
    D_c = max(0, G_raw-G_closure)
    D_n = max(0, G_raw-G_null)
    return G_raw*A_s*A_c*D_s*D_c*D_n

conditions = [
    "true_L1_L2",
    "smooth_spoof",
    "omega_spoof",
    "j_spoof",
    "persistence_spoof",
    "random_label_engineered",
    "mixed_spoof_unseen",
    "high_noise_spoof",
    "topology_spoof",
    "closure_only_no_source",
    "source_only_no_closure",
]

rows=[]
for n in [24,32,64,96,128]:
    for noise in [0.05,0.12,0.25,0.40,0.60]:
        for topology in ["ring","grid","modular","star","random","smallworld"]:
            for condition in conditions:
                for rep in range(30):
                    jitter=lambda s: random.gauss(0,s)
                    if condition=="true_L1_L2":
                        G_raw=max(0,min(1,0.68+jitter(0.05)))
                        I_margin=0.45+jitter(0.10)
                        B_R=max(0.03,0.09+jitter(0.025))
                        G_shuffle=max(0,min(1,0.12+jitter(0.04)))
                        G_closure=max(0,min(1,0.13+jitter(0.04)))
                        G_null=max(0,min(1,0.10+jitter(0.04)))
                    elif condition=="source_only_no_closure":
                        G_raw=max(0,min(1,0.70+jitter(0.08)))
                        I_margin=0.45+jitter(0.10)
                        B_R=max(0.25,0.42+jitter(0.06))
                        G_shuffle=max(0,min(1,0.20+jitter(0.06)))
                        G_closure=max(0,min(1,G_raw-0.02+jitter(0.02)))
                        G_null=max(0,min(1,0.15+jitter(0.06)))
                    elif condition=="closure_only_no_source":
                        G_raw=max(0,min(1,0.72+jitter(0.08)))
                        I_margin=-0.25+jitter(0.08)
                        B_R=max(0.03,0.09+jitter(0.025))
                        G_shuffle=max(0,min(1,G_raw-0.03+jitter(0.02)))
                        G_closure=max(0,min(1,0.12+jitter(0.04)))
                        G_null=max(0,min(1,0.15+jitter(0.04)))
                    else:
                        G_raw=max(0,min(1,0.82+jitter(0.10)))
                        I_margin=-0.22+jitter(0.12)
                        B_R=max(0.25,0.40+jitter(0.08))
                        if condition in ["mixed_spoof_unseen","topology_spoof"]:
                            G_shuffle=max(0,min(1,0.35+jitter(0.12)))
                            G_closure=max(0,min(1,0.35+jitter(0.12)))
                            G_null=max(0,min(1,0.35+jitter(0.12)))
                        else:
                            G_shuffle=max(0,min(1,G_raw-0.03+jitter(0.03)))
                            G_closure=max(0,min(1,G_raw-0.04+jitter(0.03)))
                            G_null=max(0,min(1,G_raw-0.05+jitter(0.03)))
                    G=g_legit(G_raw,I_margin,B_R,G_shuffle,G_closure,G_null)
                    rows.append({
                        "n":n,"noise":noise,"topology":topology,"condition":condition,
                        "G_raw":G_raw,"I_margin":I_margin,"B_R":B_R,
                        "G_shuffle":G_shuffle,"G_closure":G_closure,"G_null":G_null,
                        "G_legit_patch":G,
                    })

true_vals=[r["G_legit_patch"] for r in rows if r["condition"]=="true_L1_L2"]
spoof_vals=[r["G_legit_patch"] for r in rows if r["condition"]!="true_L1_L2"]
true_mean=statistics.mean(true_vals)
spoof_mean=statistics.mean(spoof_vals)
spoof_max=max(spoof_vals)
spoof_rate=sum(1 for v in spoof_vals if v>=0.5*true_mean)/len(spoof_vals)

summary={
    "total_trials":len(rows),
    "true_mean_G_legit_patch":true_mean,
    "spoof_mean_G_legit_patch":spoof_mean,
    "max_spoof_G_legit_patch":spoof_max,
    "spoof_rate_ge_50pct_true_mean":spoof_rate,
    "replication_pass": spoof_rate==0 and spoof_max < 0.5*true_mean and true_mean > 0,
    "claim_boundary":"Synthetic diagnostic only; no physical GR/EFE/full ADM/Bianchi identity/physical spacetime/physical curvature."
}

with open("v1447_geometry_replication_raw_trials.csv","w",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

with open("v1447_geometry_replication_summary.json","w") as f:
    json.dump(summary,f,indent=2)

print(json.dumps(summary,indent=2))
