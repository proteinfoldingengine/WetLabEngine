# V1447 Source-Conditioned Geometry Legitimacy Replication Package

## Purpose

Replicate the patched synthetic geometry-legitimacy result:

```text
source-origin information
→ source admissibility
→ B-like closure admissibility
→ source-conditioned geometry legitimacy
```

## Run

```bash
python replicate_source_conditioned_geometry_legitimacy.py
```

## Outputs

```text
v1447_geometry_replication_raw_trials.csv
v1447_geometry_replication_summary.json
```

## Metric

```text
G_legit = G_raw · A_s · A_c_patch · D_s · D_c · D_n
```

where:

```text
A_s = sigmoid(10(I_source - I_min))
A_c_patch = sigmoid(20(β - B_R))
β = 0.20
```

## Expected result

Replication passes if:

```text
spoof_rate_ge_50pct_true_mean = 0
max_spoof_G_legit_patch < 0.5 * true_mean_G_legit_patch
true_mean_G_legit_patch > 0
```

## Claim boundaries

Do not interpret this as:

```text
physical geometry
GR
Einstein equations
physical spacetime
actual Bianchi identity
full ADM
```

This is a synthetic source-conditioned diagnostic only.
