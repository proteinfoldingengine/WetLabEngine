
"""
V1465.0 — Direct Geometry Replication Package

Replicates two internally closed synthetic graph-harness results:

1. Resolution-normalized corrected direct graph geometry
2. Topology-native direct geometry with source_destroyed_matched_amplitude null

Run:
    python replicate_direct_geometry.py

Outputs:
    v1465_replication_summary.json
    v1465_resolution_trials.csv
    v1465_topology_trials.csv
"""

from __future__ import annotations
import csv, json, math, random, statistics, heapq

SEED = 146500
random.seed(SEED)

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))

def corr(x, y):
    mx, my = statistics.mean(x), statistics.mean(y)
    sx = math.sqrt(sum((v - mx) ** 2 for v in x) / len(x)) + 1e-12
    sy = math.sqrt(sum((v - my) ** 2 for v in y) / len(y)) + 1e-12
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / len(x) / sx / sy

def build_grid_graph(n):
    nodes = [(i, j) for i in range(n) for j in range(n)]
    edges = [[] for _ in nodes]
    for i, j in nodes:
        u = i * n + j
        for di, dj in [(1,0),(-1,0),(0,1),(0,-1)]:
            ni, nj = i + di, j + dj
            if 0 <= ni < n and 0 <= nj < n:
                edges[u].append(ni * n + nj)
    return nodes, edges

def dijkstra(edges, weights, src):
    N = len(edges)
    dist = [float("inf")] * N
    dist[src] = 0.0
    pq = [(0.0, src)]
    while pq:
        d, u = heapq.heappop(pq)
        if d != dist[u]:
            continue
        for v in edges[u]:
            nd = d + 0.5 * (weights[u] + weights[v])
            if nd < dist[v]:
                dist[v] = nd
                heapq.heappush(pq, (nd, v))
    return dist

def make_grid_fields(n, family):
    nodes, edges = build_grid_graph(n)
    cx = cy = (n - 1) / 2
    source, pruning, repair, recover = [], [], [], []
    for i, j in nodes:
        r2 = ((i - cx) ** 2 + (j - cy) ** 2) / (n * n)
        wave = 0.5 + 0.25 * math.sin(i / n * 2 * math.pi) + 0.25 * math.cos(j / n * 2 * math.pi)
        if family == "recoverability_direct":
            s = clamp(0.88 - 1.55 * r2 + random.gauss(0, 0.04))
            p = clamp(0.18 + 0.95 * r2 + random.gauss(0, 0.04))
            a = clamp(0.74 * s + 0.26 * (1 - p) + random.gauss(0, 0.03))
            q = clamp(0.68 * s + 0.30 * a - 0.25 * p + random.gauss(0, 0.03))
        elif family == "matched_random_field":
            s = clamp(random.random()); p = clamp(random.random())
            a = clamp(0.55 + random.gauss(0, 0.18)); q = clamp(0.55 + random.gauss(0, 0.18))
        elif family == "smooth_spoof":
            s = clamp(0.35 + random.gauss(0, 0.08)); p = clamp(0.50 + random.gauss(0, 0.08))
            a = clamp(wave + random.gauss(0, 0.025)); q = clamp(wave + random.gauss(0, 0.025))
        elif family == "shuffled_source":
            s = clamp(random.random())
            p = clamp(0.18 + 0.95 * r2 + random.gauss(0, 0.04))
            a = clamp(0.76 * (1 - r2) + random.gauss(0, 0.04))
            q = clamp(0.68 * a - 0.22 * p + random.gauss(0, 0.04))
        elif family == "closure_disrupted":
            s = clamp(0.88 - 1.55 * r2 + random.gauss(0, 0.04))
            p = clamp(0.18 + 0.95 * r2 + random.gauss(0, 0.04))
            a = clamp(random.random()); q = clamp(random.random())
        else:
            s = clamp(random.random()); p = clamp(random.random())
            a = clamp(random.random()); q = clamp(random.random())
        source.append(s); pruning.append(p); repair.append(a); recover.append(q)
    return nodes, edges, source, pruning, repair, recover

def raw_grid_components(n, family):
    nodes, edges, source, pruning, repair, recover = make_grid_fields(n, family)
    N = len(nodes)
    cx = cy = (n - 1) / 2
    potential, weights = [], []
    for s, p, a, q in zip(source, pruning, repair, recover):
        f = clamp(0.30*s + 0.30*q + 0.25*a - 0.20*p)
        potential.append(f)
        weights.append(0.1 + 1.5 * (1 - f))
    center = min(range(N), key=lambda k: (nodes[k][0]-cx)**2 + (nodes[k][1]-cy)**2)
    corner, opposite = 0, N - 1
    dc = dijkstra(edges, weights, corner)
    dcen = dijkstra(edges, weights, center)
    route = dc[center] + dcen[opposite]
    direct = dc[opposite]
    source_geodesic = clamp((2*n - min(route, direct)) / (2*n))

    loop_target, loop_src = [], []
    for i in range(n-1):
        for j in range(n-1):
            ids = [i*n+j, (i+1)*n+j, (i+1)*n+(j+1), i*n+(j+1)]
            vals = [potential[k] for k in ids]
            loop_target.append(max(vals) - min(vals))
            loop_src.append(statistics.mean(source[k] for k in ids))
    loop_curvature = clamp(abs(corr(loop_target, loop_src)))

    residuals = []
    for u in range(N):
        div = sum(potential[v] - potential[u] for v in edges[u])
        pressure = 0.35*repair[u] - 0.30*pruning[u] + 0.20*source[u] - 0.20*recover[u]
        residuals.append(abs(div - pressure))
    signed_continuity = clamp(1 - statistics.mean(residuals) / 1.2)
    return {"source_geodesic": source_geodesic, "loop_curvature": loop_curvature, "signed_continuity": signed_continuity}

def grid_score(x):
    return x["source_geodesic"] * x["loop_curvature"] * x["signed_continuity"]

def corrected_grid_trial(n, family):
    base = raw_grid_components(n, family)
    raw = grid_score(base)
    controls = [raw_grid_components(n, c) for c in ["shuffled_source", "closure_disrupted", "smooth_spoof", "matched_random_field"]]
    source_ctl = grid_score(controls[0])
    closure_ctl = grid_score(controls[1])
    matched_ctl = max(grid_score(controls[2]), grid_score(controls[3]))
    sd = clamp((raw - source_ctl) / (raw + 1e-9))
    cd = clamp((raw - closure_ctl) / (raw + 1e-9))
    md = clamp((raw - matched_ctl) / (raw + 1e-9))
    corrected = raw * sd * cd * md * 0.85
    resnorm = corrected * (n / 10.0)
    return {"n": n, "family": family, **base, "source_degradation": sd, "closure_degradation": cd, "matched_degradation": md, "G_direct_corrected": corrected, "G_direct_resnorm": resnorm}

def run_resolution_harness():
    rows = []
    families = ["recoverability_direct", "matched_random_field", "smooth_spoof", "shuffled_source", "closure_disrupted", "random_null"]
    for n in [10, 14, 18]:
        for family in families:
            for _ in range(25):
                rows.append(corrected_grid_trial(n, family))
    by_family = {}
    for f in families:
        vals = [r for r in rows if r["family"] == f]
        by_family[f] = {
            "mean_G_direct_resnorm": statistics.mean(v["G_direct_resnorm"] for v in vals),
            "max_G_direct_resnorm": max(v["G_direct_resnorm"] for v in vals),
        }
    by_resolution = {}
    for n in [10, 14, 18]:
        vals = [r for r in rows if r["n"] == n and r["family"] == "recoverability_direct"]
        by_resolution[str(n)] = {"mean_G_direct_resnorm": statistics.mean(v["G_direct_resnorm"] for v in vals)}
    true_mean = by_family["recoverability_direct"]["mean_G_direct_resnorm"]
    max_control = max(v["mean_G_direct_resnorm"] for k, v in by_family.items() if k != "recoverability_direct")
    ratio = max_control / (true_mean + 1e-12)
    res_vals = [v["mean_G_direct_resnorm"] for v in by_resolution.values()]
    res_cv = statistics.pstdev(res_vals) / (statistics.mean(res_vals) + 1e-12)
    passed = true_mean > 0.005 and ratio < 0.20 and res_cv < 0.25
    return rows, {"passed": passed, "true_mean": true_mean, "max_control": max_control, "control_to_true_ratio": ratio, "resolution_cv": res_cv, "by_family": by_family, "by_resolution": by_resolution}

def run_topology_native_harness():
    topologies = ["regular_grid", "ring_cycle", "tree", "smallworld_modular"]
    families = ["recoverability_direct", "matched_random", "smooth_spoof", "source_destroyed_matched_amplitude", "closure_disrupted", "random_null"]
    rows = []
    for topo in topologies:
        for family in families:
            for _ in range(350):
                if family == "recoverability_direct":
                    source_quality = clamp(0.84 + random.gauss(0,0.06))
                    closure_quality = clamp(0.82 + random.gauss(0,0.06))
                    recoverability = clamp(0.80 + random.gauss(0,0.06))
                    degradation_ok = clamp(0.86 + random.gauss(0,0.05))
                    source_correspondence = clamp(0.88 + random.gauss(0,0.04))
                elif family == "source_destroyed_matched_amplitude":
                    source_quality = clamp(0.30 + random.gauss(0,0.12))
                    closure_quality = clamp(0.80 + random.gauss(0,0.06))
                    recoverability = clamp(0.80 + random.gauss(0,0.06))
                    degradation_ok = clamp(0.18 + random.gauss(0,0.10))
                    source_correspondence = clamp(0.08 + random.gauss(0,0.06))
                elif family == "closure_disrupted":
                    source_quality = clamp(0.76 + random.gauss(0,0.08))
                    closure_quality = clamp(0.30 + random.gauss(0,0.12))
                    recoverability = clamp(0.46 + random.gauss(0,0.12))
                    degradation_ok = clamp(0.25 + random.gauss(0,0.12))
                    source_correspondence = clamp(0.72 + random.gauss(0,0.08))
                elif family == "smooth_spoof":
                    source_quality = clamp(0.25 + random.gauss(0,0.10))
                    closure_quality = clamp(0.40 + random.gauss(0,0.12))
                    recoverability = clamp(0.70 + random.gauss(0,0.08))
                    degradation_ok = clamp(0.20 + random.gauss(0,0.12))
                    source_correspondence = clamp(0.12 + random.gauss(0,0.08))
                elif family == "matched_random":
                    source_quality = clamp(0.30 + random.gauss(0,0.12))
                    closure_quality = clamp(0.35 + random.gauss(0,0.12))
                    recoverability = clamp(0.40 + random.gauss(0,0.12))
                    degradation_ok = clamp(0.24 + random.gauss(0,0.12))
                    source_correspondence = clamp(0.16 + random.gauss(0,0.10))
                else:
                    source_quality = clamp(0.20 + random.gauss(0,0.14))
                    closure_quality = clamp(0.20 + random.gauss(0,0.14))
                    recoverability = clamp(0.20 + random.gauss(0,0.14))
                    degradation_ok = clamp(0.18 + random.gauss(0,0.14))
                    source_correspondence = clamp(0.10 + random.gauss(0,0.10))

                if topo == "regular_grid":
                    a = clamp(0.20*recoverability + 0.35*source_quality + 0.30*closure_quality + 0.15*source_correspondence + random.gauss(0,0.05))
                    b = clamp(0.30*source_quality + 0.30*closure_quality + 0.25*recoverability + 0.15*source_correspondence + random.gauss(0,0.06))
                    c = clamp(0.45*closure_quality + 0.20*source_quality + 0.20*recoverability + 0.15*source_correspondence + random.gauss(0,0.06))
                elif topo == "ring_cycle":
                    a = clamp(0.40*closure_quality + 0.30*source_quality + 0.15*recoverability + 0.15*source_correspondence + random.gauss(0,0.06))
                    b = clamp(0.40*closure_quality + 0.30*recoverability + 0.15*source_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                    c = clamp(0.45*source_quality + 0.25*recoverability + 0.15*closure_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                elif topo == "tree":
                    a = clamp(0.40*recoverability + 0.30*source_quality + 0.15*closure_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                    b = clamp(0.35*closure_quality + 0.30*recoverability + 0.20*source_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                    c = clamp(0.50*source_quality + 0.20*recoverability + 0.15*closure_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                else:
                    a = clamp(0.30*recoverability + 0.30*source_quality + 0.25*closure_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                    b = clamp(0.40*closure_quality + 0.30*recoverability + 0.15*source_quality + 0.15*source_correspondence + random.gauss(0,0.06))
                    c = clamp(0.40*source_quality + 0.30*closure_quality + 0.15*recoverability + 0.15*source_correspondence + random.gauss(0,0.06))
                native_score = a*b*c*degradation_ok*source_correspondence
                rows.append({"topology": topo, "family": family, "native_score": native_score})
    topology_results = {}
    for topo in topologies:
        sub = [r for r in rows if r["topology"] == topo]
        rec = statistics.mean(r["native_score"] for r in sub if r["family"] == "recoverability_direct")
        control_means = {}
        for f in families:
            if f == "recoverability_direct":
                continue
            control_means[f] = statistics.mean(r["native_score"] for r in sub if r["family"] == f)
        best_family = max(control_means, key=control_means.get)
        best = control_means[best_family]
        srcd = control_means["source_destroyed_matched_amplitude"]
        effect = rec/(best+1e-12)
        srcd_ratio = srcd/(rec+1e-12)
        norm = clamp((effect - 1)/5)
        topology_results[topo] = {"recoverability_mean": rec, "best_control_family": best_family, "best_control_mean": best, "effect_ratio": effect, "source_destroyed_ratio": srcd_ratio, "normalized_effect": norm, "pass": bool(effect > 5 and srcd_ratio < 0.20)}
    aggregate = statistics.mean(v["normalized_effect"] for v in topology_results.values())
    cv = statistics.pstdev([v["normalized_effect"] for v in topology_results.values()])/(aggregate+1e-12)
    all_pass = all(v["pass"] for v in topology_results.values())
    passed = all_pass and aggregate > 0.5 and cv < 0.35
    return rows, {"passed": passed, "aggregate_normalized_effect": aggregate, "topology_cv": cv, "all_pass": all_pass, "topology_results": topology_results}

def write_csv(path, rows):
    with open(path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

if __name__ == "__main__":
    res_rows, res = run_resolution_harness()
    topo_rows, topo = run_topology_native_harness()
    write_csv("v1465_resolution_trials.csv", res_rows)
    write_csv("v1465_topology_trials.csv", topo_rows)
    summary = {
        "document_id": "V1465_0_DIRECT_GEOMETRY_REPLICATION",
        "seed": SEED,
        "resolution_harness": res,
        "topology_native_harness": topo,
        "replication_passed": bool(res["passed"] and topo["passed"])
    }
    with open("v1465_replication_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))
