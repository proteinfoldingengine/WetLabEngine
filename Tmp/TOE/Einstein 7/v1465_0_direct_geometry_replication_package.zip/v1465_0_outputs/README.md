# V1465.0 Direct Geometry Replication Package

## Purpose

This package creates a standalone replication of the two closed internal direct-geometry harnesses:

1. `V1463.6` — resolution-normalized corrected direct graph geometry.
2. `V1464.6` — topology-native direct geometry with `source_destroyed_matched_amplitude` null.

## Run

```bash
python replicate_direct_geometry.py
```

## Outputs

```text
v1465_replication_summary.json
v1465_resolution_trials.csv
v1465_topology_trials.csv
```

## Pass Criteria

The package passes if:

```text
resolution_harness.passed == true
topology_native_harness.passed == true
replication_passed == true
```

## Scientific Meaning

This is a standalone synthetic graph-harness replication of direct geometry emergence from recoverability/source structure under hard controls.

## Still Needed

Independent rerun outside this chat/runtime.
