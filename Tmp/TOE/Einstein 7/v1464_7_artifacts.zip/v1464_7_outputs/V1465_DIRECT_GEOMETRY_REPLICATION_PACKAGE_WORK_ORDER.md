# V1465 Work Order — Direct Geometry Replication Package

## Goal
Create a standalone script that reproduces:
- V1463.6 resolution-normalized corrected direct graph result
- V1464.6 topology-native direct graph result

## Include
- README
- single Python script
- expected summary JSON
- CSV outputs
- strict claim boundaries
- no notebook dependency

## Pass
A fresh run reproduces both closures.
