# V1464.7 — Direct Geometry Branch Closure

## Status
Completed.

## Decision

```text
direct_geometry_branch_closed_in_synthetic_graph_harness
```

## Evidence

| version   | test                                                                        | decision                                            | key_result                                                                        | meaning                                                                              |
|:----------|:----------------------------------------------------------------------------|:----------------------------------------------------|:----------------------------------------------------------------------------------|:-------------------------------------------------------------------------------------|
| V1463.6   | Resolution-normalized corrected direct graph harness                        | resolution_normalized_direct_graph_geometry_emerges | true=0.07428001; control=0.00206499; ratio=0.027800; resolution_CV=0.055379       | Corrected direct graph geometry separated controls and stabilized across resolution. |
| V1464.0   | Direct topology generalization                                              | direct_topology_geometry_not_closed                 | true=0.00151653; control=0.00325940; ratio=2.149249; topology_CV=1.224360         | One-size-fits-all topology score failed.                                             |
| V1464.1   | Topology failure forensics                                                  | topology_failure_explained                          | lowest=ring; highest=smallworld; top_false_positive=shuffled_source on smallworld | Failure was topology-score bias plus contaminated shuffled-source control.           |
| V1464.4   | Source-shuffle contamination forensics                                      | source_shuffle_control_contamination_identified     | regular_grid=0.0688; smallworld_modular=0.0693                                    | Shuffled-source was low but preserved too much amplitude/closure structure.          |
| V1464.6   | Topology-native direct harness with source-destroyed matched-amplitude null | topology_native_direct_geometry_closed              | aggregate_effect=1.000000; topology_CV=0.000000; all_pass=True                    | Topology-native direct geometry closed under stricter source-destroyed null.         |

## What Is Supported

```text
The corrected direct graph harness separates recoverability-derived geometry from matched controls after removing trivial metrics.

Resolution normalization repaired the grid-resolution decay observed in the corrected graph harness.

A topology-native protocol repaired the failure caused by applying one geometry score across incompatible graph families.

The stricter source_destroyed_matched_amplitude null remained far below recoverability across all topology classes.

Topology-native direct geometry passed for regular grid, ring/cycle, tree, and smallworld/modular classes.
```

## What Is Not Yet Done

```text
Standalone external replication package for the direct topology-native harness.

A compact theorem/report integrating geometry-blind, direct graph, resolution, and topology-native results.

A single clean Python script that reproduces V1463.6 and V1464.6 from scratch.

Independent rerun by another agent/environment.
```

## Current Geometry Chain

```text
geometry-blind recoverability field
→ corrected direct graph geometry
→ resolution-normalized direct geometry
→ topology-native direct geometry
→ source-destroyed matched-amplitude null separation
```

## Report Threshold Status

```text
promising_internal_closure_not_external_report_ready
```

## Next

```text
V1465 — standalone replication package for direct geometry harness
```
