"""Independent immutable publication-byte readback, without science execution."""
import base64
import hashlib
import json
from pathlib import Path
import stat
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'uqcf-history-publish'
BASE = 'ResearchHistory/UQCF-GEM/research/physical-bridge/history_orientation/'
CONT = 'ResearchHistory/UQCF-GEM/research/physical-bridge/COUPLED_C3_NATIVE_RECORD_ORIGIN_CONTINUATION.md'

def parse(data):
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj: raise ValueError('duplicate key')
            obj[key] = value
        return obj
    def invalid(value): raise ValueError('nonfinite constant')
    return json.loads(data, object_pairs_hook=unique, parse_constant=invalid)

def identity(data):
    return {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest(),
        'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()}

def remote_bytes(record):
    obj = record['result']['structuredContent']
    if obj['encoding'] == 'base64': return base64.b64decode(''.join(obj['content'].split()),validate=True)
    assert obj['encoding'] == 'utf-8'
    return obj['content'].encode()

bundle = parse((OUT / 'immutable_connector_readback.json').read_bytes())
commit = bundle['commit']
assert commit['sha'] == '294d46a082ce624cd76af8e7b9a29beb26f1a9f3'
assert [p['sha'] for p in commit['parents']] == ['a42ca9e248c438081f31dcaba2ba5c6ffb36cec0']
assert commit['commit']['tree']['sha'] == '05136c24d80a8b469223f4c92430c48a85b50a4a'
assert commit['author']['login'] == commit['committer']['login'] == 'proteinfolding-gpt'
manifest_path = BASE+'EVIDENCE_MANIFEST.json'
manifest = parse((ROOT / manifest_path).read_bytes())
assert manifest['parent_commit'] == commit['parents'][0]['sha']
assert manifest['status'] == 'REVIEW_BLOCKED_HTTP429'
assert len(manifest['files']) == 29
expected = set(manifest['files']) | {manifest_path}
assert len(expected) == 30
comparison = bundle['comparison']
assert comparison['status'] == 'ahead' and comparison['ahead_by'] == comparison['total_commits'] == 1 and comparison['behind_by'] == 0
assert {f['filename'] for f in comparison['files']} == expected
assert {f['filename'] for f in comparison['files'] if f['status']=='modified'} == {CONT}
assert sum(f['status']=='added' for f in comparison['files']) == 29
assert {r['path'] for r in bundle['files']} == expected and len(bundle['files']) == 30
checked = []
for record in bundle['files']:
    name = record['path']
    data = remote_bytes(record)
    calculated = identity(data)
    assert calculated['git_blob'] == record['result']['structuredContent']['sha'], name
    assert data == (ROOT / name).read_bytes(), name
    if name != manifest_path: assert calculated == manifest['files'][name], name
    checked.append({'path':name, **calculated})
frozen = []
assert len(bundle['frozen_inputs']) == 14
for record in bundle['frozen_inputs']:
    name = record['path']
    data = remote_bytes(record)
    assert data == (OUT.parent / 'uqcf-history' / name).read_bytes(), name
    calculated = identity(data)
    assert calculated['git_blob'] == record['result']['structuredContent']['sha']
    frozen.append({'path':name, **calculated})
prior = parse((OUT / 'prior_continuation_readback.json').read_bytes())
prior_data = remote_bytes(prior)
current = (ROOT / CONT).read_bytes()
assert current.startswith(prior_data) and len(current) > len(prior_data)
assert prior_data == next(r for r in parse((OUT.parent / 'uqcf-history-audit/connector_readback.json').read_bytes())['files'] if r['path']==CONT)['result']['structuredContent']['content'].encode()
originals = []
for run, archives in [('38927190206',['history-integrity','history-review']), ('38927950314',['history-integrity-1','history-review-1'])]:
    pub = ROOT / BASE / 'evidence' / ('run-'+run)
    local = OUT.parent / 'uqcf-history-evidence' / run
    for filename in [n+'.zip' for n in archives]+['integrity.log','mathematical-review.log','run.json','jobs.json','artifacts.json']:
        data = (pub / filename).read_bytes()
        assert data == (local / filename).read_bytes()
        originals.append({'run_id':run,'filename':filename,**identity(data)})
    review = local / archives[1]
    for filename in ['infrastructure_failure.json','model_availability.json','provenance.json']:
        assert (pub / filename).read_bytes() == (review / filename).read_bytes()
audit_dir = OUT.parent / 'uqcf-history-audit'
with zipfile.ZipFile(ROOT / BASE / 'AUDIT_RAW.zip') as z:
    names = z.namelist()
    assert len(names)==len(set(names))
    assert set(names)=={p.name for p in audit_dir.iterdir() if p.is_file()}
    assert all(not stat.S_ISLNK(i.external_attr >> 16) for i in z.infolist())
    for name in names: assert z.read(name)==(audit_dir/name).read_bytes()
    m = parse(z.read('audit_file_manifest.json'))
    assert set(m)==set(names)-{'audit_file_manifest.json'}
    for name, entry in m.items():
        d=identity(z.read(name))
        assert entry=={k:d[k] for k in ('bytes','sha256')}
for name in ['PUBLICATION_AUDIT.md','PUBLICATION_AUDIT.json','failed_run_audit.json','retry_run_audit.json','retry_source_stage_audit.json','source_stage_audit.json']:
    assert (ROOT/BASE/name).read_bytes()==(audit_dir/name).read_bytes()
report = {'verdict':'PUBLICATION_INTEGRITY_PASS','evidence_commit':commit['sha'],'tree_sha':commit['commit']['tree']['sha'],
    'parent_commit':commit['parents'][0]['sha'],'author':commit['author']['login'],'committer':commit['committer']['login'],
    'changed_paths':30,'added_paths':29,'modified_paths':[CONT],'manifest_bound_files':29,'manifest_independently_verified':True,
    'binary_archives_verified':5,'original_actions_archives_preserved':4,'original_job_logs_preserved':4,'audit_raw_members_verified':len(names),
    'continuation_append_only':True,'continuation_original_bytes':len(prior_data),'continuation_append_bytes':len(current)-len(prior_data),
    'frozen_source_and_manifest_paths_unchanged':14,'scientific_review_status':'REVIEW_BLOCKED_HTTP429','gemini_acceptance':False,
    'native_milestone':'OPEN','no_science_execution':True,'external_writes_by_auditor':False,
    'scope':'Independent immutable publication and evidence-byte readback. Not mathematical acceptance, native-mechanism validation or numbered-stage closure.',
    'checked':sorted(checked,key=lambda x:x['path']),'frozen_inputs':sorted(frozen,key=lambda x:x['path']),'preserved_originals':originals}
(OUT/'FINAL_PUBLICATION_AUDIT.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print('PASS: all 30 immutable path bytes, 29 manifest entries plus manifest, 5 ZIPs, 14 frozen source paths, bot author/committer and append-only continuation. REVIEW_BLOCKED_HTTP429.')
