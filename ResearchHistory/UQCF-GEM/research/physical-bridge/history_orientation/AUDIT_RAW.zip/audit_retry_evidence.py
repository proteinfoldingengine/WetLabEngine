"""Independent byte audit only; never imports or runs a scientific module."""
import hashlib
import json
from pathlib import Path
import stat
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent / 'uqcf-history'
RUN = OUT.parent / 'uqcf-history-evidence/38927950314'
BASE = ROOT / 'ResearchHistory/UQCF-GEM/research/physical-bridge/history_orientation'

def strict(data):
    def unique(pairs):
        obj = {}
        for key, value in pairs:
            if key in obj:
                raise ValueError('duplicate key')
            obj[key] = value
        return obj
    def invalid(value):
        raise ValueError('nonfinite constant')
    return json.loads(data, object_pairs_hook=unique, parse_constant=invalid)

def digest(data):
    return hashlib.sha256(data).hexdigest()

meta = strict((OUT / 'retry_run_connector.json').read_bytes())
inputs = strict((BASE / 'input_manifest.json').read_bytes())
ident = {'contract_commit':'68fcd6d6118f7cb30bdca88814d1a5dc8260f0da',
    'run_attempt':'1', 'run_id':'38927950314',
    'scientific_sha':'a42ca9e248c438081f31dcaba2ba5c6ffb36cec0',
    'source_parent':'24dbac1a7da1a2484dd3d28f66c3b62c7ae632af',
    'workflow_sha':'a42ca9e248c438081f31dcaba2ba5c6ffb36cec0'}
report = {'status':'RETRY_FAILED_EVIDENCE_VERIFIED', **ident, 'artifacts':[],
    'jobs':{x['name']:x['conclusion'] for x in meta['jobs']}}
assert meta['run']['head_sha'] == ident['scientific_sha']
assert meta['run']['run_attempt'] == 1
assert len(meta['artifacts']) == 2
for art in meta['artifacts']:
    path = RUN / (art['name'] + '.zip')
    data = path.read_bytes()
    assert len(data) == art['size_in_bytes']
    assert 'sha256:' + digest(data) == art['digest']
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
        assert all(not stat.S_ISLNK(i.external_attr >> 16) for i in z.infolist())
        manifest = strict(z.read('file_manifest.json'))
        assert set(names) == set(manifest) | {'file_manifest.json'}
        for name, record in manifest.items():
            b = z.read(name)
            assert record == {'bytes':len(b),'sha256':digest(b)}
            assert b == (RUN / art['name'] / name).read_bytes()
        assert strict(z.read('provenance.json')) == ident
        if art['name'] == 'history-integrity-1':
            assert set(names) == {'file_manifest.json','input_manifest.json','integrity.json','provenance.json'} | {'snapshot/'+n for n in inputs}
            assert z.read('input_manifest.json') == (BASE / 'input_manifest.json').read_bytes()
            for name in inputs:
                assert z.read('snapshot/'+name) == (ROOT / name).read_bytes()
            assert strict(z.read('integrity.json')) == {'verified':True,'source_count':19,'inputs':inputs,'scope':'document identities only; no numerical science or inherited replay'}
        else:
            assert art['name'] == 'history-review-1'
            assert set(names) == {'file_manifest.json','model_availability.json','infrastructure_failure.json','prompt.txt','provenance.json'}
            prompt = (BASE / 'REVIEW_INSTRUCTIONS.txt').read_text() + '\nEXACT IDENTITY\n' + json.dumps(ident,sort_keys=True)
            for name in ('CONTRACT.md','RESULT.md'):
                prompt += '\n\nCURRENT DOCUMENT '+name+'\n'+(BASE / name).read_text()
            prompt += '\n\nPINNED FULL SOURCE PACKET\n'+(BASE / 'source_packet.json').read_text()
            assert z.read('prompt.txt') == prompt.encode()
            failure = strict(z.read('infrastructure_failure.json'))
            assert failure == {'error_type':'HTTPError','http_status':429,'status':'INFRASTRUCTURE_FAILURE_NOT_MATHEMATICAL_VERDICT'}
            report['failure'] = failure
            available = strict(z.read('model_availability.json'))
            assert available['name'] == 'models/gemini-3.1-pro-preview'
            assert 'generateContent' in available['supportedGenerationMethods']
        report['artifacts'].append({'id':art['id'],'name':art['name'],'bytes':len(data),'sha256':digest(data),'members':sorted(names)})
logs = strict((OUT / 'retry_run_logs_connector.json').read_bytes())
report['logs'] = []
for row in logs:
    name = {117064240851:'integrity',117064454683:'mathematical-review'}[row['job_id']]
    data = (RUN / (name+'.log')).read_bytes()
    assert data == row['result']['structuredContent']['content'].encode()
    report['logs'].append({'job_id':row['job_id'],'name':name,'bytes':len(data),'sha256':digest(data)})
report['interpretation'] = 'Second and final authorized attempt: source integrity succeeded; availability succeeded; generation failed HTTP 429; no response or mathematical verdict; publication skipped. REVIEW_BLOCKED; no further retries, native milestone OPEN.'
(OUT / 'retry_run_audit.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print('PASS: retry original archive digests, all members, snapshots, full prompt, identities and independently fetched logs; REVIEW_BLOCKED')
