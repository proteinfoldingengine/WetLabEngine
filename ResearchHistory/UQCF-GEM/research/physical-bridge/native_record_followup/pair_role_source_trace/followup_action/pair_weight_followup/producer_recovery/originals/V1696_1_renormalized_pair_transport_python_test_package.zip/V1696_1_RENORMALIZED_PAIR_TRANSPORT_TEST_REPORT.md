# V1696.1 — Renormalized Pair Transport Python Test

**Verdict:** `RENORMALIZED_PAIR_TRANSPORT_FAIL_NO_LAW_CLAIM`

```json
{
  "ladder_cases": 10,
  "action_reduction_rate": 0.0,
  "mean_I_RG": 0.622750798128829,
  "mean_energy_gap": 0.07400851958804704,
  "all_null_valid_beats_rate": 0.34,
  "scale_scramble_valid_beats_rate": 0.3,
  "aggregation_broken_valid_beats_rate": 0.4,
  "orientation_drop_valid_beats_rate": 0.0,
  "weight_shuffle_valid_beats_rate": 0.3,
  "nearest_cell_valid_beats_rate": 0.7
}
```
