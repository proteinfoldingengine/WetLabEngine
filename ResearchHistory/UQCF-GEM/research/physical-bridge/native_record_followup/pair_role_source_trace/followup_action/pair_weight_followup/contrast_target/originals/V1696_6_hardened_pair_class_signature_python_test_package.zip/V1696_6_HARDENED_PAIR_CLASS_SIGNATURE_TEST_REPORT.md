# V1696.6 — Hardened Pair-Class Signature Python Test

**Verdict:** `HARDENED_PAIR_CLASS_SIGNATURE_MIXED_NO_LAW_CLAIM`

```json
{
  "class_cases": 210,
  "action_reduction_rate": 0.0,
  "coarse_class_defined_rate": 1.0,
  "mean_class_distance": 0.5624734684524351,
  "mean_coherence_score": 0.6415704913808189,
  "all_null_valid_beats_rate": 0.8198412698412698,
  "D1D2_scramble_valid_beats_rate": 0.4857142857142857,
  "support_shuffle_valid_beats_rate": 0.8523809523809524,
  "order_scramble_valid_beats_rate": 0.9809523809523809,
  "role_vector_scramble_valid_beats_rate": 0.6,
  "orientation_flip_valid_beats_rate": 1.0,
  "class_broken_valid_beats_rate": 1.0
}
```
