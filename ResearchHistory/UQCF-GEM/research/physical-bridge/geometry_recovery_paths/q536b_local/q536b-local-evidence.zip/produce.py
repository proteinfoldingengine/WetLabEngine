"""Exhaust all class pairs by vectorized row updates at each ordered pair of actors."""
from collections import defaultdict
from hashlib import sha256
from pathlib import Path
import json
import time

import numpy as np

HERE = Path(__file__).resolve().parent
assert sha256((HERE / "check_geometry_repair.py").read_bytes()).hexdigest() == "4d9c4a2c9392acf02fb62fd07dadb996ecedfcb03c1a2aa95885e5777e195cfe"
import check_geometry_repair as fixture


def run():
    started = time.monotonic()
    features, _ = fixture.fixture()
    rows = [set(r) for r in fixture.initial_state(features)]
    rows[fixture.A].remove(fixture.T)
    n = len(rows)
    totals = [f[1] for f in features]
    for v in reversed(range(1, len(features))):
        totals[features[v][0]] += totals[v]
    squares = np.square(totals, dtype=np.int64)
    work = np.array(fixture.work_for(rows, squares))
    groups = defaultdict(list)
    for v, (parent, grade, support) in enumerate(features):
        key = v if v < 6 else (parent, grade, tuple(sorted(support)))
        groups[key].append(v)
    classes = list(groups.values())
    rep = np.array([g[0] for g in classes])
    size = np.array([len(g) for g in classes])
    weight = squares[rep]
    held = np.array([[v in row for row in rows] for v in rep])
    legal = []
    for i, row in enumerate(rows):
        active_parents = {features[v][0] for v in row}
        valid = []
        for t, group in enumerate(classes):
            v = group[0]
            assert all(all((w in rowj) == (v in rowj) for w in group) for rowj in rows)
            if v and v in row and v not in active_parents and held[t].sum() >= 2:
                # At depth one this fixture cannot unlock a new parent or a last-copy guard.
                # Check the fixed tree and populations before using the second-move domain.
                assert held[t].sum() >= 3
                assert features[v][0] == 0
                valid.append(t)
        legal.append(np.array(valid))
    delta = weight[:, None] * np.where(held, 1, -1)
    raw = [int(size[ids].sum()) for ids in legal]
    depth_one = []
    for i, ids in enumerate(legal):
        other = np.array([j for j in range(n) if j != i])
        off = work[np.ix_(other, other)].copy()
        np.fill_diagonal(off, np.iinfo(np.int64).max)
        level = off.min()
        wanted = 4 - (off == level).sum(axis=1)
        if (level != fixture.MU or np.any((wanted < 0) | (wanted > 1)) or wanted.sum() != 4):
            continue
        values = work[i, other] + delta[np.ix_(ids, other)]
        hits = np.all((values >= level) & ((values == level) == wanted), axis=1)
        depth_one.extend([i, int(rep[t])] for t in ids[hits])
    if depth_one != [[fixture.B, fixture.ULEAF]]:
        raise ValueError(f"Depth-one reproduction failed: {depth_one}")

    output = {"depth_one":depth_one, "depth_two":[], "free_only":[],
              "first_class_ids":[rep[ids].tolist() for ids in legal],
              "legal_raw":raw, "ordered_domain":[], "features":len(features),
              "classes":len(classes)}
    for i, xs in enumerate(legal):
        for j, ys in enumerate(legal):
            other = np.array([k for k in range(n) if k != i and k != j])
            off = work[np.ix_(other,other)].copy()
            np.fill_diagonal(off, np.iinfo(np.int64).max)
            # Every four-regular graph has an edge off the at-most-two edited rows.
            # That edge forces the minimum to equal the minimum of this untouched subtable.
            level = int(off.min())
            need = 4 - (off == level).sum(axis=1)
            shared = np.intersect1d(xs,ys)
            same_class = xs[:, None] == ys
            different_copies = ~same_class | (size[xs, None] >= 2)
            n_different = int(different_copies.sum())
            n_same = len(shared) if i != j else 0
            raw_count = raw[i]*raw[j] - (raw[i] if i == j else 0)
            output["ordered_domain"].append([i, j, n_different+n_same, raw_count])
            target = output["depth_two"] if level == fixture.MU else output["free_only"]

            def record(mask, same):
                for x, y in zip(*np.nonzero(mask)):
                    target.append([i, int(rep[xs[x]]), j, int(rep[ys[y]]), same])

            if i == j:
                if np.any((need < 0) | (need > 1)) or need.sum() != 4:
                    continue
                good = different_copies.copy()
                for k, must_tie in zip(other, need):
                    values = work[i,k] + delta[xs,k,None] + delta[ys,k]
                    good &= (values == level) if must_tie else (values > level)
                record(good, False)
                continue

            # Off-row degrees fix whether the two candidate rows must supply zero,
            # one, or two incident edges to each untouched view.
            if np.any((need < 0) | (need > 2)):
                continue
            bits = 1 << np.arange(len(other), dtype=np.int64)
            one = int(bits[need == 1].sum())
            two = int(bits[need == 2].sum())

            def row_stats(actor, ids):
                values = work[actor,other] + delta[np.ix_(ids,other)]
                equal = values == level
                return equal @ bits, equal.sum(axis=1), (values >= level).all(axis=1)

            mask_i, degree_i, valid_i = row_stats(i, xs)
            mask_j, degree_j, valid_j = row_stats(j, ys)
            valid = valid_i[:,None] & valid_j
            valid &= (mask_i[:,None] ^ mask_j) == one
            valid &= (mask_i[:,None] & mask_j) == two
            joint = work[i,j] + delta[xs,j,None] + delta[ys,i]

            def admitted(shared_work):
                tie = shared_work == level
                return ((shared_work >= level) & (degree_i[:,None] + tie == 4)
                        & (degree_j + tie == 4))

            record(valid & different_copies & admitted(joint), False)
            # For two edits of the very same feature the second editor now sees
            # the first editor lacking it. The two changes to their pair cancel.
            record(valid & same_class & admitted(joint - 2*weight[xs,None]), True)
        print(f"first actor {i} complete", flush=True)
    output["elapsed_seconds"] = round(time.monotonic()-started, 3)
    (HERE/"PRODUCTION.json").write_text(json.dumps(output, separators=(",",":")) + "\n")


if __name__ == "__main__":
    run()
