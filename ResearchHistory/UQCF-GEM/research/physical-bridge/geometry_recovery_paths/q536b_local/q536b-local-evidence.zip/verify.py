"""Independent cut-based search, with necessary-condition pruning on the second editor."""
from collections import Counter, defaultdict
from hashlib import sha256
from itertools import combinations
import json
from pathlib import Path
import random
import time

HERE = Path(__file__).resolve().parent
assert sha256((HERE / "check_geometry_repair.py").read_bytes()).hexdigest() == "4d9c4a2c9392acf02fb62fd07dadb996ecedfcb03c1a2aa95885e5777e195cfe"
import check_geometry_repair as fixture


def work_from_columns(columns, weights, n):
    """Each cut contributes its weight to every unordered pair crossing it."""
    work = [[0]*n for _ in range(n)]
    merged = Counter()
    for holders, weight in zip(columns, weights):
        merged[holders] += weight
    universe = set(range(n))
    for holders, weight in merged.items():
        missing = universe - holders
        for i in holders:
            for j in missing:
                work[i][j] += weight
                work[j][i] += weight
    return work


def prune(work, columns, weights, actor, vertex):
    """Update only the differences between the old cut and the new cut."""
    old = columns[vertex]
    new = old - {actor}
    assert actor in old
    for k in range(len(work)):
        if k != actor:
            old_cross = (actor in old) != (k in old)
            new_cross = (actor in new) != (k in new)
            work[actor][k] += (new_cross - old_cross)*weights[vertex]
            work[k][actor] = work[actor][k]
    columns[vertex] = new


def degree_gate(work):
    pairs = list(combinations(range(len(work)), 2))
    level = min(work[i][j] for i, j in pairs)
    degree = Counter(k for i,j in pairs if work[i][j] == level for k in (i,j))
    return all(degree[i] == 4 for i in range(len(work))), level


def run():
    started = time.monotonic()
    features, _ = fixture.fixture()
    n = len(fixture.LABELS)
    labels = list(range(n))
    children = defaultdict(list)
    for v, (p, _, _) in enumerate(features):
        children[p].append(v)

    def subtree(v):
        return features[v][1] + sum(subtree(w) for w in children[v])

    weights = [subtree(v)**2 for v in range(len(features))]
    columns = [frozenset(f[2]) for f in features]
    columns[fixture.T] -= {fixture.A}
    initial_work = work_from_columns(columns, weights, n)
    by_key = defaultdict(list)
    for v, (p,g,holding) in enumerate(features):
        key = (v,) if v < 6 else (p,g,frozenset(holding))
        by_key[key].append(v)
    groups = {min(group): group for group in by_key.values()}
    class_of = {v: c for c, group in groups.items() for v in group}

    def legal(cols, i, v):
        return (v > 0 and i in cols[v] and len(cols[v]) > 1
                and all(i not in cols[w] for w in children[v]))

    raw_choices = [[v for v in range(len(features)) if legal(columns, i, v)] for i in labels]
    first_classes = [sorted({class_of[v] for v in row}) for row in raw_choices]
    output = {"depth_one":[], "depth_two":[], "free_only":[], "legal_raw":list(map(len,raw_choices)),
              "first_class_ids":first_classes, "ordered_domain":[], "negative_samples":[]}
    pairs = list(combinations(labels, 2))
    # A four-regular endpoint must contain an edge outside both editors. Thus its
    # minimum is the exact minimum on their fixed complement, recomputed for each pair.
    fixed_min = {(i,j): min(initial_work[k][l] for k,l in pairs
                             if i not in (k,l) and j not in (k,l))
                 for i in labels for j in labels}
    for i, firsts in enumerate(first_classes):
        # For different classes only deleting a child could newly legalize its parent.
        # Independently check the domain of every legal first feature in this fixture.
        assert all(features[v][0] == 0 for v in raw_choices[i])
        domain = [[0,0] for _ in labels]
        for x in firsts:
            group = groups[x]
            cols = columns.copy()
            work = [row.copy() for row in initial_work]
            prune(work, cols, weights, i, x)
            if degree_gate(work) == (True,fixture.MU):
                output["depth_one"].append([i,x])
            for j in labels:
                # Reconstruct both current support orbits of the first class, including
                # its remaining undeleted copies. Other features keep their original legality.
                base = legal(columns, j, x)
                edited_orbit = legal(cols, j, x)
                other_orbit = len(group) > 1 and legal(cols, j, group[1])
                domain[j][0] += len(first_classes[j]) - base + edited_orbit + other_orbit
                domain[j][1] += (len(raw_choices[j]) - base*len(group) + edited_orbit
                                 + other_orbit*(len(group)-1))*len(group)
                level = fixed_min[i,j]
                # Only edges touching j can change. Evaluate every off-j defect via the
                # post-first graph; each deficient vertex can gain at most the edge to j.
                bad = any(work[i][k] < level for k in labels if k not in (i,j)) if i != j else False
                if bad:
                    continue
                required = []
                possible = True
                for k in labels:
                    if k == j:
                        continue
                    count = sum(w == level for v,w in enumerate(work[k]) if v != j and v != k)
                    if count < 3 or count > 4:
                        possible = False
                        break
                    if count == 3:
                        required.append(k)
                if not possible or len(required) != 4:
                    continue
                sizes = {abs(work[j][k]-level) for k in required}
                if len(sizes) != 1 or 0 in sizes:
                    continue
                weight, = sizes
                candidates = [v for v in raw_choices[j] if weights[v] == weight and legal(cols,j,v)]
                seen = set()
                for y in candidates:
                    code = (class_of[y], y == x)
                    if code in seen:
                        continue
                    seen.add(code)
                    final_work = [row.copy() for row in work]
                    final_cols = cols.copy()
                    prune(final_work, final_cols, weights, j, y)
                    regular, final_level = degree_gate(final_work)
                    if regular:
                        assert work_from_columns(final_cols, weights, n) == final_work
                        record = [i,x,j,class_of[y],y==x]
                        output["depth_two" if final_level == fixture.MU else "free_only"].append(record)
        output["ordered_domain"].extend([i,j,*domain[j]] for j in labels)
        print(f"first actor {i} complete", flush=True)
    # Full independent column rebuild for every one-edit recovery as well.
    for i,x in output["depth_one"]:
        cols = columns.copy()
        cols[x] -= {i}
        assert degree_gate(work_from_columns(cols, weights, n)) == (True,fixture.MU)
    rng = random.Random(536)
    all_moves = [(i,v) for i in labels for v in raw_choices[i]]
    while len(output["negative_samples"]) < 200:
        i,x = rng.choice(all_moves)
        j,y = rng.choice(all_moves)
        cols = columns.copy()
        work = [row.copy() for row in initial_work]
        prune(work, cols, weights, i, x)
        if not legal(cols,j,y):
            continue
        prune(work, cols, weights, j, y)
        rebuilt = work_from_columns(cols, weights, n)
        assert rebuilt == work
        result, level = degree_gate(rebuilt)
        if not result:
            output["negative_samples"].append([i,x,j,y,level])
    output["elapsed_seconds"] = round(time.monotonic()-started, 3)
    (HERE/"VERIFIER.json").write_text(json.dumps(output,separators=(",",":"))+"\n")


if __name__ == "__main__":
    run()
