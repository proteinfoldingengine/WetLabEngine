"""Run the frozen local verification within the declared CPU, disk, memory and time limits."""
from pathlib import Path
import json
import os
import platform
import subprocess
import sys
import time
import psutil
import numpy

HERE = Path(__file__).resolve().parent

def main():
    env = dict(os.environ, OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1", OMP_NUM_THREADS="1",
               PYTHONDONTWRITEBYTECODE="1")
    core_set = sorted(os.sched_getaffinity(0))[:8]
    os.sched_setaffinity(0,core_set)
    stats = {}
    total_start = time.monotonic()
    for step, budget, log in (("produce",3600,"production"), ("verify",5400,"verifier"),
                               ("engine_checks",5400,"engine"), ("reconcile",5400,"controls")):
        stamp = time.monotonic()
        peak = 0
        peak_disk = 0
        with (HERE/(log+".log")).open("w") as handle:
            proc = subprocess.Popen([sys.executable,"-u",step+".py"],cwd=HERE,env=env,
                                    stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
            while proc.poll() is None:
                try:
                    tree = [psutil.Process(proc.pid)] + psutil.Process(proc.pid).children(recursive=True)
                    rss = sum(p.memory_info().rss for p in tree if p.is_running())
                except psutil.NoSuchProcess:
                    continue
                peak = max(peak,rss)
                disk = sum(p.stat().st_size for p in HERE.rglob("*") if p.is_file())
                peak_disk = max(peak_disk,disk)
                if (time.monotonic()-stamp > budget or time.monotonic()-total_start > 5400 or
                        rss > 1_500_000_000 or disk > 200_000_000):
                    os.killpg(proc.pid,15)
                    proc.wait()
                    raise RuntimeError(f"Resource limit reached during {step}")
                time.sleep(0.1)
        if proc.returncode:
            raise RuntimeError(f"{step} failed; see {log}.log")
        stats[step] = {"elapsed_seconds":round(time.monotonic()-stamp,3),"sampled_peak_tree_rss_bytes":peak,
                       "sampled_peak_disk_bytes":peak_disk}
    stats.update(python=sys.version.split()[0],numpy=numpy.__version__,psutil=psutil.__version__,
                 platform=platform.platform(),available_worker_cpus=len(core_set),
                 total_seconds=round(time.monotonic()-total_start,3))
    (HERE/"RESOURCES.json").write_text(json.dumps(stats,indent=2,sort_keys=True)+"\n")
    print("All local stages passed.",flush=True)


if __name__ == "__main__":
    main()
