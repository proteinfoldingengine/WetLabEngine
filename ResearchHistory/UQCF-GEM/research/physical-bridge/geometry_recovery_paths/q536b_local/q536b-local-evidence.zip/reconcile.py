"""Compare both exact results and exercise rejecting controls on their records."""
from collections import Counter
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import check_geometry_repair as fixture
import verify

HERE = Path(__file__).resolve().parent
def read(name):
    return json.loads((HERE/name).read_bytes())

def write(name, data):
    (HERE/name).write_text(json.dumps(data,indent=2,sort_keys=True)+"\n")

def compare(candidate, reference):
    for field in ("depth_one","depth_two","free_only","first_class_ids","legal_raw","ordered_domain"):
        if field in ("depth_one","depth_two","free_only"):
            left, right = map(sorted,(candidate[field],reference[field]))
        else:
            left, right = candidate[field], reference[field]
        if left != right:
            raise ValueError(field)
    for k in ("depth_one","depth_two","free_only"):
        if any(n != 1 for n in Counter(map(tuple, candidate[k])).values()):
            raise ValueError("duplicate "+k)

def main():
    p, v, engine = read("PRODUCTION.json"), read("VERIFIER.json"), read("ENGINE.json")
    compare(p,v)
    features, _ = fixture.fixture()
    rows = list(map(set,fixture.initial_state(features)))
    subtotals = [f[1] for f in features]
    for vertex in reversed(range(1,len(features))):
        subtotals[features[vertex][0]] += subtotals[vertex]
    squares = [x*x for x in subtotals]
    initial = fixture.work_for(rows,squares)
    assert verify.degree_gate(initial) == (True,fixture.MU)
    changed = [list(row) for row in initial]
    a,b = fixture.edges(initial)[1][0]
    changed[a][b] += 1
    changed[b][a] += 1
    assert verify.degree_gate(changed) != (True,fixture.MU)
    rows[fixture.A].remove(fixture.T)
    after = fixture.work_for(rows,squares)
    assert verify.degree_gate(after) != (True,fixture.MU)
    cols = [set(f[2]) for f in features]
    cols[fixture.T].remove(fixture.A)
    # Third coverage calculation, using the initial column counts from the frozen fixture.
    counts = Counter()
    for vertex, holders in enumerate(cols):
        if vertex and len(holders) >= 2:
            counts.update(holders - {fixture.A} if vertex == fixture.R else holders)
    assert p["legal_raw"] == [counts[i] for i in range(25)] and sum(counts.values()) == 32575
    checks = {}
    def reject(label, candidate, ref):
        try:
            compare(candidate,ref)
        except ValueError as exc:
            checks[label] = str(exc)
        else:
            raise AssertionError(label)
    for field, baseline in (("depth_one",v),("depth_two",dict(v,depth_two=[[0,1,12,2,False]]))):
        # The two-edit actual production set is empty. A known two-atom recovery
        # starting one state earlier gives a positive record to test the same comparator.
        if field == "depth_two":
            plus_b = [row.copy() for row in rows]
            plus_b[12].remove(2)
            assert verify.degree_gate(fixture.work_for(plus_b,squares)) == (True,fixture.MU)
        for name in ("missing","duplicated","substituted"):
            mutant = deepcopy(baseline)
            if name == "missing":
                mutant[field].pop()
            elif name == "duplicated":
                mutant[field].append(mutant[field][0])
            else:
                mutant[field][0][0] = 1
            reject(field+"_"+name,mutant,baseline)
    for field, update in (("legal_raw",lambda m: m.__setitem__(0,m[0]-1)),
                          ("first_class_ids",lambda m: m[0].pop()),
                          ("ordered_domain",lambda m: m[0].__setitem__(3,m[0][3]-1))):
        mutant = deepcopy(v)
        update(mutant[field])
        reject("false_coverage_"+field,mutant,v)
    assert p["depth_one"] == [[12,2]] and len(v["negative_samples"]) == 200
    engine_counts = Counter(r[0] for r in engine["checks"])
    assert engine_counts == {"source":1,"illegal":5,"depth_one":300,"depth_two":300}
    assert all(r[3] == (r[0] != "illegal") for r in engine["checks"])
    by_class = {}
    for vertex,(parent,grade,support) in enumerate(features):
        key = vertex if vertex < 6 else (parent,grade,frozenset(support))
        by_class.setdefault(key,[]).append(vertex)
    members = {g[0]:g for g in by_class.values()}
    class_of = {v:c for c,group in members.items() for v in group}
    def state_for(record):
        i,x,j,y,same = record
        second = members[y][1] if x == y and not same else y
        end = [s.copy() for s in rows]
        end[i].remove(x)
        end[j].remove(second)
        canonical = tuple(sorted((class_of[v],tuple(k for k,s in enumerate(end) if v in s))
                                 for v in range(len(features))))
        return end,canonical
    fixed = [s.copy() for s in rows]
    fixed[12].remove(2)
    fixed_edges = fixture.edges(fixture.work_for(fixed,squares))[1]
    diagnostic = []
    for rec in p["depth_two"]:
        end,key = state_for(rec)
        i,x,j,y,_ = rec
        end_work = fixture.work_for(end,squares)
        diagnostic.append({"record":rec, "includes_B_U":(12,2) in ((i,x),(j,y)),
            "first_actor_work_restored":end_work[i] == after[i],
            "edges_match_one_edit":fixture.edges(end_work)[1] == fixed_edges})
    result = []
    for i in range(25):
        firsts = {r[1] for r in p["depth_one"] + p["depth_two"] if r[0] == i}
        one = [r for r in p["depth_one"] if r[0]==i]
        result.append({"view":i,"legal_raw":p["legal_raw"][i],"legal_classes":len(p["first_class_ids"][i]),
            "recovers":bool(firsts),"min_depth":1 if one else (2 if firsts else None),
            "N_raw":sum(len(members[x]) for x in firsts), "N_class":len(firsts),
            "recovering_first_classes":sorted(firsts),"depth_two_completions":[r for r in p["depth_two"] if r[0]==i]})
    write("RESULTS.json",{"per_view":result, "raw_ordered_paths":sum(d[3] for d in p["ordered_domain"]),
        "class_ordered_paths":sum(d[2] for d in p["ordered_domain"]),
        "free_only_unique_endpoints":len({state_for(r)[1] for r in p["free_only"]}),
        "depth_two_diagnostics":diagnostic,"class_representative":"least raw feature index"})
    write("VERIFY.json",{"exact_record_and_per_view_domain_comparisons":"PASS",
        "checked_negative_full_rebuilds":200,"free_only":v["free_only"],"depth_two":v["depth_two"],"depth_one":v["depth_one"],
        "verifier_sha256":sha256((HERE/"VERIFIER.json").read_bytes()).hexdigest()})
    write("CONTROLS.json",{"C1_engine_illegal":engine["checks"][1:6],
        "C2_initial_and_raised_minimum_and_source_checks":"PASS","C3_C4_rejections":checks,
        "C5_one_edit":p["depth_one"],"engine_sample_counts":engine_counts})
    print("Exact output comparison and all rejecting controls passed.")

if __name__ == "__main__":
    main()
