"""Compare the candidate legality rule to the unmodified v16.26 atom."""
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor
from hashlib import sha1, sha256
import json
from pathlib import Path
import random
import time

HERE = Path(__file__).resolve().parent
source_bytes = (HERE / "check_geometry_repair.py").read_bytes()
assert sha256(source_bytes).hexdigest() == "4d9c4a2c9392acf02fb62fd07dadb996ecedfcb03c1a2aa95885e5777e195cfe"
engine_bytes = (HERE / "engine.py").read_bytes()
assert sha1(f"blob {len(engine_bytes)}\0".encode() + engine_bytes).hexdigest() == "c10ac57f988a439144e21898bd2b33ece0838a9b"

import check_geometry_repair as fixture
import engine

features, _ = fixture.fixture()
parents = tuple(f[0] for f in features)
initial = fixture.initial_state(features)
children = defaultdict(set)
for feature, parent in enumerate(parents):
    children[parent].add(feature)
source = (fixture.A, fixture.T)


def remove(rows, move):
    actor, feature = move
    return rows[:actor] + (tuple(v for v in rows[actor] if v != feature),) + rows[actor + 1:]


start_state = remove(initial, source)
start_sets = tuple(map(frozenset, start_state))


def legal(rows, move):
    actor, v = move
    return (v != 0 and v in rows[actor] and children[v].isdisjoint(rows[actor])
            and any(k != actor and v in row for k, row in enumerate(rows)))


def check(case):
    kind, first, move = case
    state = initial if kind == "source" else start_state
    if first is not None:
        state = remove(state, first)
    expected = legal(tuple(map(frozenset, state)), move)
    try:
        after = engine.atomic(parents, state, *move)["after"]
    except ValueError as exc:
        assert not expected, (case, str(exc))
        return [kind, first, move, False, str(exc)]
    assert expected and tuple(map(tuple, after)) == remove(state, move)
    return [kind, first, move, True, "accepted"]


def cases():
    groups = defaultdict(list)
    for v, (parent, grade, support) in enumerate(features):
        key = v if v < 6 else (parent, grade, tuple(sorted(support)))
        groups[key].append(v)
    firsts = [(i, members[0]) for i in range(25) for members in groups.values()
              if legal(start_sets, (i, members[0]))]
    rng = random.Random(536)
    yield ("source", None, source)
    for move in [(0, 3), (0, 4), (0, 0), (0, 2), (0, 1)]:
        yield ("illegal", None, move)
    for move in rng.sample(firsts, 300):
        yield ("depth_one", None, move)
    for _ in range(300):
        first = rng.choice(firsts)
        state = tuple(map(frozenset, remove(start_state, first)))
        # At depth two, the first copy is distinguishable from other equivalent copies.
        members = next(group for group in groups.values() if group[0] == first[1])
        extra = [(i, members[1]) for i in range(25)] if len(members) > 1 else []
        while True:
            move = rng.choice(firsts + extra)
            if legal(state, move):
                break
        yield ("depth_two", first, move)


if __name__ == "__main__":
    started = time.monotonic()
    with ProcessPoolExecutor(max_workers=4) as pool:
        records = []
        for index, record in enumerate(pool.map(check, cases(), chunksize=2), 1):
            records.append(record)
            if index % 50 == 0:
                print(f"{index} atom comparisons complete", flush=True)
    assert len(records) == 606
    assert [r[-1] for r in records if r[0] == "illegal"] == ["non-leaf", "same union", "leaf", "leaf", "leaf"]
    result = {"checks": records, "elapsed_seconds": round(time.monotonic() - started, 3)}
    (HERE / "ENGINE.json").write_text(json.dumps(result, indent=1) + "\n")
    print("All source, legal, and rejecting checks passed.", flush=True)
